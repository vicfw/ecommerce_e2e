// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/reducedMotion.mjs
var defaultStyles = {
  transition: "none"
};
function resolveReducedMotionStyles(reducedMotion, styles) {
  if (reducedMotion === "always") {
    return styles;
  }
  if (reducedMotion === "system") {
    return {
      "@media (prefers-reduced-motion: reduce)": styles
    };
  }
  return null;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/transitions/utils.mjs
var reflow = (node) => node.scrollTop;
var DEFAULT_TRANSLATE_OFFSET = {
  offsetX: 0,
  offsetY: 0
};
var EMPTY_STYLE = {};
var DEFAULT_TRANSITION_PROPS = ["all"];
var EMPTY_OPTIONS = {};
var transformOffsetIndexes = {
  matrix: [4, 5],
  matrix3d: [12, 13],
  translate: [0, 1],
  translate3d: [0, 1],
  translateX: [0, null],
  translateY: [null, 0]
};
function parseTranslateValue(value) {
  const parsedValue = parseFloat(value ?? "");
  return Number.isNaN(parsedValue) ? 0 : parsedValue;
}
function parseTransform(transform) {
  const match = transform.match(/^(matrix|matrix3d|translate|translate3d|translateX|translateY)\((.+)\)$/);
  if (!match) {
    return null;
  }
  return {
    type: match[1],
    values: match[2].split(",").map(parseTranslateValue)
  };
}
function getTranslateOffsetValue(values, index) {
  return index === null ? 0 : values[index] || 0;
}
function getTranslateOffsets(transform) {
  if (!transform || transform === "none") {
    return DEFAULT_TRANSLATE_OFFSET;
  }
  const parsedTransform = parseTransform(transform);
  if (!parsedTransform) {
    return DEFAULT_TRANSLATE_OFFSET;
  }
  const {
    type,
    values
  } = parsedTransform;
  const offsetIndexes = transformOffsetIndexes[type];
  if (!offsetIndexes) {
    return DEFAULT_TRANSLATE_OFFSET;
  }
  return {
    offsetX: getTranslateOffsetValue(values, offsetIndexes[0]),
    offsetY: getTranslateOffsetValue(values, offsetIndexes[1])
  };
}
function normalizedTransitionCallback(nodeRef, callback) {
  return (maybeIsAppearing) => {
    if (callback) {
      const node = nodeRef.current;
      if (maybeIsAppearing === void 0) {
        callback(node);
      } else {
        callback(node, maybeIsAppearing);
      }
    }
  };
}
function getTransitionChildStyle(state, inProp, baseStyles, hiddenStyles, styleProp, childStyle) {
  const base = state === "exited" && !inProp ? hiddenStyles : baseStyles[state] || baseStyles.exited;
  return styleProp || childStyle ? {
    ...base,
    ...styleProp,
    ...childStyle
  } : base;
}
function getTransitionProps(props, options) {
  const {
    timeout,
    easing,
    style = EMPTY_STYLE
  } = props;
  return {
    duration: style.transitionDuration ?? (typeof timeout === "number" ? timeout : timeout[options.mode] || 0),
    easing: style.transitionTimingFunction ?? (typeof easing === "object" ? easing[options.mode] : easing),
    delay: style.transitionDelay
  };
}
function getReducedMotionStyles(theme, styles) {
  const resolvedStyles = styles ?? defaultStyles;
  return resolveReducedMotionStyles(theme.motion?.reducedMotion, resolvedStyles);
}
function getTransitionStyles(theme, props = DEFAULT_TRANSITION_PROPS, options = EMPTY_OPTIONS) {
  const transition = theme.transitions?.create?.(props, options);
  const reducedMotionStyles = getReducedMotionStyles(theme);
  if (transition === void 0) {
    return reducedMotionStyles ?? EMPTY_STYLE;
  }
  const transitionStyles = {
    transition
  };
  return reducedMotionStyles ? {
    ...transitionStyles,
    ...reducedMotionStyles
  } : transitionStyles;
}

export {
  reflow,
  getTranslateOffsets,
  normalizedTransitionCallback,
  getTransitionChildStyle,
  getTransitionProps,
  getReducedMotionStyles,
  getTransitionStyles
};
//# sourceMappingURL=chunk-B2OBFM6G.js.map
