import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/orders/OrderList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import Chip from "/node_modules/.vite/deps/@mui_material_Chip.js?v=49ae7072";
import {
  List,
  Datagrid,
  NumberField,
  DateField,
  FunctionField,
  SelectInput
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import {
  ORDER_STATUS_CHOICES,
  ORDER_STATUS_COLORS
} from "/src/lib/orderStatus.ts";
const orderFilters = [
  /* @__PURE__ */ jsxDEV(
    SelectInput,
    {
      source: "status",
      choices: ORDER_STATUS_CHOICES,
      alwaysOn: true
    },
    "status",
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
      lineNumber: 16,
      columnNumber: 1
    },
    this
  )
];
export const OrderList = () => {
  return /* @__PURE__ */ jsxDEV(List, { filters: orderFilters, sort: { field: "createdAt", order: "DESC" }, children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "show", children: [
    /* @__PURE__ */ jsxDEV(NumberField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
      lineNumber: 28,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      FunctionField,
      {
        label: "Status",
        render: (record) => /* @__PURE__ */ jsxDEV(
          Chip,
          {
            label: record.status || "unknown",
            color: ORDER_STATUS_COLORS[record.status || ""] || "default",
            size: "small"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
            lineNumber: 32,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
        lineNumber: 29,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "totalAmount", label: "Total" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
      lineNumber: 39,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "deliveryAmount", label: "Delivery" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
      lineNumber: 40,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      FunctionField,
      {
        label: "Customer",
        render: (record) => {
          const u = record.user;
          if (!u) return "-";
          const name = [u.name, u.lastName].filter(Boolean).join(" ");
          return name || u.phoneNumber || "-";
        }
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
        lineNumber: 41,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(DateField, { source: "createdAt", label: "Date", showTime: true }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
      lineNumber: 52,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
    lineNumber: 27,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_c = OrderList;
var _c;
$RefreshReg$(_c, "OrderList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUU7QUFmRixPQUFPQSxVQUFVO0FBQ2pCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE1BQU1DLGVBQWU7QUFBQSxFQUNuQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BRUMsUUFBTztBQUFBLE1BQ1AsU0FBU0Y7QUFBQUEsTUFDVCxVQUFRO0FBQUE7QUFBQSxJQUhKO0FBQUEsSUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSVU7QUFDUjtBQUdHLGFBQU1HLFlBQVlBLE1BQU07QUFDN0IsU0FDRSx1QkFBQyxRQUFLLFNBQVNELGNBQWMsTUFBTSxFQUFFRSxPQUFPLGFBQWFDLE9BQU8sT0FBTyxHQUNyRSxpQ0FBQyxZQUFTLFVBQVMsUUFDakI7QUFBQSwyQkFBQyxlQUFZLFFBQU8sUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixRQUFRLENBQUNDLFdBQ1A7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9BLE9BQU9DLFVBQVU7QUFBQSxZQUN4QixPQUFPTixvQkFBb0JLLE9BQU9DLFVBQVUsRUFBRSxLQUFLO0FBQUEsWUFDbkQsTUFBSztBQUFBO0FBQUEsVUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHYztBQUFBO0FBQUEsTUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUk7QUFBQSxJQUVKLHVCQUFDLGVBQVksUUFBTyxlQUFjLE9BQU0sV0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQy9DLHVCQUFDLGVBQVksUUFBTyxrQkFBaUIsT0FBTSxjQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsSUFDckQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFFBQVEsQ0FBQ0QsV0FFSDtBQUNKLGdCQUFNRSxJQUFJRixPQUFPRztBQUNqQixjQUFJLENBQUNELEVBQUcsUUFBTztBQUNmLGdCQUFNRSxPQUFPLENBQUNGLEVBQUVFLE1BQU1GLEVBQUVHLFFBQVEsRUFBRUMsT0FBT0MsT0FBTyxFQUFFQyxLQUFLLEdBQUc7QUFDMUQsaUJBQU9KLFFBQVFGLEVBQUVPLGVBQWU7QUFBQSxRQUNsQztBQUFBO0FBQUEsTUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTSTtBQUFBLElBRUosdUJBQUMsYUFBVSxRQUFPLGFBQVksT0FBTSxRQUFPLFVBQVEsUUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRDtBQUFBLE9BekJyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0QkE7QUFFSjtBQUFFQyxLQWhDV2I7QUFBUyxJQUFBYTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDaGlwIiwiTGlzdCIsIkRhdGFncmlkIiwiTnVtYmVyRmllbGQiLCJEYXRlRmllbGQiLCJGdW5jdGlvbkZpZWxkIiwiU2VsZWN0SW5wdXQiLCJPUkRFUl9TVEFUVVNfQ0hPSUNFUyIsIk9SREVSX1NUQVRVU19DT0xPUlMiLCJvcmRlckZpbHRlcnMiLCJPcmRlckxpc3QiLCJmaWVsZCIsIm9yZGVyIiwicmVjb3JkIiwic3RhdHVzIiwidSIsInVzZXIiLCJuYW1lIiwibGFzdE5hbWUiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsInBob25lTnVtYmVyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3JkZXJMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ2hpcCBmcm9tIFwiQG11aS9tYXRlcmlhbC9DaGlwXCI7XG5pbXBvcnQge1xuICBMaXN0LFxuICBEYXRhZ3JpZCxcbiAgTnVtYmVyRmllbGQsXG4gIERhdGVGaWVsZCxcbiAgRnVuY3Rpb25GaWVsZCxcbiAgU2VsZWN0SW5wdXQsXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IHtcbiAgT1JERVJfU1RBVFVTX0NIT0lDRVMsXG4gIE9SREVSX1NUQVRVU19DT0xPUlMsXG59IGZyb20gXCIuLi8uLi9saWIvb3JkZXJTdGF0dXNcIjtcblxuY29uc3Qgb3JkZXJGaWx0ZXJzID0gW1xuICA8U2VsZWN0SW5wdXRcbiAgICBrZXk9XCJzdGF0dXNcIlxuICAgIHNvdXJjZT1cInN0YXR1c1wiXG4gICAgY2hvaWNlcz17T1JERVJfU1RBVFVTX0NIT0lDRVN9XG4gICAgYWx3YXlzT25cbiAgLz4sXG5dO1xuXG5leHBvcnQgY29uc3QgT3JkZXJMaXN0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxMaXN0IGZpbHRlcnM9e29yZGVyRmlsdGVyc30gc29ydD17eyBmaWVsZDogXCJjcmVhdGVkQXRcIiwgb3JkZXI6IFwiREVTQ1wiIH19PlxuICAgICAgPERhdGFncmlkIHJvd0NsaWNrPVwic2hvd1wiPlxuICAgICAgICA8TnVtYmVyRmllbGQgc291cmNlPVwiaWRcIiAvPlxuICAgICAgICA8RnVuY3Rpb25GaWVsZFxuICAgICAgICAgIGxhYmVsPVwiU3RhdHVzXCJcbiAgICAgICAgICByZW5kZXI9eyhyZWNvcmQ6IHsgc3RhdHVzPzogc3RyaW5nIH0pID0+IChcbiAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgIGxhYmVsPXtyZWNvcmQuc3RhdHVzIHx8IFwidW5rbm93blwifVxuICAgICAgICAgICAgICBjb2xvcj17T1JERVJfU1RBVFVTX0NPTE9SU1tyZWNvcmQuc3RhdHVzIHx8IFwiXCJdIHx8IFwiZGVmYXVsdFwifVxuICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuICAgICAgICAvPlxuICAgICAgICA8TnVtYmVyRmllbGQgc291cmNlPVwidG90YWxBbW91bnRcIiBsYWJlbD1cIlRvdGFsXCIgLz5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cImRlbGl2ZXJ5QW1vdW50XCIgbGFiZWw9XCJEZWxpdmVyeVwiIC8+XG4gICAgICAgIDxGdW5jdGlvbkZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJDdXN0b21lclwiXG4gICAgICAgICAgcmVuZGVyPXsocmVjb3JkOiB7XG4gICAgICAgICAgICB1c2VyPzogeyBuYW1lPzogc3RyaW5nOyBsYXN0TmFtZT86IHN0cmluZzsgcGhvbmVOdW1iZXI/OiBzdHJpbmcgfTtcbiAgICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgICBjb25zdCB1ID0gcmVjb3JkLnVzZXI7XG4gICAgICAgICAgICBpZiAoIXUpIHJldHVybiBcIi1cIjtcbiAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBbdS5uYW1lLCB1Lmxhc3ROYW1lXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIik7XG4gICAgICAgICAgICByZXR1cm4gbmFtZSB8fCB1LnBob25lTnVtYmVyIHx8IFwiLVwiO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICAgIDxEYXRlRmllbGQgc291cmNlPVwiY3JlYXRlZEF0XCIgbGFiZWw9XCJEYXRlXCIgc2hvd1RpbWUgLz5cbiAgICAgIDwvRGF0YWdyaWQ+XG4gICAgPC9MaXN0PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9vcmRlcnMvT3JkZXJMaXN0LnRzeCJ9