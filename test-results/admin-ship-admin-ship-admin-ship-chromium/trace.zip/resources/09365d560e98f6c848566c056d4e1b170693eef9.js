import {
  unstable_memoTheme
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/utils/memoTheme.mjs
var memoTheme = unstable_memoTheme;
var memoTheme_default = memoTheme;

export {
  memoTheme_default
};
//# sourceMappingURL=chunk-YIMRGSOF.js.map
