import {
  formHelperTextClasses_default,
  formLabelClasses_default,
  nativeSelectClasses_default
} from "/node_modules/.vite/deps/chunk-Y26CSB6V.js?v=49ae7072";
import {
  toggleButtonClasses_default
} from "/node_modules/.vite/deps/chunk-NS7DFSYZ.js?v=49ae7072";
import {
  autocompleteClasses_default
} from "/node_modules/.vite/deps/chunk-LV56RCRM.js?v=49ae7072";
import {
  filledInputClasses_default,
  inputClasses_default,
  outlinedInputClasses_default
} from "/node_modules/.vite/deps/chunk-DOCG3UWO.js?v=49ae7072";
import {
  ClassNameGenerator_default,
  InitColorSchemeScript,
  ThemeProvider_default,
  createBox,
  createBreakpoints,
  createCssVarsProvider,
  createSpacing,
  createTheme,
  createThemeWithVars,
  createTypography,
  deepmerge,
  defaultTheme_default,
  generateUtilityClass,
  generateUtilityClasses,
  identifier_default,
  require_prop_types,
  styleFunctionSx_default,
  useThemeProps
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Box/Box.mjs
var import_prop_types2 = __toESM(require_prop_types(), 1);

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/adaptV4Theme.mjs
function adaptV4Theme(inputTheme) {
  if (true) {
    console.warn(["MUI: adaptV4Theme() is deprecated.", "Follow the upgrade guide on https://mui.com/r/migration-v4#theme."].join("\n"));
  }
  const {
    defaultProps = {},
    mixins = {},
    overrides = {},
    palette = {},
    props = {},
    styleOverrides = {},
    ...other
  } = inputTheme;
  const theme = {
    ...other,
    components: {}
  };
  Object.keys(defaultProps).forEach((component) => {
    const componentValue = theme.components[component] || {};
    componentValue.defaultProps = defaultProps[component];
    theme.components[component] = componentValue;
  });
  Object.keys(props).forEach((component) => {
    const componentValue = theme.components[component] || {};
    componentValue.defaultProps = props[component];
    theme.components[component] = componentValue;
  });
  Object.keys(styleOverrides).forEach((component) => {
    const componentValue = theme.components[component] || {};
    componentValue.styleOverrides = styleOverrides[component];
    theme.components[component] = componentValue;
  });
  Object.keys(overrides).forEach((component) => {
    const componentValue = theme.components[component] || {};
    componentValue.styleOverrides = overrides[component];
    theme.components[component] = componentValue;
  });
  theme.spacing = createSpacing(inputTheme.spacing);
  const breakpoints = createBreakpoints(inputTheme.breakpoints || {});
  const spacing = theme.spacing;
  theme.mixins = {
    gutters: (styles = {}) => {
      return {
        paddingLeft: spacing(2),
        paddingRight: spacing(2),
        ...styles,
        [breakpoints.up("sm")]: {
          paddingLeft: spacing(3),
          paddingRight: spacing(3),
          ...styles[breakpoints.up("sm")]
        }
      };
    },
    ...mixins
  };
  const {
    type: typeInput,
    mode: modeInput,
    ...paletteRest
  } = palette;
  const finalMode = modeInput || typeInput || "light";
  theme.palette = {
    // theme.palette.text.hint
    text: {
      hint: finalMode === "dark" ? "rgba(255, 255, 255, 0.5)" : "rgba(0, 0, 0, 0.38)"
    },
    mode: finalMode,
    type: finalMode,
    ...paletteRest
  };
  return theme;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/AccordionSummary/accordionSummaryClasses.mjs
function getAccordionSummaryUtilityClass(slot) {
  return generateUtilityClass("MuiAccordionSummary", slot);
}
var accordionSummaryClasses = generateUtilityClasses("MuiAccordionSummary", ["root", "expanded", "focusVisible", "disabled", "gutters", "content", "expandIconWrapper"]);
var accordionSummaryClasses_default = accordionSummaryClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Checkbox/checkboxClasses.mjs
function getCheckboxUtilityClass(slot) {
  return generateUtilityClass("MuiCheckbox", slot);
}
var checkboxClasses = generateUtilityClasses("MuiCheckbox", ["root", "checked", "disabled", "indeterminate", "colorPrimary", "colorSecondary", "sizeSmall", "sizeMedium"]);
var checkboxClasses_default = checkboxClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/FormControlLabel/formControlLabelClasses.mjs
function getFormControlLabelUtilityClasses(slot) {
  return generateUtilityClass("MuiFormControlLabel", slot);
}
var formControlLabelClasses = generateUtilityClasses("MuiFormControlLabel", ["root", "labelPlacementStart", "labelPlacementEnd", "labelPlacementTop", "labelPlacementBottom", "disabled", "label", "error", "required", "asterisk"]);
var formControlLabelClasses_default = formControlLabelClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/ListItemButton/listItemButtonClasses.mjs
function getListItemButtonUtilityClass(slot) {
  return generateUtilityClass("MuiListItemButton", slot);
}
var listItemButtonClasses = generateUtilityClasses("MuiListItemButton", ["root", "focusVisible", "dense", "alignItemsFlexStart", "disabled", "divider", "gutters", "selected"]);
var listItemButtonClasses_default = listItemButtonClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/MenuItem/menuItemClasses.mjs
function getMenuItemUtilityClass(slot) {
  return generateUtilityClass("MuiMenuItem", slot);
}
var menuItemClasses = generateUtilityClasses("MuiMenuItem", ["root", "focusVisible", "dense", "disabled", "divider", "gutters", "selected"]);
var menuItemClasses_default = menuItemClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Radio/radioClasses.mjs
function getRadioUtilityClass(slot) {
  return generateUtilityClass("MuiRadio", slot);
}
var radioClasses = generateUtilityClasses("MuiRadio", ["root", "checked", "disabled", "colorPrimary", "colorSecondary", "sizeSmall"]);
var radioClasses_default = radioClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Slider/sliderClasses.mjs
function getSliderUtilityClass(slot) {
  return generateUtilityClass("MuiSlider", slot);
}
var sliderClasses = generateUtilityClasses("MuiSlider", ["root", "active", "colorPrimary", "colorSecondary", "colorError", "colorInfo", "colorSuccess", "colorWarning", "disabled", "dragging", "focusVisible", "mark", "markActive", "marked", "markLabel", "markLabelActive", "rail", "sizeSmall", "thumb", "track", "trackInverted", "trackFalse", "valueLabel", "valueLabelOpen", "valueLabelCircle", "valueLabelLabel", "vertical"]);
var sliderClasses_default = sliderClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/enhanceHighContrast.mjs
var defaultHcTokens = {
  disabled: "GrayText",
  error: "ActiveText",
  selectedBackground: "SelectedItem",
  selectedText: "SelectedItemText",
  activeBackground: "Highlight",
  activeText: "HighlightText",
  buttonBorder: "ButtonBorder",
  buttonText: "ButtonText",
  canvas: "Canvas"
};
var HCM = "@media (forced-colors: active)";
function enhanceHighContrast(themeInput, tokens) {
  const hcTokens = {
    disabled: tokens?.disabled ?? defaultHcTokens.disabled,
    error: tokens?.error ?? defaultHcTokens.error,
    selectedBackground: tokens?.selectedBackground ?? defaultHcTokens.selectedBackground,
    selectedText: tokens?.selectedText ?? defaultHcTokens.selectedText,
    activeBackground: tokens?.activeBackground ?? defaultHcTokens.activeBackground,
    activeText: tokens?.activeText ?? defaultHcTokens.activeText,
    buttonBorder: tokens?.buttonBorder ?? defaultHcTokens.buttonBorder,
    buttonText: tokens?.buttonText ?? defaultHcTokens.buttonText,
    canvas: tokens?.canvas ?? defaultHcTokens.canvas
  };
  const theme = {
    ...themeInput
  };
  const c = theme.components;
  theme.components = {
    ...c,
    MuiAccordionSummary: {
      ...c?.MuiAccordionSummary,
      styleOverrides: {
        ...c?.MuiAccordionSummary?.styleOverrides,
        root: [c?.MuiAccordionSummary?.styleOverrides?.root, {
          [`&.${accordionSummaryClasses_default.disabled}`]: {
            [HCM]: {
              opacity: 1
            }
          }
        }]
      }
    },
    MuiAutocomplete: {
      ...c?.MuiAutocomplete,
      styleOverrides: {
        ...c?.MuiAutocomplete?.styleOverrides,
        listbox: [c?.MuiAutocomplete?.styleOverrides?.listbox, {
          [`& .${autocompleteClasses_default.option}`]: {
            '&[aria-disabled="true"]': {
              [HCM]: {
                color: hcTokens.disabled,
                opacity: 1
              }
            },
            [`&.${autocompleteClasses_default.focused}, &.${autocompleteClasses_default.focusVisible}`]: {
              [HCM]: {
                forcedColorAdjust: "none",
                color: hcTokens.activeText,
                backgroundColor: hcTokens.activeBackground
              }
            },
            '&[aria-selected="true"]': {
              [HCM]: {
                forcedColorAdjust: "none",
                color: hcTokens.selectedText,
                backgroundColor: hcTokens.selectedBackground
              },
              [`&.${autocompleteClasses_default.focused}`]: {
                [HCM]: {
                  color: hcTokens.activeText,
                  backgroundColor: hcTokens.activeBackground
                }
              }
            }
          }
        }]
      }
    },
    MuiCheckbox: {
      ...c?.MuiCheckbox,
      styleOverrides: {
        ...c?.MuiCheckbox?.styleOverrides,
        root: [c?.MuiCheckbox?.styleOverrides?.root, {
          [`&.${checkboxClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiFilledInput: {
      ...c?.MuiFilledInput,
      styleOverrides: {
        ...c?.MuiFilledInput?.styleOverrides,
        root: [c?.MuiFilledInput?.styleOverrides?.root, {
          [`&.${filledInputClasses_default.error}`]: {
            "&::before, &::after": {
              [HCM]: {
                borderBottomColor: hcTokens.error
              }
            }
          },
          [`&.${filledInputClasses_default.disabled}:before`]: {
            [HCM]: {
              borderBottomStyle: "solid",
              borderBottomColor: hcTokens.disabled
            }
          },
          [`&.${filledInputClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiFormControlLabel: {
      ...c?.MuiFormControlLabel,
      styleOverrides: {
        ...c?.MuiFormControlLabel?.styleOverrides,
        root: [c?.MuiFormControlLabel?.styleOverrides?.root, {
          [`& .${formControlLabelClasses_default.label}.${formControlLabelClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiFormHelperText: {
      ...c?.MuiFormHelperText,
      styleOverrides: {
        ...c?.MuiFormHelperText?.styleOverrides,
        root: [c?.MuiFormHelperText?.styleOverrides?.root, {
          [`&.${formHelperTextClasses_default.error}`]: {
            [HCM]: {
              color: hcTokens.error
            }
          },
          [`&.${formHelperTextClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiFormLabel: {
      ...c?.MuiFormLabel,
      styleOverrides: {
        ...c?.MuiFormLabel?.styleOverrides,
        root: [c?.MuiFormLabel?.styleOverrides?.root, {
          [`&.${formLabelClasses_default.error}`]: {
            [HCM]: {
              color: hcTokens.error
            }
          },
          [`&.${formLabelClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiInput: {
      ...c?.MuiInput,
      styleOverrides: {
        ...c?.MuiInput?.styleOverrides,
        root: [c?.MuiInput?.styleOverrides?.root, {
          [`&.${inputClasses_default.error}`]: {
            "&::before, &::after": {
              [HCM]: {
                borderBottomColor: hcTokens.error
              }
            }
          },
          [`&.${inputClasses_default.disabled}:before`]: {
            [HCM]: {
              borderBottomStyle: "solid",
              borderBottomColor: hcTokens.disabled
            }
          },
          [`&.${inputClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiLinearProgress: {
      ...c?.MuiLinearProgress,
      styleOverrides: {
        ...c?.MuiLinearProgress?.styleOverrides,
        root: [c?.MuiLinearProgress?.styleOverrides?.root, {
          [HCM]: {
            forcedColorAdjust: "none",
            outline: `1px solid ${hcTokens.buttonBorder}`,
            backgroundColor: hcTokens.canvas
          }
        }],
        bar: [c?.MuiLinearProgress?.styleOverrides?.bar, {
          [HCM]: {
            backgroundColor: hcTokens.buttonText
          }
        }],
        bar2: [c?.MuiLinearProgress?.styleOverrides?.bar2, {
          variants: [{
            props: {
              variant: "buffer"
            },
            style: {
              [HCM]: {
                backgroundColor: hcTokens.disabled
              }
            }
          }]
        }]
      }
    },
    MuiInputBase: {
      ...c?.MuiInputBase,
      styleOverrides: {
        ...c?.MuiInputBase?.styleOverrides,
        input: [c?.MuiInputBase?.styleOverrides?.input, {
          [HCM]: {
            "&::placeholder": {
              opacity: 1
            }
          }
        }]
      }
    },
    MuiMenuItem: {
      ...c?.MuiMenuItem,
      styleOverrides: {
        ...c?.MuiMenuItem?.styleOverrides,
        root: [c?.MuiMenuItem?.styleOverrides?.root, {
          [`&.${menuItemClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled,
              opacity: 1
            }
          },
          [`&.${menuItemClasses_default.focusVisible}, &:hover`]: {
            [HCM]: {
              forcedColorAdjust: "none",
              color: hcTokens.activeText,
              backgroundColor: hcTokens.activeBackground,
              outline: "none"
            }
          },
          [`&.${menuItemClasses_default.selected}`]: {
            [HCM]: {
              forcedColorAdjust: "none",
              color: hcTokens.selectedText,
              backgroundColor: hcTokens.selectedBackground
            }
          },
          [`&.${menuItemClasses_default.selected}.${menuItemClasses_default.focusVisible}, &.${menuItemClasses_default.selected}:hover`]: {
            [HCM]: {
              color: hcTokens.activeText,
              backgroundColor: hcTokens.activeBackground
            }
          }
        }]
      }
    },
    MuiListItemIcon: {
      ...c?.MuiListItemIcon,
      styleOverrides: {
        ...c?.MuiListItemIcon?.styleOverrides,
        root: [c?.MuiListItemIcon?.styleOverrides?.root, {
          [HCM]: {
            color: "inherit"
          }
        }]
      }
    },
    MuiListItemButton: {
      ...c?.MuiListItemButton,
      styleOverrides: {
        ...c?.MuiListItemButton?.styleOverrides,
        root: [c?.MuiListItemButton?.styleOverrides?.root, {
          [`&.${listItemButtonClasses_default.focusVisible}, &:hover`]: {
            [HCM]: {
              forcedColorAdjust: "none",
              color: hcTokens.activeText,
              backgroundColor: hcTokens.activeBackground
            }
          },
          [`&.${listItemButtonClasses_default.selected}`]: {
            [HCM]: {
              forcedColorAdjust: "none",
              color: hcTokens.selectedText,
              backgroundColor: hcTokens.selectedBackground
            }
          },
          [`&.${listItemButtonClasses_default.selected}.${listItemButtonClasses_default.focusVisible}, &.${listItemButtonClasses_default.selected}:hover`]: {
            [HCM]: {
              color: hcTokens.activeText,
              backgroundColor: hcTokens.activeBackground
            }
          }
        }]
      }
    },
    MuiNativeSelect: {
      ...c?.MuiNativeSelect,
      styleOverrides: {
        ...c?.MuiNativeSelect?.styleOverrides,
        icon: [c?.MuiNativeSelect?.styleOverrides?.icon, {
          [`&.${nativeSelectClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiOutlinedInput: {
      ...c?.MuiOutlinedInput,
      styleOverrides: {
        ...c?.MuiOutlinedInput?.styleOverrides,
        root: [c?.MuiOutlinedInput?.styleOverrides?.root, {
          [`&.${outlinedInputClasses_default.error} .${outlinedInputClasses_default.notchedOutline}`]: {
            [HCM]: {
              borderColor: hcTokens.error
            }
          },
          [`&.${outlinedInputClasses_default.disabled} .${outlinedInputClasses_default.notchedOutline}`]: {
            [HCM]: {
              borderColor: hcTokens.disabled
            }
          },
          [`&.${outlinedInputClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiRadio: {
      ...c?.MuiRadio,
      styleOverrides: {
        ...c?.MuiRadio?.styleOverrides,
        root: [c?.MuiRadio?.styleOverrides?.root, {
          [`&.${radioClasses_default.disabled}`]: {
            [HCM]: {
              color: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiSlider: {
      ...c?.MuiSlider,
      styleOverrides: {
        ...c?.MuiSlider?.styleOverrides,
        // track doesn't receive the disabled class — use ownerState
        track: [c?.MuiSlider?.styleOverrides?.track, ({
          ownerState
        }) => ({
          ...ownerState.disabled && {
            [HCM]: {
              borderColor: hcTokens.disabled
            }
          }
        })],
        // thumb receives the disabled class directly
        thumb: [c?.MuiSlider?.styleOverrides?.thumb, {
          [`&.${sliderClasses_default.disabled}`]: {
            [HCM]: {
              borderColor: hcTokens.disabled
            }
          }
        }]
      }
    },
    MuiSwitch: {
      ...c?.MuiSwitch,
      styleOverrides: {
        ...c?.MuiSwitch?.styleOverrides,
        // track and thumb don't receive the disabled class — use ownerState
        track: [c?.MuiSwitch?.styleOverrides?.track, ({
          ownerState
        }) => ({
          ...ownerState.disabled && {
            [HCM]: {
              borderColor: hcTokens.disabled
            }
          }
        })],
        thumb: [c?.MuiSwitch?.styleOverrides?.thumb, ({
          ownerState
        }) => ({
          ...ownerState.disabled && {
            [HCM]: {
              borderColor: hcTokens.disabled
            }
          }
        })]
      }
    },
    MuiButtonBase: {
      ...c?.MuiButtonBase,
      styleOverrides: {
        ...c?.MuiButtonBase?.styleOverrides,
        root: [c?.MuiButtonBase?.styleOverrides?.root, {
          // Restore the focus outline in HCM since the ripple is not visible.
          // Also handle components where the focusable element is a hidden inner input (Checkbox, Radio, Switch).
          [HCM]: {
            "&:focus-visible, &:focus-within:has(input:focus-visible)": {
              outline: `5px auto ${hcTokens.activeBackground}`
            }
          }
        }]
      }
    },
    MuiTooltip: {
      ...c?.MuiTooltip,
      styleOverrides: {
        ...c?.MuiTooltip?.styleOverrides,
        tooltip: [c?.MuiTooltip?.styleOverrides?.tooltip, {
          [HCM]: {
            border: `1px solid ${hcTokens.buttonText}`
          }
        }]
      }
    },
    MuiToggleButton: {
      ...c?.MuiToggleButton,
      styleOverrides: {
        ...c?.MuiToggleButton?.styleOverrides,
        root: [c?.MuiToggleButton?.styleOverrides?.root, {
          [`&.${toggleButtonClasses_default.selected}`]: {
            [HCM]: {
              forcedColorAdjust: "none",
              color: hcTokens.activeText,
              backgroundColor: hcTokens.activeBackground,
              borderColor: hcTokens.activeBackground
            },
            "&:hover": {
              [HCM]: {
                backgroundColor: hcTokens.activeBackground,
                borderColor: hcTokens.buttonBorder
              }
            }
          }
        }]
      }
    }
  };
  return theme;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/createMuiStrictModeTheme.mjs
function createMuiStrictModeTheme(options, ...args) {
  return createTheme(deepmerge({
    unstable_strictMode: true
  }, options), ...args);
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/createStyles.mjs
var warnedOnce = false;
function createStyles(styles) {
  if (!warnedOnce) {
    console.warn(["MUI: createStyles from @mui/material/styles is deprecated.", "Please use @mui/styles/createStyles"].join("\n"));
    warnedOnce = true;
  }
  return styles;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/cssUtils.mjs
function isUnitless(value) {
  return String(parseFloat(value)).length === String(value).length;
}
function getUnit(input) {
  return String(input).match(/[\d.\-+]*\s*(.*)/)[1] || "";
}
function toUnitless(length) {
  return parseFloat(length);
}
function convertLength(baseFontSize) {
  return (length, toUnit) => {
    const fromUnit = getUnit(length);
    if (fromUnit === toUnit) {
      return length;
    }
    let pxLength = toUnitless(length);
    if (fromUnit !== "px") {
      if (fromUnit === "em") {
        pxLength = toUnitless(length) * toUnitless(baseFontSize);
      } else if (fromUnit === "rem") {
        pxLength = toUnitless(length) * toUnitless(baseFontSize);
      }
    }
    let outputLength = pxLength;
    if (toUnit !== "px") {
      if (toUnit === "em") {
        outputLength = pxLength / toUnitless(baseFontSize);
      } else if (toUnit === "rem") {
        outputLength = pxLength / toUnitless(baseFontSize);
      } else {
        return length;
      }
    }
    return parseFloat(outputLength.toFixed(5)) + toUnit;
  };
}
function alignProperty({
  size,
  grid
}) {
  const sizeBelow = size - size % grid;
  const sizeAbove = sizeBelow + grid;
  return size - sizeBelow < sizeAbove - size ? sizeBelow : sizeAbove;
}
function fontGrid({
  lineHeight,
  pixels,
  htmlFontSize
}) {
  return pixels / (lineHeight * htmlFontSize);
}
function responsiveProperty({
  cssProperty,
  min,
  max,
  unit = "rem",
  breakpoints = [600, 900, 1200],
  transform = null
}) {
  const output = {
    [cssProperty]: `${min}${unit}`
  };
  const factor = (max - min) / breakpoints[breakpoints.length - 1];
  breakpoints.forEach((breakpoint) => {
    let value = min + factor * breakpoint;
    if (transform !== null) {
      value = transform(value);
    }
    output[`@media (min-width:${breakpoint}px)`] = {
      [cssProperty]: `${Math.round(value * 1e4) / 1e4}${unit}`
    };
  });
  return output;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/responsiveFontSizes.mjs
function responsiveFontSizes(themeInput, options = {}) {
  const {
    breakpoints = ["sm", "md", "lg"],
    disableAlign = false,
    factor = 2,
    variants = ["h1", "h2", "h3", "h4", "h5", "h6", "subtitle1", "subtitle2", "body1", "body2", "caption", "button", "overline"]
  } = options;
  const theme = {
    ...themeInput
  };
  theme.typography = {
    ...theme.typography
  };
  const typography = theme.typography;
  const convert = convertLength(typography.htmlFontSize);
  const breakpointValues = breakpoints.map((x) => theme.breakpoints.values[x]);
  variants.forEach((variant) => {
    const style = typography[variant];
    if (!style) {
      return;
    }
    const remFontSize = parseFloat(convert(style.fontSize, "rem"));
    if (remFontSize <= 1) {
      return;
    }
    const maxFontSize = remFontSize;
    const minFontSize = 1 + (maxFontSize - 1) / factor;
    let {
      lineHeight
    } = style;
    if (!isUnitless(lineHeight) && !disableAlign) {
      throw new Error(true ? "MUI: Unsupported non-unitless line height with grid alignment.\nUse unitless line heights instead." : formatMuiErrorMessage(6));
    }
    if (!isUnitless(lineHeight)) {
      lineHeight = parseFloat(convert(lineHeight, "rem")) / parseFloat(remFontSize);
    }
    let transform = null;
    if (!disableAlign) {
      transform = (value) => alignProperty({
        size: value,
        grid: fontGrid({
          pixels: 4,
          lineHeight,
          htmlFontSize: typography.htmlFontSize
        })
      });
    }
    const responsive = responsiveProperty({
      cssProperty: "fontSize",
      min: minFontSize,
      max: maxFontSize,
      unit: "rem",
      breakpoints: breakpointValues,
      transform
    });
    if (breakpointValues.length > 0) {
      const lastBreakpoint = breakpointValues[breakpointValues.length - 1];
      responsive[`@media (min-width:${lastBreakpoint}px)`] = {
        fontSize: `${Math.round(maxFontSize * 1e4) / 1e4}rem`
      };
    }
    typography[variant] = {
      ...style,
      ...responsive
    };
  });
  return theme;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/useThemeProps.mjs
function useThemeProps2({
  props,
  name
}) {
  return useThemeProps({
    props,
    name,
    defaultTheme: defaultTheme_default,
    themeId: identifier_default
  });
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/ThemeProvider.mjs
var React2 = __toESM(require_react(), 1);

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/ThemeProviderNoVars.mjs
var React = __toESM(require_react(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
function ThemeProviderNoVars({
  theme: themeInput,
  ...props
}) {
  const scopedTheme = identifier_default in themeInput ? themeInput[identifier_default] : void 0;
  return (0, import_jsx_runtime.jsx)(ThemeProvider_default, {
    ...props,
    themeId: scopedTheme ? identifier_default : void 0,
    theme: scopedTheme || themeInput
  });
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/InitColorSchemeScript/InitColorSchemeScript.mjs
var import_prop_types = __toESM(require_prop_types(), 1);
var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
var defaultConfig = {
  attribute: "data-mui-color-scheme",
  colorSchemeStorageKey: "mui-color-scheme",
  defaultLightColorScheme: "light",
  defaultDarkColorScheme: "dark",
  modeStorageKey: "mui-mode"
};
function InitColorSchemeScript2(props) {
  const {
    defaultMode = "system",
    defaultLightColorScheme = defaultConfig.defaultLightColorScheme,
    defaultDarkColorScheme = defaultConfig.defaultDarkColorScheme,
    modeStorageKey = defaultConfig.modeStorageKey,
    colorSchemeStorageKey = defaultConfig.colorSchemeStorageKey,
    attribute: initialAttribute = defaultConfig.attribute,
    colorSchemeNode = "document.documentElement",
    nonce
  } = props;
  return (0, import_jsx_runtime2.jsx)(InitColorSchemeScript, {
    defaultMode,
    defaultLightColorScheme,
    defaultDarkColorScheme,
    modeStorageKey,
    colorSchemeStorageKey,
    attribute: initialAttribute,
    colorSchemeNode,
    nonce
  });
}
true ? InitColorSchemeScript2.propTypes = {
  // ┌────────────────────────────── Warning ──────────────────────────────┐
  // │ These PropTypes are generated from the TypeScript type definitions. │
  // │ To update them, edit the TypeScript types and run `pnpm proptypes`. │
  // └─────────────────────────────────────────────────────────────────────┘
  /**
   * DOM attribute for applying a color scheme.
   * @default 'data-mui-color-scheme'
   * @example '.mode-%s' // for class based color scheme
   * @example '[data-mode-%s]' // for data-attribute without '='
   */
  attribute: import_prop_types.default.string,
  /**
   * The node (provided as string) used to attach the color-scheme attribute.
   * @default 'document.documentElement'
   */
  colorSchemeNode: import_prop_types.default.string,
  /**
   * localStorage key used to store `colorScheme`.
   * @default 'mui-color-scheme'
   */
  colorSchemeStorageKey: import_prop_types.default.string,
  /**
   * The default color scheme to be used in dark mode.
   * @default 'dark'
   */
  defaultDarkColorScheme: import_prop_types.default.string,
  /**
   * The default color scheme to be used in light mode.
   * @default 'light'
   */
  defaultLightColorScheme: import_prop_types.default.string,
  /**
   * The default mode when the storage is empty (user's first visit).
   * @default 'system'
   */
  defaultMode: import_prop_types.default.oneOf(["dark", "light", "system"]),
  /**
   * localStorage key used to store `mode`.
   * @default 'mui-mode'
   */
  modeStorageKey: import_prop_types.default.string,
  /**
   * Nonce string to pass to the inline script for CSP headers.
   */
  nonce: import_prop_types.default.string
} : void 0;
var InitColorSchemeScript_default = InitColorSchemeScript2;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/ThemeProviderWithVars.mjs
var import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
var {
  CssVarsProvider: InternalCssVarsProvider,
  useColorScheme,
  getInitColorSchemeScript: deprecatedGetInitColorSchemeScript
} = createCssVarsProvider({
  themeId: identifier_default,
  // @ts-ignore ignore module augmentation tests
  theme: () => createTheme({
    cssVariables: true
  }),
  colorSchemeStorageKey: defaultConfig.colorSchemeStorageKey,
  modeStorageKey: defaultConfig.modeStorageKey,
  defaultColorScheme: {
    light: defaultConfig.defaultLightColorScheme,
    dark: defaultConfig.defaultDarkColorScheme
  },
  resolveTheme: (theme) => {
    const newTheme = {
      ...theme,
      typography: createTypography(theme.palette, theme.typography)
    };
    newTheme.unstable_sx = function sx(props) {
      return styleFunctionSx_default({
        sx: props,
        theme: this
      });
    };
    return newTheme;
  }
});
var warnedOnce2 = false;
function Experimental_CssVarsProvider(props) {
  if (true) {
    if (!warnedOnce2) {
      console.warn(["MUI: The Experimental_CssVarsProvider component has been ported into ThemeProvider.", "", "You should use `import { ThemeProvider } from '@mui/material/styles'` instead.", "For more details, check out https://mui.com/material-ui/customization/css-theme-variables/usage/"].join("\n"));
      warnedOnce2 = true;
    }
  }
  return (0, import_jsx_runtime3.jsx)(InternalCssVarsProvider, {
    ...props
  });
}
var warnedInitScriptOnce = false;
var getInitColorSchemeScript = (params) => {
  if (!warnedInitScriptOnce) {
    console.warn(["MUI: The getInitColorSchemeScript function has been deprecated.", "", "You should use `import InitColorSchemeScript from '@mui/material/InitColorSchemeScript'`", "and replace the function call with `<InitColorSchemeScript />` instead."].join("\n"));
    warnedInitScriptOnce = true;
  }
  return deprecatedGetInitColorSchemeScript(params);
};
var CssVarsProvider = InternalCssVarsProvider;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/ThemeProvider.mjs
var import_jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
function ThemeProvider({
  theme,
  ...props
}) {
  const noVarsTheme = React2.useMemo(() => {
    if (typeof theme === "function") {
      return theme;
    }
    const muiTheme = identifier_default in theme ? theme[identifier_default] : theme;
    if (!("colorSchemes" in muiTheme)) {
      if (!("vars" in muiTheme)) {
        return {
          ...theme,
          vars: null
        };
      }
      return theme;
    }
    return null;
  }, [theme]);
  if (noVarsTheme) {
    return (0, import_jsx_runtime4.jsx)(ThemeProviderNoVars, {
      theme: noVarsTheme,
      ...props
    });
  }
  return (0, import_jsx_runtime4.jsx)(CssVarsProvider, {
    theme,
    ...props
  });
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/makeStyles.mjs
function makeStyles() {
  throw new Error(true ? "MUI: makeStyles is no longer exported from @mui/material/styles.\nYou have to import it from @mui/styles.\nSee https://mui.com/r/migration-v4/#mui-material-styles for more details." : formatMuiErrorMessage(14));
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/withStyles.mjs
function withStyles() {
  throw new Error(true ? "MUI: withStyles is no longer exported from @mui/material/styles.\nYou have to import it from @mui/styles.\nSee https://mui.com/r/migration-v4/#mui-material-styles for more details." : formatMuiErrorMessage(15));
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/withTheme.mjs
function withTheme() {
  throw new Error(true ? "MUI: withTheme is no longer exported from @mui/material/styles.\nYou have to import it from @mui/styles.\nSee https://mui.com/r/migration-v4/#mui-material-styles for more details." : formatMuiErrorMessage(16));
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/experimental_extendTheme.mjs
var warnedOnce3 = false;
function deprecatedExtendTheme(...args) {
  if (!warnedOnce3) {
    console.warn(["MUI: The `experimental_extendTheme` has been stabilized.", "", "You should use `import { extendTheme } from '@mui/material/styles'`"].join("\n"));
    warnedOnce3 = true;
  }
  return createThemeWithVars(...args);
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/styles/index.mjs
function experimental_sx() {
  throw new Error(true ? "MUI: The `experimental_sx` has been moved to `theme.unstable_sx`.For more details, see https://github.com/mui/material-ui/pull/35150." : formatMuiErrorMessage(19));
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Box/boxClasses.mjs
var boxClasses = generateUtilityClasses("MuiBox", ["root"]);
var boxClasses_default = boxClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Box/Box.mjs
var defaultTheme = createTheme();
var Box = createBox({
  themeId: identifier_default,
  defaultTheme,
  defaultClassName: boxClasses_default.root,
  generateClassName: ClassNameGenerator_default.generate
});
true ? Box.propTypes = {
  // ┌────────────────────────────── Warning ──────────────────────────────┐
  // │ These PropTypes are generated from the TypeScript type definitions. │
  // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
  // └─────────────────────────────────────────────────────────────────────┘
  /**
   * @ignore
   */
  children: import_prop_types2.default.node,
  /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */
  component: import_prop_types2.default.elementType,
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: import_prop_types2.default.oneOfType([import_prop_types2.default.arrayOf(import_prop_types2.default.oneOfType([import_prop_types2.default.func, import_prop_types2.default.object, import_prop_types2.default.bool])), import_prop_types2.default.func, import_prop_types2.default.object])
} : void 0;
var Box_default = Box;

export {
  adaptV4Theme,
  getAccordionSummaryUtilityClass,
  accordionSummaryClasses_default,
  getCheckboxUtilityClass,
  checkboxClasses_default,
  getFormControlLabelUtilityClasses,
  formControlLabelClasses_default,
  getListItemButtonUtilityClass,
  listItemButtonClasses_default,
  getMenuItemUtilityClass,
  menuItemClasses_default,
  getRadioUtilityClass,
  radioClasses_default,
  getSliderUtilityClass,
  sliderClasses_default,
  enhanceHighContrast,
  createMuiStrictModeTheme,
  createStyles,
  getUnit,
  toUnitless,
  responsiveFontSizes,
  useThemeProps2 as useThemeProps,
  InitColorSchemeScript_default,
  useColorScheme,
  Experimental_CssVarsProvider,
  getInitColorSchemeScript,
  CssVarsProvider,
  ThemeProvider,
  makeStyles,
  withStyles,
  withTheme,
  deprecatedExtendTheme,
  experimental_sx,
  boxClasses_default,
  Box_default
};
//# sourceMappingURL=chunk-6ZZQDDJN.js.map
