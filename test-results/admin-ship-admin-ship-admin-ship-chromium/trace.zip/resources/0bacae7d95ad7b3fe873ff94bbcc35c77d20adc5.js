import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/users/UserEdit.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import {
  BooleanInput,
  Edit,
  NumberInput,
  SimpleForm,
  TextInput
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
export const UserEdit = () => {
  return /* @__PURE__ */ jsxDEV(Edit, { mutationMode: "pessimistic", redirect: "list", children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        flexDirection: "column",
        gap: 2,
        width: "100%"
      },
      children: /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            flexWrap: "wrap",
            gap: 2
          },
          children: [
            /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(TextInput, { source: "phoneNumber", label: "Phone", disabled: true, fullWidth: true }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 30,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 29,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(TextInput, { source: "name", label: "Name", disabled: true, fullWidth: true }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 33,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 32,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
              TextInput,
              {
                source: "lastName",
                label: "Last Name",
                disabled: true,
                fullWidth: true
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
                lineNumber: 36,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 35,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
              TextInput,
              {
                source: "createdAtdAt",
                label: "Joined",
                disabled: true,
                fullWidth: true
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
                lineNumber: 44,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 43,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(BooleanInput, { source: "isAdmin", label: "Admin", fullWidth: true }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 52,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 51,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(NumberInput, { source: "point", label: "Loyalty Points", min: 0, fullWidth: true }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 55,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
              lineNumber: 54,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
          lineNumber: 22,
          columnNumber: 11
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
      lineNumber: 14,
      columnNumber: 9
    },
    this
  ) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
};
_c = UserEdit;
var _c;
$RefreshReg$(_c, "UserEdit");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserEdit.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJjO0FBN0JkLE9BQU9BLFNBQVM7QUFDaEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRUEsYUFBTUMsV0FBV0EsTUFBTTtBQUM1QixTQUNFLHVCQUFDLFFBQUssY0FBYSxlQUFjLFVBQVMsUUFDeEMsaUNBQUMsY0FDQztBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsSUFBSTtBQUFBLFFBQ0ZDLFNBQVM7QUFBQSxRQUNUQyxlQUFlO0FBQUEsUUFDZkMsS0FBSztBQUFBLFFBQ0xDLE9BQU87QUFBQSxNQUNUO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBSTtBQUFBLFlBQ0ZILFNBQVM7QUFBQSxZQUNUSSxVQUFVO0FBQUEsWUFDVkYsS0FBSztBQUFBLFVBQ1A7QUFBQSxVQUVBO0FBQUEsbUNBQUMsT0FBSSxJQUFJLEVBQUVDLE9BQU8sRUFBRUUsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3RELGlDQUFDLGFBQVUsUUFBTyxlQUFjLE9BQU0sU0FBUSxVQUFRLE1BQUMsV0FBUyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFJLElBQUksRUFBRUgsT0FBTyxFQUFFRSxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQsaUNBQUMsYUFBVSxRQUFPLFFBQU8sT0FBTSxRQUFPLFVBQVEsTUFBQyxXQUFTLFFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdELEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFSCxPQUFPLEVBQUVFLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFFBQU87QUFBQSxnQkFDUCxPQUFNO0FBQUEsZ0JBQ047QUFBQSxnQkFDQSxXQUFTO0FBQUE7QUFBQSxjQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlXLEtBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxJQUFJLEVBQUVILE9BQU8sRUFBRUUsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsUUFBTztBQUFBLGdCQUNQLE9BQU07QUFBQSxnQkFDTjtBQUFBLGdCQUNBLFdBQVM7QUFBQTtBQUFBLGNBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSVcsS0FMYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxPQUFJLElBQUksRUFBRUgsT0FBTyxFQUFFRSxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQsaUNBQUMsZ0JBQWEsUUFBTyxXQUFVLE9BQU0sU0FBUSxXQUFTLFFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFSCxPQUFPLEVBQUVFLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RCxpQ0FBQyxlQUFZLFFBQU8sU0FBUSxPQUFNLGtCQUFpQixLQUFLLEdBQUcsV0FBUyxRQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRSxLQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQTtBQUFBLFFBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW1DQTtBQUFBO0FBQUEsSUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBNENBLEtBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4Q0EsS0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdEQTtBQUVKO0FBQUVDLEtBcERXUjtBQUFRLElBQUFRO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJveCIsIkJvb2xlYW5JbnB1dCIsIkVkaXQiLCJOdW1iZXJJbnB1dCIsIlNpbXBsZUZvcm0iLCJUZXh0SW5wdXQiLCJVc2VyRWRpdCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwid2lkdGgiLCJmbGV4V3JhcCIsInhzIiwibWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyRWRpdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcbmltcG9ydCB7XG4gIEJvb2xlYW5JbnB1dCxcbiAgRWRpdCxcbiAgTnVtYmVySW5wdXQsXG4gIFNpbXBsZUZvcm0sXG4gIFRleHRJbnB1dCxcbn0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5cbmV4cG9ydCBjb25zdCBVc2VyRWRpdCA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8RWRpdCBtdXRhdGlvbk1vZGU9XCJwZXNzaW1pc3RpY1wiIHJlZGlyZWN0PVwibGlzdFwiPlxuICAgICAgPFNpbXBsZUZvcm0+XG4gICAgICAgIDxCb3hcbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8Qm94XG4gICAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgZmxleFdyYXA6IFwid3JhcFwiLFxuICAgICAgICAgICAgICBnYXA6IDIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgICAgICA8VGV4dElucHV0IHNvdXJjZT1cInBob25lTnVtYmVyXCIgbGFiZWw9XCJQaG9uZVwiIGRpc2FibGVkIGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgPFRleHRJbnB1dCBzb3VyY2U9XCJuYW1lXCIgbGFiZWw9XCJOYW1lXCIgZGlzYWJsZWQgZnVsbFdpZHRoIC8+XG4gICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICAgICAgc291cmNlPVwibGFzdE5hbWVcIlxuICAgICAgICAgICAgICAgIGxhYmVsPVwiTGFzdCBOYW1lXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZFxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgICAgICAgIHNvdXJjZT1cImNyZWF0ZWRBdGRBdFwiXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJKb2luZWRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkXG4gICAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgICAgICA8Qm9vbGVhbklucHV0IHNvdXJjZT1cImlzQWRtaW5cIiBsYWJlbD1cIkFkbWluXCIgZnVsbFdpZHRoIC8+XG4gICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgICAgICA8TnVtYmVySW5wdXQgc291cmNlPVwicG9pbnRcIiBsYWJlbD1cIkxveWFsdHkgUG9pbnRzXCIgbWluPXswfSBmdWxsV2lkdGggLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L0JveD5cbiAgICAgIDwvU2ltcGxlRm9ybT5cbiAgICA8L0VkaXQ+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL3VzZXJzL1VzZXJFZGl0LnRzeCJ9