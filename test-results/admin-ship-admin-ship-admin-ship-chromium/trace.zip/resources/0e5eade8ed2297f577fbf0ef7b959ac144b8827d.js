import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/color-images/ColorImageEdit.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Edit, SimpleForm } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { ColorImageForm } from "/src/resources/color-images/ColorImageForm.tsx";
import { transformColorImageData } from "/src/resources/color-images/colorImageTransform.ts";
export const ColorImageEdit = () => {
  return /* @__PURE__ */ jsxDEV(
    Edit,
    {
      transform: transformColorImageData,
      mutationMode: "pessimistic",
      redirect: "list",
      children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(ColorImageForm, {}, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageEdit.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageEdit.tsx",
        lineNumber: 12,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageEdit.tsx",
      lineNumber: 7,
      columnNumber: 5
    },
    this
  );
};
_c = ColorImageEdit;
var _c;
$RefreshReg$(_c, "ColorImageEdit");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageEdit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageEdit.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageEdit.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7QUFaUixTQUFTQSxNQUFNQyxrQkFBa0I7QUFDakMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLCtCQUErQjtBQUVqQyxhQUFNQyxpQkFBaUJBLE1BQU07QUFDbEMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV0Q7QUFBQUEsTUFDWCxjQUFhO0FBQUEsTUFDYixVQUFTO0FBQUEsTUFFVCxpQ0FBQyxjQUNDLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQTtBQUFBLElBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUE7QUFFSjtBQUFFRSxLQVpXRDtBQUFjLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkVkaXQiLCJTaW1wbGVGb3JtIiwiQ29sb3JJbWFnZUZvcm0iLCJ0cmFuc2Zvcm1Db2xvckltYWdlRGF0YSIsIkNvbG9ySW1hZ2VFZGl0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29sb3JJbWFnZUVkaXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVkaXQsIFNpbXBsZUZvcm0gfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCB7IENvbG9ySW1hZ2VGb3JtIH0gZnJvbSBcIi4vQ29sb3JJbWFnZUZvcm1cIjtcbmltcG9ydCB7IHRyYW5zZm9ybUNvbG9ySW1hZ2VEYXRhIH0gZnJvbSBcIi4vY29sb3JJbWFnZVRyYW5zZm9ybVwiO1xuXG5leHBvcnQgY29uc3QgQ29sb3JJbWFnZUVkaXQgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEVkaXRcbiAgICAgIHRyYW5zZm9ybT17dHJhbnNmb3JtQ29sb3JJbWFnZURhdGF9XG4gICAgICBtdXRhdGlvbk1vZGU9XCJwZXNzaW1pc3RpY1wiXG4gICAgICByZWRpcmVjdD1cImxpc3RcIlxuICAgID5cbiAgICAgIDxTaW1wbGVGb3JtPlxuICAgICAgICA8Q29sb3JJbWFnZUZvcm0gLz5cbiAgICAgIDwvU2ltcGxlRm9ybT5cbiAgICA8L0VkaXQ+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2NvbG9yLWltYWdlcy9Db2xvckltYWdlRWRpdC50c3gifQ==