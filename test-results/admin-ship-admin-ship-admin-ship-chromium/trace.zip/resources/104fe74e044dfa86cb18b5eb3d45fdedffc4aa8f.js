import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SwatchOption.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useRecordContext, FunctionField } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import { ColorSwatch } from "/src/components/ColorSwatch.tsx";
export const SwatchOption = ({
  imageField,
  labelField,
  fallbackAlt = ""
}) => {
  _s();
  const record = useRecordContext();
  if (!record) return null;
  const label = record[labelField];
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        alignItems: "center",
        gap: 1
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          ColorSwatch,
          {
            src: record[imageField],
            alt: label || fallbackAlt,
            size: 24
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx",
            lineNumber: 30,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { children: label }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx",
          lineNumber: 35,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx",
      lineNumber: 23,
      columnNumber: 5
    },
    this
  );
};
_s(SwatchOption, "vquj8sjWea6OxDri+f+hy9sTw2k=", false, function() {
  return [useRecordContext];
});
_c = SwatchOption;
export const fieldInputText = (field) => (choice) => choice?.[field] || "";
export const fieldMatchSuggestion = (field) => (filter, choice) => {
  if (!filter) return true;
  return (choice?.[field] || "").toLowerCase().includes(filter.toLowerCase());
};
export const SwatchField = ({
  imageSource,
  labelSource,
  label = "Icon",
  size = 32
}) => /* @__PURE__ */ jsxDEV(
  FunctionField,
  {
    label,
    render: (record) => record?.[imageSource] ? /* @__PURE__ */ jsxDEV(
      ColorSwatch,
      {
        src: record[imageSource],
        alt: record[labelSource] || label,
        size
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx",
        lineNumber: 71,
        columnNumber: 3
      },
      this
    ) : "-"
  },
  void 0,
  false,
  {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx",
    lineNumber: 67,
    columnNumber: 1
  },
  this
);
_c2 = SwatchField;
var _c, _c2;
$RefreshReg$(_c, "SwatchOption");
$RefreshReg$(_c2, "SwatchField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/components/SwatchOption.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOztBQTdCTixTQUFTQSxrQkFBa0JDLHFCQUFxQjtBQUNoRCxPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLG1CQUFtQjtBQVNyQixhQUFNQyxlQUFlQSxDQUFDO0FBQUEsRUFDM0JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGNBQWM7QUFDRyxNQUFNO0FBQUFDLEtBQUE7QUFDdkIsUUFBTUMsU0FBU1QsaUJBQXFEO0FBQ3BFLE1BQUksQ0FBQ1MsT0FBUSxRQUFPO0FBRXBCLFFBQU1DLFFBQVFELE9BQU9ILFVBQVU7QUFFL0IsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsSUFBSTtBQUFBLFFBQ0ZLLFNBQVM7QUFBQSxRQUNUQyxZQUFZO0FBQUEsUUFDWkMsS0FBSztBQUFBLE1BQ1A7QUFBQSxNQUVBO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEtBQUtKLE9BQU9KLFVBQVU7QUFBQSxZQUN0QixLQUFLSyxTQUFTSDtBQUFBQSxZQUNkLE1BQU07QUFBQTtBQUFBLFVBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR1c7QUFBQSxRQUVYLHVCQUFDLFVBQU1HLG1CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYTtBQUFBO0FBQUE7QUFBQSxJQVpmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWFBO0FBRUo7QUFBRUYsR0ExQldKLGNBQVk7QUFBQSxVQUtSSixnQkFBZ0I7QUFBQTtBQUFBLEtBTHBCSTtBQTRCTixhQUFNVSxpQkFDWEEsQ0FBQ0MsVUFBa0IsQ0FBQ0MsV0FDbEJBLFNBQVNELEtBQUssS0FBSztBQUVoQixhQUFNRSx1QkFDWEEsQ0FBQ0YsVUFDRCxDQUFDRyxRQUFnQkYsV0FBc0Q7QUFDckUsTUFBSSxDQUFDRSxPQUFRLFFBQU87QUFDcEIsVUFBUUYsU0FBU0QsS0FBSyxLQUFLLElBQ3hCSSxZQUFZLEVBQ1pDLFNBQVNGLE9BQU9DLFlBQVksQ0FBQztBQUNsQztBQVVLLGFBQU1FLGNBQWNBLENBQUM7QUFBQSxFQUMxQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQWIsUUFBUTtBQUFBLEVBQ1JjLE9BQU87QUFDUyxNQUNoQjtBQUFBLEVBQUM7QUFBQTtBQUFBLElBQ0M7QUFBQSxJQUNBLFFBQVEsQ0FBQ2YsV0FDUEEsU0FBU2EsV0FBVyxJQUNsQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsS0FBS2IsT0FBT2EsV0FBVztBQUFBLFFBQ3ZCLEtBQUtiLE9BQU9jLFdBQVcsS0FBS2I7QUFBQUEsUUFDNUI7QUFBQTtBQUFBLE1BSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR2EsSUFHYjtBQUFBO0FBQUEsRUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWUc7QUFFSGUsTUFwQldKO0FBQVcsSUFBQUssSUFBQUQ7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVJlY29yZENvbnRleHQiLCJGdW5jdGlvbkZpZWxkIiwiQm94IiwiQ29sb3JTd2F0Y2giLCJTd2F0Y2hPcHRpb24iLCJpbWFnZUZpZWxkIiwibGFiZWxGaWVsZCIsImZhbGxiYWNrQWx0IiwiX3MiLCJyZWNvcmQiLCJsYWJlbCIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwiZmllbGRJbnB1dFRleHQiLCJmaWVsZCIsImNob2ljZSIsImZpZWxkTWF0Y2hTdWdnZXN0aW9uIiwiZmlsdGVyIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsIlN3YXRjaEZpZWxkIiwiaW1hZ2VTb3VyY2UiLCJsYWJlbFNvdXJjZSIsInNpemUiLCJfYzIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTd2F0Y2hPcHRpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlY29yZENvbnRleHQsIEZ1bmN0aW9uRmllbGQgfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCBCb3ggZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQm94XCI7XG5pbXBvcnQgeyBDb2xvclN3YXRjaCB9IGZyb20gXCIuL0NvbG9yU3dhdGNoXCI7XG5cbnR5cGUgU3dhdGNoT3B0aW9uUHJvcHMgPSB7XG4gIGltYWdlRmllbGQ6IHN0cmluZztcbiAgbGFiZWxGaWVsZDogc3RyaW5nO1xuICBmYWxsYmFja0FsdD86IHN0cmluZztcbn07XG5cbi8qKiBBdXRvY29tcGxldGUgb3B0aW9uIHJvdzogc3dhdGNoIGltYWdlICsgbGFiZWwgKi9cbmV4cG9ydCBjb25zdCBTd2F0Y2hPcHRpb24gPSAoe1xuICBpbWFnZUZpZWxkLFxuICBsYWJlbEZpZWxkLFxuICBmYWxsYmFja0FsdCA9IFwiXCIsXG59OiBTd2F0Y2hPcHRpb25Qcm9wcykgPT4ge1xuICBjb25zdCByZWNvcmQgPSB1c2VSZWNvcmRDb250ZXh0PFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IHVuZGVmaW5lZD4+KCk7XG4gIGlmICghcmVjb3JkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBsYWJlbCA9IHJlY29yZFtsYWJlbEZpZWxkXTtcblxuICByZXR1cm4gKFxuICAgIDxCb3hcbiAgICAgIHN4PXt7XG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICBnYXA6IDEsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxDb2xvclN3YXRjaFxuICAgICAgICBzcmM9e3JlY29yZFtpbWFnZUZpZWxkXX1cbiAgICAgICAgYWx0PXtsYWJlbCB8fCBmYWxsYmFja0FsdH1cbiAgICAgICAgc2l6ZT17MjR9XG4gICAgICAvPlxuICAgICAgPHNwYW4+e2xhYmVsfTwvc3Bhbj5cbiAgICA8L0JveD5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBmaWVsZElucHV0VGV4dCA9XG4gIChmaWVsZDogc3RyaW5nKSA9PiAoY2hvaWNlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCB1bmRlZmluZWQ+IHwgbnVsbCkgPT5cbiAgICBjaG9pY2U/LltmaWVsZF0gfHwgXCJcIjtcblxuZXhwb3J0IGNvbnN0IGZpZWxkTWF0Y2hTdWdnZXN0aW9uID1cbiAgKGZpZWxkOiBzdHJpbmcpID0+XG4gIChmaWx0ZXI6IHN0cmluZywgY2hvaWNlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCB1bmRlZmluZWQ+IHwgbnVsbCkgPT4ge1xuICAgIGlmICghZmlsdGVyKSByZXR1cm4gdHJ1ZTtcbiAgICByZXR1cm4gKGNob2ljZT8uW2ZpZWxkXSB8fCBcIlwiKVxuICAgICAgLnRvTG93ZXJDYXNlKClcbiAgICAgIC5pbmNsdWRlcyhmaWx0ZXIudG9Mb3dlckNhc2UoKSk7XG4gIH07XG5cbnR5cGUgU3dhdGNoRmllbGRQcm9wcyA9IHtcbiAgaW1hZ2VTb3VyY2U6IHN0cmluZztcbiAgbGFiZWxTb3VyY2U6IHN0cmluZztcbiAgbGFiZWw/OiBzdHJpbmc7XG4gIHNpemU/OiBudW1iZXI7XG59O1xuXG4vKiogRGF0YWdyaWQgY29sdW1uIHRoYXQgcmVuZGVycyBhIHN3YXRjaCAob3IgXCItXCIpICovXG5leHBvcnQgY29uc3QgU3dhdGNoRmllbGQgPSAoe1xuICBpbWFnZVNvdXJjZSxcbiAgbGFiZWxTb3VyY2UsXG4gIGxhYmVsID0gXCJJY29uXCIsXG4gIHNpemUgPSAzMixcbn06IFN3YXRjaEZpZWxkUHJvcHMpID0+IChcbiAgPEZ1bmN0aW9uRmllbGRcbiAgICBsYWJlbD17bGFiZWx9XG4gICAgcmVuZGVyPXsocmVjb3JkOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCB1bmRlZmluZWQ+KSA9PlxuICAgICAgcmVjb3JkPy5baW1hZ2VTb3VyY2VdID8gKFxuICAgICAgICA8Q29sb3JTd2F0Y2hcbiAgICAgICAgICBzcmM9e3JlY29yZFtpbWFnZVNvdXJjZV19XG4gICAgICAgICAgYWx0PXtyZWNvcmRbbGFiZWxTb3VyY2VdIHx8IGxhYmVsfVxuICAgICAgICAgIHNpemU9e3NpemV9XG4gICAgICAgIC8+XG4gICAgICApIDogKFxuICAgICAgICBcIi1cIlxuICAgICAgKVxuICAgIH1cbiAgLz5cbik7XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9jb21wb25lbnRzL1N3YXRjaE9wdGlvbi50c3gifQ==