import {
  generateUtilityClass,
  generateUtilityClasses
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Autocomplete/autocompleteClasses.mjs
function getAutocompleteUtilityClass(slot) {
  return generateUtilityClass("MuiAutocomplete", slot);
}
var autocompleteClasses = generateUtilityClasses("MuiAutocomplete", ["root", "expanded", "fullWidth", "focused", "focusVisible", "tag", "tagSizeSmall", "tagSizeMedium", "hasPopupIcon", "hasClearIcon", "inputRoot", "input", "inputFocused", "endAdornment", "clearIndicator", "popupIndicator", "popupIndicatorOpen", "popper", "popperDisablePortal", "paper", "listbox", "loading", "noOptions", "status", "option", "groupLabel", "groupUl"]);
var autocompleteClasses_default = autocompleteClasses;

export {
  getAutocompleteUtilityClass,
  autocompleteClasses_default
};
//# sourceMappingURL=chunk-LV56RCRM.js.map
