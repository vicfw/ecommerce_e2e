import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/brands/BrandForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { required, TextInput } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
export const BrandForm = () => {
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        flexDirection: "column",
        gap: 2
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "name",
                  label: "Name",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
                  lineNumber: 21,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
                lineNumber: 20,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "engName",
                  label: "English Name",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
                  lineNumber: 29,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
                lineNumber: 28,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
            lineNumber: 13,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "slug",
            label: "Slug",
            fullWidth: true,
            validate: required()
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
            lineNumber: 39,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
          lineNumber: 38,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx",
      lineNumber: 6,
      columnNumber: 5
    },
    this
  );
};
_c = BrandForm;
var _c;
$RefreshReg$(_c, "BrandForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JVO0FBcEJWLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxPQUFPQyxTQUFTO0FBRVQsYUFBTUMsWUFBWUEsTUFBTTtBQUM3QixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxJQUFJO0FBQUEsUUFDRkMsU0FBUztBQUFBLFFBQ1RDLGVBQWU7QUFBQSxRQUNmQyxLQUFLO0FBQUEsTUFDUDtBQUFBLE1BRUE7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSTtBQUFBLGNBQ0ZGLFNBQVM7QUFBQSxjQUNURyxVQUFVO0FBQUEsY0FDVkQsS0FBSztBQUFBLFlBQ1A7QUFBQSxZQUVBO0FBQUEscUNBQUMsT0FBSSxJQUFJLEVBQUVFLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFFBQU87QUFBQSxrQkFDUCxPQUFNO0FBQUEsa0JBQ047QUFBQSxrQkFDQSxVQUFVVixTQUFTO0FBQUE7QUFBQSxnQkFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVCLEtBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFUSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFPO0FBQUEsa0JBQ1AsT0FBTTtBQUFBLGtCQUNOO0FBQUEsa0JBQ0EsVUFBVVYsU0FBUztBQUFBO0FBQUEsZ0JBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1QixLQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXVCQTtBQUFBLFFBRUEsdUJBQUMsT0FBSSxJQUFJLEVBQUVRLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxRQUFPO0FBQUEsWUFDUCxPQUFNO0FBQUEsWUFDTjtBQUFBLFlBQ0EsVUFBVVYsU0FBUztBQUFBO0FBQUEsVUFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXVCLEtBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBO0FBQUE7QUFBQSxJQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3Q0E7QUFFSjtBQUFFVyxLQTVDV1I7QUFBUyxJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJyZXF1aXJlZCIsIlRleHRJbnB1dCIsIkJveCIsIkJyYW5kRm9ybSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiZmxleFdyYXAiLCJ3aWR0aCIsInhzIiwibWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCcmFuZEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHJlcXVpcmVkLCBUZXh0SW5wdXQgfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCBCb3ggZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQm94XCI7XG5cbmV4cG9ydCBjb25zdCBCcmFuZEZvcm0gPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEJveFxuICAgICAgc3g9e3tcbiAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgIGdhcDogMixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICBnYXA6IDIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgIDxUZXh0SW5wdXRcbiAgICAgICAgICAgIHNvdXJjZT1cIm5hbWVcIlxuICAgICAgICAgICAgbGFiZWw9XCJOYW1lXCJcbiAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgdmFsaWRhdGU9e3JlcXVpcmVkKCl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9Cb3g+XG4gICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgIDxUZXh0SW5wdXRcbiAgICAgICAgICAgIHNvdXJjZT1cImVuZ05hbWVcIlxuICAgICAgICAgICAgbGFiZWw9XCJFbmdsaXNoIE5hbWVcIlxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICB2YWxpZGF0ZT17cmVxdWlyZWQoKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cbiAgICAgIDwvQm94PlxuXG4gICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgIHNvdXJjZT1cInNsdWdcIlxuICAgICAgICAgIGxhYmVsPVwiU2x1Z1wiXG4gICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgdmFsaWRhdGU9e3JlcXVpcmVkKCl9XG4gICAgICAgIC8+XG4gICAgICA8L0JveD5cbiAgICA8L0JveD5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9yZXNvdXJjZXMvYnJhbmRzL0JyYW5kRm9ybS50c3gifQ==