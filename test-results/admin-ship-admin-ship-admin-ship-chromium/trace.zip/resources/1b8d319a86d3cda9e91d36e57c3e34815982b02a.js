import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Admin, CustomRoutes, Resource } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=49ae7072";
import { Route } from "/node_modules/.vite/deps/react-router-dom.js?v=49ae7072";
import {
  axiosDataProvider,
  queryClient
} from "/src/providers/ReactQueryDataProvider.tsx";
import {
  ProductCreate,
  ProductEdit,
  ProductList
} from "/src/resources/products/index.ts";
import {
  CategoryCreate,
  CategoryEdit,
  CategoryList
} from "/src/resources/categories/index.ts";
import {
  BrandCreate,
  BrandEdit,
  BrandList
} from "/src/resources/brands/index.ts";
import {
  ColorImageCreate,
  ColorImageEdit,
  ColorImageList
} from "/src/resources/color-images/index.ts";
import { BadgeCreate, BadgeEdit, BadgeList } from "/src/resources/badges/index.ts";
import { UserEdit, UserList } from "/src/resources/users/index.ts";
import { OrderList, OrderShow } from "/src/resources/orders/index.ts";
import { CommentList } from "/src/resources/comments/index.ts";
import { AppLayout } from "/src/layouts/AppLayout.tsx";
import { adminDarkTheme, adminLightTheme } from "/src/theme/adminTheme.ts";
import { Dashboard } from "/src/pages/Dashboard.tsx";
import { DeliveryCostSettings } from "/src/pages/DeliveryCostSettings.tsx";
import { HomepageEditor } from "/src/pages/HomepageEditor.tsx";
import { SiteLogoSettings } from "/src/pages/SiteLogoSettings.tsx";
import { LoginPage } from "/src/pages/Login.tsx";
import { authProvider } from "/src/providers/authProvider.ts";
function App() {
  const dataProvider = axiosDataProvider();
  return /* @__PURE__ */ jsxDEV(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxDEV(
    Admin,
    {
      title: "Ecommerce Admin",
      dataProvider,
      authProvider,
      loginPage: LoginPage,
      layout: AppLayout,
      dashboard: Dashboard,
      lightTheme: adminLightTheme,
      darkTheme: adminDarkTheme,
      defaultTheme: "light",
      children: [
        /* @__PURE__ */ jsxDEV(
          Resource,
          {
            name: "category",
            list: CategoryList,
            create: CategoryCreate,
            edit: CategoryEdit
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 57,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Resource,
          {
            name: "brand",
            list: BrandList,
            create: BrandCreate,
            edit: BrandEdit
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 63,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Resource,
          {
            name: "colorImage",
            list: ColorImageList,
            create: ColorImageCreate,
            edit: ColorImageEdit
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 69,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Resource,
          {
            name: "badge",
            list: BadgeList,
            create: BadgeCreate,
            edit: BadgeEdit
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 75,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Resource,
          {
            name: "product",
            list: ProductList,
            create: ProductCreate,
            edit: ProductEdit
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 81,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Resource, { name: "order", list: OrderList, show: OrderShow }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
          lineNumber: 87,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Resource, { name: "users", list: UserList, edit: UserEdit }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
          lineNumber: 88,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Resource, { name: "comment", list: CommentList }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
          lineNumber: 89,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(CustomRoutes, { children: [
          /* @__PURE__ */ jsxDEV(Route, { path: "/delivery-cost", element: /* @__PURE__ */ jsxDEV(DeliveryCostSettings, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 91,
            columnNumber: 49
          }, this) }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 91,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/homepage", element: /* @__PURE__ */ jsxDEV(HomepageEditor, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 92,
            columnNumber: 44
          }, this) }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 92,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "/site-logo", element: /* @__PURE__ */ jsxDEV(SiteLogoSettings, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 93,
            columnNumber: 45
          }, this) }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
            lineNumber: 93,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
          lineNumber: 90,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
      lineNumber: 46,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/App.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RRO0FBeERSLFNBQVNBLE9BQU9DLGNBQWNDLGdCQUFnQjtBQUM5QyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxhQUFhQyxXQUFXQyxpQkFBaUI7QUFDbEQsU0FBU0MsVUFBVUMsZ0JBQWdCO0FBQ25DLFNBQVNDLFdBQVdDLGlCQUFpQjtBQUNyQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGdCQUFnQkMsdUJBQXVCO0FBQ2hELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msb0JBQW9CO0FBRTdCLFNBQVNDLE1BQU07QUFDYixRQUFNQyxlQUFlaEMsa0JBQWtCO0FBRXZDLFNBQ0UsdUJBQUMsdUJBQW9CLFFBQVFDLGFBQzNCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFNO0FBQUEsTUFDTjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVc0QjtBQUFBQSxNQUNYLFFBQVFQO0FBQUFBLE1BQ1IsV0FBV0c7QUFBQUEsTUFDWCxZQUFZRDtBQUFBQSxNQUNaLFdBQVdEO0FBQUFBLE1BQ1gsY0FBYTtBQUFBLE1BRWI7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBTWhCO0FBQUFBLFlBQ04sUUFBUUY7QUFBQUEsWUFDUixNQUFNQztBQUFBQTtBQUFBQSxVQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlxQjtBQUFBLFFBRXJCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxNQUFNSTtBQUFBQSxZQUNOLFFBQVFGO0FBQUFBLFlBQ1IsTUFBTUM7QUFBQUE7QUFBQUEsVUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJa0I7QUFBQSxRQUVsQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBTUk7QUFBQUEsWUFDTixRQUFRRjtBQUFBQSxZQUNSLE1BQU1DO0FBQUFBO0FBQUFBLFVBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXVCO0FBQUEsUUFFdkI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE1BQU1JO0FBQUFBLFlBQ04sUUFBUUY7QUFBQUEsWUFDUixNQUFNQztBQUFBQTtBQUFBQSxVQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlrQjtBQUFBLFFBRWxCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxNQUFNWDtBQUFBQSxZQUNOLFFBQVFGO0FBQUFBLFlBQ1IsTUFBTUM7QUFBQUE7QUFBQUEsVUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJb0I7QUFBQSxRQUVwQix1QkFBQyxZQUFTLE1BQUssU0FBUSxNQUFNZ0IsV0FBVyxNQUFNQyxhQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFDeEQsdUJBQUMsWUFBUyxNQUFLLFNBQVEsTUFBTUYsVUFBVSxNQUFNRCxZQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNEO0FBQUEsUUFDdEQsdUJBQUMsWUFBUyxNQUFLLFdBQVUsTUFBTUksZUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQztBQUFBLFFBQzNDLHVCQUFDLGdCQUNDO0FBQUEsaUNBQUMsU0FBTSxNQUFLLGtCQUFpQixTQUFTLHVCQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDL0QsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsU0FBTSxNQUFLLGNBQWEsU0FBUyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQixLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBO0FBQUE7QUFBQSxJQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpREEsS0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1EQTtBQUVKO0FBQUNZLEtBekRRRjtBQTJEVCxlQUFlQTtBQUFJLElBQUFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFkbWluIiwiQ3VzdG9tUm91dGVzIiwiUmVzb3VyY2UiLCJRdWVyeUNsaWVudFByb3ZpZGVyIiwiUm91dGUiLCJheGlvc0RhdGFQcm92aWRlciIsInF1ZXJ5Q2xpZW50IiwiUHJvZHVjdENyZWF0ZSIsIlByb2R1Y3RFZGl0IiwiUHJvZHVjdExpc3QiLCJDYXRlZ29yeUNyZWF0ZSIsIkNhdGVnb3J5RWRpdCIsIkNhdGVnb3J5TGlzdCIsIkJyYW5kQ3JlYXRlIiwiQnJhbmRFZGl0IiwiQnJhbmRMaXN0IiwiQ29sb3JJbWFnZUNyZWF0ZSIsIkNvbG9ySW1hZ2VFZGl0IiwiQ29sb3JJbWFnZUxpc3QiLCJCYWRnZUNyZWF0ZSIsIkJhZGdlRWRpdCIsIkJhZGdlTGlzdCIsIlVzZXJFZGl0IiwiVXNlckxpc3QiLCJPcmRlckxpc3QiLCJPcmRlclNob3ciLCJDb21tZW50TGlzdCIsIkFwcExheW91dCIsImFkbWluRGFya1RoZW1lIiwiYWRtaW5MaWdodFRoZW1lIiwiRGFzaGJvYXJkIiwiRGVsaXZlcnlDb3N0U2V0dGluZ3MiLCJIb21lcGFnZUVkaXRvciIsIlNpdGVMb2dvU2V0dGluZ3MiLCJMb2dpblBhZ2UiLCJhdXRoUHJvdmlkZXIiLCJBcHAiLCJkYXRhUHJvdmlkZXIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFkbWluLCBDdXN0b21Sb3V0ZXMsIFJlc291cmNlIH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQgeyBRdWVyeUNsaWVudFByb3ZpZGVyIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xuaW1wb3J0IHsgUm91dGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHtcbiAgYXhpb3NEYXRhUHJvdmlkZXIsXG4gIHF1ZXJ5Q2xpZW50LFxufSBmcm9tIFwiLi9wcm92aWRlcnMvUmVhY3RRdWVyeURhdGFQcm92aWRlclwiO1xuaW1wb3J0IHtcbiAgUHJvZHVjdENyZWF0ZSxcbiAgUHJvZHVjdEVkaXQsXG4gIFByb2R1Y3RMaXN0LFxufSBmcm9tIFwiLi9yZXNvdXJjZXMvcHJvZHVjdHNcIjtcbmltcG9ydCB7XG4gIENhdGVnb3J5Q3JlYXRlLFxuICBDYXRlZ29yeUVkaXQsXG4gIENhdGVnb3J5TGlzdCxcbn0gZnJvbSBcIi4vcmVzb3VyY2VzL2NhdGVnb3JpZXNcIjtcbmltcG9ydCB7XG4gIEJyYW5kQ3JlYXRlLFxuICBCcmFuZEVkaXQsXG4gIEJyYW5kTGlzdCxcbn0gZnJvbSBcIi4vcmVzb3VyY2VzL2JyYW5kc1wiO1xuaW1wb3J0IHtcbiAgQ29sb3JJbWFnZUNyZWF0ZSxcbiAgQ29sb3JJbWFnZUVkaXQsXG4gIENvbG9ySW1hZ2VMaXN0LFxufSBmcm9tIFwiLi9yZXNvdXJjZXMvY29sb3ItaW1hZ2VzXCI7XG5pbXBvcnQgeyBCYWRnZUNyZWF0ZSwgQmFkZ2VFZGl0LCBCYWRnZUxpc3QgfSBmcm9tIFwiLi9yZXNvdXJjZXMvYmFkZ2VzXCI7XG5pbXBvcnQgeyBVc2VyRWRpdCwgVXNlckxpc3QgfSBmcm9tIFwiLi9yZXNvdXJjZXMvdXNlcnNcIjtcbmltcG9ydCB7IE9yZGVyTGlzdCwgT3JkZXJTaG93IH0gZnJvbSBcIi4vcmVzb3VyY2VzL29yZGVyc1wiO1xuaW1wb3J0IHsgQ29tbWVudExpc3QgfSBmcm9tIFwiLi9yZXNvdXJjZXMvY29tbWVudHNcIjtcbmltcG9ydCB7IEFwcExheW91dCB9IGZyb20gXCIuL2xheW91dHMvQXBwTGF5b3V0XCI7XG5pbXBvcnQgeyBhZG1pbkRhcmtUaGVtZSwgYWRtaW5MaWdodFRoZW1lIH0gZnJvbSBcIi4vdGhlbWUvYWRtaW5UaGVtZVwiO1xuaW1wb3J0IHsgRGFzaGJvYXJkIH0gZnJvbSBcIi4vcGFnZXMvRGFzaGJvYXJkXCI7XG5pbXBvcnQgeyBEZWxpdmVyeUNvc3RTZXR0aW5ncyB9IGZyb20gXCIuL3BhZ2VzL0RlbGl2ZXJ5Q29zdFNldHRpbmdzXCI7XG5pbXBvcnQgeyBIb21lcGFnZUVkaXRvciB9IGZyb20gXCIuL3BhZ2VzL0hvbWVwYWdlRWRpdG9yXCI7XG5pbXBvcnQgeyBTaXRlTG9nb1NldHRpbmdzIH0gZnJvbSBcIi4vcGFnZXMvU2l0ZUxvZ29TZXR0aW5nc1wiO1xuaW1wb3J0IHsgTG9naW5QYWdlIH0gZnJvbSBcIi4vcGFnZXMvTG9naW5cIjtcbmltcG9ydCB7IGF1dGhQcm92aWRlciB9IGZyb20gXCIuL3Byb3ZpZGVycy9hdXRoUHJvdmlkZXJcIjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBkYXRhUHJvdmlkZXIgPSBheGlvc0RhdGFQcm92aWRlcigpO1xuXG4gIHJldHVybiAoXG4gICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XG4gICAgICA8QWRtaW5cbiAgICAgICAgdGl0bGU9XCJFY29tbWVyY2UgQWRtaW5cIlxuICAgICAgICBkYXRhUHJvdmlkZXI9e2RhdGFQcm92aWRlcn1cbiAgICAgICAgYXV0aFByb3ZpZGVyPXthdXRoUHJvdmlkZXJ9XG4gICAgICAgIGxvZ2luUGFnZT17TG9naW5QYWdlfVxuICAgICAgICBsYXlvdXQ9e0FwcExheW91dH1cbiAgICAgICAgZGFzaGJvYXJkPXtEYXNoYm9hcmR9XG4gICAgICAgIGxpZ2h0VGhlbWU9e2FkbWluTGlnaHRUaGVtZX1cbiAgICAgICAgZGFya1RoZW1lPXthZG1pbkRhcmtUaGVtZX1cbiAgICAgICAgZGVmYXVsdFRoZW1lPVwibGlnaHRcIlxuICAgICAgPlxuICAgICAgICA8UmVzb3VyY2VcbiAgICAgICAgICBuYW1lPVwiY2F0ZWdvcnlcIlxuICAgICAgICAgIGxpc3Q9e0NhdGVnb3J5TGlzdH1cbiAgICAgICAgICBjcmVhdGU9e0NhdGVnb3J5Q3JlYXRlfVxuICAgICAgICAgIGVkaXQ9e0NhdGVnb3J5RWRpdH1cbiAgICAgICAgLz5cbiAgICAgICAgPFJlc291cmNlXG4gICAgICAgICAgbmFtZT1cImJyYW5kXCJcbiAgICAgICAgICBsaXN0PXtCcmFuZExpc3R9XG4gICAgICAgICAgY3JlYXRlPXtCcmFuZENyZWF0ZX1cbiAgICAgICAgICBlZGl0PXtCcmFuZEVkaXR9XG4gICAgICAgIC8+XG4gICAgICAgIDxSZXNvdXJjZVxuICAgICAgICAgIG5hbWU9XCJjb2xvckltYWdlXCJcbiAgICAgICAgICBsaXN0PXtDb2xvckltYWdlTGlzdH1cbiAgICAgICAgICBjcmVhdGU9e0NvbG9ySW1hZ2VDcmVhdGV9XG4gICAgICAgICAgZWRpdD17Q29sb3JJbWFnZUVkaXR9XG4gICAgICAgIC8+XG4gICAgICAgIDxSZXNvdXJjZVxuICAgICAgICAgIG5hbWU9XCJiYWRnZVwiXG4gICAgICAgICAgbGlzdD17QmFkZ2VMaXN0fVxuICAgICAgICAgIGNyZWF0ZT17QmFkZ2VDcmVhdGV9XG4gICAgICAgICAgZWRpdD17QmFkZ2VFZGl0fVxuICAgICAgICAvPlxuICAgICAgICA8UmVzb3VyY2VcbiAgICAgICAgICBuYW1lPVwicHJvZHVjdFwiXG4gICAgICAgICAgbGlzdD17UHJvZHVjdExpc3R9XG4gICAgICAgICAgY3JlYXRlPXtQcm9kdWN0Q3JlYXRlfVxuICAgICAgICAgIGVkaXQ9e1Byb2R1Y3RFZGl0fVxuICAgICAgICAvPlxuICAgICAgICA8UmVzb3VyY2UgbmFtZT1cIm9yZGVyXCIgbGlzdD17T3JkZXJMaXN0fSBzaG93PXtPcmRlclNob3d9IC8+XG4gICAgICAgIDxSZXNvdXJjZSBuYW1lPVwidXNlcnNcIiBsaXN0PXtVc2VyTGlzdH0gZWRpdD17VXNlckVkaXR9IC8+XG4gICAgICAgIDxSZXNvdXJjZSBuYW1lPVwiY29tbWVudFwiIGxpc3Q9e0NvbW1lbnRMaXN0fSAvPlxuICAgICAgICA8Q3VzdG9tUm91dGVzPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2RlbGl2ZXJ5LWNvc3RcIiBlbGVtZW50PXs8RGVsaXZlcnlDb3N0U2V0dGluZ3MgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaG9tZXBhZ2VcIiBlbGVtZW50PXs8SG9tZXBhZ2VFZGl0b3IgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvc2l0ZS1sb2dvXCIgZWxlbWVudD17PFNpdGVMb2dvU2V0dGluZ3MgLz59IC8+XG4gICAgICAgIDwvQ3VzdG9tUm91dGVzPlxuICAgICAgPC9BZG1pbj5cbiAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL0FwcC50c3gifQ==