import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/orders/OrderShow.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
import Table from "/node_modules/.vite/deps/@mui_material_Table.js?v=49ae7072";
import TableBody from "/node_modules/.vite/deps/@mui_material_TableBody.js?v=49ae7072";
import TableCell from "/node_modules/.vite/deps/@mui_material_TableCell.js?v=49ae7072";
import TableHead from "/node_modules/.vite/deps/@mui_material_TableHead.js?v=49ae7072";
import TableRow from "/node_modules/.vite/deps/@mui_material_TableRow.js?v=49ae7072";
import Chip from "/node_modules/.vite/deps/@mui_material_Chip.js?v=49ae7072";
import {
  Show,
  SelectInput,
  SaveButton,
  SimpleForm,
  Toolbar,
  useRecordContext,
  useUpdate,
  useNotify,
  useRefresh
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { ORDER_STATUS_CHOICES } from "/src/lib/orderStatus.ts";
import { parseOrderItems } from "/src/lib/orderItems.ts";
const OrderStatusForm = () => {
  _s();
  const record = useRecordContext();
  const [update, { isPending }] = useUpdate();
  const notify = useNotify();
  const refresh = useRefresh();
  if (!record) return null;
  return /* @__PURE__ */ jsxDEV(
    SimpleForm,
    {
      record,
      toolbar: /* @__PURE__ */ jsxDEV(Toolbar, { children: /* @__PURE__ */ jsxDEV(SaveButton, { label: "Update Status", disabled: isPending }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 37,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 36,
        columnNumber: 7
      }, this),
      onSubmit: async (data) => {
        try {
          await update("order", {
            id: record.id,
            data: { status: data.status },
            previousData: record
          });
          notify("Order status updated", { type: "success" });
          refresh();
        } catch {
          notify("Failed to update order status", { type: "error" });
        }
      },
      children: /* @__PURE__ */ jsxDEV(SelectInput, { source: "status", choices: ORDER_STATUS_CHOICES, fullWidth: true }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 54,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 33,
      columnNumber: 5
    },
    this
  );
};
_s(OrderStatusForm, "zJ/MfWkNsiW97pJKaWloY3EP7iE=", false, function() {
  return [useRecordContext, useUpdate, useNotify, useRefresh];
});
_c = OrderStatusForm;
const DetailRow = ({
  label,
  value
}) => /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexDirection: "column", gap: 0.5 }, children: [
  /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: label }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
    lineNumber: 67,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", children: value }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
    lineNumber: 70,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
  lineNumber: 66,
  columnNumber: 1
}, this);
_c2 = DetailRow;
const OrderItemsTable = () => {
  _s2();
  const record = useRecordContext();
  const items = parseOrderItems(record?.orderItem);
  if (items.length === 0) {
    return /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "No items" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 80,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Table, { size: "small", children: [
    /* @__PURE__ */ jsxDEV(TableHead, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
      /* @__PURE__ */ jsxDEV(TableCell, { children: "Product" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 90,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Qty" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 91,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Price" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 92,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableBody, { children: items.map(
      (item, index) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { children: item.product?.prName || item.product?.enName || "-" }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 98,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: item.quantity }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 101,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: item.itemPrice?.toLocaleString() }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 102,
          columnNumber: 13
        }, this)
      ] }, index, true, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
    lineNumber: 87,
    columnNumber: 5
  }, this);
};
_s2(OrderItemsTable, "vquj8sjWea6OxDri+f+hy9sTw2k=", false, function() {
  return [useRecordContext];
});
_c3 = OrderItemsTable;
const OrderDetails = () => {
  _s3();
  const record = useRecordContext();
  if (!record) return null;
  const customerName = [record.user?.name, record.user?.lastName].filter(Boolean).join(" ") || "-";
  const receiverName = [record.address?.receiverName, record.address?.receiverLastName].filter(Boolean).join(" ") || "-";
  const fullAddress = record.address ? [record.address.province, record.address.city, record.address.street, record.address.address].filter(Boolean).join(", ") : "-";
  return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 2, display: "flex", flexDirection: "column", gap: 3 }, children: [
    /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 3 }, children: [
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            flex: 1,
            minWidth: 280,
            p: 2,
            borderRadius: 2,
            border: "1px solid",
            borderColor: "divider",
            display: "flex",
            flexDirection: "column",
            gap: 2
          },
          children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700 }, children: "Order Summary" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 168,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(DetailRow, { label: "Order ID", value: record.id }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 171,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Status",
                value: /* @__PURE__ */ jsxDEV(Chip, { label: record.status, size: "small" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                  lineNumber: 174,
                  columnNumber: 20
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 172,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Inventory",
                value: record.inventoryStatus || "-"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 176,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Total Amount",
                value: record.totalAmount?.toLocaleString() ?? "-"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 180,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Delivery Amount",
                value: record.deliveryAmount?.toLocaleString() ?? "-"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 184,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Profit from Discount",
                value: record.profitFromDiscount?.toLocaleString() ?? "-"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 188,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Created",
                value: record.createdAt ? new Date(record.createdAt).toLocaleString() : "-"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 192,
                columnNumber: 11
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 155,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            flex: 1,
            minWidth: 280,
            p: 2,
            borderRadius: 2,
            border: "1px solid",
            borderColor: "divider"
          },
          children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700, mb: 2 }, children: "Update Status" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 212,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(OrderStatusForm, {}, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 215,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 202,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 154,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 3 }, children: [
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            flex: 1,
            minWidth: 280,
            p: 2,
            borderRadius: 2,
            border: "1px solid",
            borderColor: "divider",
            display: "flex",
            flexDirection: "column",
            gap: 2
          },
          children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700 }, children: "Customer" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 233,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(DetailRow, { label: "Name", value: customerName }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 236,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(DetailRow, { label: "Phone", value: record.user?.phoneNumber || "-" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 237,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(DetailRow, { label: "Points", value: record.user?.point ?? "-" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 238,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 220,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            flex: 1,
            minWidth: 280,
            p: 2,
            borderRadius: 2,
            border: "1px solid",
            borderColor: "divider",
            display: "flex",
            flexDirection: "column",
            gap: 2
          },
          children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700 }, children: "Shipping Address" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 254,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(DetailRow, { label: "Receiver", value: receiverName }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 257,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              DetailRow,
              {
                label: "Phone",
                value: record.address?.receiverPhoneNumber || "-"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
                lineNumber: 258,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(DetailRow, { label: "Address", value: fullAddress }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
              lineNumber: 262,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
          lineNumber: 241,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
      lineNumber: 219,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          p: 2,
          borderRadius: 2,
          border: "1px solid",
          borderColor: "divider"
        },
        children: [
          /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700, mb: 2 }, children: "Line Items" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
            lineNumber: 274,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(OrderItemsTable, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
            lineNumber: 277,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
        lineNumber: 266,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
    lineNumber: 153,
    columnNumber: 5
  }, this);
};
_s3(OrderDetails, "vquj8sjWea6OxDri+f+hy9sTw2k=", false, function() {
  return [useRecordContext];
});
_c4 = OrderDetails;
export const OrderShow = () => {
  return /* @__PURE__ */ jsxDEV(Show, { children: /* @__PURE__ */ jsxDEV(OrderDetails, {}, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
    lineNumber: 286,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx",
    lineNumber: 285,
    columnNumber: 5
  }, this);
};
_c5 = OrderShow;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "OrderStatusForm");
$RefreshReg$(_c2, "DetailRow");
$RefreshReg$(_c3, "OrderItemsTable");
$RefreshReg$(_c4, "OrderDetails");
$RefreshReg$(_c5, "OrderShow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/orders/OrderShow.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NVOztBQW5DVixPQUFPQSxTQUFTO0FBQ2hCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsVUFBVTtBQUNqQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsdUJBQXVCO0FBRWhDLE1BQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU1DLFNBQVNSLGlCQUFrRDtBQUNqRSxRQUFNLENBQUNTLFFBQVEsRUFBRUMsVUFBVSxDQUFDLElBQUlULFVBQVU7QUFDMUMsUUFBTVUsU0FBU1QsVUFBVTtBQUN6QixRQUFNVSxVQUFVVCxXQUFXO0FBRTNCLE1BQUksQ0FBQ0ssT0FBUSxRQUFPO0FBRXBCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxTQUNFLHVCQUFDLFdBQ0MsaUNBQUMsY0FBVyxPQUFNLGlCQUFnQixVQUFVRSxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYsVUFBVSxPQUFPRyxTQUFrQztBQUNqRCxZQUFJO0FBQ0YsZ0JBQU1KLE9BQU8sU0FBUztBQUFBLFlBQ3BCSyxJQUFJTixPQUFPTTtBQUFBQSxZQUNYRCxNQUFNLEVBQUVFLFFBQVFGLEtBQUtFLE9BQWlCO0FBQUEsWUFDdENDLGNBQWNSO0FBQUFBLFVBQ2hCLENBQUM7QUFDREcsaUJBQU8sd0JBQXdCLEVBQUVNLE1BQU0sVUFBVSxDQUFDO0FBQ2xETCxrQkFBUTtBQUFBLFFBQ1YsUUFBUTtBQUNORCxpQkFBTyxpQ0FBaUMsRUFBRU0sTUFBTSxRQUFRLENBQUM7QUFBQSxRQUMzRDtBQUFBLE1BQ0Y7QUFBQSxNQUVBLGlDQUFDLGVBQVksUUFBTyxVQUFTLFNBQVNiLHNCQUFzQixXQUFTLFFBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQTtBQUFBLElBckJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFzQkE7QUFFSjtBQUFFRyxHQWpDSUQsaUJBQWU7QUFBQSxVQUNKTixrQkFDaUJDLFdBQ2pCQyxXQUNDQyxVQUFVO0FBQUE7QUFBQSxLQUp0Qkc7QUFtQ04sTUFBTVksWUFBWUEsQ0FBQztBQUFBLEVBQ2pCQztBQUFBQSxFQUNBQztBQUlGLE1BQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVDLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLElBQUksR0FDNUQ7QUFBQSx5QkFBQyxjQUFXLFNBQVEsV0FBVSxPQUFNLGtCQUNqQ0osbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQUEsRUFDQSx1QkFBQyxjQUFXLFNBQVEsU0FBU0MsbUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUM7QUFBQSxLQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BS0E7QUFDQUksTUFiSU47QUFlTixNQUFNTyxrQkFBa0JBLE1BQU07QUFBQUMsTUFBQTtBQUM1QixRQUFNbEIsU0FBU1IsaUJBQTBDO0FBQ3pELFFBQU0yQixRQUFRdEIsZ0JBQWdCRyxRQUFRb0IsU0FBUztBQUUvQyxNQUFJRCxNQUFNRSxXQUFXLEdBQUc7QUFDdEIsV0FDRSx1QkFBQyxjQUFXLFNBQVEsU0FBUSxPQUFNLGtCQUFnQix3QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FBTSxNQUFLLFNBQ1Y7QUFBQSwyQkFBQyxhQUNDLGlDQUFDLFlBQ0M7QUFBQSw2QkFBQyxhQUFVLHVCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0I7QUFBQSxNQUNsQix1QkFBQyxhQUFVLE9BQU0sU0FBUSxtQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLE1BQzVCLHVCQUFDLGFBQVUsT0FBTSxTQUFRLHFCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsU0FIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFDQSx1QkFBQyxhQUNFRixnQkFBTUc7QUFBQUEsTUFBSSxDQUFDQyxNQUFNQyxVQUNoQix1QkFBQyxZQUNDO0FBQUEsK0JBQUMsYUFDRUQsZUFBS0UsU0FBU0MsVUFBVUgsS0FBS0UsU0FBU0UsVUFBVSxPQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGFBQVUsT0FBTSxTQUFTSixlQUFLSyxZQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsYUFBVSxPQUFNLFNBQ2RMLGVBQUtNLFdBQVdDLGVBQWUsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQYU4sT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxJQUNELEtBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCQTtBQUVKO0FBQUVOLElBcENJRCxpQkFBZTtBQUFBLFVBQ0p6QixnQkFBZ0I7QUFBQTtBQUFBLE1BRDNCeUI7QUFzQ04sTUFBTWMsZUFBZUEsTUFBTTtBQUFBQyxNQUFBO0FBQ3pCLFFBQU1oQyxTQUFTUixpQkF1Qlo7QUFFSCxNQUFJLENBQUNRLE9BQVEsUUFBTztBQUVwQixRQUFNaUMsZUFDSixDQUFDakMsT0FBT2tDLE1BQU1DLE1BQU1uQyxPQUFPa0MsTUFBTUUsUUFBUSxFQUFFQyxPQUFPQyxPQUFPLEVBQUVDLEtBQUssR0FBRyxLQUFLO0FBQzFFLFFBQU1DLGVBQ0osQ0FBQ3hDLE9BQU95QyxTQUFTRCxjQUFjeEMsT0FBT3lDLFNBQVNDLGdCQUFnQixFQUM1REwsT0FBT0MsT0FBTyxFQUNkQyxLQUFLLEdBQUcsS0FBSztBQUNsQixRQUFNSSxjQUFjM0MsT0FBT3lDLFVBQ3ZCLENBQUN6QyxPQUFPeUMsUUFBUUcsVUFBVTVDLE9BQU95QyxRQUFRSSxNQUFNN0MsT0FBT3lDLFFBQVFLLFFBQVE5QyxPQUFPeUMsUUFBUUEsT0FBTyxFQUN6RkosT0FBT0MsT0FBTyxFQUNkQyxLQUFLLElBQUksSUFDWjtBQUVKLFNBQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVRLEdBQUcsR0FBR2xDLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLEVBQUUsR0FDaEU7QUFBQSwyQkFBQyxPQUFJLElBQUksRUFBRUYsU0FBUyxRQUFRbUMsVUFBVSxRQUFRakMsS0FBSyxFQUFFLEdBQ25EO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUk7QUFBQSxZQUNGa0MsTUFBTTtBQUFBLFlBQ05DLFVBQVU7QUFBQSxZQUNWSCxHQUFHO0FBQUEsWUFDSEksY0FBYztBQUFBLFlBQ2RDLFFBQVE7QUFBQSxZQUNSQyxhQUFhO0FBQUEsWUFDYnhDLFNBQVM7QUFBQSxZQUNUQyxlQUFlO0FBQUEsWUFDZkMsS0FBSztBQUFBLFVBQ1A7QUFBQSxVQUVBO0FBQUEsbUNBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFdUMsWUFBWSxJQUFJLEdBQUUsNkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGFBQVUsT0FBTSxZQUFXLE9BQU90RCxPQUFPTSxNQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU8sdUJBQUMsUUFBSyxPQUFPTixPQUFPTyxRQUFRLE1BQUssV0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0M7QUFBQTtBQUFBLGNBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUVxRDtBQUFBLFlBRXJEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU9QLE9BQU91RCxtQkFBbUI7QUFBQTtBQUFBLGNBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUV1QztBQUFBLFlBRXZDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU92RCxPQUFPd0QsYUFBYTFCLGVBQWUsS0FBSztBQUFBO0FBQUEsY0FGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRXFEO0FBQUEsWUFFckQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sT0FBTzlCLE9BQU95RCxnQkFBZ0IzQixlQUFlLEtBQUs7QUFBQTtBQUFBLGNBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUV3RDtBQUFBLFlBRXhEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU85QixPQUFPMEQsb0JBQW9CNUIsZUFBZSxLQUFLO0FBQUE7QUFBQSxjQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFNEQ7QUFBQSxZQUU1RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTixPQUNFOUIsT0FBTzJELFlBQ0gsSUFBSUMsS0FBSzVELE9BQU8yRCxTQUFTLEVBQUU3QixlQUFlLElBQzFDO0FBQUE7QUFBQSxjQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1HO0FBQUE7QUFBQTtBQUFBLFFBM0NMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTZDQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUk7QUFBQSxZQUNGbUIsTUFBTTtBQUFBLFlBQ05DLFVBQVU7QUFBQSxZQUNWSCxHQUFHO0FBQUEsWUFDSEksY0FBYztBQUFBLFlBQ2RDLFFBQVE7QUFBQSxZQUNSQyxhQUFhO0FBQUEsVUFDZjtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxjQUFXLFNBQVEsTUFBSyxJQUFJLEVBQUVDLFlBQVksS0FBS08sSUFBSSxFQUFFLEdBQUUsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUE7QUFBQTtBQUFBLFFBYmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWNBO0FBQUEsU0E5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStEQTtBQUFBLElBRUEsdUJBQUMsT0FBSSxJQUFJLEVBQUVoRCxTQUFTLFFBQVFtQyxVQUFVLFFBQVFqQyxLQUFLLEVBQUUsR0FDbkQ7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBSTtBQUFBLFlBQ0ZrQyxNQUFNO0FBQUEsWUFDTkMsVUFBVTtBQUFBLFlBQ1ZILEdBQUc7QUFBQSxZQUNISSxjQUFjO0FBQUEsWUFDZEMsUUFBUTtBQUFBLFlBQ1JDLGFBQWE7QUFBQSxZQUNieEMsU0FBUztBQUFBLFlBQ1RDLGVBQWU7QUFBQSxZQUNmQyxLQUFLO0FBQUEsVUFDUDtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxjQUFXLFNBQVEsTUFBSyxJQUFJLEVBQUV1QyxZQUFZLElBQUksR0FBRSx3QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxPQUFNLFFBQU8sT0FBT3JCLGdCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLFlBQzVDLHVCQUFDLGFBQVUsT0FBTSxTQUFRLE9BQU9qQyxPQUFPa0MsTUFBTTRCLGVBQWUsT0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxZQUNoRSx1QkFBQyxhQUFVLE9BQU0sVUFBUyxPQUFPOUQsT0FBT2tDLE1BQU02QixTQUFTLE9BQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUE7QUFBQTtBQUFBLFFBbEI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFtQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJO0FBQUEsWUFDRmQsTUFBTTtBQUFBLFlBQ05DLFVBQVU7QUFBQSxZQUNWSCxHQUFHO0FBQUEsWUFDSEksY0FBYztBQUFBLFlBQ2RDLFFBQVE7QUFBQSxZQUNSQyxhQUFhO0FBQUEsWUFDYnhDLFNBQVM7QUFBQSxZQUNUQyxlQUFlO0FBQUEsWUFDZkMsS0FBSztBQUFBLFVBQ1A7QUFBQSxVQUVBO0FBQUEsbUNBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFdUMsWUFBWSxJQUFJLEdBQUUsZ0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGFBQVUsT0FBTSxZQUFXLE9BQU9kLGdCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQ2hEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU94QyxPQUFPeUMsU0FBU3VCLHVCQUF1QjtBQUFBO0FBQUEsY0FGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRW9EO0FBQUEsWUFFcEQsdUJBQUMsYUFBVSxPQUFNLFdBQVUsT0FBT3JCLGVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDO0FBQUE7QUFBQTtBQUFBLFFBckJoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzQkE7QUFBQSxTQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkNBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBSTtBQUFBLFVBQ0ZJLEdBQUc7QUFBQSxVQUNISSxjQUFjO0FBQUEsVUFDZEMsUUFBUTtBQUFBLFVBQ1JDLGFBQWE7QUFBQSxRQUNmO0FBQUEsUUFFQTtBQUFBLGlDQUFDLGNBQVcsU0FBUSxNQUFLLElBQUksRUFBRUMsWUFBWSxLQUFLTyxJQUFJLEVBQUUsR0FBRSwwQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQTtBQUFBO0FBQUEsTUFYbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUE7QUFBQSxPQTdIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEhBO0FBRUo7QUFBRTdCLElBektJRCxjQUFZO0FBQUEsVUFDRHZDLGdCQUFnQjtBQUFBO0FBQUEsTUFEM0J1QztBQTJLQyxhQUFNa0MsWUFBWUEsTUFBTTtBQUM3QixTQUNFLHVCQUFDLFFBQ0MsaUNBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFhLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBRUMsTUFOV0Q7QUFBUyxJQUFBRSxJQUFBbkQsS0FBQW9ELEtBQUFDLEtBQUFIO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFuRCxLQUFBO0FBQUEsYUFBQW9ELEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUgsS0FBQSIsIm5hbWVzIjpbIkJveCIsIlR5cG9ncmFwaHkiLCJUYWJsZSIsIlRhYmxlQm9keSIsIlRhYmxlQ2VsbCIsIlRhYmxlSGVhZCIsIlRhYmxlUm93IiwiQ2hpcCIsIlNob3ciLCJTZWxlY3RJbnB1dCIsIlNhdmVCdXR0b24iLCJTaW1wbGVGb3JtIiwiVG9vbGJhciIsInVzZVJlY29yZENvbnRleHQiLCJ1c2VVcGRhdGUiLCJ1c2VOb3RpZnkiLCJ1c2VSZWZyZXNoIiwiT1JERVJfU1RBVFVTX0NIT0lDRVMiLCJwYXJzZU9yZGVySXRlbXMiLCJPcmRlclN0YXR1c0Zvcm0iLCJfcyIsInJlY29yZCIsInVwZGF0ZSIsImlzUGVuZGluZyIsIm5vdGlmeSIsInJlZnJlc2giLCJkYXRhIiwiaWQiLCJzdGF0dXMiLCJwcmV2aW91c0RhdGEiLCJ0eXBlIiwiRGV0YWlsUm93IiwibGFiZWwiLCJ2YWx1ZSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiX2MyIiwiT3JkZXJJdGVtc1RhYmxlIiwiX3MyIiwiaXRlbXMiLCJvcmRlckl0ZW0iLCJsZW5ndGgiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJwcm9kdWN0IiwicHJOYW1lIiwiZW5OYW1lIiwicXVhbnRpdHkiLCJpdGVtUHJpY2UiLCJ0b0xvY2FsZVN0cmluZyIsIk9yZGVyRGV0YWlscyIsIl9zMyIsImN1c3RvbWVyTmFtZSIsInVzZXIiLCJuYW1lIiwibGFzdE5hbWUiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsInJlY2VpdmVyTmFtZSIsImFkZHJlc3MiLCJyZWNlaXZlckxhc3ROYW1lIiwiZnVsbEFkZHJlc3MiLCJwcm92aW5jZSIsImNpdHkiLCJzdHJlZXQiLCJwIiwiZmxleFdyYXAiLCJmbGV4IiwibWluV2lkdGgiLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJib3JkZXJDb2xvciIsImZvbnRXZWlnaHQiLCJpbnZlbnRvcnlTdGF0dXMiLCJ0b3RhbEFtb3VudCIsImRlbGl2ZXJ5QW1vdW50IiwicHJvZml0RnJvbURpc2NvdW50IiwiY3JlYXRlZEF0IiwiRGF0ZSIsIm1iIiwicGhvbmVOdW1iZXIiLCJwb2ludCIsInJlY2VpdmVyUGhvbmVOdW1iZXIiLCJPcmRlclNob3ciLCJfYzUiLCJfYyIsIl9jMyIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPcmRlclNob3cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgQm94IGZyb20gXCJAbXVpL21hdGVyaWFsL0JveFwiO1xuaW1wb3J0IFR5cG9ncmFwaHkgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVHlwb2dyYXBoeVwiO1xuaW1wb3J0IFRhYmxlIGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYmxlXCI7XG5pbXBvcnQgVGFibGVCb2R5IGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYmxlQm9keVwiO1xuaW1wb3J0IFRhYmxlQ2VsbCBmcm9tIFwiQG11aS9tYXRlcmlhbC9UYWJsZUNlbGxcIjtcbmltcG9ydCBUYWJsZUhlYWQgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFibGVIZWFkXCI7XG5pbXBvcnQgVGFibGVSb3cgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFibGVSb3dcIjtcbmltcG9ydCBDaGlwIGZyb20gXCJAbXVpL21hdGVyaWFsL0NoaXBcIjtcbmltcG9ydCB7XG4gIFNob3csXG4gIFNlbGVjdElucHV0LFxuICBTYXZlQnV0dG9uLFxuICBTaW1wbGVGb3JtLFxuICBUb29sYmFyLFxuICB1c2VSZWNvcmRDb250ZXh0LFxuICB1c2VVcGRhdGUsXG4gIHVzZU5vdGlmeSxcbiAgdXNlUmVmcmVzaCxcbn0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQgeyBPUkRFUl9TVEFUVVNfQ0hPSUNFUyB9IGZyb20gXCIuLi8uLi9saWIvb3JkZXJTdGF0dXNcIjtcbmltcG9ydCB7IHBhcnNlT3JkZXJJdGVtcyB9IGZyb20gXCIuLi8uLi9saWIvb3JkZXJJdGVtc1wiO1xuXG5jb25zdCBPcmRlclN0YXR1c0Zvcm0gPSAoKSA9PiB7XG4gIGNvbnN0IHJlY29yZCA9IHVzZVJlY29yZENvbnRleHQ8eyBpZDogbnVtYmVyOyBzdGF0dXM/OiBzdHJpbmcgfT4oKTtcbiAgY29uc3QgW3VwZGF0ZSwgeyBpc1BlbmRpbmcgfV0gPSB1c2VVcGRhdGUoKTtcbiAgY29uc3Qgbm90aWZ5ID0gdXNlTm90aWZ5KCk7XG4gIGNvbnN0IHJlZnJlc2ggPSB1c2VSZWZyZXNoKCk7XG5cbiAgaWYgKCFyZWNvcmQpIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPFNpbXBsZUZvcm1cbiAgICAgIHJlY29yZD17cmVjb3JkfVxuICAgICAgdG9vbGJhcj17XG4gICAgICAgIDxUb29sYmFyPlxuICAgICAgICAgIDxTYXZlQnV0dG9uIGxhYmVsPVwiVXBkYXRlIFN0YXR1c1wiIGRpc2FibGVkPXtpc1BlbmRpbmd9IC8+XG4gICAgICAgIDwvVG9vbGJhcj5cbiAgICAgIH1cbiAgICAgIG9uU3VibWl0PXthc3luYyAoZGF0YTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCB1cGRhdGUoXCJvcmRlclwiLCB7XG4gICAgICAgICAgICBpZDogcmVjb3JkLmlkLFxuICAgICAgICAgICAgZGF0YTogeyBzdGF0dXM6IGRhdGEuc3RhdHVzIGFzIHN0cmluZyB9LFxuICAgICAgICAgICAgcHJldmlvdXNEYXRhOiByZWNvcmQsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbm90aWZ5KFwiT3JkZXIgc3RhdHVzIHVwZGF0ZWRcIiwgeyB0eXBlOiBcInN1Y2Nlc3NcIiB9KTtcbiAgICAgICAgICByZWZyZXNoKCk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIG5vdGlmeShcIkZhaWxlZCB0byB1cGRhdGUgb3JkZXIgc3RhdHVzXCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgICAgICB9XG4gICAgICB9fVxuICAgID5cbiAgICAgIDxTZWxlY3RJbnB1dCBzb3VyY2U9XCJzdGF0dXNcIiBjaG9pY2VzPXtPUkRFUl9TVEFUVVNfQ0hPSUNFU30gZnVsbFdpZHRoIC8+XG4gICAgPC9TaW1wbGVGb3JtPlxuICApO1xufTtcblxuY29uc3QgRGV0YWlsUm93ID0gKHtcbiAgbGFiZWwsXG4gIHZhbHVlLFxufToge1xuICBsYWJlbDogc3RyaW5nO1xuICB2YWx1ZTogUmVhY3ROb2RlO1xufSkgPT4gKFxuICA8Qm94IHN4PXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IDAuNSB9fT5cbiAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiY2FwdGlvblwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5cbiAgICAgIHtsYWJlbH1cbiAgICA8L1R5cG9ncmFwaHk+XG4gICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCI+e3ZhbHVlfTwvVHlwb2dyYXBoeT5cbiAgPC9Cb3g+XG4pO1xuXG5jb25zdCBPcmRlckl0ZW1zVGFibGUgPSAoKSA9PiB7XG4gIGNvbnN0IHJlY29yZCA9IHVzZVJlY29yZENvbnRleHQ8eyBvcmRlckl0ZW0/OiB1bmtub3duIH0+KCk7XG4gIGNvbnN0IGl0ZW1zID0gcGFyc2VPcmRlckl0ZW1zKHJlY29yZD8ub3JkZXJJdGVtKTtcblxuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5cbiAgICAgICAgTm8gaXRlbXNcbiAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8VGFibGUgc2l6ZT1cInNtYWxsXCI+XG4gICAgICA8VGFibGVIZWFkPlxuICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgPFRhYmxlQ2VsbD5Qcm9kdWN0PC9UYWJsZUNlbGw+XG4gICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+UXR5PC9UYWJsZUNlbGw+XG4gICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+UHJpY2U8L1RhYmxlQ2VsbD5cbiAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgIDwvVGFibGVIZWFkPlxuICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICA8VGFibGVSb3cga2V5PXtpbmRleH0+XG4gICAgICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgICAgICB7aXRlbS5wcm9kdWN0Py5wck5hbWUgfHwgaXRlbS5wcm9kdWN0Py5lbk5hbWUgfHwgXCItXCJ9XG4gICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgIDxUYWJsZUNlbGwgYWxpZ249XCJyaWdodFwiPntpdGVtLnF1YW50aXR5fTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+XG4gICAgICAgICAgICAgIHtpdGVtLml0ZW1QcmljZT8udG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICkpfVxuICAgICAgPC9UYWJsZUJvZHk+XG4gICAgPC9UYWJsZT5cbiAgKTtcbn07XG5cbmNvbnN0IE9yZGVyRGV0YWlscyA9ICgpID0+IHtcbiAgY29uc3QgcmVjb3JkID0gdXNlUmVjb3JkQ29udGV4dDx7XG4gICAgaWQ/OiBudW1iZXI7XG4gICAgc3RhdHVzPzogc3RyaW5nO1xuICAgIGludmVudG9yeVN0YXR1cz86IHN0cmluZztcbiAgICB0b3RhbEFtb3VudD86IG51bWJlcjtcbiAgICBkZWxpdmVyeUFtb3VudD86IG51bWJlcjtcbiAgICBwcm9maXRGcm9tRGlzY291bnQ/OiBudW1iZXI7XG4gICAgY3JlYXRlZEF0Pzogc3RyaW5nO1xuICAgIHVzZXI/OiB7XG4gICAgICBuYW1lPzogc3RyaW5nO1xuICAgICAgbGFzdE5hbWU/OiBzdHJpbmc7XG4gICAgICBwaG9uZU51bWJlcj86IHN0cmluZztcbiAgICAgIHBvaW50PzogbnVtYmVyO1xuICAgIH07XG4gICAgYWRkcmVzcz86IHtcbiAgICAgIHJlY2VpdmVyTmFtZT86IHN0cmluZztcbiAgICAgIHJlY2VpdmVyTGFzdE5hbWU/OiBzdHJpbmc7XG4gICAgICByZWNlaXZlclBob25lTnVtYmVyPzogc3RyaW5nO1xuICAgICAgcHJvdmluY2U/OiBzdHJpbmc7XG4gICAgICBjaXR5Pzogc3RyaW5nO1xuICAgICAgc3RyZWV0Pzogc3RyaW5nO1xuICAgICAgYWRkcmVzcz86IHN0cmluZztcbiAgICB9O1xuICB9PigpO1xuXG4gIGlmICghcmVjb3JkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBjdXN0b21lck5hbWUgPVxuICAgIFtyZWNvcmQudXNlcj8ubmFtZSwgcmVjb3JkLnVzZXI/Lmxhc3ROYW1lXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIiBcIikgfHwgXCItXCI7XG4gIGNvbnN0IHJlY2VpdmVyTmFtZSA9XG4gICAgW3JlY29yZC5hZGRyZXNzPy5yZWNlaXZlck5hbWUsIHJlY29yZC5hZGRyZXNzPy5yZWNlaXZlckxhc3ROYW1lXVxuICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgLmpvaW4oXCIgXCIpIHx8IFwiLVwiO1xuICBjb25zdCBmdWxsQWRkcmVzcyA9IHJlY29yZC5hZGRyZXNzXG4gICAgPyBbcmVjb3JkLmFkZHJlc3MucHJvdmluY2UsIHJlY29yZC5hZGRyZXNzLmNpdHksIHJlY29yZC5hZGRyZXNzLnN0cmVldCwgcmVjb3JkLmFkZHJlc3MuYWRkcmVzc11cbiAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAuam9pbihcIiwgXCIpXG4gICAgOiBcIi1cIjtcblxuICByZXR1cm4gKFxuICAgIDxCb3ggc3g9e3sgcDogMiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMyB9fT5cbiAgICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhXcmFwOiBcIndyYXBcIiwgZ2FwOiAzIH19PlxuICAgICAgICA8Qm94XG4gICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgIGZsZXg6IDEsXG4gICAgICAgICAgICBtaW5XaWR0aDogMjgwLFxuICAgICAgICAgICAgcDogMixcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogMixcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgIGdhcDogMixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgc3g9e3sgZm9udFdlaWdodDogNzAwIH19PlxuICAgICAgICAgICAgT3JkZXIgU3VtbWFyeVxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICA8RGV0YWlsUm93IGxhYmVsPVwiT3JkZXIgSURcIiB2YWx1ZT17cmVjb3JkLmlkfSAvPlxuICAgICAgICAgIDxEZXRhaWxSb3dcbiAgICAgICAgICAgIGxhYmVsPVwiU3RhdHVzXCJcbiAgICAgICAgICAgIHZhbHVlPXs8Q2hpcCBsYWJlbD17cmVjb3JkLnN0YXR1c30gc2l6ZT1cInNtYWxsXCIgLz59XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8RGV0YWlsUm93XG4gICAgICAgICAgICBsYWJlbD1cIkludmVudG9yeVwiXG4gICAgICAgICAgICB2YWx1ZT17cmVjb3JkLmludmVudG9yeVN0YXR1cyB8fCBcIi1cIn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxEZXRhaWxSb3dcbiAgICAgICAgICAgIGxhYmVsPVwiVG90YWwgQW1vdW50XCJcbiAgICAgICAgICAgIHZhbHVlPXtyZWNvcmQudG90YWxBbW91bnQ/LnRvTG9jYWxlU3RyaW5nKCkgPz8gXCItXCJ9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8RGV0YWlsUm93XG4gICAgICAgICAgICBsYWJlbD1cIkRlbGl2ZXJ5IEFtb3VudFwiXG4gICAgICAgICAgICB2YWx1ZT17cmVjb3JkLmRlbGl2ZXJ5QW1vdW50Py50b0xvY2FsZVN0cmluZygpID8/IFwiLVwifVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPERldGFpbFJvd1xuICAgICAgICAgICAgbGFiZWw9XCJQcm9maXQgZnJvbSBEaXNjb3VudFwiXG4gICAgICAgICAgICB2YWx1ZT17cmVjb3JkLnByb2ZpdEZyb21EaXNjb3VudD8udG9Mb2NhbGVTdHJpbmcoKSA/PyBcIi1cIn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxEZXRhaWxSb3dcbiAgICAgICAgICAgIGxhYmVsPVwiQ3JlYXRlZFwiXG4gICAgICAgICAgICB2YWx1ZT17XG4gICAgICAgICAgICAgIHJlY29yZC5jcmVhdGVkQXRcbiAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHJlY29yZC5jcmVhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKClcbiAgICAgICAgICAgICAgICA6IFwiLVwiXG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgPEJveFxuICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICBmbGV4OiAxLFxuICAgICAgICAgICAgbWluV2lkdGg6IDI4MCxcbiAgICAgICAgICAgIHA6IDIsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDIsXG4gICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkXCIsXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNlwiIHN4PXt7IGZvbnRXZWlnaHQ6IDcwMCwgbWI6IDIgfX0+XG4gICAgICAgICAgICBVcGRhdGUgU3RhdHVzXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgIDxPcmRlclN0YXR1c0Zvcm0gLz5cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleFdyYXA6IFwid3JhcFwiLCBnYXA6IDMgfX0+XG4gICAgICAgIDxCb3hcbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgZmxleDogMSxcbiAgICAgICAgICAgIG1pbldpZHRoOiAyODAsXG4gICAgICAgICAgICBwOiAyLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAyLFxuICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZFwiLFxuICAgICAgICAgICAgYm9yZGVyQ29sb3I6IFwiZGl2aWRlclwiLFxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIiBzeD17eyBmb250V2VpZ2h0OiA3MDAgfX0+XG4gICAgICAgICAgICBDdXN0b21lclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICA8RGV0YWlsUm93IGxhYmVsPVwiTmFtZVwiIHZhbHVlPXtjdXN0b21lck5hbWV9IC8+XG4gICAgICAgICAgPERldGFpbFJvdyBsYWJlbD1cIlBob25lXCIgdmFsdWU9e3JlY29yZC51c2VyPy5waG9uZU51bWJlciB8fCBcIi1cIn0gLz5cbiAgICAgICAgICA8RGV0YWlsUm93IGxhYmVsPVwiUG9pbnRzXCIgdmFsdWU9e3JlY29yZC51c2VyPy5wb2ludCA/PyBcIi1cIn0gLz5cbiAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgPEJveFxuICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICBmbGV4OiAxLFxuICAgICAgICAgICAgbWluV2lkdGg6IDI4MCxcbiAgICAgICAgICAgIHA6IDIsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDIsXG4gICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkXCIsXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICBnYXA6IDIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNlwiIHN4PXt7IGZvbnRXZWlnaHQ6IDcwMCB9fT5cbiAgICAgICAgICAgIFNoaXBwaW5nIEFkZHJlc3NcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgPERldGFpbFJvdyBsYWJlbD1cIlJlY2VpdmVyXCIgdmFsdWU9e3JlY2VpdmVyTmFtZX0gLz5cbiAgICAgICAgICA8RGV0YWlsUm93XG4gICAgICAgICAgICBsYWJlbD1cIlBob25lXCJcbiAgICAgICAgICAgIHZhbHVlPXtyZWNvcmQuYWRkcmVzcz8ucmVjZWl2ZXJQaG9uZU51bWJlciB8fCBcIi1cIn1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxEZXRhaWxSb3cgbGFiZWw9XCJBZGRyZXNzXCIgdmFsdWU9e2Z1bGxBZGRyZXNzfSAvPlxuICAgICAgICA8L0JveD5cbiAgICAgIDwvQm94PlxuXG4gICAgICA8Qm94XG4gICAgICAgIHN4PXt7XG4gICAgICAgICAgcDogMixcbiAgICAgICAgICBib3JkZXJSYWRpdXM6IDIsXG4gICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZFwiLFxuICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgc3g9e3sgZm9udFdlaWdodDogNzAwLCBtYjogMiB9fT5cbiAgICAgICAgICBMaW5lIEl0ZW1zXG4gICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgPE9yZGVySXRlbXNUYWJsZSAvPlxuICAgICAgPC9Cb3g+XG4gICAgPC9Cb3g+XG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgT3JkZXJTaG93ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxTaG93PlxuICAgICAgPE9yZGVyRGV0YWlscyAvPlxuICAgIDwvU2hvdz5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9yZXNvdXJjZXMvb3JkZXJzL09yZGVyU2hvdy50c3gifQ==