import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/users/UserList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  List,
  Datagrid,
  TextField,
  NumberField,
  BooleanField,
  EditButton,
  DateField
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
export const UserList = () => {
  return /* @__PURE__ */ jsxDEV(List, { children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "edit", children: [
    /* @__PURE__ */ jsxDEV(NumberField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 15,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "phoneNumber", label: "Phone" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "lastName", label: "Last Name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "point", label: "Points" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(BooleanField, { source: "isAdmin", label: "Admin" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 20,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DateField, { source: "createdAtdAt", label: "Joined", showTime: true }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 21,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
    lineNumber: 14,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
};
_c = UserList;
var _c;
$RefreshReg$(_c, "UserList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/users/UserList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1E7QUFkUjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFQSxhQUFNQyxXQUFXQSxNQUFNO0FBQzVCLFNBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxZQUFTLFVBQVMsUUFDakI7QUFBQSwyQkFBQyxlQUFZLFFBQU8sUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCLHVCQUFDLGFBQVUsUUFBTyxlQUFjLE9BQU0sV0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLGFBQVUsUUFBTyxVQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFDeEIsdUJBQUMsYUFBVSxRQUFPLFlBQVcsT0FBTSxlQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFDOUMsdUJBQUMsZUFBWSxRQUFPLFNBQVEsT0FBTSxZQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsSUFDMUMsdUJBQUMsZ0JBQWEsUUFBTyxXQUFVLE9BQU0sV0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QztBQUFBLElBQzVDLHVCQUFDLGFBQVUsUUFBTyxnQkFBZSxPQUFNLFVBQVMsVUFBUSxRQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdEO0FBQUEsSUFDeEQsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXO0FBQUEsT0FSYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFFQyxLQWZXRDtBQUFRLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpc3QiLCJEYXRhZ3JpZCIsIlRleHRGaWVsZCIsIk51bWJlckZpZWxkIiwiQm9vbGVhbkZpZWxkIiwiRWRpdEJ1dHRvbiIsIkRhdGVGaWVsZCIsIlVzZXJMaXN0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVXNlckxpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIExpc3QsXG4gIERhdGFncmlkLFxuICBUZXh0RmllbGQsXG4gIE51bWJlckZpZWxkLFxuICBCb29sZWFuRmllbGQsXG4gIEVkaXRCdXR0b24sXG4gIERhdGVGaWVsZCxcbn0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5cbmV4cG9ydCBjb25zdCBVc2VyTGlzdCA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8TGlzdD5cbiAgICAgIDxEYXRhZ3JpZCByb3dDbGljaz1cImVkaXRcIj5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cImlkXCIgLz5cbiAgICAgICAgPFRleHRGaWVsZCBzb3VyY2U9XCJwaG9uZU51bWJlclwiIGxhYmVsPVwiUGhvbmVcIiAvPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cIm5hbWVcIiAvPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cImxhc3ROYW1lXCIgbGFiZWw9XCJMYXN0IE5hbWVcIiAvPlxuICAgICAgICA8TnVtYmVyRmllbGQgc291cmNlPVwicG9pbnRcIiBsYWJlbD1cIlBvaW50c1wiIC8+XG4gICAgICAgIDxCb29sZWFuRmllbGQgc291cmNlPVwiaXNBZG1pblwiIGxhYmVsPVwiQWRtaW5cIiAvPlxuICAgICAgICA8RGF0ZUZpZWxkIHNvdXJjZT1cImNyZWF0ZWRBdGRBdFwiIGxhYmVsPVwiSm9pbmVkXCIgc2hvd1RpbWUgLz5cbiAgICAgICAgPEVkaXRCdXR0b24gLz5cbiAgICAgIDwvRGF0YWdyaWQ+XG4gICAgPC9MaXN0PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy91c2Vycy9Vc2VyTGlzdC50c3gifQ==