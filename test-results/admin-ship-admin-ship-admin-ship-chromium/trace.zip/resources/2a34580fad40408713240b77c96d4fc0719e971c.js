import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/categories/CategoryList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  List,
  Datagrid,
  TextField,
  NumberField,
  BooleanField,
  EditButton,
  DeleteButton,
  ReferenceField
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
export const CategoryList = () => {
  return /* @__PURE__ */ jsxDEV(List, { children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "edit", children: [
    /* @__PURE__ */ jsxDEV(TextField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "slug" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "level", label: "Level" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      ReferenceField,
      {
        source: "parentId",
        reference: "category",
        label: "Parent",
        emptyText: "-",
        children: /* @__PURE__ */ jsxDEV(TextField, { source: "name" }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
          lineNumber: 26,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
        lineNumber: 20,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(BooleanField, { source: "isActive", label: "Active" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 28,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "sortOrder", label: "Sort Order" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DeleteButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
      lineNumber: 31,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
};
_c = CategoryList;
var _c;
$RefreshReg$(_c, "CategoryList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7QUFmUjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFQSxhQUFNQyxlQUFlQSxNQUFNO0FBQ2hDLFNBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxZQUFTLFVBQVMsUUFDakI7QUFBQSwyQkFBQyxhQUFVLFFBQU8sUUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQjtBQUFBLElBQ3RCLHVCQUFDLGFBQVUsUUFBTyxVQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFDeEIsdUJBQUMsYUFBVSxRQUFPLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUN4Qix1QkFBQyxlQUFZLFFBQU8sU0FBUSxPQUFNLFdBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUN6QztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBTztBQUFBLFFBQ1AsV0FBVTtBQUFBLFFBQ1YsT0FBTTtBQUFBLFFBQ04sV0FBVTtBQUFBLFFBRVYsaUNBQUMsYUFBVSxRQUFPLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQTtBQUFBLE1BTjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsSUFDQSx1QkFBQyxnQkFBYSxRQUFPLFlBQVcsT0FBTSxZQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFDOUMsdUJBQUMsZUFBWSxRQUFPLGFBQVksT0FBTSxnQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRDtBQUFBLElBQ2xELHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVztBQUFBLElBQ1gsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhO0FBQUEsT0FoQmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBRUMsS0F2QldEO0FBQVksSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGlzdCIsIkRhdGFncmlkIiwiVGV4dEZpZWxkIiwiTnVtYmVyRmllbGQiLCJCb29sZWFuRmllbGQiLCJFZGl0QnV0dG9uIiwiRGVsZXRlQnV0dG9uIiwiUmVmZXJlbmNlRmllbGQiLCJDYXRlZ29yeUxpc3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXRlZ29yeUxpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIExpc3QsXG4gIERhdGFncmlkLFxuICBUZXh0RmllbGQsXG4gIE51bWJlckZpZWxkLFxuICBCb29sZWFuRmllbGQsXG4gIEVkaXRCdXR0b24sXG4gIERlbGV0ZUJ1dHRvbixcbiAgUmVmZXJlbmNlRmllbGQsXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnlMaXN0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxMaXN0PlxuICAgICAgPERhdGFncmlkIHJvd0NsaWNrPVwiZWRpdFwiPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cImlkXCIgLz5cbiAgICAgICAgPFRleHRGaWVsZCBzb3VyY2U9XCJuYW1lXCIgLz5cbiAgICAgICAgPFRleHRGaWVsZCBzb3VyY2U9XCJzbHVnXCIgLz5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cImxldmVsXCIgbGFiZWw9XCJMZXZlbFwiIC8+XG4gICAgICAgIDxSZWZlcmVuY2VGaWVsZFxuICAgICAgICAgIHNvdXJjZT1cInBhcmVudElkXCJcbiAgICAgICAgICByZWZlcmVuY2U9XCJjYXRlZ29yeVwiXG4gICAgICAgICAgbGFiZWw9XCJQYXJlbnRcIlxuICAgICAgICAgIGVtcHR5VGV4dD1cIi1cIlxuICAgICAgICA+XG4gICAgICAgICAgPFRleHRGaWVsZCBzb3VyY2U9XCJuYW1lXCIgLz5cbiAgICAgICAgPC9SZWZlcmVuY2VGaWVsZD5cbiAgICAgICAgPEJvb2xlYW5GaWVsZCBzb3VyY2U9XCJpc0FjdGl2ZVwiIGxhYmVsPVwiQWN0aXZlXCIgLz5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cInNvcnRPcmRlclwiIGxhYmVsPVwiU29ydCBPcmRlclwiIC8+XG4gICAgICAgIDxFZGl0QnV0dG9uIC8+XG4gICAgICAgIDxEZWxldGVCdXR0b24gLz5cbiAgICAgIDwvRGF0YWdyaWQ+XG4gICAgPC9MaXN0PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9jYXRlZ29yaWVzL0NhdGVnb3J5TGlzdC50c3gifQ==