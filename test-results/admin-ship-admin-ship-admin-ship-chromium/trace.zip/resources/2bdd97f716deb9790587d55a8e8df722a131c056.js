import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DeliveryCostSettings.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
import Button from "/node_modules/.vite/deps/@mui_material_Button.js?v=49ae7072";
import TextField from "/node_modules/.vite/deps/@mui_material_TextField.js?v=49ae7072";
import Table from "/node_modules/.vite/deps/@mui_material_Table.js?v=49ae7072";
import TableBody from "/node_modules/.vite/deps/@mui_material_TableBody.js?v=49ae7072";
import TableCell from "/node_modules/.vite/deps/@mui_material_TableCell.js?v=49ae7072";
import TableHead from "/node_modules/.vite/deps/@mui_material_TableHead.js?v=49ae7072";
import TableRow from "/node_modules/.vite/deps/@mui_material_TableRow.js?v=49ae7072";
import __vite__cjsImport10_react from "/node_modules/.vite/deps/react.js?v=49ae7072"; const useCallback = __vite__cjsImport10_react["useCallback"]; const useEffect = __vite__cjsImport10_react["useEffect"]; const useState = __vite__cjsImport10_react["useState"];
import { Title, useNotify } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import {
  createDeliveryCost,
  getAllDeliveryCosts,
  getLatestDeliveryCost
} from "/src/api/admin/index.ts";
export const DeliveryCostSettings = () => {
  _s();
  const notify = useNotify();
  const [currentCost, setCurrentCost] = useState(null);
  const [history, setHistory] = useState([]);
  const [newCost, setNewCost] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [latest, all] = await Promise.all(
        [
          getLatestDeliveryCost(),
          getAllDeliveryCosts()
        ]
      );
      setCurrentCost(latest ?? null);
      setHistory(all ?? []);
    } catch {
      notify("Failed to load delivery cost settings", { type: "error" });
    } finally {
      setLoading(false);
    }
  }, [notify]);
  useEffect(() => {
    loadData();
  }, [loadData]);
  const handleSave = async () => {
    const cost = parseFloat(newCost);
    if (isNaN(cost) || cost < 0) {
      notify("Please enter a valid cost", { type: "warning" });
      return;
    }
    setSaving(true);
    try {
      await createDeliveryCost(cost);
      notify("Delivery cost updated", { type: "success" });
      setNewCost("");
      await loadData();
    } catch {
      notify("Failed to update delivery cost", { type: "error" });
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3 }, children: [
    /* @__PURE__ */ jsxDEV(Title, { title: "Delivery Cost" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          display: "flex",
          flexDirection: "column",
          gap: 3,
          maxWidth: 720
        },
        children: [
          /* @__PURE__ */ jsxDEV(Box, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", sx: { fontWeight: 700, mb: 1 }, children: "Delivery Cost Settings" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
              lineNumber: 80,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Set the shipping cost applied to customer orders." }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
              lineNumber: 83,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
            lineNumber: 79,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            Box,
            {
              sx: {
                p: 3,
                borderRadius: 2,
                border: "1px solid",
                borderColor: "divider",
                bgcolor: "background.paper"
              },
              children: [
                /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", color: "text.secondary", gutterBottom: true, children: "Current delivery cost" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                  lineNumber: 97,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(Typography, { variant: "h4", sx: { fontWeight: 800, mb: 2 }, children: loading ? "..." : currentCost ? `${currentCost.cost.toLocaleString()}` : "Not set" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                  lineNumber: 100,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Box,
                  {
                    sx: {
                      display: "flex",
                      flexWrap: "wrap",
                      gap: 2,
                      alignItems: "flex-end"
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        TextField,
                        {
                          label: "New delivery cost",
                          type: "number",
                          value: newCost,
                          onChange: (e) => setNewCost(e.target.value),
                          size: "small",
                          sx: { width: { xs: "100%", sm: 240 } }
                        },
                        void 0,
                        false,
                        {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                          lineNumber: 116,
                          columnNumber: 13
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Button,
                        {
                          variant: "contained",
                          onClick: handleSave,
                          disabled: saving || !newCost,
                          children: saving ? "Saving..." : "Update Cost"
                        },
                        void 0,
                        false,
                        {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                          lineNumber: 124,
                          columnNumber: 13
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                    lineNumber: 108,
                    columnNumber: 11
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
              lineNumber: 88,
              columnNumber: 9
            },
            this
          ),
          history.length > 0 && /* @__PURE__ */ jsxDEV(Box, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700, mb: 1.5 }, children: "History" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
              lineNumber: 136,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Table, { size: "small", children: [
              /* @__PURE__ */ jsxDEV(TableHead, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
                /* @__PURE__ */ jsxDEV(TableCell, { children: "Cost" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                  lineNumber: 142,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(TableCell, { children: "Created" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                  lineNumber: 143,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                lineNumber: 141,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                lineNumber: 140,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(TableBody, { children: history.map(
                (item) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
                  /* @__PURE__ */ jsxDEV(TableCell, { children: item.cost.toLocaleString() }, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                    lineNumber: 149,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(TableCell, { children: new Date(item.createdAt).toLocaleString() }, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                    lineNumber: 150,
                    columnNumber: 21
                  }, this)
                ] }, item.id, true, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                  lineNumber: 148,
                  columnNumber: 15
                }, this)
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
                lineNumber: 146,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
              lineNumber: 139,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
            lineNumber: 135,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
        lineNumber: 71,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx",
    lineNumber: 68,
    columnNumber: 5
  }, this);
};
_s(DeliveryCostSettings, "1tJhzp9J0BGbRaeVNeM5IxBNioE=", false, function() {
  return [useNotify];
});
_c = DeliveryCostSettings;
var _c;
$RefreshReg$(_c, "DeliveryCostSettings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/pages/DeliveryCostSettings.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VNOztBQXBFTixPQUFPQSxTQUFTO0FBQ2hCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBQ3JCLFNBQVNDLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUNqRCxTQUFTQyxPQUFPQyxpQkFBaUI7QUFDakM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBRUEsYUFBTUMsdUJBQXVCQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEMsUUFBTUMsU0FBU04sVUFBVTtBQUN6QixRQUFNLENBQUNPLGFBQWFDLGNBQWMsSUFBSVYsU0FBOEIsSUFBSTtBQUN4RSxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSVosU0FBeUIsRUFBRTtBQUN6RCxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ2lCLFFBQVFDLFNBQVMsSUFBSWxCLFNBQVMsS0FBSztBQUUxQyxRQUFNbUIsV0FBV3JCLFlBQVksWUFBWTtBQUN2Q2tCLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNLENBQUNJLFFBQVFDLEdBQUcsSUFBSSxNQUFNQyxRQUFRRDtBQUFBQSxRQUFJO0FBQUEsVUFDdENoQixzQkFBc0I7QUFBQSxVQUN0QkQsb0JBQW9CO0FBQUEsUUFBQztBQUFBLE1BQ3RCO0FBQ0RNLHFCQUFlVSxVQUFVLElBQUk7QUFDN0JSLGlCQUFXUyxPQUFPLEVBQUU7QUFBQSxJQUN0QixRQUFRO0FBQ05iLGFBQU8seUNBQXlDLEVBQUVlLE1BQU0sUUFBUSxDQUFDO0FBQUEsSUFDbkUsVUFBQztBQUNDUCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ1IsTUFBTSxDQUFDO0FBRVhULFlBQVUsTUFBTTtBQUNkb0IsYUFBUztBQUFBLEVBQ1gsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFYixRQUFNSyxhQUFhLFlBQVk7QUFDN0IsVUFBTUMsT0FBT0MsV0FBV2IsT0FBTztBQUMvQixRQUFJYyxNQUFNRixJQUFJLEtBQUtBLE9BQU8sR0FBRztBQUMzQmpCLGFBQU8sNkJBQTZCLEVBQUVlLE1BQU0sVUFBVSxDQUFDO0FBQ3ZEO0FBQUEsSUFDRjtBQUVBTCxjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTWYsbUJBQW1Cc0IsSUFBSTtBQUM3QmpCLGFBQU8seUJBQXlCLEVBQUVlLE1BQU0sVUFBVSxDQUFDO0FBQ25EVCxpQkFBVyxFQUFFO0FBQ2IsWUFBTUssU0FBUztBQUFBLElBQ2pCLFFBQVE7QUFDTlgsYUFBTyxrQ0FBa0MsRUFBRWUsTUFBTSxRQUFRLENBQUM7QUFBQSxJQUM1RCxVQUFDO0FBQ0NMLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLE9BQUksSUFBSSxFQUFFVSxHQUFHLEVBQUUsR0FDZDtBQUFBLDJCQUFDLFNBQU0sT0FBTSxtQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRCO0FBQUEsSUFFNUI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUk7QUFBQSxVQUNGQyxTQUFTO0FBQUEsVUFDVEMsZUFBZTtBQUFBLFVBQ2ZDLEtBQUs7QUFBQSxVQUNMQyxVQUFVO0FBQUEsUUFDWjtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxPQUNDO0FBQUEsbUNBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFQyxZQUFZLEtBQUtDLElBQUksRUFBRSxHQUFFLHNDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxjQUFXLFNBQVEsU0FBUSxPQUFNLGtCQUFnQixpRUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUk7QUFBQSxnQkFDRk4sR0FBRztBQUFBLGdCQUNITyxjQUFjO0FBQUEsZ0JBQ2RDLFFBQVE7QUFBQSxnQkFDUkMsYUFBYTtBQUFBLGdCQUNiQyxTQUFTO0FBQUEsY0FDWDtBQUFBLGNBRUE7QUFBQSx1Q0FBQyxjQUFXLFNBQVEsYUFBWSxPQUFNLGtCQUFpQixjQUFZLDJDQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFTCxZQUFZLEtBQUtDLElBQUksRUFBRSxHQUNuRG5CLG9CQUNHLFFBQ0FOLGNBQ0UsR0FBR0EsWUFBWWdCLEtBQUtjLGVBQWUsQ0FBQyxLQUNwQyxhQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFJO0FBQUEsc0JBQ0ZWLFNBQVM7QUFBQSxzQkFDVFcsVUFBVTtBQUFBLHNCQUNWVCxLQUFLO0FBQUEsc0JBQ0xVLFlBQVk7QUFBQSxvQkFDZDtBQUFBLG9CQUVBO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsT0FBTTtBQUFBLDBCQUNOLE1BQUs7QUFBQSwwQkFDTCxPQUFPNUI7QUFBQUEsMEJBQ1AsVUFBVSxDQUFDNkIsTUFBTTVCLFdBQVc0QixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsMEJBQzFDLE1BQUs7QUFBQSwwQkFDTCxJQUFJLEVBQUVDLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLElBQUksRUFBRTtBQUFBO0FBQUEsd0JBTnZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNeUM7QUFBQSxzQkFFekM7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsU0FBUTtBQUFBLDBCQUNSLFNBQVN2QjtBQUFBQSwwQkFDVCxVQUFVUCxVQUFVLENBQUNKO0FBQUFBLDBCQUVwQkksbUJBQVMsY0FBYztBQUFBO0FBQUEsd0JBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNQTtBQUFBO0FBQUE7QUFBQSxrQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXVCQTtBQUFBO0FBQUE7QUFBQSxZQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE0Q0E7QUFBQSxVQUVDTixRQUFRcUMsU0FBUyxLQUNoQix1QkFBQyxPQUNDO0FBQUEsbUNBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFZixZQUFZLEtBQUtDLElBQUksSUFBSSxHQUFFLHVCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFNLE1BQUssU0FDVjtBQUFBLHFDQUFDLGFBQ0MsaUNBQUMsWUFDQztBQUFBLHVDQUFDLGFBQVUsb0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUNmLHVCQUFDLGFBQVUsdUJBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0I7QUFBQSxtQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLGFBQ0V2QixrQkFBUXNDO0FBQUFBLGdCQUFJLENBQUNDLFNBQ1osdUJBQUMsWUFDQztBQUFBLHlDQUFDLGFBQVdBLGVBQUt6QixLQUFLYyxlQUFlLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3ZDLHVCQUFDLGFBQ0UsY0FBSVksS0FBS0QsS0FBS0UsU0FBUyxFQUFFYixlQUFlLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKYVcsS0FBS0csSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGNBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQTtBQUFBO0FBQUEsTUF0Rko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBd0ZBO0FBQUEsT0EzRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRGQTtBQUVKO0FBQUU5QyxHQS9JV0Qsc0JBQW9CO0FBQUEsVUFDaEJKLFNBQVM7QUFBQTtBQUFBLEtBRGJJO0FBQW9CLElBQUFnRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJCb3giLCJUeXBvZ3JhcGh5IiwiQnV0dG9uIiwiVGV4dEZpZWxkIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUNlbGwiLCJUYWJsZUhlYWQiLCJUYWJsZVJvdyIsInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJUaXRsZSIsInVzZU5vdGlmeSIsImNyZWF0ZURlbGl2ZXJ5Q29zdCIsImdldEFsbERlbGl2ZXJ5Q29zdHMiLCJnZXRMYXRlc3REZWxpdmVyeUNvc3QiLCJEZWxpdmVyeUNvc3RTZXR0aW5ncyIsIl9zIiwibm90aWZ5IiwiY3VycmVudENvc3QiLCJzZXRDdXJyZW50Q29zdCIsImhpc3RvcnkiLCJzZXRIaXN0b3J5IiwibmV3Q29zdCIsInNldE5ld0Nvc3QiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNhdmluZyIsInNldFNhdmluZyIsImxvYWREYXRhIiwibGF0ZXN0IiwiYWxsIiwiUHJvbWlzZSIsInR5cGUiLCJoYW5kbGVTYXZlIiwiY29zdCIsInBhcnNlRmxvYXQiLCJpc05hTiIsInAiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsIm1heFdpZHRoIiwiZm9udFdlaWdodCIsIm1iIiwiYm9yZGVyUmFkaXVzIiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJiZ2NvbG9yIiwidG9Mb2NhbGVTdHJpbmciLCJmbGV4V3JhcCIsImFsaWduSXRlbXMiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJ3aWR0aCIsInhzIiwic20iLCJsZW5ndGgiLCJtYXAiLCJpdGVtIiwiRGF0ZSIsImNyZWF0ZWRBdCIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGVsaXZlcnlDb3N0U2V0dGluZ3MudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBCb3ggZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQm94XCI7XG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UeXBvZ3JhcGh5XCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL0J1dHRvblwiO1xuaW1wb3J0IFRleHRGaWVsZCBmcm9tIFwiQG11aS9tYXRlcmlhbC9UZXh0RmllbGRcIjtcbmltcG9ydCBUYWJsZSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UYWJsZVwiO1xuaW1wb3J0IFRhYmxlQm9keSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UYWJsZUJvZHlcIjtcbmltcG9ydCBUYWJsZUNlbGwgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFibGVDZWxsXCI7XG5pbXBvcnQgVGFibGVIZWFkIGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYmxlSGVhZFwiO1xuaW1wb3J0IFRhYmxlUm93IGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYmxlUm93XCI7XG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgVGl0bGUsIHVzZU5vdGlmeSB9IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IHtcbiAgY3JlYXRlRGVsaXZlcnlDb3N0LFxuICBnZXRBbGxEZWxpdmVyeUNvc3RzLFxuICBnZXRMYXRlc3REZWxpdmVyeUNvc3QsXG4gIHR5cGUgRGVsaXZlcnlDb3N0LFxufSBmcm9tIFwiLi4vYXBpL2FkbWluXCI7XG5cbmV4cG9ydCBjb25zdCBEZWxpdmVyeUNvc3RTZXR0aW5ncyA9ICgpID0+IHtcbiAgY29uc3Qgbm90aWZ5ID0gdXNlTm90aWZ5KCk7XG4gIGNvbnN0IFtjdXJyZW50Q29zdCwgc2V0Q3VycmVudENvc3RdID0gdXNlU3RhdGU8RGVsaXZlcnlDb3N0IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtoaXN0b3J5LCBzZXRIaXN0b3J5XSA9IHVzZVN0YXRlPERlbGl2ZXJ5Q29zdFtdPihbXSk7XG4gIGNvbnN0IFtuZXdDb3N0LCBzZXROZXdDb3N0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBsb2FkRGF0YSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBbbGF0ZXN0LCBhbGxdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBnZXRMYXRlc3REZWxpdmVyeUNvc3QoKSxcbiAgICAgICAgZ2V0QWxsRGVsaXZlcnlDb3N0cygpLFxuICAgICAgXSk7XG4gICAgICBzZXRDdXJyZW50Q29zdChsYXRlc3QgPz8gbnVsbCk7XG4gICAgICBzZXRIaXN0b3J5KGFsbCA/PyBbXSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBub3RpZnkoXCJGYWlsZWQgdG8gbG9hZCBkZWxpdmVyeSBjb3N0IHNldHRpbmdzXCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtub3RpZnldKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWREYXRhKCk7XG4gIH0sIFtsb2FkRGF0YV0pO1xuXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgY29zdCA9IHBhcnNlRmxvYXQobmV3Q29zdCk7XG4gICAgaWYgKGlzTmFOKGNvc3QpIHx8IGNvc3QgPCAwKSB7XG4gICAgICBub3RpZnkoXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBjb3N0XCIsIHsgdHlwZTogXCJ3YXJuaW5nXCIgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0U2F2aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjcmVhdGVEZWxpdmVyeUNvc3QoY29zdCk7XG4gICAgICBub3RpZnkoXCJEZWxpdmVyeSBjb3N0IHVwZGF0ZWRcIiwgeyB0eXBlOiBcInN1Y2Nlc3NcIiB9KTtcbiAgICAgIHNldE5ld0Nvc3QoXCJcIik7XG4gICAgICBhd2FpdCBsb2FkRGF0YSgpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbm90aWZ5KFwiRmFpbGVkIHRvIHVwZGF0ZSBkZWxpdmVyeSBjb3N0XCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxCb3ggc3g9e3sgcDogMyB9fT5cbiAgICAgIDxUaXRsZSB0aXRsZT1cIkRlbGl2ZXJ5IENvc3RcIiAvPlxuXG4gICAgICA8Qm94XG4gICAgICAgIHN4PXt7XG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICBnYXA6IDMsXG4gICAgICAgICAgbWF4V2lkdGg6IDcyMCxcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPEJveD5cbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDVcIiBzeD17eyBmb250V2VpZ2h0OiA3MDAsIG1iOiAxIH19PlxuICAgICAgICAgICAgRGVsaXZlcnkgQ29zdCBTZXR0aW5nc1xuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICBTZXQgdGhlIHNoaXBwaW5nIGNvc3QgYXBwbGllZCB0byBjdXN0b21lciBvcmRlcnMuXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICA8L0JveD5cblxuICAgICAgICA8Qm94XG4gICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgIHA6IDMsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDIsXG4gICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkXCIsXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICBiZ2NvbG9yOiBcImJhY2tncm91bmQucGFwZXJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMlwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBndXR0ZXJCb3R0b20+XG4gICAgICAgICAgICBDdXJyZW50IGRlbGl2ZXJ5IGNvc3RcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg0XCIgc3g9e3sgZm9udFdlaWdodDogODAwLCBtYjogMiB9fT5cbiAgICAgICAgICAgIHtsb2FkaW5nXG4gICAgICAgICAgICAgID8gXCIuLi5cIlxuICAgICAgICAgICAgICA6IGN1cnJlbnRDb3N0XG4gICAgICAgICAgICAgICAgPyBgJHtjdXJyZW50Q29zdC5jb3N0LnRvTG9jYWxlU3RyaW5nKCl9YFxuICAgICAgICAgICAgICAgIDogXCJOb3Qgc2V0XCJ9XG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuXG4gICAgICAgICAgPEJveFxuICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImZsZXgtZW5kXCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgbGFiZWw9XCJOZXcgZGVsaXZlcnkgY29zdFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICB2YWx1ZT17bmV3Q29zdH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDb3N0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBzbTogMjQwIH0gfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nIHx8ICFuZXdDb3N0fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7c2F2aW5nID8gXCJTYXZpbmcuLi5cIiA6IFwiVXBkYXRlIENvc3RcIn1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L0JveD5cblxuICAgICAgICB7aGlzdG9yeS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8Qm94PlxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgc3g9e3sgZm9udFdlaWdodDogNzAwLCBtYjogMS41IH19PlxuICAgICAgICAgICAgICBIaXN0b3J5XG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICA8VGFibGUgc2l6ZT1cInNtYWxsXCI+XG4gICAgICAgICAgICAgIDxUYWJsZUhlYWQ+XG4gICAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5Db3N0PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPkNyZWF0ZWQ8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICA8L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICAgICAgICB7aGlzdG9yeS5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxUYWJsZVJvdyBrZXk9e2l0ZW0uaWR9PlxuICAgICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPntpdGVtLmNvc3QudG9Mb2NhbGVTdHJpbmcoKX08L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoaXRlbS5jcmVhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgICA8L1RhYmxlPlxuICAgICAgICAgIDwvQm94PlxuICAgICAgICApfVxuICAgICAgPC9Cb3g+XG4gICAgPC9Cb3g+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcGFnZXMvRGVsaXZlcnlDb3N0U2V0dGluZ3MudHN4In0=