import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/categories/CategoryForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import {
  BooleanInput,
  FormDataConsumer,
  NumberInput,
  ReferenceInput,
  required,
  SelectInput,
  TextInput
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
export const CategoryForm = ({ mode = "create" }) => {
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        flexDirection: "column",
        gap: 2
      },
      children: [
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: mode === "create" ? /* @__PURE__ */ jsxDEV(
          SelectInput,
          {
            source: "level",
            label: "Category Level",
            choices: [
              { id: 1, name: "Parent (Level 1)" },
              { id: 2, name: "Child (Level 2)" },
              { id: 3, name: "Subchild (Level 3)" }
            ],
            defaultValue: 1,
            validate: required(),
            fullWidth: true
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
            lineNumber: 27,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV(NumberInput, { source: "level", label: "Category Level", disabled: true, fullWidth: true }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
          lineNumber: 40,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
          lineNumber: 25,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "name",
                  label: "Name",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                  lineNumber: 52,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 51,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "slug",
                  label: "Slug",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                  lineNumber: 60,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 59,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
            lineNumber: 44,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "description",
            label: "Description",
            fullWidth: true,
            multiline: true,
            rows: 3
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
            lineNumber: 70,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
          lineNumber: 69,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(FormDataConsumer, { children: ({ formData }) => {
          const currentLevel = formData?.level || 1;
          return /* @__PURE__ */ jsxDEV(Fragment, { children: [
            currentLevel === 1 && /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 2
                },
                children: [
                  /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                    TextInput,
                    {
                      source: "parentImage",
                      label: "Parent Image URL",
                      fullWidth: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                      lineNumber: 94,
                      columnNumber: 21
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                    lineNumber: 93,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                    TextInput,
                    {
                      source: "parentBanner",
                      label: "Parent Banner URL",
                      fullWidth: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                      lineNumber: 101,
                      columnNumber: 21
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                    lineNumber: 100,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 86,
                columnNumber: 15
              },
              this
            ),
            (currentLevel === 2 || currentLevel === 3) && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              mode === "create" && /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
                ReferenceInput,
                {
                  source: "parentId",
                  reference: "category",
                  filter: { level: currentLevel === 2 ? 1 : 2 },
                  children: /* @__PURE__ */ jsxDEV(
                    SelectInput,
                    {
                      optionText: "name",
                      label: currentLevel === 2 ? "Parent Category" : "Child Category",
                      fullWidth: true,
                      validate: required()
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                      lineNumber: 119,
                      columnNumber: 25
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                  lineNumber: 114,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 113,
                columnNumber: 17
              }, this),
              mode === "edit" && /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
                ReferenceInput,
                {
                  source: "parentId",
                  reference: "category",
                  children: /* @__PURE__ */ jsxDEV(
                    SelectInput,
                    {
                      optionText: "name",
                      label: "Parent Category",
                      fullWidth: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                      lineNumber: 138,
                      columnNumber: 25
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                  lineNumber: 134,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 133,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Box,
                {
                  sx: {
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 2
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      Box,
                      {
                        sx: {
                          width: { xs: "100%", md: "calc(33.333% - 11px)" }
                        },
                        children: /* @__PURE__ */ jsxDEV(TextInput, { source: "image", label: "Image URL", fullWidth: true }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                          lineNumber: 158,
                          columnNumber: 23
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                        lineNumber: 153,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Box,
                      {
                        sx: {
                          width: { xs: "100%", md: "calc(33.333% - 11px)" }
                        },
                        children: /* @__PURE__ */ jsxDEV(TextInput, { source: "color", label: "Color", fullWidth: true }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                          lineNumber: 165,
                          columnNumber: 23
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                        lineNumber: 160,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Box,
                      {
                        sx: {
                          width: { xs: "100%", md: "calc(33.333% - 11px)" }
                        },
                        children: /* @__PURE__ */ jsxDEV(TextInput, { source: "icon", label: "Icon URL", fullWidth: true }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                          lineNumber: 172,
                          columnNumber: 23
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                        lineNumber: 167,
                        columnNumber: 21
                      },
                      this
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                  lineNumber: 146,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
              lineNumber: 111,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
            lineNumber: 84,
            columnNumber: 13
          }, this);
        } }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
          lineNumber: 79,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(BooleanInput, { source: "isActive", label: "Active", fullWidth: true }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 190,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 189,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(NumberInput, { source: "sortOrder", label: "Sort Order", min: 0, fullWidth: true }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 193,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
                lineNumber: 192,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
            lineNumber: 182,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx",
      lineNumber: 18,
      columnNumber: 5
    },
    this
  );
};
_c = CategoryForm;
var _c;
$RefreshReg$(_c, "CategoryForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJVLFNBb0ZNLFVBcEZOO0FBMUJWLE9BQU9BLFNBQVM7QUFDaEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBTUEsYUFBTUMsZUFBZUEsQ0FBQyxFQUFFQyxPQUFPLFNBQTRCLE1BQU07QUFDdEUsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsSUFBSTtBQUFBLFFBQ0ZDLFNBQVM7QUFBQSxRQUNUQyxlQUFlO0FBQUEsUUFDZkMsS0FBSztBQUFBLE1BQ1A7QUFBQSxNQUVBO0FBQUEsK0JBQUMsT0FBSSxJQUFJLEVBQUVDLE9BQU8sT0FBTyxHQUN0QkosbUJBQVMsV0FDUjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsUUFBTztBQUFBLFlBQ1AsT0FBTTtBQUFBLFlBQ04sU0FBUztBQUFBLGNBQ1AsRUFBRUssSUFBSSxHQUFHQyxNQUFNLG1CQUFtQjtBQUFBLGNBQ2xDLEVBQUVELElBQUksR0FBR0MsTUFBTSxrQkFBa0I7QUFBQSxjQUNqQyxFQUFFRCxJQUFJLEdBQUdDLE1BQU0scUJBQXFCO0FBQUEsWUFBQztBQUFBLFlBRXZDLGNBQWM7QUFBQSxZQUNkLFVBQVVWLFNBQVM7QUFBQSxZQUNuQixXQUFTO0FBQUE7QUFBQSxVQVZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVXLElBR1gsdUJBQUMsZUFBWSxRQUFPLFNBQVEsT0FBTSxrQkFBaUIsVUFBUSxNQUFDLFdBQVMsUUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRSxLQWZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSTtBQUFBLGNBQ0ZLLFNBQVM7QUFBQSxjQUNUTSxVQUFVO0FBQUEsY0FDVkosS0FBSztBQUFBLFlBQ1A7QUFBQSxZQUVBO0FBQUEscUNBQUMsT0FBSSxJQUFJLEVBQUVDLE9BQU8sRUFBRUksSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFFBQU87QUFBQSxrQkFDUCxPQUFNO0FBQUEsa0JBQ047QUFBQSxrQkFDQSxVQUFVYixTQUFTO0FBQUE7QUFBQSxnQkFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVCLEtBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFUSxPQUFPLEVBQUVJLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFPO0FBQUEsa0JBQ1AsT0FBTTtBQUFBLGtCQUNOO0FBQUEsa0JBQ0EsVUFBVWIsU0FBUztBQUFBO0FBQUEsZ0JBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1QixLQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXVCQTtBQUFBLFFBRUEsdUJBQUMsT0FBSSxJQUFJLEVBQUVRLE9BQU8sT0FBTyxHQUN2QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsUUFBTztBQUFBLFlBQ1AsT0FBTTtBQUFBLFlBQ047QUFBQSxZQUNBO0FBQUEsWUFDQSxNQUFNO0FBQUE7QUFBQSxVQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtVLEtBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxvQkFDRSxXQUFDLEVBQUVNLFNBQVMsTUFBTTtBQUNqQixnQkFBTUMsZUFBZUQsVUFBVUUsU0FBUztBQUV4QyxpQkFDRSxtQ0FDR0Q7QUFBQUEsNkJBQWlCLEtBQ2hCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSTtBQUFBLGtCQUNGVixTQUFTO0FBQUEsa0JBQ1RNLFVBQVU7QUFBQSxrQkFDVkosS0FBSztBQUFBLGdCQUNQO0FBQUEsZ0JBRUE7QUFBQSx5Q0FBQyxPQUFJLElBQUksRUFBRUMsT0FBTyxFQUFFSSxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsUUFBTztBQUFBLHNCQUNQLE9BQU07QUFBQSxzQkFDTixXQUFTO0FBQUE7QUFBQSxvQkFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBR1csS0FKYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsT0FBSSxJQUFJLEVBQUVMLE9BQU8sRUFBRUksSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFFBQU87QUFBQSxzQkFDUCxPQUFNO0FBQUEsc0JBQ04sV0FBUztBQUFBO0FBQUEsb0JBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUdXLEtBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFxQkE7QUFBQSxhQUdBRSxpQkFBaUIsS0FBS0EsaUJBQWlCLE1BQ3ZDLG1DQUNHWDtBQUFBQSx1QkFBUyxZQUNSLHVCQUFDLE9BQUksSUFBSSxFQUFFSSxPQUFPLE9BQU8sR0FDdkI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsUUFBTztBQUFBLGtCQUNQLFdBQVU7QUFBQSxrQkFDVixRQUFRLEVBQUVRLE9BQU9ELGlCQUFpQixJQUFJLElBQUksRUFBRTtBQUFBLGtCQUU1QztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxZQUFXO0FBQUEsc0JBQ1gsT0FDRUEsaUJBQWlCLElBQ2Isb0JBQ0E7QUFBQSxzQkFFTjtBQUFBLHNCQUNBLFVBQVVmLFNBQVM7QUFBQTtBQUFBLG9CQVJyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUXVCO0FBQUE7QUFBQSxnQkFiekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUVESSxTQUFTLFVBQ1IsdUJBQUMsT0FBSSxJQUFJLEVBQUVJLE9BQU8sT0FBTyxHQUN2QjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFPO0FBQUEsa0JBQ1AsV0FBVTtBQUFBLGtCQUVWO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFlBQVc7QUFBQSxzQkFDWCxPQUFNO0FBQUEsc0JBQ04sV0FBUztBQUFBO0FBQUEsb0JBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUdXO0FBQUE7QUFBQSxnQkFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUVGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUk7QUFBQSxvQkFDRkgsU0FBUztBQUFBLG9CQUNUTSxVQUFVO0FBQUEsb0JBQ1ZKLEtBQUs7QUFBQSxrQkFDUDtBQUFBLGtCQUVBO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBSTtBQUFBLDBCQUNGQyxPQUFPLEVBQUVJLElBQUksUUFBUUMsSUFBSSx1QkFBdUI7QUFBQSx3QkFDbEQ7QUFBQSx3QkFFQSxpQ0FBQyxhQUFVLFFBQU8sU0FBUSxPQUFNLGFBQVksV0FBUyxRQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxRDtBQUFBO0FBQUEsc0JBTHZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLElBQUk7QUFBQSwwQkFDRkwsT0FBTyxFQUFFSSxJQUFJLFFBQVFDLElBQUksdUJBQXVCO0FBQUEsd0JBQ2xEO0FBQUEsd0JBRUEsaUNBQUMsYUFBVSxRQUFPLFNBQVEsT0FBTSxTQUFRLFdBQVMsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUQ7QUFBQTtBQUFBLHNCQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFJO0FBQUEsMEJBQ0ZMLE9BQU8sRUFBRUksSUFBSSxRQUFRQyxJQUFJLHVCQUF1QjtBQUFBLHdCQUNsRDtBQUFBLHdCQUVBLGlDQUFDLGFBQVUsUUFBTyxRQUFPLE9BQU0sWUFBVyxXQUFTLFFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW1EO0FBQUE7QUFBQSxzQkFMckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUE7QUFBQTtBQUFBLGdCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E0QkE7QUFBQSxpQkEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnRUE7QUFBQSxlQTNGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZGQTtBQUFBLFFBRUosS0FwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFHQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxjQUNGUixTQUFTO0FBQUEsY0FDVE0sVUFBVTtBQUFBLGNBQ1ZKLEtBQUs7QUFBQSxZQUNQO0FBQUEsWUFFQTtBQUFBLHFDQUFDLE9BQUksSUFBSSxFQUFFQyxPQUFPLEVBQUVJLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RCxpQ0FBQyxnQkFBYSxRQUFPLFlBQVcsT0FBTSxVQUFTLFdBQVMsUUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0QsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBSSxJQUFJLEVBQUVMLE9BQU8sRUFBRUksSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3RELGlDQUFDLGVBQVksUUFBTyxhQUFZLE9BQU0sY0FBYSxLQUFLLEdBQUcsV0FBUyxRQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRSxLQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUE7QUFBQTtBQUFBLFVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQTtBQUFBO0FBQUEsSUFqTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0xBO0FBRUo7QUFBRUksS0F0TFdkO0FBQVksSUFBQWM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQm94IiwiQm9vbGVhbklucHV0IiwiRm9ybURhdGFDb25zdW1lciIsIk51bWJlcklucHV0IiwiUmVmZXJlbmNlSW5wdXQiLCJyZXF1aXJlZCIsIlNlbGVjdElucHV0IiwiVGV4dElucHV0IiwiQ2F0ZWdvcnlGb3JtIiwibW9kZSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwid2lkdGgiLCJpZCIsIm5hbWUiLCJmbGV4V3JhcCIsInhzIiwibWQiLCJmb3JtRGF0YSIsImN1cnJlbnRMZXZlbCIsImxldmVsIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2F0ZWdvcnlGb3JtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQm94IGZyb20gXCJAbXVpL21hdGVyaWFsL0JveFwiO1xuaW1wb3J0IHtcbiAgQm9vbGVhbklucHV0LFxuICBGb3JtRGF0YUNvbnN1bWVyLFxuICBOdW1iZXJJbnB1dCxcbiAgUmVmZXJlbmNlSW5wdXQsXG4gIHJlcXVpcmVkLFxuICBTZWxlY3RJbnB1dCxcbiAgVGV4dElucHV0LFxufSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcblxudHlwZSBDYXRlZ29yeUZvcm1Qcm9wcyA9IHtcbiAgbW9kZT86IFwiY3JlYXRlXCIgfCBcImVkaXRcIjtcbn07XG5cbmV4cG9ydCBjb25zdCBDYXRlZ29yeUZvcm0gPSAoeyBtb2RlID0gXCJjcmVhdGVcIiB9OiBDYXRlZ29yeUZvcm1Qcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxCb3hcbiAgICAgIHN4PXt7XG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICBnYXA6IDIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxuICAgICAgICB7bW9kZSA9PT0gXCJjcmVhdGVcIiA/IChcbiAgICAgICAgICA8U2VsZWN0SW5wdXRcbiAgICAgICAgICAgIHNvdXJjZT1cImxldmVsXCJcbiAgICAgICAgICAgIGxhYmVsPVwiQ2F0ZWdvcnkgTGV2ZWxcIlxuICAgICAgICAgICAgY2hvaWNlcz17W1xuICAgICAgICAgICAgICB7IGlkOiAxLCBuYW1lOiBcIlBhcmVudCAoTGV2ZWwgMSlcIiB9LFxuICAgICAgICAgICAgICB7IGlkOiAyLCBuYW1lOiBcIkNoaWxkIChMZXZlbCAyKVwiIH0sXG4gICAgICAgICAgICAgIHsgaWQ6IDMsIG5hbWU6IFwiU3ViY2hpbGQgKExldmVsIDMpXCIgfSxcbiAgICAgICAgICAgIF19XG4gICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezF9XG4gICAgICAgICAgICB2YWxpZGF0ZT17cmVxdWlyZWQoKX1cbiAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPE51bWJlcklucHV0IHNvdXJjZT1cImxldmVsXCIgbGFiZWw9XCJDYXRlZ29yeSBMZXZlbFwiIGRpc2FibGVkIGZ1bGxXaWR0aCAvPlxuICAgICAgICApfVxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgZ2FwOiAyLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICBzb3VyY2U9XCJuYW1lXCJcbiAgICAgICAgICAgIGxhYmVsPVwiTmFtZVwiXG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQm94PlxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICBzb3VyY2U9XCJzbHVnXCJcbiAgICAgICAgICAgIGxhYmVsPVwiU2x1Z1wiXG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQm94PlxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxuICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgc291cmNlPVwiZGVzY3JpcHRpb25cIlxuICAgICAgICAgIGxhYmVsPVwiRGVzY3JpcHRpb25cIlxuICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgIG11bHRpbGluZVxuICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgIC8+XG4gICAgICA8L0JveD5cblxuICAgICAgPEZvcm1EYXRhQ29uc3VtZXI+XG4gICAgICAgIHsoeyBmb3JtRGF0YSB9KSA9PiB7XG4gICAgICAgICAgY29uc3QgY3VycmVudExldmVsID0gZm9ybURhdGE/LmxldmVsIHx8IDE7XG5cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAge2N1cnJlbnRMZXZlbCA9PT0gMSAmJiAoXG4gICAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHNvdXJjZT1cInBhcmVudEltYWdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlBhcmVudCBJbWFnZSBVUkxcIlxuICAgICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHNvdXJjZT1cInBhcmVudEJhbm5lclwiXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQYXJlbnQgQmFubmVyIFVSTFwiXG4gICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7KGN1cnJlbnRMZXZlbCA9PT0gMiB8fCBjdXJyZW50TGV2ZWwgPT09IDMpICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAge21vZGUgPT09IFwiY3JlYXRlXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8UmVmZXJlbmNlSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHNvdXJjZT1cInBhcmVudElkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZmVyZW5jZT1cImNhdGVnb3J5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcj17eyBsZXZlbDogY3VycmVudExldmVsID09PSAyID8gMSA6IDIgfX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVGV4dD1cIm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudExldmVsID09PSAyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiUGFyZW50IENhdGVnb3J5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDaGlsZCBDYXRlZ29yeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L1JlZmVyZW5jZUlucHV0PlxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7bW9kZSA9PT0gXCJlZGl0XCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8UmVmZXJlbmNlSW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHNvdXJjZT1cInBhcmVudElkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZmVyZW5jZT1cImNhdGVnb3J5XCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uVGV4dD1cIm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlBhcmVudCBDYXRlZ29yeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L1JlZmVyZW5jZUlucHV0PlxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgZmxleFdyYXA6IFwid3JhcFwiLFxuICAgICAgICAgICAgICAgICAgICAgIGdhcDogMixcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBcImNhbGMoMzMuMzMzJSAtIDExcHgpXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFRleHRJbnB1dCBzb3VyY2U9XCJpbWFnZVwiIGxhYmVsPVwiSW1hZ2UgVVJMXCIgZnVsbFdpZHRoIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYygzMy4zMzMlIC0gMTFweClcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dElucHV0IHNvdXJjZT1cImNvbG9yXCIgbGFiZWw9XCJDb2xvclwiIGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBcImNhbGMoMzMuMzMzJSAtIDExcHgpXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFRleHRJbnB1dCBzb3VyY2U9XCJpY29uXCIgbGFiZWw9XCJJY29uIFVSTFwiIGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKTtcbiAgICAgICAgfX1cbiAgICAgIDwvRm9ybURhdGFDb25zdW1lcj5cblxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICBnYXA6IDIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgIDxCb29sZWFuSW5wdXQgc291cmNlPVwiaXNBY3RpdmVcIiBsYWJlbD1cIkFjdGl2ZVwiIGZ1bGxXaWR0aCAvPlxuICAgICAgICA8L0JveD5cbiAgICAgICAgPEJveCBzeD17eyB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBcImNhbGMoNTAlIC0gOHB4KVwiIH0gfX0+XG4gICAgICAgICAgPE51bWJlcklucHV0IHNvdXJjZT1cInNvcnRPcmRlclwiIGxhYmVsPVwiU29ydCBPcmRlclwiIG1pbj17MH0gZnVsbFdpZHRoIC8+XG4gICAgICAgIDwvQm94PlxuICAgICAgPC9Cb3g+XG4gICAgPC9Cb3g+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2NhdGVnb3JpZXMvQ2F0ZWdvcnlGb3JtLnRzeCJ9