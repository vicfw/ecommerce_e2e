import {
  activeElement,
  ownerDocument
} from "/node_modules/.vite/deps/chunk-AMU7WGDT.js?v=49ae7072";
import {
  useEnhancedEffect_default
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/utils/useEnhancedEffect.mjs
var useEnhancedEffect_default2 = useEnhancedEffect_default;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/utils/ownerDocument.mjs
var ownerDocument_default = ownerDocument;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/utils/getActiveElement.mjs
var getActiveElement_default = activeElement;

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/debounce/debounce.mjs
function debounce(func, wait = 166) {
  let timeout;
  function debounced(...args) {
    const later = () => {
      func.apply(this, args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  }
  debounced.clear = () => {
    clearTimeout(timeout);
  };
  return debounced;
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/ownerWindow/ownerWindow.mjs
function ownerWindow(node) {
  const doc = ownerDocument(node);
  return doc.defaultView || window;
}

export {
  debounce,
  ownerWindow,
  useEnhancedEffect_default2 as useEnhancedEffect_default,
  ownerDocument_default,
  getActiveElement_default
};
//# sourceMappingURL=chunk-OBO4F245.js.map
