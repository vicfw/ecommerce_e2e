"use client";
import "/node_modules/.vite/deps/chunk-BWL3NMBV.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-2CTOBPYC.js?v=49ae7072";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-ZMHT7GOB.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-B2OBFM6G.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-YIMRGSOF.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/LocalOffer.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var LocalOffer_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "m21.41 11.58-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41s-.23-1.06-.59-1.42M5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7"
}), "LocalOffer");
export {
  LocalOffer_default as default
};
//# sourceMappingURL=@mui_icons-material_LocalOffer.js.map
