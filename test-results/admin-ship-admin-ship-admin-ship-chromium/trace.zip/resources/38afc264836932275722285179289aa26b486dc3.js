import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import axios from "/node_modules/.vite/deps/axios.js?v=49ae7072";
import { clearSession, TOKEN_KEY } from "/src/api/auth/session.ts";
const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:9000/api/v1";
export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json"
  }
});
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      clearSession();
      if (!window.location.pathname.startsWith("/login")) {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF4aW9zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmltcG9ydCB7IGNsZWFyU2Vzc2lvbiwgVE9LRU5fS0VZIH0gZnJvbSBcIi4vYXV0aC9zZXNzaW9uXCI7XG5cbmNvbnN0IEFQSV9CQVNFX1VSTCA9XG4gIGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9VUkwgfHwgXCJodHRwOi8vbG9jYWxob3N0OjkwMDAvYXBpL3YxXCI7XG5cbmV4cG9ydCBjb25zdCBhcGlDbGllbnQgPSBheGlvcy5jcmVhdGUoe1xuICBiYXNlVVJMOiBBUElfQkFTRV9VUkwsXG4gIGhlYWRlcnM6IHtcbiAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgfSxcbn0pO1xuXG5hcGlDbGllbnQuaW50ZXJjZXB0b3JzLnJlcXVlc3QudXNlKFxuICAoY29uZmlnKSA9PiB7XG4gICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShUT0tFTl9LRVkpO1xuICAgIGlmICh0b2tlbikge1xuICAgICAgY29uZmlnLmhlYWRlcnMuQXV0aG9yaXphdGlvbiA9IGBCZWFyZXIgJHt0b2tlbn1gO1xuICAgIH1cbiAgICByZXR1cm4gY29uZmlnO1xuICB9LFxuICAoZXJyb3IpID0+IHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICB9XG4pO1xuXG5hcGlDbGllbnQuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLnVzZShcbiAgKHJlc3BvbnNlKSA9PiByZXNwb25zZSxcbiAgKGVycm9yKSA9PiB7XG4gICAgaWYgKGVycm9yLnJlc3BvbnNlPy5zdGF0dXMgPT09IDQwMSkge1xuICAgICAgY2xlYXJTZXNzaW9uKCk7XG4gICAgICBpZiAoIXdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKFwiL2xvZ2luXCIpKSB7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvbG9naW5cIjtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgfVxuKTtcblxuZXhwb3J0IHR5cGUgQXhpb3NSZXNwb25zZTxUPiA9IHtcbiAgZGF0YTogVDtcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBzdWNjZXNzOiBib29sZWFuO1xufTtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYyxpQkFBaUI7QUFFeEMsTUFBTSxlQUNKLFlBQVksSUFBSSxnQkFBZ0I7QUFFM0IsYUFBTSxZQUFZLE1BQU0sT0FBTztBQUFBLEVBQ3BDLFNBQVM7QUFBQSxFQUNULFNBQVM7QUFBQSxJQUNQLGdCQUFnQjtBQUFBLEVBQ2xCO0FBQ0YsQ0FBQztBQUVELFVBQVUsYUFBYSxRQUFRO0FBQUEsRUFDN0IsQ0FBQyxXQUFXO0FBQ1YsVUFBTSxRQUFRLGFBQWEsUUFBUSxTQUFTO0FBQzVDLFFBQUksT0FBTztBQUNULGFBQU8sUUFBUSxnQkFBZ0IsVUFBVSxLQUFLO0FBQUEsSUFDaEQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsQ0FBQyxVQUFVO0FBQ1QsV0FBTyxRQUFRLE9BQU8sS0FBSztBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxVQUFVLGFBQWEsU0FBUztBQUFBLEVBQzlCLENBQUMsYUFBYTtBQUFBLEVBQ2QsQ0FBQyxVQUFVO0FBQ1QsUUFBSSxNQUFNLFVBQVUsV0FBVyxLQUFLO0FBQ2xDLG1CQUFhO0FBQ2IsVUFBSSxDQUFDLE9BQU8sU0FBUyxTQUFTLFdBQVcsUUFBUSxHQUFHO0FBQ2xELGVBQU8sU0FBUyxPQUFPO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQ0EsV0FBTyxRQUFRLE9BQU8sS0FBSztBQUFBLEVBQzdCO0FBQ0Y7IiwibmFtZXMiOltdfQ==