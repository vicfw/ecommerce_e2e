import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/badges/BadgeList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  List,
  Datagrid,
  TextField,
  NumberField,
  EditButton,
  DeleteButton
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { SwatchField } from "/src/components/SwatchOption.tsx";
export const BadgeList = () => {
  return /* @__PURE__ */ jsxDEV(List, { children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "edit", children: [
    /* @__PURE__ */ jsxDEV(NumberField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
      lineNumber: 15,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      SwatchField,
      {
        imageSource: "icon",
        labelSource: "title",
        label: "Icon"
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
        lineNumber: 16,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(TextField, { source: "title" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
      lineNumber: 21,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DeleteButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
    lineNumber: 14,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
};
_c = BadgeList;
var _c;
$RefreshReg$(_c, "BadgeList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1E7QUFkUjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsWUFBWUEsTUFBTTtBQUM3QixTQUNFLHVCQUFDLFFBQ0MsaUNBQUMsWUFBUyxVQUFTLFFBQ2pCO0FBQUEsMkJBQUMsZUFBWSxRQUFPLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUN4QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsYUFBWTtBQUFBLFFBQ1osYUFBWTtBQUFBLFFBQ1osT0FBTTtBQUFBO0FBQUEsTUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHYztBQUFBLElBRWQsdUJBQUMsYUFBVSxRQUFPLFdBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxJQUN6Qix1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVc7QUFBQSxJQUNYLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYTtBQUFBLE9BVGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBRUMsS0FoQldEO0FBQVMsSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGlzdCIsIkRhdGFncmlkIiwiVGV4dEZpZWxkIiwiTnVtYmVyRmllbGQiLCJFZGl0QnV0dG9uIiwiRGVsZXRlQnV0dG9uIiwiU3dhdGNoRmllbGQiLCJCYWRnZUxpc3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCYWRnZUxpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIExpc3QsXG4gIERhdGFncmlkLFxuICBUZXh0RmllbGQsXG4gIE51bWJlckZpZWxkLFxuICBFZGl0QnV0dG9uLFxuICBEZWxldGVCdXR0b24sXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IHsgU3dhdGNoRmllbGQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9Td2F0Y2hPcHRpb25cIjtcblxuZXhwb3J0IGNvbnN0IEJhZGdlTGlzdCA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8TGlzdD5cbiAgICAgIDxEYXRhZ3JpZCByb3dDbGljaz1cImVkaXRcIj5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cImlkXCIgLz5cbiAgICAgICAgPFN3YXRjaEZpZWxkXG4gICAgICAgICAgaW1hZ2VTb3VyY2U9XCJpY29uXCJcbiAgICAgICAgICBsYWJlbFNvdXJjZT1cInRpdGxlXCJcbiAgICAgICAgICBsYWJlbD1cIkljb25cIlxuICAgICAgICAvPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cInRpdGxlXCIgLz5cbiAgICAgICAgPEVkaXRCdXR0b24gLz5cbiAgICAgICAgPERlbGV0ZUJ1dHRvbiAvPlxuICAgICAgPC9EYXRhZ3JpZD5cbiAgICA8L0xpc3Q+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2JhZGdlcy9CYWRnZUxpc3QudHN4In0=