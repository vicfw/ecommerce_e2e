import {
  useLazyRef
} from "/node_modules/.vite/deps/chunk-HFNW56X4.js?v=49ae7072";
import {
  reflow
} from "/node_modules/.vite/deps/chunk-B2OBFM6G.js?v=49ae7072";
import {
  require_prop_types,
  useEnhancedEffect_default
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/internal/Transition.mjs
var React2 = __toESM(require_react(), 1);
var import_prop_types = __toESM(require_prop_types(), 1);

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useValueAsRef/useValueAsRef.mjs
function useValueAsRef(value) {
  const latest = useLazyRef(() => createValueRef(value)).current;
  latest.next = value;
  useEnhancedEffect_default(latest.effect);
  return latest;
}
function createValueRef(value) {
  const latest = {
    current: value,
    next: value,
    effect: () => {
      latest.current = latest.next;
    }
  };
  return latest;
}

// node_modules/.pnpm/react-transition-group@4.4.5_react-dom@19.2.8_react@19.2.8__react@19.2.8/node_modules/react-transition-group/esm/TransitionGroupContext.js
var import_react = __toESM(require_react());
var TransitionGroupContext_default = import_react.default.createContext(null);

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/internal/Transition.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
function resolveTimeouts(timeout) {
  if (timeout == null) {
    return {
      appear: void 0,
      enter: void 0,
      exit: void 0
    };
  }
  if (typeof timeout === "number") {
    return {
      appear: timeout,
      enter: timeout,
      exit: timeout
    };
  }
  const enter = timeout.enter;
  const exit = timeout.exit;
  const appear = timeout.appear !== void 0 ? timeout.appear : enter;
  return {
    appear,
    enter,
    exit
  };
}
function getCompletionTimeout(params) {
  if (params.autoTimeout != null) {
    return params.autoTimeout;
  }
  const resolved = resolveTimeouts(params.timeout);
  if (params.currentStatus === "entering") {
    return params.isAppearing ? resolved.appear ?? resolved.enter ?? null : resolved.enter ?? null;
  }
  return resolved.exit ?? null;
}
function Transition(props) {
  const {
    in: inProp = false,
    appear = false,
    enter = true,
    exit = true,
    mountOnEnter = false,
    unmountOnExit = false,
    timeout,
    addEndListener,
    reduceMotion = false,
    getAutoTimeout,
    nodeRef,
    onEnter,
    onEntering,
    onEntered,
    onExit,
    onExiting,
    onExited,
    children,
    ...childProps
  } = props;
  const parentGroup = React2.useContext(TransitionGroupContext_default);
  const shouldEnterOnMount = parentGroup && !parentGroup.isMounting ? enter : appear;
  const [status, setStatus] = React2.useState(() => {
    if (inProp) {
      return shouldEnterOnMount ? "exited" : "entered";
    }
    if (mountOnEnter || unmountOnExit) {
      return "unmounted";
    }
    return "exited";
  });
  const statusRef = React2.useRef(status);
  statusRef.current = status;
  if (inProp && status === "unmounted") {
    statusRef.current = "exited";
    setStatus("exited");
  }
  const shouldAppearOnMountRef = React2.useRef(inProp && shouldEnterOnMount);
  const mountedRef = React2.useRef(false);
  const nextCallbackRef = React2.useRef(null);
  const lastFiredStatusRef = React2.useRef(status);
  const isAppearingRef = React2.useRef(false);
  const transitionReduceMotionRef = React2.useRef(reduceMotion);
  const propsRef = useValueAsRef({
    timeout,
    addEndListener,
    reduceMotion,
    getAutoTimeout,
    onEnter,
    onEntering,
    onEntered,
    onExit,
    onExiting,
    onExited,
    enter,
    exit,
    mountOnEnter,
    unmountOnExit,
    nodeRef,
    parentGroup
  });
  const cancelPendingCallback = React2.useCallback(() => {
    if (nextCallbackRef.current !== null) {
      nextCallbackRef.current.cancel();
      nextCallbackRef.current = null;
    }
  }, []);
  const makeCallback = React2.useCallback((handler) => {
    let active = true;
    const wrapped = () => {
      if (active) {
        active = false;
        nextCallbackRef.current = null;
        handler();
      }
    };
    wrapped.cancel = () => {
      active = false;
    };
    nextCallbackRef.current = wrapped;
    return wrapped;
  }, []);
  const scheduleTransitionEnd = React2.useCallback((nextStatus, currentStatus) => {
    let timeoutId;
    const clearTimer = () => {
      if (timeoutId !== void 0) {
        clearTimeout(timeoutId);
        timeoutId = void 0;
      }
    };
    const done = makeCallback(() => {
      clearTimer();
      statusRef.current = nextStatus;
      setStatus(nextStatus);
    });
    const cancelDone = done.cancel;
    done.cancel = () => {
      clearTimer();
      cancelDone();
    };
    const node = propsRef.current.nodeRef.current;
    const listener = propsRef.current.addEndListener;
    const hasAutoTimeout = propsRef.current.getAutoTimeout !== void 0;
    const autoTimeout = propsRef.current.getAutoTimeout?.();
    const authoredTimeout = getCompletionTimeout({
      currentStatus,
      isAppearing: isAppearingRef.current,
      timeout: propsRef.current.timeout,
      autoTimeout
    });
    const transitionReduceMotion = transitionReduceMotionRef.current;
    const fallbackTimeout = authoredTimeout ?? (transitionReduceMotion && hasAutoTimeout ? 0 : null);
    const scheduleTimer = (value) => {
      timeoutId = setTimeout(done, value);
    };
    if (!node) {
      if (true) {
        console.warn(["MUI: The transition child does not expose a DOM element.", "Make sure the child accepts a ref and forwards it to the underlying DOM element.", "The transition animation cannot be observed without a DOM element and will be skipped."].join("\n"));
      }
      scheduleTimer(0);
      return;
    }
    if (listener) {
      if (fallbackTimeout != null) {
        scheduleTimer(transitionReduceMotion ? 0 : fallbackTimeout);
      }
      if (listener.length >= 2) {
        listener(node, done);
      } else {
        listener(done);
      }
      return;
    }
    scheduleTimer(transitionReduceMotion ? 0 : authoredTimeout ?? 0);
  }, [makeCallback, propsRef]);
  const performEnter = React2.useCallback((mounting) => {
    const current = propsRef.current;
    const isAppearing = current.parentGroup ? current.parentGroup.isMounting : mounting;
    isAppearingRef.current = isAppearing;
    if (!mounting && !current.enter) {
      statusRef.current = "entered";
      setStatus("entered");
      return;
    }
    transitionReduceMotionRef.current = current.reduceMotion;
    current.onEnter?.(isAppearing);
    statusRef.current = "entering";
    setStatus("entering");
  }, [propsRef]);
  const performExit = React2.useCallback(() => {
    const current = propsRef.current;
    if (!current.exit) {
      statusRef.current = "exited";
      setStatus("exited");
      return;
    }
    transitionReduceMotionRef.current = current.reduceMotion;
    current.onExit?.();
    statusRef.current = "exiting";
    setStatus("exiting");
  }, [propsRef]);
  const updateStatus = React2.useCallback((mounting, nextStatus) => {
    cancelPendingCallback();
    if (nextStatus === "entering") {
      const current = propsRef.current;
      if (current.mountOnEnter || current.unmountOnExit) {
        const node = current.nodeRef.current;
        if (node) {
          reflow(node);
        }
      }
      performEnter(mounting);
    } else {
      performExit();
    }
  }, [cancelPendingCallback, performEnter, performExit, propsRef]);
  useEnhancedEffect_default(() => {
    mountedRef.current = true;
    if (shouldAppearOnMountRef.current) {
      shouldAppearOnMountRef.current = false;
      updateStatus(true, "entering");
    }
    return () => {
      mountedRef.current = false;
      cancelPendingCallback();
    };
  }, [cancelPendingCallback, updateStatus]);
  useEnhancedEffect_default(() => {
    if (!mountedRef.current) {
      return;
    }
    const current = statusRef.current;
    if (inProp) {
      if (current !== "entering" && current !== "entered") {
        updateStatus(false, "entering");
      }
    } else if (current === "entering" || current === "entered") {
      updateStatus(false, "exiting");
    } else if (current === "exited" && unmountOnExit) {
      statusRef.current = "unmounted";
      setStatus("unmounted");
    }
  }, [inProp, status, unmountOnExit, updateStatus]);
  useEnhancedEffect_default(() => {
    if (status === "unmounted" || lastFiredStatusRef.current === "unmounted") {
      lastFiredStatusRef.current = status;
      return;
    }
    const prev = lastFiredStatusRef.current;
    const statusChanged = prev !== status;
    if (statusChanged) {
      lastFiredStatusRef.current = status;
    }
    const current = propsRef.current;
    if (status === "entering") {
      if (statusChanged) {
        current.onEntering?.(isAppearingRef.current);
      }
      if (nextCallbackRef.current === null && statusRef.current === status) {
        scheduleTransitionEnd("entered", "entering");
      }
    } else if (status === "exiting") {
      if (statusChanged) {
        current.onExiting?.();
      }
      if (nextCallbackRef.current === null && statusRef.current === status) {
        scheduleTransitionEnd("exited", "exiting");
      }
    } else if (status === "entered" && statusChanged) {
      current.onEntered?.(isAppearingRef.current);
    } else if (status === "exited" && statusChanged) {
      current.onExited?.();
    }
  }, [propsRef, scheduleTransitionEnd, status]);
  if (status === "unmounted") {
    return null;
  }
  return (0, import_jsx_runtime.jsx)(TransitionGroupContext_default.Provider, {
    value: null,
    children: children(status, childProps)
  });
}
true ? Transition.propTypes = {
  // ┌────────────────────────────── Warning ──────────────────────────────┐
  // │ These PropTypes are generated from the TypeScript type definitions. │
  // │ To update them, edit the TypeScript types and run `pnpm proptypes`. │
  // └─────────────────────────────────────────────────────────────────────┘
  /**
   * @ignore
   */
  addEndListener: import_prop_types.default.func,
  /**
   * @ignore
   */
  appear: import_prop_types.default.bool,
  /**
   * @ignore
   */
  children: import_prop_types.default.func.isRequired,
  /**
   * @ignore
   */
  enter: import_prop_types.default.bool,
  /**
   * @ignore
   */
  exit: import_prop_types.default.bool,
  /**
   * @ignore
   */
  getAutoTimeout: import_prop_types.default.func,
  /**
   * @ignore
   */
  in: import_prop_types.default.bool,
  /**
   * @ignore
   */
  mountOnEnter: import_prop_types.default.bool,
  /**
   * @ignore
   */
  nodeRef: import_prop_types.default.shape({
    current: (props, propName) => {
      if (props[propName] == null) {
        return null;
      }
      if (typeof props[propName] !== "object" || props[propName].nodeType !== 1) {
        return new Error(`Expected prop '${propName}' to be of type Element`);
      }
      return null;
    }
  }).isRequired,
  /**
   * @ignore
   */
  onEnter: import_prop_types.default.func,
  /**
   * @ignore
   */
  onEntered: import_prop_types.default.func,
  /**
   * @ignore
   */
  onEntering: import_prop_types.default.func,
  /**
   * @ignore
   */
  onExit: import_prop_types.default.func,
  /**
   * @ignore
   */
  onExited: import_prop_types.default.func,
  /**
   * @ignore
   */
  onExiting: import_prop_types.default.func,
  /**
   * @ignore
   */
  reduceMotion: import_prop_types.default.bool,
  /**
   * @ignore
   */
  timeout: import_prop_types.default.oneOfType([import_prop_types.default.number, import_prop_types.default.shape({
    appear: import_prop_types.default.number,
    enter: import_prop_types.default.number,
    exit: import_prop_types.default.number
  })]),
  /**
   * @ignore
   */
  unmountOnExit: import_prop_types.default.bool
} : void 0;
var Transition_default = Transition;

export {
  Transition_default
};
//# sourceMappingURL=chunk-23SU6EBW.js.map
