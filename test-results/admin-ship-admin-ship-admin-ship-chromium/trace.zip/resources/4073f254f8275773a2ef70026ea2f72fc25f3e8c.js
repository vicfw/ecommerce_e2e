import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Login.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=49ae7072"; const useState = __vite__cjsImport1_react["useState"];
import { Login, useLogin, useNotify } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Button from "/node_modules/.vite/deps/@mui_material_Button.js?v=49ae7072";
import Card from "/node_modules/.vite/deps/@mui_material_Card.js?v=49ae7072";
import CardContent from "/node_modules/.vite/deps/@mui_material_CardContent.js?v=49ae7072";
import TextField from "/node_modules/.vite/deps/@mui_material_TextField.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
import { requestOtp } from "/src/api/auth/index.ts";
const PHONE_REGEX = /^(?:(?:(?:\+?|00)(98))|(0))?((?:90|91|92|93|99)[0-9]{8})$/;
export const LoginPage = () => {
  _s();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [code, setCode] = useState("");
  const [codeSent, setCodeSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const login = useLogin();
  const notify = useNotify();
  const handleSendCode = async () => {
    const trimmedPhone = phoneNumber.trim();
    if (!PHONE_REGEX.test(trimmedPhone)) {
      notify("Please enter a valid phone number", { type: "warning" });
      return;
    }
    setLoading(true);
    try {
      const response = await requestOtp(trimmedPhone);
      setPhoneNumber(trimmedPhone);
      setCodeSent(true);
      notify(
        response.code ? `Verification code sent (${response.code})` : "Verification code sent",
        { type: "info" }
      );
    } catch (error) {
      const message = error?.response?.data?.message ?? "Failed to send verification code";
      notify(message, { type: "error" });
    } finally {
      setLoading(false);
    }
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    if (!/^\d{4}$/.test(code)) {
      notify("Verification code must be 4 digits", { type: "warning" });
      return;
    }
    setLoading(true);
    try {
      await login({ phoneNumber: phoneNumber.trim(), code });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Login failed";
      notify(message, { type: "error" });
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Login, { children: /* @__PURE__ */ jsxDEV(
    Card,
    {
      sx: {
        minWidth: 320,
        maxWidth: 420,
        width: "100%"
      },
      children: /* @__PURE__ */ jsxDEV(CardContent, { children: /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            flexDirection: "column",
            gap: 2
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  display: "flex",
                  flexDirection: "column",
                  gap: 0.5
                },
                children: [
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", sx: { fontWeight: 800 }, children: "Admin Login" }, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                    lineNumber: 96,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Sign in with your admin phone number and verification code." }, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                    lineNumber: 99,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                lineNumber: 89,
                columnNumber: 13
              },
              this
            ),
            !codeSent ? /* @__PURE__ */ jsxDEV(
              Box,
              {
                component: "form",
                onSubmit: (event) => {
                  event.preventDefault();
                  void handleSendCode();
                },
                sx: {
                  display: "flex",
                  flexDirection: "column",
                  gap: 2
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    TextField,
                    {
                      label: "Phone number",
                      value: phoneNumber,
                      onChange: (event) => setPhoneNumber(event.target.value),
                      fullWidth: true,
                      autoFocus: true,
                      placeholder: "09XXXXXXXXX"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                      lineNumber: 117,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "submit",
                      variant: "contained",
                      disabled: loading,
                      fullWidth: true,
                      children: "Send code"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                      lineNumber: 125,
                      columnNumber: 17
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                lineNumber: 105,
                columnNumber: 13
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              Box,
              {
                component: "form",
                onSubmit: (event) => {
                  void handleLogin(event);
                },
                sx: {
                  display: "flex",
                  flexDirection: "column",
                  gap: 2
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    TextField,
                    {
                      label: "Phone number",
                      value: phoneNumber,
                      disabled: true,
                      fullWidth: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                      lineNumber: 146,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    TextField,
                    {
                      label: "Verification code",
                      value: code,
                      onChange: (event) => setCode(event.target.value),
                      fullWidth: true,
                      autoFocus: true,
                      inputProps: { maxLength: 4, inputMode: "numeric" }
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                      lineNumber: 152,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "submit",
                      variant: "contained",
                      disabled: loading,
                      fullWidth: true,
                      children: "Login"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                      lineNumber: 160,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "button",
                      variant: "text",
                      disabled: loading,
                      onClick: () => {
                        setCodeSent(false);
                        setCode("");
                      },
                      children: "Change phone number"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                      lineNumber: 168,
                      columnNumber: 17
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
                lineNumber: 135,
                columnNumber: 13
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
          lineNumber: 82,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
        lineNumber: 81,
        columnNumber: 9
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
      lineNumber: 74,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx",
    lineNumber: 73,
    columnNumber: 5
  }, this);
};
_s(LoginPage, "TUCpBtufK7DxsmWFY5zO92bDreE=", false, function() {
  return [useLogin, useNotify];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/pages/Login.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZjOztBQS9GZCxTQUFTQSxnQkFBZ0I7QUFFekIsU0FBU0MsT0FBT0MsVUFBVUMsaUJBQWlCO0FBQzNDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsY0FDSjtBQUVLLGFBQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSWYsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2dCLE1BQU1DLE9BQU8sSUFBSWpCLFNBQVMsRUFBRTtBQUNuQyxRQUFNLENBQUNrQixVQUFVQyxXQUFXLElBQUluQixTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDb0IsU0FBU0MsVUFBVSxJQUFJckIsU0FBUyxLQUFLO0FBQzVDLFFBQU1zQixRQUFRcEIsU0FBUztBQUN2QixRQUFNcUIsU0FBU3BCLFVBQVU7QUFFekIsUUFBTXFCLGlCQUFpQixZQUFZO0FBQ2pDLFVBQU1DLGVBQWVYLFlBQVlZLEtBQUs7QUFFdEMsUUFBSSxDQUFDZixZQUFZZ0IsS0FBS0YsWUFBWSxHQUFHO0FBQ25DRixhQUFPLHFDQUFxQyxFQUFFSyxNQUFNLFVBQVUsQ0FBQztBQUMvRDtBQUFBLElBQ0Y7QUFFQVAsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFlBQU1RLFdBQVcsTUFBTW5CLFdBQVdlLFlBQVk7QUFDOUNWLHFCQUFlVSxZQUFZO0FBQzNCTixrQkFBWSxJQUFJO0FBQ2hCSTtBQUFBQSxRQUNFTSxTQUFTYixPQUNMLDJCQUEyQmEsU0FBU2IsSUFBSSxNQUN4QztBQUFBLFFBQ0osRUFBRVksTUFBTSxPQUFPO0FBQUEsTUFDakI7QUFBQSxJQUNGLFNBQVNFLE9BQWdCO0FBQ3ZCLFlBQU1DLFVBQ0hELE9BQTBERCxVQUN2REcsTUFBTUQsV0FBVztBQUN2QlIsYUFBT1EsU0FBUyxFQUFFSCxNQUFNLFFBQVEsQ0FBQztBQUFBLElBQ25DLFVBQUM7QUFDQ1AsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFFBQU1ZLGNBQWMsT0FBT0MsVUFBcUI7QUFDOUNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSSxDQUFDLFVBQVVSLEtBQUtYLElBQUksR0FBRztBQUN6Qk8sYUFBTyxzQ0FBc0MsRUFBRUssTUFBTSxVQUFVLENBQUM7QUFDaEU7QUFBQSxJQUNGO0FBRUFQLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNQyxNQUFNLEVBQUVSLGFBQWFBLFlBQVlZLEtBQUssR0FBR1YsS0FBSyxDQUFDO0FBQUEsSUFDdkQsU0FBU2MsT0FBZ0I7QUFDdkIsWUFBTUMsVUFDSkQsaUJBQWlCTSxRQUFRTixNQUFNQyxVQUFVO0FBQzNDUixhQUFPUSxTQUFTLEVBQUVILE1BQU0sUUFBUSxDQUFDO0FBQUEsSUFDbkMsVUFBQztBQUNDUCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxJQUFJO0FBQUEsUUFDRmdCLFVBQVU7QUFBQSxRQUNWQyxVQUFVO0FBQUEsUUFDVkMsT0FBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLGlDQUFDLGVBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUk7QUFBQSxZQUNGQyxTQUFTO0FBQUEsWUFDVEMsZUFBZTtBQUFBLFlBQ2ZDLEtBQUs7QUFBQSxVQUNQO0FBQUEsVUFFQTtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSTtBQUFBLGtCQUNGRixTQUFTO0FBQUEsa0JBQ1RDLGVBQWU7QUFBQSxrQkFDZkMsS0FBSztBQUFBLGdCQUNQO0FBQUEsZ0JBRUE7QUFBQSx5Q0FBQyxjQUFXLFNBQVEsTUFBSyxJQUFJLEVBQUVDLFlBQVksSUFBSSxHQUFFLDJCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBZ0IsMkVBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLFlBRUMsQ0FBQ3pCLFdBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsVUFBVSxDQUFDZ0IsVUFBVTtBQUNuQkEsd0JBQU1DLGVBQWU7QUFDckIsdUJBQUtYLGVBQWU7QUFBQSxnQkFDdEI7QUFBQSxnQkFDQSxJQUFJO0FBQUEsa0JBQ0ZnQixTQUFTO0FBQUEsa0JBQ1RDLGVBQWU7QUFBQSxrQkFDZkMsS0FBSztBQUFBLGdCQUNQO0FBQUEsZ0JBRUE7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBTzVCO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ29CLFVBQVVuQixlQUFlbUIsTUFBTVUsT0FBT0MsS0FBSztBQUFBLHNCQUN0RDtBQUFBLHNCQUNBO0FBQUEsc0JBQ0EsYUFBWTtBQUFBO0FBQUEsb0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU0yQjtBQUFBLGtCQUUzQjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUTtBQUFBLHNCQUNSLFVBQVV6QjtBQUFBQSxzQkFDVixXQUFTO0FBQUE7QUFBQTtBQUFBLG9CQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBO0FBQUE7QUFBQSxjQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE0QkEsSUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixVQUFVLENBQUNjLFVBQVU7QUFDbkIsdUJBQUtELFlBQVlDLEtBQUs7QUFBQSxnQkFDeEI7QUFBQSxnQkFDQSxJQUFJO0FBQUEsa0JBQ0ZNLFNBQVM7QUFBQSxrQkFDVEMsZUFBZTtBQUFBLGtCQUNmQyxLQUFLO0FBQUEsZ0JBQ1A7QUFBQSxnQkFFQTtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPNUI7QUFBQUEsc0JBQ1A7QUFBQSxzQkFDQSxXQUFTO0FBQUE7QUFBQSxvQkFKWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSVc7QUFBQSxrQkFFWDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT0U7QUFBQUEsc0JBQ1AsVUFBVSxDQUFDa0IsVUFBVWpCLFFBQVFpQixNQUFNVSxPQUFPQyxLQUFLO0FBQUEsc0JBQy9DO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQSxZQUFZLEVBQUVDLFdBQVcsR0FBR0MsV0FBVyxVQUFVO0FBQUE7QUFBQSxvQkFObkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1xRDtBQUFBLGtCQUVyRDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUTtBQUFBLHNCQUNSLFVBQVUzQjtBQUFBQSxzQkFDVixXQUFTO0FBQUE7QUFBQTtBQUFBLG9CQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFRO0FBQUEsc0JBQ1IsVUFBVUE7QUFBQUEsc0JBQ1YsU0FBUyxNQUFNO0FBQ2JELG9DQUFZLEtBQUs7QUFDakJGLGdDQUFRLEVBQUU7QUFBQSxzQkFDWjtBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQTtBQUFBO0FBQUEsY0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBNENBO0FBQUE7QUFBQTtBQUFBLFFBakdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW1HQSxLQXBHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUdBO0FBQUE7QUFBQSxJQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE2R0EsS0E5R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStHQTtBQUVKO0FBQUVKLEdBM0tXRCxXQUFTO0FBQUEsVUFLTlYsVUFDQ0MsU0FBUztBQUFBO0FBQUEsS0FOYlM7QUFBUyxJQUFBb0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMb2dpbiIsInVzZUxvZ2luIiwidXNlTm90aWZ5IiwiQm94IiwiQnV0dG9uIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsInJlcXVlc3RPdHAiLCJQSE9ORV9SRUdFWCIsIkxvZ2luUGFnZSIsIl9zIiwicGhvbmVOdW1iZXIiLCJzZXRQaG9uZU51bWJlciIsImNvZGUiLCJzZXRDb2RlIiwiY29kZVNlbnQiLCJzZXRDb2RlU2VudCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibG9naW4iLCJub3RpZnkiLCJoYW5kbGVTZW5kQ29kZSIsInRyaW1tZWRQaG9uZSIsInRyaW0iLCJ0ZXN0IiwidHlwZSIsInJlc3BvbnNlIiwiZXJyb3IiLCJtZXNzYWdlIiwiZGF0YSIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsIkVycm9yIiwibWluV2lkdGgiLCJtYXhXaWR0aCIsIndpZHRoIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJnYXAiLCJmb250V2VpZ2h0IiwidGFyZ2V0IiwidmFsdWUiLCJtYXhMZW5ndGgiLCJpbnB1dE1vZGUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb2dpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMb2dpbiwgdXNlTG9naW4sIHVzZU5vdGlmeSB9IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQnV0dG9uXCI7XG5pbXBvcnQgQ2FyZCBmcm9tIFwiQG11aS9tYXRlcmlhbC9DYXJkXCI7XG5pbXBvcnQgQ2FyZENvbnRlbnQgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQ2FyZENvbnRlbnRcIjtcbmltcG9ydCBUZXh0RmllbGQgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGV4dEZpZWxkXCI7XG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UeXBvZ3JhcGh5XCI7XG5pbXBvcnQgeyByZXF1ZXN0T3RwIH0gZnJvbSBcIi4uL2FwaS9hdXRoXCI7XG5cbmNvbnN0IFBIT05FX1JFR0VYID1cbiAgL14oPzooPzooPzpcXCs/fDAwKSg5OCkpfCgwKSk/KCg/OjkwfDkxfDkyfDkzfDk5KVswLTldezh9KSQvO1xuXG5leHBvcnQgY29uc3QgTG9naW5QYWdlID0gKCkgPT4ge1xuICBjb25zdCBbcGhvbmVOdW1iZXIsIHNldFBob25lTnVtYmVyXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbY29kZSwgc2V0Q29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2NvZGVTZW50LCBzZXRDb2RlU2VudF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgbG9naW4gPSB1c2VMb2dpbigpO1xuICBjb25zdCBub3RpZnkgPSB1c2VOb3RpZnkoKTtcblxuICBjb25zdCBoYW5kbGVTZW5kQ29kZSA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB0cmltbWVkUGhvbmUgPSBwaG9uZU51bWJlci50cmltKCk7XG5cbiAgICBpZiAoIVBIT05FX1JFR0VYLnRlc3QodHJpbW1lZFBob25lKSkge1xuICAgICAgbm90aWZ5KFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcGhvbmUgbnVtYmVyXCIsIHsgdHlwZTogXCJ3YXJuaW5nXCIgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCByZXF1ZXN0T3RwKHRyaW1tZWRQaG9uZSk7XG4gICAgICBzZXRQaG9uZU51bWJlcih0cmltbWVkUGhvbmUpO1xuICAgICAgc2V0Q29kZVNlbnQodHJ1ZSk7XG4gICAgICBub3RpZnkoXG4gICAgICAgIHJlc3BvbnNlLmNvZGVcbiAgICAgICAgICA/IGBWZXJpZmljYXRpb24gY29kZSBzZW50ICgke3Jlc3BvbnNlLmNvZGV9KWBcbiAgICAgICAgICA6IFwiVmVyaWZpY2F0aW9uIGNvZGUgc2VudFwiLFxuICAgICAgICB7IHR5cGU6IFwiaW5mb1wiIH1cbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgICAoZXJyb3IgYXMgeyByZXNwb25zZT86IHsgZGF0YT86IHsgbWVzc2FnZT86IHN0cmluZyB9IH0gfSk/LnJlc3BvbnNlXG4gICAgICAgICAgPy5kYXRhPy5tZXNzYWdlID8/IFwiRmFpbGVkIHRvIHNlbmQgdmVyaWZpY2F0aW9uIGNvZGVcIjtcbiAgICAgIG5vdGlmeShtZXNzYWdlLCB7IHR5cGU6IFwiZXJyb3JcIiB9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50OiBGb3JtRXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgaWYgKCEvXlxcZHs0fSQvLnRlc3QoY29kZSkpIHtcbiAgICAgIG5vdGlmeShcIlZlcmlmaWNhdGlvbiBjb2RlIG11c3QgYmUgNCBkaWdpdHNcIiwgeyB0eXBlOiBcIndhcm5pbmdcIiB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBsb2dpbih7IHBob25lTnVtYmVyOiBwaG9uZU51bWJlci50cmltKCksIGNvZGUgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiTG9naW4gZmFpbGVkXCI7XG4gICAgICBub3RpZnkobWVzc2FnZSwgeyB0eXBlOiBcImVycm9yXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxMb2dpbj5cbiAgICAgIDxDYXJkXG4gICAgICAgIHN4PXt7XG4gICAgICAgICAgbWluV2lkdGg6IDMyMCxcbiAgICAgICAgICBtYXhXaWR0aDogNDIwLFxuICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPENhcmRDb250ZW50PlxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgICBnYXA6IDIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgICAgIGdhcDogMC41LFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDVcIiBzeD17eyBmb250V2VpZ2h0OiA4MDAgfX0+XG4gICAgICAgICAgICAgICAgQWRtaW4gTG9naW5cbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgU2lnbiBpbiB3aXRoIHlvdXIgYWRtaW4gcGhvbmUgbnVtYmVyIGFuZCB2ZXJpZmljYXRpb24gY29kZS5cbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgICAgIHshY29kZVNlbnQgPyAoXG4gICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJmb3JtXCJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgdm9pZCBoYW5kbGVTZW5kQ29kZSgpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgICAgICAgIGdhcDogMixcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQaG9uZSBudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bob25lTnVtYmVyfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UGhvbmVOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjA5WFhYWFhYWFhYXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFNlbmQgY29kZVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJmb3JtXCJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICB2b2lkIGhhbmRsZUxvZ2luKGV2ZW50KTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICAgICAgICBnYXA6IDIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUGhvbmUgbnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZU51bWJlcn1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkXG4gICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVmVyaWZpY2F0aW9uIGNvZGVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvZGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRDb2RlKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgICAgICAgaW5wdXRQcm9wcz17eyBtYXhMZW5ndGg6IDQsIGlucHV0TW9kZTogXCJudW1lcmljXCIgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIExvZ2luXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29kZVNlbnQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDb2RlKFwiXCIpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDaGFuZ2UgcGhvbmUgbnVtYmVyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0JveD5cbiAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgIDwvQ2FyZD5cbiAgICA8L0xvZ2luPlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3BhZ2VzL0xvZ2luLnRzeCJ9