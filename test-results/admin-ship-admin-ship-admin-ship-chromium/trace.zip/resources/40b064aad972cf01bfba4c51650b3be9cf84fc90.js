// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/isHostComponent/isHostComponent.mjs
function isHostComponent(element) {
  return typeof element === "string";
}
var isHostComponent_default = isHostComponent;

export {
  isHostComponent_default
};
//# sourceMappingURL=chunk-X6MKMRHY.js.map
