import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/AppLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Layout } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { AppBar } from "/src/layouts/AppBar.tsx";
import { Menu } from "/src/layouts/Menu.tsx";
export const AppLayout = (props) => /* @__PURE__ */ jsxDEV(Layout, { ...props, appBar: AppBar, menu: Menu }, void 0, false, {
  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppLayout.tsx",
  lineNumber: 7,
  columnNumber: 1
}, this);
_c = AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppLayout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUU7QUFMRixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsWUFBWTtBQUVkLGFBQU1DLFlBQVlBLENBQUNDLFVBQ3hCLHVCQUFDLFVBQU8sR0FBSUEsT0FBTyxRQUFRSCxRQUFRLE1BQU1DLFFBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBOEM7QUFDOUNHLEtBRldGO0FBQVMsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGF5b3V0IiwiQXBwQmFyIiwiTWVudSIsIkFwcExheW91dCIsInByb3BzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXBwTGF5b3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IExheW91dFByb3BzIH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQgeyBMYXlvdXQgfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCB7IEFwcEJhciB9IGZyb20gXCIuL0FwcEJhclwiO1xuaW1wb3J0IHsgTWVudSB9IGZyb20gXCIuL01lbnVcIjtcblxuZXhwb3J0IGNvbnN0IEFwcExheW91dCA9IChwcm9wczogTGF5b3V0UHJvcHMpID0+IChcbiAgPExheW91dCB7Li4ucHJvcHN9IGFwcEJhcj17QXBwQmFyfSBtZW51PXtNZW51fSAvPlxuKTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL2xheW91dHMvQXBwTGF5b3V0LnRzeCJ9