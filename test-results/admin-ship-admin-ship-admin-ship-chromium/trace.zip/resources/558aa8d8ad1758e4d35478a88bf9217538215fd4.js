import {
  clsx_default,
  composeClasses,
  generateUtilityClass,
  generateUtilityClasses,
  require_prop_types,
  styled_default,
  useDefaultProps
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/CardContent/CardContent.mjs
var React = __toESM(require_react(), 1);
var import_prop_types = __toESM(require_prop_types(), 1);

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/CardContent/cardContentClasses.mjs
function getCardContentUtilityClass(slot) {
  return generateUtilityClass("MuiCardContent", slot);
}
var cardContentClasses = generateUtilityClasses("MuiCardContent", ["root"]);
var cardContentClasses_default = cardContentClasses;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/CardContent/CardContent.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var useUtilityClasses = (ownerState) => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ["root"]
  };
  return composeClasses(slots, getCardContentUtilityClass, classes);
};
var CardContentRoot = styled_default("div", {
  name: "MuiCardContent",
  slot: "Root"
})({
  padding: 16,
  "&:last-child": {
    paddingBottom: 24
  }
});
var CardContent = React.forwardRef(function CardContent2(inProps, ref) {
  const props = useDefaultProps({
    props: inProps,
    name: "MuiCardContent"
  });
  const {
    className,
    component = "div",
    ...other
  } = props;
  const ownerState = {
    ...props,
    component
  };
  const classes = useUtilityClasses(ownerState);
  return (0, import_jsx_runtime.jsx)(CardContentRoot, {
    as: component,
    className: clsx_default(classes.root, className),
    ownerState,
    ref,
    ...other
  });
});
true ? CardContent.propTypes = {
  // ┌────────────────────────────── Warning ──────────────────────────────┐
  // │ These PropTypes are generated from the TypeScript type definitions. │
  // │    To update them, edit the d.ts file and run `pnpm proptypes`.     │
  // └─────────────────────────────────────────────────────────────────────┘
  /**
   * The content of the component.
   */
  children: import_prop_types.default.node,
  /**
   * Override or extend the styles applied to the component.
   */
  classes: import_prop_types.default.object,
  /**
   * @ignore
   */
  className: import_prop_types.default.string,
  /**
   * The component used for the root node.
   * Either a string to use a HTML element or a component.
   */
  component: import_prop_types.default.elementType,
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: import_prop_types.default.oneOfType([import_prop_types.default.arrayOf(import_prop_types.default.oneOfType([import_prop_types.default.func, import_prop_types.default.object, import_prop_types.default.bool])), import_prop_types.default.func, import_prop_types.default.object])
} : void 0;
var CardContent_default = CardContent;

export {
  getCardContentUtilityClass,
  cardContentClasses_default,
  CardContent_default
};
//# sourceMappingURL=chunk-DXAZBM7C.js.map
