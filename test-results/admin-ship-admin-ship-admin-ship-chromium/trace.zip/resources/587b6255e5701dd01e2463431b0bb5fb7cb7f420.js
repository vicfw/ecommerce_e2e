import {
  setRef
} from "/node_modules/.vite/deps/chunk-QTIS3M7A.js?v=49ae7072";
import {
  useForkRef
} from "/node_modules/.vite/deps/chunk-N6SJX73J.js?v=49ae7072";
import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-HGBJD63U.js?v=49ae7072";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import {
  exactProp,
  require_prop_types,
  useEnhancedEffect_default
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Portal/Portal.mjs
var React2 = __toESM(require_react(), 1);
var ReactDOM = __toESM(require_react_dom(), 1);
var import_prop_types = __toESM(require_prop_types(), 1);

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/getReactElementRef/getReactElementRef.mjs
var React = __toESM(require_react(), 1);
function getReactElementRef(element) {
  if (parseInt(React.version, 10) >= 19) {
    return element?.props?.ref || null;
  }
  return element?.ref || null;
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/HTMLElementType/HTMLElementType.mjs
function HTMLElementType(props, propName, componentName, location, propFullName) {
  if (false) {
    return null;
  }
  const propValue = props[propName];
  const safePropName = propFullName || propName;
  if (propValue == null) {
    return null;
  }
  if (propValue && propValue.nodeType !== 1) {
    return new Error(`Invalid ${location} \`${safePropName}\` supplied to \`${componentName}\`. Expected an HTMLElement.`);
  }
  return null;
}

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/Portal/Portal.mjs
function getContainer(container) {
  return typeof container === "function" ? container() : container;
}
var Portal = React2.forwardRef(function Portal2(props, forwardedRef) {
  const {
    children,
    container,
    disablePortal = false
  } = props;
  const [mountNode, setMountNode] = React2.useState(null);
  const handleRef = useForkRef(React2.isValidElement(children) ? getReactElementRef(children) : null, forwardedRef);
  useEnhancedEffect_default(() => {
    if (!disablePortal) {
      setMountNode(getContainer(container) || document.body);
    }
  }, [container, disablePortal]);
  useEnhancedEffect_default(() => {
    if (mountNode && !disablePortal) {
      setRef(forwardedRef, mountNode);
      return () => {
        setRef(forwardedRef, null);
      };
    }
    return void 0;
  }, [forwardedRef, mountNode, disablePortal]);
  if (disablePortal) {
    if (React2.isValidElement(children)) {
      const newProps = {
        ref: handleRef
      };
      return React2.cloneElement(children, newProps);
    }
    return children;
  }
  return mountNode ? ReactDOM.createPortal(children, mountNode) : mountNode;
});
true ? Portal.propTypes = {
  // ┌────────────────────────────── Warning ──────────────────────────────┐
  // │ These PropTypes are generated from the TypeScript type definitions. │
  // │ To update them, edit the TypeScript types and run `pnpm proptypes`. │
  // └─────────────────────────────────────────────────────────────────────┘
  /**
   * The children to render into the `container`.
   */
  children: import_prop_types.default.node,
  /**
   * An HTML element or function that returns one.
   * The `container` will have the portal children appended to it.
   *
   * You can also provide a callback, which is called in a React layout effect.
   * This lets you set the container from a ref, and also makes server-side rendering possible.
   *
   * By default, it uses the body of the top-level document object,
   * so it's simply `document.body` most of the time.
   */
  container: import_prop_types.default.oneOfType([HTMLElementType, import_prop_types.default.func]),
  /**
   * The `children` will be under the DOM hierarchy of the parent component.
   * @default false
   */
  disablePortal: import_prop_types.default.bool
} : void 0;
if (true) {
  Portal["propTypes"] = exactProp(Portal.propTypes);
}
var Portal_default = Portal;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/internal/svg-icons/ArrowDropDown.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var ArrowDropDown_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M7 10l5 5 5-5z"
}), "ArrowDropDown");

export {
  HTMLElementType,
  getReactElementRef,
  Portal_default,
  ArrowDropDown_default
};
//# sourceMappingURL=chunk-CIZAJYEI.js.map
