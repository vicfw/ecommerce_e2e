"use client";
import "/node_modules/.vite/deps/chunk-BWL3NMBV.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-2CTOBPYC.js?v=49ae7072";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-ZMHT7GOB.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-B2OBFM6G.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-YIMRGSOF.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/Image.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var Image_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2M8.5 13.5l2.5 3.01L14.5 12l4.5 6H5z"
}), "Image");
export {
  Image_default as default
};
//# sourceMappingURL=@mui_icons-material_Image.js.map
