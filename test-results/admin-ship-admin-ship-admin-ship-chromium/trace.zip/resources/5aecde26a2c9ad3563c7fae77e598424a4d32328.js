import {
  appendOwnerState_default,
  mergeSlotProps_default,
  resolveComponentProps_default
} from "/node_modules/.vite/deps/chunk-KNTPUW4T.js?v=49ae7072";
import {
  useForkRef
} from "/node_modules/.vite/deps/chunk-N6SJX73J.js?v=49ae7072";

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/contains/contains.mjs
function contains(parent, child) {
  if (!parent || !child) {
    return false;
  }
  if (parent.contains(child)) {
    return true;
  }
  const rootNode = child.getRootNode?.();
  if (rootNode && rootNode instanceof ShadowRoot) {
    let next = child;
    while (next) {
      if (parent === next) {
        return true;
      }
      next = next.parentNode ?? next.host ?? null;
    }
  }
  return false;
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useSlotProps/useSlotProps.mjs
function useSlotProps(parameters) {
  const {
    elementType,
    externalSlotProps,
    ownerState,
    skipResolvingSlotProps = false,
    ...other
  } = parameters;
  const resolvedComponentsProps = skipResolvingSlotProps ? {} : resolveComponentProps_default(externalSlotProps, ownerState);
  const {
    props: mergedProps,
    internalRef
  } = mergeSlotProps_default({
    ...other,
    externalSlotProps: resolvedComponentsProps
  });
  const ref = useForkRef(internalRef, resolvedComponentsProps?.ref, parameters.additionalProps?.ref);
  const props = appendOwnerState_default(elementType, {
    ...mergedProps,
    ref
  }, ownerState);
  return props;
}
var useSlotProps_default = useSlotProps;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/utils/isLayoutSupported.mjs
function isLayoutSupported() {
  return !(/jsdom|HappyDOM/.test(window.navigator.userAgent) || // TODO(v9): Remove the test environment check
  // eslint-disable-next-line mui/consistent-production-guard
  false);
}

export {
  contains,
  useSlotProps_default,
  isLayoutSupported
};
//# sourceMappingURL=chunk-7D3DOUEK.js.map
