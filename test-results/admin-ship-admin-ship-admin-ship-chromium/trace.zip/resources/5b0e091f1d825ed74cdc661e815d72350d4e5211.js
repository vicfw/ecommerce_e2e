import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/color-images/ColorImageForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  ArrayInput,
  ReferenceInput,
  required,
  AutocompleteInput,
  SimpleFormIterator,
  TextInput
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
export const ColorImageForm = () => {
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        flexDirection: "column",
        gap: 2
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "name",
                  label: "Name",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
                  lineNumber: 28,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
                lineNumber: 27,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "colorImage",
                  label: "Swatch Image URL",
                  fullWidth: true,
                  validate: required(),
                  helperText: "URL for the color swatch thumbnail"
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
                  lineNumber: 36,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
                lineNumber: 35,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
            lineNumber: 20,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(ReferenceInput, { source: "productId", reference: "product", perPage: 50, children: /* @__PURE__ */ jsxDEV(
          AutocompleteInput,
          {
            optionText: "enName",
            label: "Product (optional)",
            fullWidth: true
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
            lineNumber: 48,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
          lineNumber: 47,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
          lineNumber: 46,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
          ArrayInput,
          {
            source: "images",
            label: "Product Images for this Color",
            validate: required(),
            children: /* @__PURE__ */ jsxDEV(SimpleFormIterator, { inline: true, children: /* @__PURE__ */ jsxDEV(
              TextInput,
              {
                source: "",
                label: "Image URL",
                fullWidth: true,
                validate: required()
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
                lineNumber: 63,
                columnNumber: 13
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
              lineNumber: 62,
              columnNumber: 11
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
            lineNumber: 57,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
          lineNumber: 56,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx",
      lineNumber: 13,
      columnNumber: 5
    },
    this
  );
};
_c = ColorImageForm;
var _c;
$RefreshReg$(_c, "ColorImageForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJVO0FBM0JWO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFNBQVM7QUFFVCxhQUFNQyxpQkFBaUJBLE1BQU07QUFDbEMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsSUFBSTtBQUFBLFFBQ0ZDLFNBQVM7QUFBQSxRQUNUQyxlQUFlO0FBQUEsUUFDZkMsS0FBSztBQUFBLE1BQ1A7QUFBQSxNQUVBO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxjQUNGRixTQUFTO0FBQUEsY0FDVEcsVUFBVTtBQUFBLGNBQ1ZELEtBQUs7QUFBQSxZQUNQO0FBQUEsWUFFQTtBQUFBLHFDQUFDLE9BQUksSUFBSSxFQUFFRSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFPO0FBQUEsa0JBQ1AsT0FBTTtBQUFBLGtCQUNOO0FBQUEsa0JBQ0EsVUFBVVosU0FBUztBQUFBO0FBQUEsZ0JBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1QixLQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxPQUFJLElBQUksRUFBRVUsT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsUUFBTztBQUFBLGtCQUNQLE9BQU07QUFBQSxrQkFDTjtBQUFBLGtCQUNBLFVBQVVaLFNBQVM7QUFBQSxrQkFDbkIsWUFBVztBQUFBO0FBQUEsZ0JBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2lELEtBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQTtBQUFBO0FBQUEsVUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBd0JBO0FBQUEsUUFFQSx1QkFBQyxPQUFJLElBQUksRUFBRVUsT0FBTyxPQUFPLEdBQ3ZCLGlDQUFDLGtCQUFlLFFBQU8sYUFBWSxXQUFVLFdBQVUsU0FBUyxJQUM5RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsWUFBVztBQUFBLFlBQ1gsT0FBTTtBQUFBLFlBQ04sV0FBUztBQUFBO0FBQUEsVUFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHVyxLQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsT0FBSSxJQUFJLEVBQUVBLE9BQU8sT0FBTyxHQUN2QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsUUFBTztBQUFBLFlBQ1AsT0FBTTtBQUFBLFlBQ04sVUFBVVYsU0FBUztBQUFBLFlBRW5CLGlDQUFDLHNCQUFtQixRQUFNLE1BQ3hCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsUUFBTztBQUFBLGdCQUNQLE9BQU07QUFBQSxnQkFDTjtBQUFBLGdCQUNBLFVBQVVBLFNBQVM7QUFBQTtBQUFBLGNBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1QixLQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUE7QUFBQSxVQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUE7QUFBQTtBQUFBLElBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJEQTtBQUVKO0FBQUVhLEtBL0RXUjtBQUFjLElBQUFRO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFycmF5SW5wdXQiLCJSZWZlcmVuY2VJbnB1dCIsInJlcXVpcmVkIiwiQXV0b2NvbXBsZXRlSW5wdXQiLCJTaW1wbGVGb3JtSXRlcmF0b3IiLCJUZXh0SW5wdXQiLCJCb3giLCJDb2xvckltYWdlRm9ybSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiZmxleFdyYXAiLCJ3aWR0aCIsInhzIiwibWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb2xvckltYWdlRm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXJyYXlJbnB1dCxcbiAgUmVmZXJlbmNlSW5wdXQsXG4gIHJlcXVpcmVkLFxuICBBdXRvY29tcGxldGVJbnB1dCxcbiAgU2ltcGxlRm9ybUl0ZXJhdG9yLFxuICBUZXh0SW5wdXQsXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcblxuZXhwb3J0IGNvbnN0IENvbG9ySW1hZ2VGb3JtID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxCb3hcbiAgICAgIHN4PXt7XG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICBnYXA6IDIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgZ2FwOiAyLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICBzb3VyY2U9XCJuYW1lXCJcbiAgICAgICAgICAgIGxhYmVsPVwiTmFtZVwiXG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQm94PlxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICBzb3VyY2U9XCJjb2xvckltYWdlXCJcbiAgICAgICAgICAgIGxhYmVsPVwiU3dhdGNoIEltYWdlIFVSTFwiXG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgICAgaGVscGVyVGV4dD1cIlVSTCBmb3IgdGhlIGNvbG9yIHN3YXRjaCB0aHVtYm5haWxcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQm94PlxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxuICAgICAgICA8UmVmZXJlbmNlSW5wdXQgc291cmNlPVwicHJvZHVjdElkXCIgcmVmZXJlbmNlPVwicHJvZHVjdFwiIHBlclBhZ2U9ezUwfT5cbiAgICAgICAgICA8QXV0b2NvbXBsZXRlSW5wdXRcbiAgICAgICAgICAgIG9wdGlvblRleHQ9XCJlbk5hbWVcIlxuICAgICAgICAgICAgbGFiZWw9XCJQcm9kdWN0IChvcHRpb25hbClcIlxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9SZWZlcmVuY2VJbnB1dD5cbiAgICAgIDwvQm94PlxuXG4gICAgICA8Qm94IHN4PXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cbiAgICAgICAgPEFycmF5SW5wdXRcbiAgICAgICAgICBzb3VyY2U9XCJpbWFnZXNcIlxuICAgICAgICAgIGxhYmVsPVwiUHJvZHVjdCBJbWFnZXMgZm9yIHRoaXMgQ29sb3JcIlxuICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICA+XG4gICAgICAgICAgPFNpbXBsZUZvcm1JdGVyYXRvciBpbmxpbmU+XG4gICAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICAgIHNvdXJjZT1cIlwiXG4gICAgICAgICAgICAgIGxhYmVsPVwiSW1hZ2UgVVJMXCJcbiAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L1NpbXBsZUZvcm1JdGVyYXRvcj5cbiAgICAgICAgPC9BcnJheUlucHV0PlxuICAgICAgPC9Cb3g+XG4gICAgPC9Cb3g+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2NvbG9yLWltYWdlcy9Db2xvckltYWdlRm9ybS50c3gifQ==