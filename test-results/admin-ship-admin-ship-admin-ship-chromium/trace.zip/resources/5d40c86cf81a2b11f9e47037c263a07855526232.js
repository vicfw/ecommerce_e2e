export const normalizeIsApprovedFilter = (filters) => {
  const result = { ...filters };
  const value = result.isApproved;
  if (value === false || value === "false") {
    result.isApproved = "false";
  } else if (value === true || value === "true") {
    result.isApproved = "true";
  }
  return result;
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW1lbnRGaWx0ZXJzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBub3JtYWxpemVJc0FwcHJvdmVkRmlsdGVyID0gKFxuICBmaWx0ZXJzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPlxuKTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPT4ge1xuICBjb25zdCByZXN1bHQgPSB7IC4uLmZpbHRlcnMgfTtcbiAgY29uc3QgdmFsdWUgPSByZXN1bHQuaXNBcHByb3ZlZDtcblxuICBpZiAodmFsdWUgPT09IGZhbHNlIHx8IHZhbHVlID09PSBcImZhbHNlXCIpIHtcbiAgICByZXN1bHQuaXNBcHByb3ZlZCA9IFwiZmFsc2VcIjtcbiAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gdHJ1ZSB8fCB2YWx1ZSA9PT0gXCJ0cnVlXCIpIHtcbiAgICByZXN1bHQuaXNBcHByb3ZlZCA9IFwidHJ1ZVwiO1xuICB9XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG4iXSwibWFwcGluZ3MiOiJBQUFPLGFBQU0sNEJBQTRCLENBQ3ZDLFlBQzRCO0FBQzVCLFFBQU0sU0FBUyxFQUFFLEdBQUcsUUFBUTtBQUM1QixRQUFNLFFBQVEsT0FBTztBQUVyQixNQUFJLFVBQVUsU0FBUyxVQUFVLFNBQVM7QUFDeEMsV0FBTyxhQUFhO0FBQUEsRUFDdEIsV0FBVyxVQUFVLFFBQVEsVUFBVSxRQUFRO0FBQzdDLFdBQU8sYUFBYTtBQUFBLEVBQ3RCO0FBRUEsU0FBTztBQUNUOyIsIm5hbWVzIjpbXX0=