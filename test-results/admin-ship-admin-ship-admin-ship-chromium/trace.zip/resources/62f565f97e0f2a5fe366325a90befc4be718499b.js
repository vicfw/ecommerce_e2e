"use client";
import "/node_modules/.vite/deps/chunk-BWL3NMBV.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-2CTOBPYC.js?v=49ae7072";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-ZMHT7GOB.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-B2OBFM6G.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-YIMRGSOF.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/Computer.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var Computer_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2zM4 6h16v10H4z"
}), "Computer");
export {
  Computer_default as default
};
//# sourceMappingURL=@mui_icons-material_Computer.js.map
