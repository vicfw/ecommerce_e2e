import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/badges/BadgeForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { required, TextInput } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
export const BadgeForm = () => {
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        flexWrap: "wrap",
        gap: 2
      },
      children: [
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "title",
            label: "Title",
            fullWidth: true,
            validate: required()
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx",
            lineNumber: 14,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx",
          lineNumber: 13,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "icon",
            label: "Icon URL",
            fullWidth: true,
            validate: required(),
            helperText: "URL for the badge icon image"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx",
            lineNumber: 22,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx",
          lineNumber: 21,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx",
      lineNumber: 6,
      columnNumber: 5
    },
    this
  );
};
_c = BadgeForm;
var _c;
$RefreshReg$(_c, "BadgeForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/badges/BadgeForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7QUFiUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsU0FBUztBQUVULGFBQU1DLFlBQVlBLE1BQU07QUFDN0IsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsSUFBSTtBQUFBLFFBQ0ZDLFNBQVM7QUFBQSxRQUNUQyxVQUFVO0FBQUEsUUFDVkMsS0FBSztBQUFBLE1BQ1A7QUFBQSxNQUVBO0FBQUEsK0JBQUMsT0FBSSxJQUFJLEVBQUVDLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxRQUFPO0FBQUEsWUFDUCxPQUFNO0FBQUEsWUFDTjtBQUFBLFlBQ0EsVUFBVVQsU0FBUztBQUFBO0FBQUEsVUFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXVCLEtBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsT0FBSSxJQUFJLEVBQUVPLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxRQUFPO0FBQUEsWUFDUCxPQUFNO0FBQUEsWUFDTjtBQUFBLFlBQ0EsVUFBVVQsU0FBUztBQUFBLFlBQ25CLFlBQVc7QUFBQTtBQUFBLFVBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSzJDLEtBTjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBO0FBQUE7QUFBQSxJQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3QkE7QUFFSjtBQUFFVSxLQTVCV1A7QUFBUyxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJyZXF1aXJlZCIsIlRleHRJbnB1dCIsIkJveCIsIkJhZGdlRm9ybSIsImRpc3BsYXkiLCJmbGV4V3JhcCIsImdhcCIsIndpZHRoIiwieHMiLCJtZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJhZGdlRm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcmVxdWlyZWQsIFRleHRJbnB1dCB9IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcblxuZXhwb3J0IGNvbnN0IEJhZGdlRm9ybSA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Qm94XG4gICAgICBzeD17e1xuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgZmxleFdyYXA6IFwid3JhcFwiLFxuICAgICAgICBnYXA6IDIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgc291cmNlPVwidGl0bGVcIlxuICAgICAgICAgIGxhYmVsPVwiVGl0bGVcIlxuICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAvPlxuICAgICAgPC9Cb3g+XG4gICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgIHNvdXJjZT1cImljb25cIlxuICAgICAgICAgIGxhYmVsPVwiSWNvbiBVUkxcIlxuICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgIHZhbGlkYXRlPXtyZXF1aXJlZCgpfVxuICAgICAgICAgIGhlbHBlclRleHQ9XCJVUkwgZm9yIHRoZSBiYWRnZSBpY29uIGltYWdlXCJcbiAgICAgICAgLz5cbiAgICAgIDwvQm94PlxuICAgIDwvQm94PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9iYWRnZXMvQmFkZ2VGb3JtLnRzeCJ9