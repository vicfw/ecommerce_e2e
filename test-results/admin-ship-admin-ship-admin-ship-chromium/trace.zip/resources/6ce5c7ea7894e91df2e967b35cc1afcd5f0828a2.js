import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SiteLogoSettings.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
import Button from "/node_modules/.vite/deps/@mui_material_Button.js?v=49ae7072";
import TextField from "/node_modules/.vite/deps/@mui_material_TextField.js?v=49ae7072";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=49ae7072"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import { Title, useNotify } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import {
  getSiteSettingsAdmin,
  updateSiteSettings,
  uploadImages
} from "/src/api/admin/index.ts";
const IMAGE_ACCEPT = "image/png,image/jpeg,image/webp,image/svg+xml";
export const SiteLogoSettings = () => {
  _s();
  const notify = useNotify();
  const [settings, setSettings] = useState(null);
  const [siteName, setSiteName] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [logoAlt, setLogoAlt] = useState("");
  const [faviconUrl, setFaviconUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingFavicon, setUploadingFavicon] = useState(false);
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getSiteSettingsAdmin();
      setSettings(data);
      setSiteName(data.siteName ?? "");
      setLogoUrl(data.logoUrl ?? "");
      setLogoAlt(data.logoAlt ?? "");
      setFaviconUrl(data.faviconUrl ?? "");
    } catch {
      notify("Failed to load site logo settings", { type: "error" });
    } finally {
      setLoading(false);
    }
  }, [notify]);
  useEffect(() => {
    loadData();
  }, [loadData]);
  const handleUpload = async (file, kind) => {
    if (!file) return;
    const setUploading = kind === "logo" ? setUploadingLogo : setUploadingFavicon;
    setUploading(true);
    try {
      const urls = await uploadImages([file]);
      if (urls?.[0]) {
        if (kind === "logo") {
          setLogoUrl(urls[0]);
        } else {
          setFaviconUrl(urls[0]);
        }
        notify("Image uploaded", { type: "success" });
      }
    } catch {
      notify("Failed to upload image", { type: "error" });
    } finally {
      setUploading(false);
    }
  };
  const handleSave = async () => {
    setSaving(true);
    try {
      const updated = await updateSiteSettings({
        siteName: siteName.trim(),
        logoUrl: logoUrl.trim() || null,
        logoAlt: logoAlt.trim() || null,
        faviconUrl: faviconUrl.trim() || null
      });
      setSettings(updated);
      notify("Site logo settings saved", { type: "success" });
    } catch {
      notify("Failed to save site logo settings", { type: "error" });
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3 }, children: [
    /* @__PURE__ */ jsxDEV(Title, { title: "Site Logo" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          display: "flex",
          flexDirection: "column",
          gap: 3,
          maxWidth: 720
        },
        children: [
          /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexDirection: "column", gap: 1 }, children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", sx: { fontWeight: 700 }, children: "Site Logo Settings" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
              lineNumber: 105,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Set the storefront logo, site name, and optional favicon. These are used in the header, auth pages, browser tab, and Google Organization markup." }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
              lineNumber: 108,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
            lineNumber: 104,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            Box,
            {
              sx: {
                p: 3,
                borderRadius: 2,
                border: "1px solid",
                borderColor: "divider",
                bgcolor: "background.paper",
                display: "flex",
                flexDirection: "column",
                gap: 2
              },
              children: [
                /* @__PURE__ */ jsxDEV(
                  TextField,
                  {
                    label: "Site name",
                    value: siteName,
                    onChange: (e) => setSiteName(e.target.value),
                    fullWidth: true,
                    size: "small",
                    disabled: loading,
                    helperText: "Used as the default page title and logo alt fallback"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                    lineNumber: 127,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  TextField,
                  {
                    label: "Logo alt text",
                    value: logoAlt,
                    onChange: (e) => setLogoAlt(e.target.value),
                    fullWidth: true,
                    size: "small",
                    disabled: loading,
                    helperText: "Leave empty to use the site name (never use “logo” alone)"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                    lineNumber: 137,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Box,
                  {
                    sx: {
                      display: "flex",
                      flexWrap: "wrap",
                      gap: 2,
                      alignItems: "flex-start"
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        Box,
                        {
                          sx: {
                            width: { xs: "100%", md: "calc(50% - 8px)" },
                            display: "flex",
                            flexDirection: "column",
                            gap: 1.5
                          },
                          children: [
                            /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: { fontWeight: 700 }, children: "Logo" }, void 0, false, {
                              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                              lineNumber: 163,
                              columnNumber: 15
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              Box,
                              {
                                sx: {
                                  width: "100%",
                                  height: 120,
                                  borderRadius: 1,
                                  border: "1px dashed",
                                  borderColor: "divider",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  bgcolor: "action.hover",
                                  overflow: "hidden",
                                  p: 1
                                },
                                children: logoUrl ? /* @__PURE__ */ jsxDEV(
                                  Box,
                                  {
                                    component: "img",
                                    src: logoUrl,
                                    alt: logoAlt || siteName || "Logo preview",
                                    sx: {
                                      maxWidth: "100%",
                                      maxHeight: "100%",
                                      objectFit: "contain"
                                    }
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                    lineNumber: 182,
                                    columnNumber: 17
                                  },
                                  this
                                ) : /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "No logo" }, void 0, false, {
                                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                  lineNumber: 193,
                                  columnNumber: 17
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                lineNumber: 166,
                                columnNumber: 15
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              Button,
                              {
                                variant: "outlined",
                                component: "label",
                                disabled: loading || uploadingLogo,
                                size: "small",
                                children: [
                                  uploadingLogo ? "Uploading…" : "Upload logo",
                                  /* @__PURE__ */ jsxDEV(
                                    "input",
                                    {
                                      type: "file",
                                      hidden: true,
                                      accept: IMAGE_ACCEPT,
                                      onChange: (e) => {
                                        const file = e.target.files?.[0];
                                        e.target.value = "";
                                        void handleUpload(file, "logo");
                                      }
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                      lineNumber: 205,
                                      columnNumber: 17
                                    },
                                    this
                                  )
                                ]
                              },
                              void 0,
                              true,
                              {
                                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                lineNumber: 198,
                                columnNumber: 15
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              TextField,
                              {
                                label: "Logo URL",
                                value: logoUrl,
                                onChange: (e) => setLogoUrl(e.target.value),
                                fullWidth: true,
                                size: "small",
                                disabled: loading,
                                helperText: "PNG/SVG/WebP, min 112×112. Upload or paste a Cloudinary URL"
                              },
                              void 0,
                              false,
                              {
                                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                lineNumber: 216,
                                columnNumber: 15
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                          lineNumber: 155,
                          columnNumber: 13
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Box,
                        {
                          sx: {
                            width: { xs: "100%", md: "calc(50% - 8px)" },
                            display: "flex",
                            flexDirection: "column",
                            gap: 1.5
                          },
                          children: [
                            /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: { fontWeight: 700 }, children: "Favicon (optional)" }, void 0, false, {
                              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                              lineNumber: 235,
                              columnNumber: 15
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              Box,
                              {
                                sx: {
                                  width: "100%",
                                  height: 120,
                                  borderRadius: 1,
                                  border: "1px dashed",
                                  borderColor: "divider",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  bgcolor: "action.hover",
                                  overflow: "hidden",
                                  p: 1
                                },
                                children: faviconUrl ? /* @__PURE__ */ jsxDEV(
                                  Box,
                                  {
                                    component: "img",
                                    src: faviconUrl,
                                    alt: "Favicon preview",
                                    sx: {
                                      width: 48,
                                      height: 48,
                                      objectFit: "contain"
                                    }
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                    lineNumber: 254,
                                    columnNumber: 17
                                  },
                                  this
                                ) : /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Falls back to logo" }, void 0, false, {
                                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                  lineNumber: 265,
                                  columnNumber: 17
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                lineNumber: 238,
                                columnNumber: 15
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              Button,
                              {
                                variant: "outlined",
                                component: "label",
                                disabled: loading || uploadingFavicon,
                                size: "small",
                                children: [
                                  uploadingFavicon ? "Uploading…" : "Upload favicon",
                                  /* @__PURE__ */ jsxDEV(
                                    "input",
                                    {
                                      type: "file",
                                      hidden: true,
                                      accept: IMAGE_ACCEPT,
                                      onChange: (e) => {
                                        const file = e.target.files?.[0];
                                        e.target.value = "";
                                        void handleUpload(file, "favicon");
                                      }
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                      lineNumber: 277,
                                      columnNumber: 17
                                    },
                                    this
                                  )
                                ]
                              },
                              void 0,
                              true,
                              {
                                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                lineNumber: 270,
                                columnNumber: 15
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              TextField,
                              {
                                label: "Favicon URL",
                                value: faviconUrl,
                                onChange: (e) => setFaviconUrl(e.target.value),
                                fullWidth: true,
                                size: "small",
                                disabled: loading,
                                helperText: "Square PNG, min 48×48 (ideally 512×512)"
                              },
                              void 0,
                              false,
                              {
                                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                                lineNumber: 288,
                                columnNumber: 15
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                          lineNumber: 227,
                          columnNumber: 13
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                    lineNumber: 147,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", gap: 2, alignItems: "center" }, children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "contained",
                      onClick: handleSave,
                      disabled: loading || saving,
                      children: saving ? "Saving…" : "Save settings"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                      lineNumber: 301,
                      columnNumber: 13
                    },
                    this
                  ),
                  settings?.updatedAt && /* @__PURE__ */ jsxDEV(Typography, { variant: "caption", color: "text.secondary", children: [
                    "Last updated: ",
                    new Date(settings.updatedAt).toLocaleString()
                  ] }, void 0, true, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                    lineNumber: 309,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
                  lineNumber: 300,
                  columnNumber: 11
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
              lineNumber: 115,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
        lineNumber: 96,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx",
    lineNumber: 93,
    columnNumber: 5
  }, this);
};
_s(SiteLogoSettings, "uhTia0L5d/K5z7TOdU4ZgFs4ko8=", false, function() {
  return [useNotify];
});
_c = SiteLogoSettings;
var _c;
$RefreshReg$(_c, "SiteLogoSettings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/pages/SiteLogoSettings.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkZNOztBQTdGTixPQUFPQSxTQUFTO0FBQ2hCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsYUFBYUMsV0FBV0MsZ0JBQWdCO0FBQ2pELFNBQVNDLE9BQU9DLGlCQUFpQjtBQUNqQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BRUs7QUFFUCxNQUFNQyxlQUFlO0FBRWQsYUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEMsUUFBTUMsU0FBU1AsVUFBVTtBQUN6QixRQUFNLENBQUNRLFVBQVVDLFdBQVcsSUFBSVgsU0FBOEIsSUFBSTtBQUNsRSxRQUFNLENBQUNZLFVBQVVDLFdBQVcsSUFBSWIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2MsU0FBU0MsVUFBVSxJQUFJZixTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDZ0IsU0FBU0MsVUFBVSxJQUFJakIsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2tCLFlBQVlDLGFBQWEsSUFBSW5CLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNvQixTQUFTQyxVQUFVLElBQUlyQixTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDc0IsUUFBUUMsU0FBUyxJQUFJdkIsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ3dCLGVBQWVDLGdCQUFnQixJQUFJekIsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzBCLGtCQUFrQkMsbUJBQW1CLElBQUkzQixTQUFTLEtBQUs7QUFFOUQsUUFBTTRCLFdBQVc5QixZQUFZLFlBQVk7QUFDdkN1QixlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTVEsT0FBTyxNQUFNMUIscUJBQXFCO0FBQ3hDUSxrQkFBWWtCLElBQUk7QUFDaEJoQixrQkFBWWdCLEtBQUtqQixZQUFZLEVBQUU7QUFDL0JHLGlCQUFXYyxLQUFLZixXQUFXLEVBQUU7QUFDN0JHLGlCQUFXWSxLQUFLYixXQUFXLEVBQUU7QUFDN0JHLG9CQUFjVSxLQUFLWCxjQUFjLEVBQUU7QUFBQSxJQUNyQyxRQUFRO0FBQ05ULGFBQU8scUNBQXFDLEVBQUVxQixNQUFNLFFBQVEsQ0FBQztBQUFBLElBQy9ELFVBQUM7QUFDQ1QsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRixHQUFHLENBQUNaLE1BQU0sQ0FBQztBQUVYVixZQUFVLE1BQU07QUFDZDZCLGFBQVM7QUFBQSxFQUNYLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTUcsZUFBZSxPQUNuQkMsTUFDQUMsU0FDRztBQUNILFFBQUksQ0FBQ0QsS0FBTTtBQUVYLFVBQU1FLGVBQ0pELFNBQVMsU0FBU1IsbUJBQW1CRTtBQUN2Q08saUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTUMsT0FBTyxNQUFNOUIsYUFBYSxDQUFDMkIsSUFBSSxDQUFDO0FBQ3RDLFVBQUlHLE9BQU8sQ0FBQyxHQUFHO0FBQ2IsWUFBSUYsU0FBUyxRQUFRO0FBQ25CbEIscUJBQVdvQixLQUFLLENBQUMsQ0FBQztBQUFBLFFBQ3BCLE9BQU87QUFDTGhCLHdCQUFjZ0IsS0FBSyxDQUFDLENBQUM7QUFBQSxRQUN2QjtBQUNBMUIsZUFBTyxrQkFBa0IsRUFBRXFCLE1BQU0sVUFBVSxDQUFDO0FBQUEsTUFDOUM7QUFBQSxJQUNGLFFBQVE7QUFDTnJCLGFBQU8sMEJBQTBCLEVBQUVxQixNQUFNLFFBQVEsQ0FBQztBQUFBLElBQ3BELFVBQUM7QUFDQ0ksbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1FLGFBQWEsWUFBWTtBQUM3QmIsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU1jLFVBQVUsTUFBTWpDLG1CQUFtQjtBQUFBLFFBQ3ZDUSxVQUFVQSxTQUFTMEIsS0FBSztBQUFBLFFBQ3hCeEIsU0FBU0EsUUFBUXdCLEtBQUssS0FBSztBQUFBLFFBQzNCdEIsU0FBU0EsUUFBUXNCLEtBQUssS0FBSztBQUFBLFFBQzNCcEIsWUFBWUEsV0FBV29CLEtBQUssS0FBSztBQUFBLE1BQ25DLENBQUM7QUFDRDNCLGtCQUFZMEIsT0FBTztBQUNuQjVCLGFBQU8sNEJBQTRCLEVBQUVxQixNQUFNLFVBQVUsQ0FBQztBQUFBLElBQ3hELFFBQVE7QUFDTnJCLGFBQU8scUNBQXFDLEVBQUVxQixNQUFNLFFBQVEsQ0FBQztBQUFBLElBQy9ELFVBQUM7QUFDQ1AsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVnQixHQUFHLEVBQUUsR0FDZDtBQUFBLDJCQUFDLFNBQU0sT0FBTSxlQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUV4QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBSTtBQUFBLFVBQ0ZDLFNBQVM7QUFBQSxVQUNUQyxlQUFlO0FBQUEsVUFDZkMsS0FBSztBQUFBLFVBQ0xDLFVBQVU7QUFBQSxRQUNaO0FBQUEsUUFFQTtBQUFBLGlDQUFDLE9BQUksSUFBSSxFQUFFSCxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxFQUFFLEdBQzFEO0FBQUEsbUNBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFRSxZQUFZLElBQUksR0FBRSxrQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBZ0IsZ0tBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFJO0FBQUEsZ0JBQ0ZMLEdBQUc7QUFBQSxnQkFDSE0sY0FBYztBQUFBLGdCQUNkQyxRQUFRO0FBQUEsZ0JBQ1JDLGFBQWE7QUFBQSxnQkFDYkMsU0FBUztBQUFBLGdCQUNUUixTQUFTO0FBQUEsZ0JBQ1RDLGVBQWU7QUFBQSxnQkFDZkMsS0FBSztBQUFBLGNBQ1A7QUFBQSxjQUVBO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTTtBQUFBLG9CQUNOLE9BQU85QjtBQUFBQSxvQkFDUCxVQUFVLENBQUNxQyxNQUFNcEMsWUFBWW9DLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxvQkFDM0M7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsVUFBVS9CO0FBQUFBLG9CQUNWLFlBQVc7QUFBQTtBQUFBLGtCQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPbUU7QUFBQSxnQkFHbkU7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTTtBQUFBLG9CQUNOLE9BQU9KO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ2lDLE1BQU1oQyxXQUFXZ0MsRUFBRUMsT0FBT0MsS0FBSztBQUFBLG9CQUMxQztBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxVQUFVL0I7QUFBQUEsb0JBQ1YsWUFBVztBQUFBO0FBQUEsa0JBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU93RTtBQUFBLGdCQUd4RTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFJO0FBQUEsc0JBQ0ZvQixTQUFTO0FBQUEsc0JBQ1RZLFVBQVU7QUFBQSxzQkFDVlYsS0FBSztBQUFBLHNCQUNMVyxZQUFZO0FBQUEsb0JBQ2Q7QUFBQSxvQkFFQTtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLElBQUk7QUFBQSw0QkFDRkMsT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCO0FBQUEsNEJBQzNDaEIsU0FBUztBQUFBLDRCQUNUQyxlQUFlO0FBQUEsNEJBQ2ZDLEtBQUs7QUFBQSwwQkFDUDtBQUFBLDBCQUVBO0FBQUEsbURBQUMsY0FBVyxTQUFRLGFBQVksSUFBSSxFQUFFRSxZQUFZLElBQUksR0FBRSxvQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUNBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLElBQUk7QUFBQSxrQ0FDRlUsT0FBTztBQUFBLGtDQUNQRyxRQUFRO0FBQUEsa0NBQ1JaLGNBQWM7QUFBQSxrQ0FDZEMsUUFBUTtBQUFBLGtDQUNSQyxhQUFhO0FBQUEsa0NBQ2JQLFNBQVM7QUFBQSxrQ0FDVGEsWUFBWTtBQUFBLGtDQUNaSyxnQkFBZ0I7QUFBQSxrQ0FDaEJWLFNBQVM7QUFBQSxrQ0FDVFcsVUFBVTtBQUFBLGtDQUNWcEIsR0FBRztBQUFBLGdDQUNMO0FBQUEsZ0NBRUN6QixvQkFDQztBQUFBLGtDQUFDO0FBQUE7QUFBQSxvQ0FDQyxXQUFVO0FBQUEsb0NBQ1YsS0FBS0E7QUFBQUEsb0NBQ0wsS0FBS0UsV0FBV0osWUFBWTtBQUFBLG9DQUM1QixJQUFJO0FBQUEsc0NBQ0YrQixVQUFVO0FBQUEsc0NBQ1ZpQixXQUFXO0FBQUEsc0NBQ1hDLFdBQVc7QUFBQSxvQ0FDYjtBQUFBO0FBQUEsa0NBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVFJLElBR0osdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBZ0IsdUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQTtBQUFBLDhCQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBK0JBO0FBQUEsNEJBQ0E7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsU0FBUTtBQUFBLGdDQUNSLFdBQVU7QUFBQSxnQ0FDVixVQUFVekMsV0FBV0k7QUFBQUEsZ0NBQ3JCLE1BQUs7QUFBQSxnQ0FFSkE7QUFBQUEsa0RBQWdCLGVBQWU7QUFBQSxrQ0FDaEM7QUFBQSxvQ0FBQztBQUFBO0FBQUEsc0NBQ0MsTUFBSztBQUFBLHNDQUNMO0FBQUEsc0NBQ0EsUUFBUWxCO0FBQUFBLHNDQUNSLFVBQVUsQ0FBQzJDLE1BQU07QUFDZiw4Q0FBTWpCLE9BQU9pQixFQUFFQyxPQUFPWSxRQUFRLENBQUM7QUFDL0JiLDBDQUFFQyxPQUFPQyxRQUFRO0FBQ2pCLDZDQUFLcEIsYUFBYUMsTUFBTSxNQUFNO0FBQUEsc0NBQ2hDO0FBQUE7QUFBQSxvQ0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBUUk7QUFBQTtBQUFBO0FBQUEsOEJBZk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQWlCQTtBQUFBLDRCQUNBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE9BQU07QUFBQSxnQ0FDTixPQUFPbEI7QUFBQUEsZ0NBQ1AsVUFBVSxDQUFDbUMsTUFBTWxDLFdBQVdrQyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsZ0NBQzFDO0FBQUEsZ0NBQ0EsTUFBSztBQUFBLGdDQUNMLFVBQVUvQjtBQUFBQSxnQ0FDVixZQUFXO0FBQUE7QUFBQSw4QkFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTzBFO0FBQUE7QUFBQTtBQUFBLHdCQXBFNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXNFQTtBQUFBLHNCQUVBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLElBQUk7QUFBQSw0QkFDRmtDLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQjtBQUFBLDRCQUMzQ2hCLFNBQVM7QUFBQSw0QkFDVEMsZUFBZTtBQUFBLDRCQUNmQyxLQUFLO0FBQUEsMEJBQ1A7QUFBQSwwQkFFQTtBQUFBLG1EQUFDLGNBQVcsU0FBUSxhQUFZLElBQUksRUFBRUUsWUFBWSxJQUFJLEdBQUUsa0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxJQUFJO0FBQUEsa0NBQ0ZVLE9BQU87QUFBQSxrQ0FDUEcsUUFBUTtBQUFBLGtDQUNSWixjQUFjO0FBQUEsa0NBQ2RDLFFBQVE7QUFBQSxrQ0FDUkMsYUFBYTtBQUFBLGtDQUNiUCxTQUFTO0FBQUEsa0NBQ1RhLFlBQVk7QUFBQSxrQ0FDWkssZ0JBQWdCO0FBQUEsa0NBQ2hCVixTQUFTO0FBQUEsa0NBQ1RXLFVBQVU7QUFBQSxrQ0FDVnBCLEdBQUc7QUFBQSxnQ0FDTDtBQUFBLGdDQUVDckIsdUJBQ0M7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsV0FBVTtBQUFBLG9DQUNWLEtBQUtBO0FBQUFBLG9DQUNMLEtBQUk7QUFBQSxvQ0FDSixJQUFJO0FBQUEsc0NBQ0ZvQyxPQUFPO0FBQUEsc0NBQ1BHLFFBQVE7QUFBQSxzQ0FDUkksV0FBVztBQUFBLG9DQUNiO0FBQUE7QUFBQSxrQ0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUUksSUFHSix1QkFBQyxjQUFXLFNBQVEsU0FBUSxPQUFNLGtCQUFnQixrQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBO0FBQUEsOEJBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkErQkE7QUFBQSw0QkFDQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxTQUFRO0FBQUEsZ0NBQ1IsV0FBVTtBQUFBLGdDQUNWLFVBQVV6QyxXQUFXTTtBQUFBQSxnQ0FDckIsTUFBSztBQUFBLGdDQUVKQTtBQUFBQSxxREFBbUIsZUFBZTtBQUFBLGtDQUNuQztBQUFBLG9DQUFDO0FBQUE7QUFBQSxzQ0FDQyxNQUFLO0FBQUEsc0NBQ0w7QUFBQSxzQ0FDQSxRQUFRcEI7QUFBQUEsc0NBQ1IsVUFBVSxDQUFDMkMsTUFBTTtBQUNmLDhDQUFNakIsT0FBT2lCLEVBQUVDLE9BQU9ZLFFBQVEsQ0FBQztBQUMvQmIsMENBQUVDLE9BQU9DLFFBQVE7QUFDakIsNkNBQUtwQixhQUFhQyxNQUFNLFNBQVM7QUFBQSxzQ0FDbkM7QUFBQTtBQUFBLG9DQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FRSTtBQUFBO0FBQUE7QUFBQSw4QkFmTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBaUJBO0FBQUEsNEJBQ0E7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsT0FBTTtBQUFBLGdDQUNOLE9BQU9kO0FBQUFBLGdDQUNQLFVBQVUsQ0FBQytCLE1BQU05QixjQUFjOEIsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGdDQUM3QztBQUFBLGdDQUNBLE1BQUs7QUFBQSxnQ0FDTCxVQUFVL0I7QUFBQUEsZ0NBQ1YsWUFBVztBQUFBO0FBQUEsOEJBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU9zRDtBQUFBO0FBQUE7QUFBQSx3QkFwRXhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFzRUE7QUFBQTtBQUFBO0FBQUEsa0JBdEpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1SkE7QUFBQSxnQkFFQSx1QkFBQyxPQUFJLElBQUksRUFBRW9CLFNBQVMsUUFBUUUsS0FBSyxHQUFHVyxZQUFZLFNBQVMsR0FDdkQ7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFRO0FBQUEsc0JBQ1IsU0FBU2pCO0FBQUFBLHNCQUNULFVBQVVoQixXQUFXRTtBQUFBQSxzQkFFcEJBLG1CQUFTLFlBQVk7QUFBQTtBQUFBLG9CQUx4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxrQkFDQ1osVUFBVXFELGFBQ1QsdUJBQUMsY0FBVyxTQUFRLFdBQVUsT0FBTSxrQkFBZ0I7QUFBQTtBQUFBLG9CQUNuQyxJQUFJQyxLQUFLdEQsU0FBU3FELFNBQVMsRUFBRUUsZUFBZTtBQUFBLHVCQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBO0FBQUE7QUFBQSxZQXRNRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF1TUE7QUFBQTtBQUFBO0FBQUEsTUExTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMk5BO0FBQUEsT0E5TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStOQTtBQUVKO0FBQUV6RCxHQTlTV0Qsa0JBQWdCO0FBQUEsVUFDWkwsU0FBUztBQUFBO0FBQUEsS0FEYks7QUFBZ0IsSUFBQTJEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJveCIsIlR5cG9ncmFwaHkiLCJCdXR0b24iLCJUZXh0RmllbGQiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVGl0bGUiLCJ1c2VOb3RpZnkiLCJnZXRTaXRlU2V0dGluZ3NBZG1pbiIsInVwZGF0ZVNpdGVTZXR0aW5ncyIsInVwbG9hZEltYWdlcyIsIklNQUdFX0FDQ0VQVCIsIlNpdGVMb2dvU2V0dGluZ3MiLCJfcyIsIm5vdGlmeSIsInNldHRpbmdzIiwic2V0U2V0dGluZ3MiLCJzaXRlTmFtZSIsInNldFNpdGVOYW1lIiwibG9nb1VybCIsInNldExvZ29VcmwiLCJsb2dvQWx0Iiwic2V0TG9nb0FsdCIsImZhdmljb25VcmwiLCJzZXRGYXZpY29uVXJsIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzYXZpbmciLCJzZXRTYXZpbmciLCJ1cGxvYWRpbmdMb2dvIiwic2V0VXBsb2FkaW5nTG9nbyIsInVwbG9hZGluZ0Zhdmljb24iLCJzZXRVcGxvYWRpbmdGYXZpY29uIiwibG9hZERhdGEiLCJkYXRhIiwidHlwZSIsImhhbmRsZVVwbG9hZCIsImZpbGUiLCJraW5kIiwic2V0VXBsb2FkaW5nIiwidXJscyIsImhhbmRsZVNhdmUiLCJ1cGRhdGVkIiwidHJpbSIsInAiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsIm1heFdpZHRoIiwiZm9udFdlaWdodCIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiYmdjb2xvciIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImZsZXhXcmFwIiwiYWxpZ25JdGVtcyIsIndpZHRoIiwieHMiLCJtZCIsImhlaWdodCIsImp1c3RpZnlDb250ZW50Iiwib3ZlcmZsb3ciLCJtYXhIZWlnaHQiLCJvYmplY3RGaXQiLCJmaWxlcyIsInVwZGF0ZWRBdCIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpdGVMb2dvU2V0dGluZ3MudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBCb3ggZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQm94XCI7XG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UeXBvZ3JhcGh5XCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL0J1dHRvblwiO1xuaW1wb3J0IFRleHRGaWVsZCBmcm9tIFwiQG11aS9tYXRlcmlhbC9UZXh0RmllbGRcIjtcbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBUaXRsZSwgdXNlTm90aWZ5IH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQge1xuICBnZXRTaXRlU2V0dGluZ3NBZG1pbixcbiAgdXBkYXRlU2l0ZVNldHRpbmdzLFxuICB1cGxvYWRJbWFnZXMsXG4gIHR5cGUgU2l0ZVNldHRpbmdzLFxufSBmcm9tIFwiLi4vYXBpL2FkbWluXCI7XG5cbmNvbnN0IElNQUdFX0FDQ0VQVCA9IFwiaW1hZ2UvcG5nLGltYWdlL2pwZWcsaW1hZ2Uvd2VicCxpbWFnZS9zdmcreG1sXCI7XG5cbmV4cG9ydCBjb25zdCBTaXRlTG9nb1NldHRpbmdzID0gKCkgPT4ge1xuICBjb25zdCBub3RpZnkgPSB1c2VOb3RpZnkoKTtcbiAgY29uc3QgW3NldHRpbmdzLCBzZXRTZXR0aW5nc10gPSB1c2VTdGF0ZTxTaXRlU2V0dGluZ3MgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NpdGVOYW1lLCBzZXRTaXRlTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvZ29VcmwsIHNldExvZ29VcmxdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsb2dvQWx0LCBzZXRMb2dvQWx0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZmF2aWNvblVybCwgc2V0RmF2aWNvblVybF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt1cGxvYWRpbmdMb2dvLCBzZXRVcGxvYWRpbmdMb2dvXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3VwbG9hZGluZ0Zhdmljb24sIHNldFVwbG9hZGluZ0Zhdmljb25dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGxvYWREYXRhID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRTaXRlU2V0dGluZ3NBZG1pbigpO1xuICAgICAgc2V0U2V0dGluZ3MoZGF0YSk7XG4gICAgICBzZXRTaXRlTmFtZShkYXRhLnNpdGVOYW1lID8/IFwiXCIpO1xuICAgICAgc2V0TG9nb1VybChkYXRhLmxvZ29VcmwgPz8gXCJcIik7XG4gICAgICBzZXRMb2dvQWx0KGRhdGEubG9nb0FsdCA/PyBcIlwiKTtcbiAgICAgIHNldEZhdmljb25VcmwoZGF0YS5mYXZpY29uVXJsID8/IFwiXCIpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbm90aWZ5KFwiRmFpbGVkIHRvIGxvYWQgc2l0ZSBsb2dvIHNldHRpbmdzXCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtub3RpZnldKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWREYXRhKCk7XG4gIH0sIFtsb2FkRGF0YV0pO1xuXG4gIGNvbnN0IGhhbmRsZVVwbG9hZCA9IGFzeW5jIChcbiAgICBmaWxlOiBGaWxlIHwgdW5kZWZpbmVkLFxuICAgIGtpbmQ6IFwibG9nb1wiIHwgXCJmYXZpY29uXCJcbiAgKSA9PiB7XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBjb25zdCBzZXRVcGxvYWRpbmcgPVxuICAgICAga2luZCA9PT0gXCJsb2dvXCIgPyBzZXRVcGxvYWRpbmdMb2dvIDogc2V0VXBsb2FkaW5nRmF2aWNvbjtcbiAgICBzZXRVcGxvYWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVybHMgPSBhd2FpdCB1cGxvYWRJbWFnZXMoW2ZpbGVdKTtcbiAgICAgIGlmICh1cmxzPy5bMF0pIHtcbiAgICAgICAgaWYgKGtpbmQgPT09IFwibG9nb1wiKSB7XG4gICAgICAgICAgc2V0TG9nb1VybCh1cmxzWzBdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRGYXZpY29uVXJsKHVybHNbMF0pO1xuICAgICAgICB9XG4gICAgICAgIG5vdGlmeShcIkltYWdlIHVwbG9hZGVkXCIsIHsgdHlwZTogXCJzdWNjZXNzXCIgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICBub3RpZnkoXCJGYWlsZWQgdG8gdXBsb2FkIGltYWdlXCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRVcGxvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNhdmluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IHVwZGF0ZVNpdGVTZXR0aW5ncyh7XG4gICAgICAgIHNpdGVOYW1lOiBzaXRlTmFtZS50cmltKCksXG4gICAgICAgIGxvZ29Vcmw6IGxvZ29VcmwudHJpbSgpIHx8IG51bGwsXG4gICAgICAgIGxvZ29BbHQ6IGxvZ29BbHQudHJpbSgpIHx8IG51bGwsXG4gICAgICAgIGZhdmljb25Vcmw6IGZhdmljb25VcmwudHJpbSgpIHx8IG51bGwsXG4gICAgICB9KTtcbiAgICAgIHNldFNldHRpbmdzKHVwZGF0ZWQpO1xuICAgICAgbm90aWZ5KFwiU2l0ZSBsb2dvIHNldHRpbmdzIHNhdmVkXCIsIHsgdHlwZTogXCJzdWNjZXNzXCIgfSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBub3RpZnkoXCJGYWlsZWQgdG8gc2F2ZSBzaXRlIGxvZ28gc2V0dGluZ3NcIiwgeyB0eXBlOiBcImVycm9yXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPEJveCBzeD17eyBwOiAzIH19PlxuICAgICAgPFRpdGxlIHRpdGxlPVwiU2l0ZSBMb2dvXCIgLz5cblxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgZ2FwOiAzLFxuICAgICAgICAgIG1heFdpZHRoOiA3MjAsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMSB9fT5cbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDVcIiBzeD17eyBmb250V2VpZ2h0OiA3MDAgfX0+XG4gICAgICAgICAgICBTaXRlIExvZ28gU2V0dGluZ3NcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlxuICAgICAgICAgICAgU2V0IHRoZSBzdG9yZWZyb250IGxvZ28sIHNpdGUgbmFtZSwgYW5kIG9wdGlvbmFsIGZhdmljb24uIFRoZXNlIGFyZVxuICAgICAgICAgICAgdXNlZCBpbiB0aGUgaGVhZGVyLCBhdXRoIHBhZ2VzLCBicm93c2VyIHRhYiwgYW5kIEdvb2dsZSBPcmdhbml6YXRpb25cbiAgICAgICAgICAgIG1hcmt1cC5cbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgIDwvQm94PlxuXG4gICAgICAgIDxCb3hcbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgcDogMyxcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogMixcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgIGJnY29sb3I6IFwiYmFja2dyb3VuZC5wYXBlclwiLFxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICBsYWJlbD1cIlNpdGUgbmFtZVwiXG4gICAgICAgICAgICB2YWx1ZT17c2l0ZU5hbWV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNpdGVOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgaGVscGVyVGV4dD1cIlVzZWQgYXMgdGhlIGRlZmF1bHQgcGFnZSB0aXRsZSBhbmQgbG9nbyBhbHQgZmFsbGJhY2tcIlxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICBsYWJlbD1cIkxvZ28gYWx0IHRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e2xvZ29BbHR9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldExvZ29BbHQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICBoZWxwZXJUZXh0PVwiTGVhdmUgZW1wdHkgdG8gdXNlIHRoZSBzaXRlIG5hbWUgKG5ldmVyIHVzZSDigJxsb2dv4oCdIGFsb25lKVwiXG4gICAgICAgICAgLz5cblxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgICAgIGdhcDogMixcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJmbGV4LXN0YXJ0XCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBcImNhbGMoNTAlIC0gOHB4KVwiIH0sXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgICAgICBnYXA6IDEuNSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMlwiIHN4PXt7IGZvbnRXZWlnaHQ6IDcwMCB9fT5cbiAgICAgICAgICAgICAgICBMb2dvXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEyMCxcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMSxcbiAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggZGFzaGVkXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgIGJnY29sb3I6IFwiYWN0aW9uLmhvdmVyXCIsXG4gICAgICAgICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgICAgICAgICAgIHA6IDEsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtsb2dvVXJsID8gKFxuICAgICAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJpbWdcIlxuICAgICAgICAgICAgICAgICAgICBzcmM9e2xvZ29Vcmx9XG4gICAgICAgICAgICAgICAgICAgIGFsdD17bG9nb0FsdCB8fCBzaXRlTmFtZSB8fCBcIkxvZ28gcHJldmlld1wifVxuICAgICAgICAgICAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgICAgICAgICAgIG1heFdpZHRoOiBcIjEwMCVcIixcbiAgICAgICAgICAgICAgICAgICAgICBtYXhIZWlnaHQ6IFwiMTAwJVwiLFxuICAgICAgICAgICAgICAgICAgICAgIG9iamVjdEZpdDogXCJjb250YWluXCIsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgIE5vIGxvZ29cbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICAgICAgY29tcG9uZW50PVwibGFiZWxcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8IHVwbG9hZGluZ0xvZ299XG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt1cGxvYWRpbmdMb2dvID8gXCJVcGxvYWRpbmfigKZcIiA6IFwiVXBsb2FkIGxvZ29cIn1cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgIGhpZGRlblxuICAgICAgICAgICAgICAgICAgYWNjZXB0PXtJTUFHRV9BQ0NFUFR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgdm9pZCBoYW5kbGVVcGxvYWQoZmlsZSwgXCJsb2dvXCIpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiTG9nbyBVUkxcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtsb2dvVXJsfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TG9nb1VybChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PVwiUE5HL1NWRy9XZWJQLCBtaW4gMTEyw5cxMTIuIFVwbG9hZCBvciBwYXN0ZSBhIENsb3VkaW5hcnkgVVJMXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuXG4gICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9LFxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICAgICAgZ2FwOiAxLjUsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIiBzeD17eyBmb250V2VpZ2h0OiA3MDAgfX0+XG4gICAgICAgICAgICAgICAgRmF2aWNvbiAob3B0aW9uYWwpXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEyMCxcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMSxcbiAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggZGFzaGVkXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgIGJnY29sb3I6IFwiYWN0aW9uLmhvdmVyXCIsXG4gICAgICAgICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgICAgICAgICAgIHA6IDEsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtmYXZpY29uVXJsID8gKFxuICAgICAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJpbWdcIlxuICAgICAgICAgICAgICAgICAgICBzcmM9e2Zhdmljb25Vcmx9XG4gICAgICAgICAgICAgICAgICAgIGFsdD1cIkZhdmljb24gcHJldmlld1wiXG4gICAgICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDQ4LFxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDgsXG4gICAgICAgICAgICAgICAgICAgICAgb2JqZWN0Rml0OiBcImNvbnRhaW5cIixcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgICAgRmFsbHMgYmFjayB0byBsb2dvXG4gICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImxhYmVsXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCB1cGxvYWRpbmdGYXZpY29ufVxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dXBsb2FkaW5nRmF2aWNvbiA/IFwiVXBsb2FkaW5n4oCmXCIgOiBcIlVwbG9hZCBmYXZpY29uXCJ9XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICBoaWRkZW5cbiAgICAgICAgICAgICAgICAgIGFjY2VwdD17SU1BR0VfQUNDRVBUfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIHZvaWQgaGFuZGxlVXBsb2FkKGZpbGUsIFwiZmF2aWNvblwiKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkZhdmljb24gVVJMXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZmF2aWNvblVybH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZhdmljb25VcmwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgICAgaGVscGVyVGV4dD1cIlNxdWFyZSBQTkcsIG1pbiA0OMOXNDggKGlkZWFsbHkgNTEyw5c1MTIpXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvQm94PlxuXG4gICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAyLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgc2F2aW5nfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7c2F2aW5nID8gXCJTYXZpbmfigKZcIiA6IFwiU2F2ZSBzZXR0aW5nc1wifVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICB7c2V0dGluZ3M/LnVwZGF0ZWRBdCAmJiAoXG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJjYXB0aW9uXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgIExhc3QgdXBkYXRlZDoge25ldyBEYXRlKHNldHRpbmdzLnVwZGF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0JveD5cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cbiAgICA8L0JveD5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9wYWdlcy9TaXRlTG9nb1NldHRpbmdzLnRzeCJ9