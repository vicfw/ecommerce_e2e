import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/color-images/ColorImageCreate.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Create, SimpleForm } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { ColorImageForm } from "/src/resources/color-images/ColorImageForm.tsx";
import { transformColorImageData } from "/src/resources/color-images/colorImageTransform.ts";
export const ColorImageCreate = () => {
  return /* @__PURE__ */ jsxDEV(Create, { transform: transformColorImageData, redirect: "list", children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(ColorImageForm, {}, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageCreate.tsx",
    lineNumber: 9,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageCreate.tsx",
    lineNumber: 8,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageCreate.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
};
_c = ColorImageCreate;
var _c;
$RefreshReg$(_c, "ColorImageCreate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageCreate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageCreate.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageCreate.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVE7QUFSUixTQUFTQSxRQUFRQyxrQkFBa0I7QUFDbkMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLCtCQUErQjtBQUVqQyxhQUFNQyxtQkFBbUJBLE1BQU07QUFDcEMsU0FDRSx1QkFBQyxVQUFPLFdBQVdELHlCQUF5QixVQUFTLFFBQ25ELGlDQUFDLGNBQ0MsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUVFLEtBUldEO0FBQWdCLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkNyZWF0ZSIsIlNpbXBsZUZvcm0iLCJDb2xvckltYWdlRm9ybSIsInRyYW5zZm9ybUNvbG9ySW1hZ2VEYXRhIiwiQ29sb3JJbWFnZUNyZWF0ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvbG9ySW1hZ2VDcmVhdGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENyZWF0ZSwgU2ltcGxlRm9ybSB9IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IHsgQ29sb3JJbWFnZUZvcm0gfSBmcm9tIFwiLi9Db2xvckltYWdlRm9ybVwiO1xuaW1wb3J0IHsgdHJhbnNmb3JtQ29sb3JJbWFnZURhdGEgfSBmcm9tIFwiLi9jb2xvckltYWdlVHJhbnNmb3JtXCI7XG5cbmV4cG9ydCBjb25zdCBDb2xvckltYWdlQ3JlYXRlID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxDcmVhdGUgdHJhbnNmb3JtPXt0cmFuc2Zvcm1Db2xvckltYWdlRGF0YX0gcmVkaXJlY3Q9XCJsaXN0XCI+XG4gICAgICA8U2ltcGxlRm9ybT5cbiAgICAgICAgPENvbG9ySW1hZ2VGb3JtIC8+XG4gICAgICA8L1NpbXBsZUZvcm0+XG4gICAgPC9DcmVhdGU+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2NvbG9yLWltYWdlcy9Db2xvckltYWdlQ3JlYXRlLnRzeCJ9