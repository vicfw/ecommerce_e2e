import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/mnt/data/ecommerce/ecommerce_admin/src/index.css"
const __vite__css = "*,\n*::before,\n*::after {\n  box-sizing: border-box;\n}\n\nhtml,\nbody,\n#root {\n  margin: 0;\n  min-height: 100%;\n  width: 100%;\n}\n\nbody {\n  font-family: \"Plus Jakarta Sans\", system-ui, -apple-system, \"Segoe UI\",\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  text-rendering: optimizeLegibility;\n  background: #f1f5f9;\n  color: #0f172a;\n}\n\na {\n  color: inherit;\n  text-decoration: none;\n}\n\nimg {\n  max-width: 100%;\n  display: block;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))