import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/brands/BrandEdit.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Edit, SimpleForm } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { BrandForm } from "/src/resources/brands/BrandForm.tsx";
export const BrandEdit = () => {
  return /* @__PURE__ */ jsxDEV(Edit, { mutationMode: "pessimistic", redirect: "list", children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(BrandForm, {}, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandEdit.tsx",
    lineNumber: 8,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandEdit.tsx",
    lineNumber: 7,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandEdit.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
};
_c = BrandEdit;
var _c;
$RefreshReg$(_c, "BrandEdit");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandEdit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandEdit.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandEdit.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixTQUFTQSxNQUFNQyxrQkFBa0I7QUFDakMsU0FBU0MsaUJBQWlCO0FBRW5CLGFBQU1DLFlBQVlBLE1BQU07QUFDN0IsU0FDRSx1QkFBQyxRQUFLLGNBQWEsZUFBYyxVQUFTLFFBQ3hDLGlDQUFDLGNBQ0MsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVUsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFFQyxLQVJXRDtBQUFTLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkVkaXQiLCJTaW1wbGVGb3JtIiwiQnJhbmRGb3JtIiwiQnJhbmRFZGl0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnJhbmRFZGl0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFZGl0LCBTaW1wbGVGb3JtIH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQgeyBCcmFuZEZvcm0gfSBmcm9tIFwiLi9CcmFuZEZvcm1cIjtcblxuZXhwb3J0IGNvbnN0IEJyYW5kRWRpdCA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8RWRpdCBtdXRhdGlvbk1vZGU9XCJwZXNzaW1pc3RpY1wiIHJlZGlyZWN0PVwibGlzdFwiPlxuICAgICAgPFNpbXBsZUZvcm0+XG4gICAgICAgIDxCcmFuZEZvcm0gLz5cbiAgICAgIDwvU2ltcGxlRm9ybT5cbiAgICA8L0VkaXQ+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2JyYW5kcy9CcmFuZEVkaXQudHN4In0=