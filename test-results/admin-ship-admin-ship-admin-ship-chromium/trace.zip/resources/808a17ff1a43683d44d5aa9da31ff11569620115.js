// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/ownerDocument/ownerDocument.mjs
function ownerDocument(node) {
  return node && node.ownerDocument || document;
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/getActiveElement/getActiveElement.mjs
function activeElement(doc) {
  let element = doc.activeElement;
  while (element?.shadowRoot?.activeElement != null) {
    element = element.shadowRoot.activeElement;
  }
  return element;
}

export {
  ownerDocument,
  activeElement
};
//# sourceMappingURL=chunk-AMU7WGDT.js.map
