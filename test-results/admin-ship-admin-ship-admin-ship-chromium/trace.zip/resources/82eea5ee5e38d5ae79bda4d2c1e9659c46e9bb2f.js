import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/products/ProductForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  ArrayInput,
  AutocompleteArrayInput,
  AutocompleteInput,
  NumberInput,
  ReferenceArrayInput,
  ReferenceInput,
  required,
  minValue,
  SimpleFormIterator,
  TextInput
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import {
  SwatchOption,
  fieldInputText,
  fieldMatchSuggestion
} from "/src/components/SwatchOption.tsx";
export const ProductForm = () => {
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      sx: {
        display: "flex",
        flexDirection: "column",
        gap: 2
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "prName",
                  label: "Persian Name",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 37,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 36,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextInput,
                {
                  source: "enName",
                  label: "English Name",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 46,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 45,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 29,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(ReferenceInput, { source: "categoryId", reference: "category", perPage: 50, children: /* @__PURE__ */ jsxDEV(
                AutocompleteInput,
                {
                  optionText: "name",
                  label: "Category",
                  fullWidth: true,
                  validate: required()
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 64,
                  columnNumber: 13
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 63,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 62,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(ReferenceInput, { source: "brandId", reference: "brand", perPage: 50, children: /* @__PURE__ */ jsxDEV(AutocompleteInput, { optionText: "name", label: "Brand", fullWidth: true }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 75,
                columnNumber: 13
              }, this) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 74,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 73,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 55,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                NumberInput,
                {
                  source: "price",
                  label: "Price",
                  fullWidth: true,
                  validate: [required(), minValue(0)],
                  min: 0,
                  step: 0.01
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 88,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 87,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                NumberInput,
                {
                  source: "discount",
                  label: "Discount",
                  fullWidth: true,
                  validate: minValue(0),
                  min: 0,
                  step: 0.01,
                  defaultValue: 0
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 99,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 98,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 80,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                NumberInput,
                {
                  source: "quantity",
                  label: "Quantity",
                  fullWidth: true,
                  validate: [required(), minValue(0)],
                  min: 0
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 119,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 118,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                NumberInput,
                {
                  source: "reservedQuantity",
                  label: "Reserved",
                  fullWidth: true,
                  disabled: true,
                  defaultValue: 0
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                  lineNumber: 129,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 128,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 111,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              flexWrap: "wrap",
              gap: 2
            },
            children: /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
              NumberInput,
              {
                source: "weight",
                label: "Weight",
                fullWidth: true,
                validate: minValue(0),
                min: 0,
                step: 0.01,
                defaultValue: 0
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 147,
                columnNumber: 11
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
              lineNumber: 146,
              columnNumber: 9
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 139,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "description",
            label: "Description",
            fullWidth: true,
            multiline: true,
            rows: 4
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 160,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 159,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(ArrayInput, { source: "images", label: "Images", children: /* @__PURE__ */ jsxDEV(SimpleFormIterator, { inline: true, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "",
            label: "Image URL",
            helperText: "Enter image URL",
            fullWidth: true,
            validate: required()
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 172,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 171,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 170,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 169,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            source: "defaultColorImage",
            label: "Default Color Image URL",
            helperText: "Optional — defaults to the first product image",
            fullWidth: true
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 184,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 183,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(ReferenceArrayInput, { source: "badges", reference: "badge", perPage: 50, children: /* @__PURE__ */ jsxDEV(
          AutocompleteArrayInput,
          {
            label: "Badges",
            optionText: /* @__PURE__ */ jsxDEV(
              SwatchOption,
              {
                imageField: "icon",
                labelField: "title",
                fallbackAlt: "Badge"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 197,
                columnNumber: 13
              },
              this
            ),
            inputText: fieldInputText("title"),
            matchSuggestion: fieldMatchSuggestion("title"),
            fullWidth: true
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 194,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 193,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 192,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: "100%" }, children: /* @__PURE__ */ jsxDEV(
          ReferenceArrayInput,
          {
            source: "colorImageIds",
            reference: "colorImage",
            perPage: 50,
            children: /* @__PURE__ */ jsxDEV(
              AutocompleteArrayInput,
              {
                label: "Color Images",
                optionText: /* @__PURE__ */ jsxDEV(
                  SwatchOption,
                  {
                    imageField: "colorImage",
                    labelField: "name",
                    fallbackAlt: "Color"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                    lineNumber: 219,
                    columnNumber: 13
                  },
                  this
                ),
                inputText: fieldInputText("name"),
                matchSuggestion: fieldMatchSuggestion("name"),
                fullWidth: true
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
                lineNumber: 216,
                columnNumber: 11
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
            lineNumber: 211,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
          lineNumber: 210,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx",
      lineNumber: 22,
      columnNumber: 5
    },
    this
  );
};
_c = ProductForm;
var _c;
$RefreshReg$(_c, "ProductForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NVO0FBcENWO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFNBQVM7QUFDaEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRUEsYUFBTUMsY0FBY0EsTUFBTTtBQUMvQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxJQUFJO0FBQUEsUUFDRkMsU0FBUztBQUFBLFFBQ1RDLGVBQWU7QUFBQSxRQUNmQyxLQUFLO0FBQUEsTUFDUDtBQUFBLE1BRUE7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSTtBQUFBLGNBQ0ZGLFNBQVM7QUFBQSxjQUNURyxVQUFVO0FBQUEsY0FDVkQsS0FBSztBQUFBLFlBQ1A7QUFBQSxZQUVBO0FBQUEscUNBQUMsT0FBSSxJQUFJLEVBQUVFLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFFBQU87QUFBQSxrQkFDUCxPQUFNO0FBQUEsa0JBQ047QUFBQSxrQkFDQSxVQUFVZixTQUFTO0FBQUE7QUFBQSxnQkFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVCLEtBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFYSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFPO0FBQUEsa0JBQ1AsT0FBTTtBQUFBLGtCQUNOO0FBQUEsa0JBQ0EsVUFBVWYsU0FBUztBQUFBO0FBQUEsZ0JBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1QixLQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXdCQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxjQUNGUyxTQUFTO0FBQUEsY0FDVEcsVUFBVTtBQUFBLGNBQ1ZELEtBQUs7QUFBQSxZQUNQO0FBQUEsWUFFQTtBQUFBLHFDQUFDLE9BQUksSUFBSSxFQUFFRSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RCxpQ0FBQyxrQkFBZSxRQUFPLGNBQWEsV0FBVSxZQUFXLFNBQVMsSUFDaEU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsWUFBVztBQUFBLGtCQUNYLE9BQU07QUFBQSxrQkFDTjtBQUFBLGtCQUNBLFVBQVVmLFNBQVM7QUFBQTtBQUFBLGdCQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJdUIsS0FMekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFYSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RCxpQ0FBQyxrQkFBZSxRQUFPLFdBQVUsV0FBVSxTQUFRLFNBQVMsSUFDMUQsaUNBQUMscUJBQWtCLFlBQVcsUUFBTyxPQUFNLFNBQVEsV0FBUyxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RCxLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBO0FBQUE7QUFBQSxVQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF1QkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFJO0FBQUEsY0FDRk4sU0FBUztBQUFBLGNBQ1RHLFVBQVU7QUFBQSxjQUNWRCxLQUFLO0FBQUEsWUFDUDtBQUFBLFlBRUE7QUFBQSxxQ0FBQyxPQUFJLElBQUksRUFBRUUsT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsUUFBTztBQUFBLGtCQUNQLE9BQU07QUFBQSxrQkFDTjtBQUFBLGtCQUNBLFVBQVUsQ0FBQ2YsU0FBUyxHQUFHQyxTQUFTLENBQUMsQ0FBQztBQUFBLGtCQUNsQyxLQUFLO0FBQUEsa0JBQ0wsTUFBTTtBQUFBO0FBQUEsZ0JBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTWEsS0FQZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FFQSx1QkFBQyxPQUFJLElBQUksRUFBRVksT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsUUFBTztBQUFBLGtCQUNQLE9BQU07QUFBQSxrQkFDTjtBQUFBLGtCQUNBLFVBQVVkLFNBQVMsQ0FBQztBQUFBLGtCQUNwQixLQUFLO0FBQUEsa0JBQ0wsTUFBTTtBQUFBLGtCQUNOLGNBQWM7QUFBQTtBQUFBLGdCQVBoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPa0IsS0FScEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBO0FBQUE7QUFBQSxVQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE2QkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFJO0FBQUEsY0FDRlEsU0FBUztBQUFBLGNBQ1RHLFVBQVU7QUFBQSxjQUNWRCxLQUFLO0FBQUEsWUFDUDtBQUFBLFlBRUE7QUFBQSxxQ0FBQyxPQUFJLElBQUksRUFBRUUsT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsUUFBTztBQUFBLGtCQUNQLE9BQU07QUFBQSxrQkFDTjtBQUFBLGtCQUNBLFVBQVUsQ0FBQ2YsU0FBUyxHQUFHQyxTQUFTLENBQUMsQ0FBQztBQUFBLGtCQUNsQyxLQUFLO0FBQUE7QUFBQSxnQkFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLUyxLQU5YO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFWSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFPO0FBQUEsa0JBQ1AsT0FBTTtBQUFBLGtCQUNOO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQSxjQUFjO0FBQUE7QUFBQSxnQkFMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2tCLEtBTnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQTtBQUFBO0FBQUEsVUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBMEJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSTtBQUFBLGNBQ0ZOLFNBQVM7QUFBQSxjQUNURyxVQUFVO0FBQUEsY0FDVkQsS0FBSztBQUFBLFlBQ1A7QUFBQSxZQUVBLGlDQUFDLE9BQUksSUFBSSxFQUFFRSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFFBQU87QUFBQSxnQkFDUCxPQUFNO0FBQUEsZ0JBQ047QUFBQSxnQkFDQSxVQUFVZCxTQUFTLENBQUM7QUFBQSxnQkFDcEIsS0FBSztBQUFBLGdCQUNMLE1BQU07QUFBQSxnQkFDTixjQUFjO0FBQUE7QUFBQSxjQVBoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPa0IsS0FScEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBO0FBQUEsVUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JBO0FBQUEsUUFFQSx1QkFBQyxPQUFJLElBQUksRUFBRVksT0FBTyxPQUFPLEdBQ3ZCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxRQUFPO0FBQUEsWUFDUCxPQUFNO0FBQUEsWUFDTjtBQUFBLFlBQ0E7QUFBQSxZQUNBLE1BQU07QUFBQTtBQUFBLFVBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS1UsS0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFQSxPQUFPLE9BQU8sR0FDdkIsaUNBQUMsY0FBVyxRQUFPLFVBQVMsT0FBTSxVQUNoQyxpQ0FBQyxzQkFBbUIsUUFBTSxNQUN4QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsUUFBTztBQUFBLFlBQ1AsT0FBTTtBQUFBLFlBQ04sWUFBVztBQUFBLFlBQ1g7QUFBQSxZQUNBLFVBQVViLFNBQVM7QUFBQTtBQUFBLFVBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUt1QixLQU56QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFYSxPQUFPLE9BQU8sR0FDdkI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFFBQU87QUFBQSxZQUNQLE9BQU07QUFBQSxZQUNOLFlBQVc7QUFBQSxZQUNYLFdBQVM7QUFBQTtBQUFBLFVBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSVcsS0FMYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFQSxPQUFPLE9BQU8sR0FDdkIsaUNBQUMsdUJBQW9CLFFBQU8sVUFBUyxXQUFVLFNBQVEsU0FBUyxJQUM5RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sWUFDRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFlBQVc7QUFBQSxnQkFDWCxZQUFXO0FBQUEsZ0JBQ1gsYUFBWTtBQUFBO0FBQUEsY0FIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHcUI7QUFBQSxZQUd2QixXQUFXUCxlQUFlLE9BQU87QUFBQSxZQUNqQyxpQkFBaUJDLHFCQUFxQixPQUFPO0FBQUEsWUFDN0MsV0FBUztBQUFBO0FBQUEsVUFYWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXVyxLQVpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFTSxPQUFPLE9BQU8sR0FDdkI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFFBQU87QUFBQSxZQUNQLFdBQVU7QUFBQSxZQUNWLFNBQVM7QUFBQSxZQUVUO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLFlBQ0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsWUFBVztBQUFBLG9CQUNYLFlBQVc7QUFBQSxvQkFDWCxhQUFZO0FBQUE7QUFBQSxrQkFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR3FCO0FBQUEsZ0JBR3ZCLFdBQVdQLGVBQWUsTUFBTTtBQUFBLGdCQUNoQyxpQkFBaUJDLHFCQUFxQixNQUFNO0FBQUEsZ0JBQzVDLFdBQVM7QUFBQTtBQUFBLGNBWFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV1c7QUFBQTtBQUFBLFVBaEJiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUE7QUFBQTtBQUFBLElBaE5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlOQTtBQUVKO0FBQUVTLEtBck5XUjtBQUFXLElBQUFRO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFycmF5SW5wdXQiLCJBdXRvY29tcGxldGVBcnJheUlucHV0IiwiQXV0b2NvbXBsZXRlSW5wdXQiLCJOdW1iZXJJbnB1dCIsIlJlZmVyZW5jZUFycmF5SW5wdXQiLCJSZWZlcmVuY2VJbnB1dCIsInJlcXVpcmVkIiwibWluVmFsdWUiLCJTaW1wbGVGb3JtSXRlcmF0b3IiLCJUZXh0SW5wdXQiLCJCb3giLCJTd2F0Y2hPcHRpb24iLCJmaWVsZElucHV0VGV4dCIsImZpZWxkTWF0Y2hTdWdnZXN0aW9uIiwiUHJvZHVjdEZvcm0iLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsImZsZXhXcmFwIiwid2lkdGgiLCJ4cyIsIm1kIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFycmF5SW5wdXQsXG4gIEF1dG9jb21wbGV0ZUFycmF5SW5wdXQsXG4gIEF1dG9jb21wbGV0ZUlucHV0LFxuICBOdW1iZXJJbnB1dCxcbiAgUmVmZXJlbmNlQXJyYXlJbnB1dCxcbiAgUmVmZXJlbmNlSW5wdXQsXG4gIHJlcXVpcmVkLFxuICBtaW5WYWx1ZSxcbiAgU2ltcGxlRm9ybUl0ZXJhdG9yLFxuICBUZXh0SW5wdXQsXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcbmltcG9ydCB7XG4gIFN3YXRjaE9wdGlvbixcbiAgZmllbGRJbnB1dFRleHQsXG4gIGZpZWxkTWF0Y2hTdWdnZXN0aW9uLFxufSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9Td2F0Y2hPcHRpb25cIjtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RGb3JtID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxCb3hcbiAgICAgIHN4PXt7XG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICBnYXA6IDIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgZ2FwOiAyLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICBzb3VyY2U9XCJwck5hbWVcIlxuICAgICAgICAgICAgbGFiZWw9XCJQZXJzaWFuIE5hbWVcIlxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICB2YWxpZGF0ZT17cmVxdWlyZWQoKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cblxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8VGV4dElucHV0XG4gICAgICAgICAgICBzb3VyY2U9XCJlbk5hbWVcIlxuICAgICAgICAgICAgbGFiZWw9XCJFbmdsaXNoIE5hbWVcIlxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICB2YWxpZGF0ZT17cmVxdWlyZWQoKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cbiAgICAgIDwvQm94PlxuXG4gICAgICA8Qm94XG4gICAgICAgIHN4PXt7XG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgZmxleFdyYXA6IFwid3JhcFwiLFxuICAgICAgICAgIGdhcDogMixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPEJveCBzeD17eyB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBcImNhbGMoNTAlIC0gOHB4KVwiIH0gfX0+XG4gICAgICAgICAgPFJlZmVyZW5jZUlucHV0IHNvdXJjZT1cImNhdGVnb3J5SWRcIiByZWZlcmVuY2U9XCJjYXRlZ29yeVwiIHBlclBhZ2U9ezUwfT5cbiAgICAgICAgICAgIDxBdXRvY29tcGxldGVJbnB1dFxuICAgICAgICAgICAgICBvcHRpb25UZXh0PVwibmFtZVwiXG4gICAgICAgICAgICAgIGxhYmVsPVwiQ2F0ZWdvcnlcIlxuICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgdmFsaWRhdGU9e3JlcXVpcmVkKCl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvUmVmZXJlbmNlSW5wdXQ+XG4gICAgICAgIDwvQm94PlxuXG4gICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgIDxSZWZlcmVuY2VJbnB1dCBzb3VyY2U9XCJicmFuZElkXCIgcmVmZXJlbmNlPVwiYnJhbmRcIiBwZXJQYWdlPXs1MH0+XG4gICAgICAgICAgICA8QXV0b2NvbXBsZXRlSW5wdXQgb3B0aW9uVGV4dD1cIm5hbWVcIiBsYWJlbD1cIkJyYW5kXCIgZnVsbFdpZHRoIC8+XG4gICAgICAgICAgPC9SZWZlcmVuY2VJbnB1dD5cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICBnYXA6IDIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgIDxOdW1iZXJJbnB1dFxuICAgICAgICAgICAgc291cmNlPVwicHJpY2VcIlxuICAgICAgICAgICAgbGFiZWw9XCJQcmljZVwiXG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgIHZhbGlkYXRlPXtbcmVxdWlyZWQoKSwgbWluVmFsdWUoMCldfVxuICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgICAgc3RlcD17MC4wMX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cblxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8TnVtYmVySW5wdXRcbiAgICAgICAgICAgIHNvdXJjZT1cImRpc2NvdW50XCJcbiAgICAgICAgICAgIGxhYmVsPVwiRGlzY291bnRcIlxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICB2YWxpZGF0ZT17bWluVmFsdWUoMCl9XG4gICAgICAgICAgICBtaW49ezB9XG4gICAgICAgICAgICBzdGVwPXswLjAxfVxuICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXswfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQm94PlxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgZ2FwOiAyLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8TnVtYmVySW5wdXRcbiAgICAgICAgICAgIHNvdXJjZT1cInF1YW50aXR5XCJcbiAgICAgICAgICAgIGxhYmVsPVwiUXVhbnRpdHlcIlxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICB2YWxpZGF0ZT17W3JlcXVpcmVkKCksIG1pblZhbHVlKDApXX1cbiAgICAgICAgICAgIG1pbj17MH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cblxuICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICA8TnVtYmVySW5wdXRcbiAgICAgICAgICAgIHNvdXJjZT1cInJlc2VydmVkUXVhbnRpdHlcIlxuICAgICAgICAgICAgbGFiZWw9XCJSZXNlcnZlZFwiXG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgIGRpc2FibGVkXG4gICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICBnYXA6IDIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgIDxOdW1iZXJJbnB1dFxuICAgICAgICAgICAgc291cmNlPVwid2VpZ2h0XCJcbiAgICAgICAgICAgIGxhYmVsPVwiV2VpZ2h0XCJcbiAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgdmFsaWRhdGU9e21pblZhbHVlKDApfVxuICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgICAgc3RlcD17MC4wMX1cbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cbiAgICAgIDwvQm94PlxuXG4gICAgICA8Qm94IHN4PXt7IHdpZHRoOiBcIjEwMCVcIiB9fT5cbiAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgIHNvdXJjZT1cImRlc2NyaXB0aW9uXCJcbiAgICAgICAgICBsYWJlbD1cIkRlc2NyaXB0aW9uXCJcbiAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICBtdWx0aWxpbmVcbiAgICAgICAgICByb3dzPXs0fVxuICAgICAgICAvPlxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxuICAgICAgICA8QXJyYXlJbnB1dCBzb3VyY2U9XCJpbWFnZXNcIiBsYWJlbD1cIkltYWdlc1wiPlxuICAgICAgICAgIDxTaW1wbGVGb3JtSXRlcmF0b3IgaW5saW5lPlxuICAgICAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgICAgICBzb3VyY2U9XCJcIlxuICAgICAgICAgICAgICBsYWJlbD1cIkltYWdlIFVSTFwiXG4gICAgICAgICAgICAgIGhlbHBlclRleHQ9XCJFbnRlciBpbWFnZSBVUkxcIlxuICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgdmFsaWRhdGU9e3JlcXVpcmVkKCl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvU2ltcGxlRm9ybUl0ZXJhdG9yPlxuICAgICAgICA8L0FycmF5SW5wdXQ+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveCBzeD17eyB3aWR0aDogXCIxMDAlXCIgfX0+XG4gICAgICAgIDxUZXh0SW5wdXRcbiAgICAgICAgICBzb3VyY2U9XCJkZWZhdWx0Q29sb3JJbWFnZVwiXG4gICAgICAgICAgbGFiZWw9XCJEZWZhdWx0IENvbG9yIEltYWdlIFVSTFwiXG4gICAgICAgICAgaGVscGVyVGV4dD1cIk9wdGlvbmFsIOKAlCBkZWZhdWx0cyB0byB0aGUgZmlyc3QgcHJvZHVjdCBpbWFnZVwiXG4gICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgIC8+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveCBzeD17eyB3aWR0aDogXCIxMDAlXCIgfX0+XG4gICAgICAgIDxSZWZlcmVuY2VBcnJheUlucHV0IHNvdXJjZT1cImJhZGdlc1wiIHJlZmVyZW5jZT1cImJhZGdlXCIgcGVyUGFnZT17NTB9PlxuICAgICAgICAgIDxBdXRvY29tcGxldGVBcnJheUlucHV0XG4gICAgICAgICAgICBsYWJlbD1cIkJhZGdlc1wiXG4gICAgICAgICAgICBvcHRpb25UZXh0PXtcbiAgICAgICAgICAgICAgPFN3YXRjaE9wdGlvblxuICAgICAgICAgICAgICAgIGltYWdlRmllbGQ9XCJpY29uXCJcbiAgICAgICAgICAgICAgICBsYWJlbEZpZWxkPVwidGl0bGVcIlxuICAgICAgICAgICAgICAgIGZhbGxiYWNrQWx0PVwiQmFkZ2VcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaW5wdXRUZXh0PXtmaWVsZElucHV0VGV4dChcInRpdGxlXCIpfVxuICAgICAgICAgICAgbWF0Y2hTdWdnZXN0aW9uPXtmaWVsZE1hdGNoU3VnZ2VzdGlvbihcInRpdGxlXCIpfVxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9SZWZlcmVuY2VBcnJheUlucHV0PlxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19PlxuICAgICAgICA8UmVmZXJlbmNlQXJyYXlJbnB1dFxuICAgICAgICAgIHNvdXJjZT1cImNvbG9ySW1hZ2VJZHNcIlxuICAgICAgICAgIHJlZmVyZW5jZT1cImNvbG9ySW1hZ2VcIlxuICAgICAgICAgIHBlclBhZ2U9ezUwfVxuICAgICAgICA+XG4gICAgICAgICAgPEF1dG9jb21wbGV0ZUFycmF5SW5wdXRcbiAgICAgICAgICAgIGxhYmVsPVwiQ29sb3IgSW1hZ2VzXCJcbiAgICAgICAgICAgIG9wdGlvblRleHQ9e1xuICAgICAgICAgICAgICA8U3dhdGNoT3B0aW9uXG4gICAgICAgICAgICAgICAgaW1hZ2VGaWVsZD1cImNvbG9ySW1hZ2VcIlxuICAgICAgICAgICAgICAgIGxhYmVsRmllbGQ9XCJuYW1lXCJcbiAgICAgICAgICAgICAgICBmYWxsYmFja0FsdD1cIkNvbG9yXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlucHV0VGV4dD17ZmllbGRJbnB1dFRleHQoXCJuYW1lXCIpfVxuICAgICAgICAgICAgbWF0Y2hTdWdnZXN0aW9uPXtmaWVsZE1hdGNoU3VnZ2VzdGlvbihcIm5hbWVcIil9XG4gICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAvPlxuICAgICAgICA8L1JlZmVyZW5jZUFycmF5SW5wdXQ+XG4gICAgICA8L0JveD5cbiAgICA8L0JveD5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9yZXNvdXJjZXMvcHJvZHVjdHMvUHJvZHVjdEZvcm0udHN4In0=