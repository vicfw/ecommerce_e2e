import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/ToggleButtonGroup/ToggleButtonGroupContext.mjs
var React = __toESM(require_react(), 1);
var ToggleButtonGroupContext = React.createContext({});
if (true) {
  ToggleButtonGroupContext.displayName = "ToggleButtonGroupContext";
}
var ToggleButtonGroupContext_default = ToggleButtonGroupContext;

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/ToggleButtonGroup/ToggleButtonGroupButtonContext.mjs
var React2 = __toESM(require_react(), 1);
var ToggleButtonGroupButtonContext = React2.createContext(void 0);
if (true) {
  ToggleButtonGroupButtonContext.displayName = "ToggleButtonGroupButtonContext";
}
var ToggleButtonGroupButtonContext_default = ToggleButtonGroupButtonContext;

export {
  ToggleButtonGroupContext_default,
  ToggleButtonGroupButtonContext_default
};
//# sourceMappingURL=chunk-DRQECRNQ.js.map
