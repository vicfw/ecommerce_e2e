import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/comments/CommentList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import Button from "/node_modules/.vite/deps/@mui_material_Button.js?v=49ae7072";
import Chip from "/node_modules/.vite/deps/@mui_material_Chip.js?v=49ae7072";
import {
  List,
  Datagrid,
  TextField,
  DateField,
  FunctionField,
  DeleteButton,
  useUpdate,
  useNotify,
  SelectInput
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
const ApproveButton = ({
  record
}) => {
  _s();
  const [update, { isPending }] = useUpdate();
  const notify = useNotify();
  if (!record || record.isApproved) return null;
  return /* @__PURE__ */ jsxDEV(
    Button,
    {
      size: "small",
      variant: "outlined",
      color: "success",
      disabled: isPending,
      onClick: async (e) => {
        e.stopPropagation();
        try {
          await update("comment", {
            id: record.id,
            data: { isApproved: true },
            previousData: record
          });
          notify("Comment approved", { type: "success" });
        } catch {
          notify("Failed to approve comment", { type: "error" });
        }
      },
      children: "Approve"
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
      lineNumber: 32,
      columnNumber: 5
    },
    this
  );
};
_s(ApproveButton, "4iqEOpwWqPXSgmffQCprmXh+VfE=", false, function() {
  return [useUpdate, useNotify];
});
_c = ApproveButton;
const commentFilters = [
  /* @__PURE__ */ jsxDEV(
    SelectInput,
    {
      source: "isApproved",
      choices: [
        { id: false, name: "Pending" },
        { id: true, name: "Approved" }
      ],
      alwaysOn: true
    },
    "isApproved",
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
      lineNumber: 57,
      columnNumber: 1
    },
    this
  )
];
export const CommentList = () => {
  return /* @__PURE__ */ jsxDEV(
    List,
    {
      filters: commentFilters,
      filterDefaultValues: { isApproved: false },
      sort: { field: "createdAt", order: "DESC" },
      children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: false, children: [
        /* @__PURE__ */ jsxDEV(TextField, { source: "id" }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
          lineNumber: 76,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          FunctionField,
          {
            label: "Product",
            render: (record) => record.product?.prName || record.product?.enName || "-"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
            lineNumber: 77,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          FunctionField,
          {
            label: "User",
            render: (record) => [record.user?.name, record.user?.lastName].filter(Boolean).join(" ") || "-"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
            lineNumber: 85,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          FunctionField,
          {
            label: "Comment",
            render: (record) => record.body && record.body.length > 80 ? `${record.body.slice(0, 80)}...` : record.body || "-"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
            lineNumber: 95,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          FunctionField,
          {
            label: "Image",
            render: (record) => record.image ? /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: record.image,
                alt: "Review",
                style: {
                  height: 40,
                  width: 40,
                  objectFit: "cover",
                  borderRadius: 6
                }
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
                lineNumber: 107,
                columnNumber: 11
              },
              this
            ) : "-"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
            lineNumber: 103,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          FunctionField,
          {
            label: "Status",
            render: (record) => /* @__PURE__ */ jsxDEV(
              Chip,
              {
                label: record.isApproved ? "Approved" : "Pending",
                color: record.isApproved ? "success" : "warning",
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
                lineNumber: 125,
                columnNumber: 11
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
            lineNumber: 122,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(DateField, { source: "createdAt", label: "Date", showTime: true }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
          lineNumber: 132,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          FunctionField,
          {
            label: "Actions",
            render: (record) => /* @__PURE__ */ jsxDEV(ApproveButton, { record }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
              lineNumber: 135,
              columnNumber: 31
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
            lineNumber: 133,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(DeleteButton, {}, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
          lineNumber: 137,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
        lineNumber: 75,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  );
};
_c2 = CommentList;
var _c, _c2;
$RefreshReg$(_c, "ApproveButton");
$RefreshReg$(_c2, "CommentList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/comments/CommentList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JJOztBQS9CSixPQUFPQSxZQUFZO0FBQ25CLE9BQU9DLFVBQVU7QUFDakI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsTUFBTUMsZ0JBQWdCQSxDQUFDO0FBQUEsRUFDckJDO0FBU0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxRQUFRLEVBQUVDLFVBQVUsQ0FBQyxJQUFJUCxVQUFVO0FBQzFDLFFBQU1RLFNBQVNQLFVBQVU7QUFFekIsTUFBSSxDQUFDRyxVQUFVQSxPQUFPSyxXQUFZLFFBQU87QUFFekMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsU0FBUTtBQUFBLE1BQ1IsT0FBTTtBQUFBLE1BQ04sVUFBVUY7QUFBQUEsTUFDVixTQUFTLE9BQU9HLE1BQU07QUFDcEJBLFVBQUVDLGdCQUFnQjtBQUNsQixZQUFJO0FBQ0YsZ0JBQU1MLE9BQU8sV0FBVztBQUFBLFlBQ3RCTSxJQUFJUixPQUFPUTtBQUFBQSxZQUNYQyxNQUFNLEVBQUVKLFlBQVksS0FBSztBQUFBLFlBQ3pCSyxjQUFjVjtBQUFBQSxVQUNoQixDQUFDO0FBQ0RJLGlCQUFPLG9CQUFvQixFQUFFTyxNQUFNLFVBQVUsQ0FBQztBQUFBLFFBQ2hELFFBQVE7QUFDTlAsaUJBQU8sNkJBQTZCLEVBQUVPLE1BQU0sUUFBUSxDQUFDO0FBQUEsUUFDdkQ7QUFBQSxNQUNGO0FBQUEsTUFBRTtBQUFBO0FBQUEsSUFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBb0JBO0FBRUo7QUFBRVYsR0F2Q0lGLGVBQWE7QUFBQSxVQVdlSCxXQUNqQkMsU0FBUztBQUFBO0FBQUEsS0FacEJFO0FBeUNOLE1BQU1hLGlCQUFpQjtBQUFBLEVBQ3JCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFFQyxRQUFPO0FBQUEsTUFDUCxTQUFTO0FBQUEsUUFDUCxFQUFFSixJQUFJLE9BQU9LLE1BQU0sVUFBVTtBQUFBLFFBQzdCLEVBQUVMLElBQUksTUFBTUssTUFBTSxXQUFXO0FBQUEsTUFBQztBQUFBLE1BRWhDLFVBQVE7QUFBQTtBQUFBLElBTko7QUFBQSxJQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPVTtBQUNSO0FBR0csYUFBTUMsY0FBY0EsTUFBTTtBQUMvQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxTQUFTRjtBQUFBQSxNQUNULHFCQUFxQixFQUFFUCxZQUFZLE1BQU07QUFBQSxNQUN6QyxNQUFNLEVBQUVVLE9BQU8sYUFBYUMsT0FBTyxPQUFPO0FBQUEsTUFFMUMsaUNBQUMsWUFBUyxVQUFVLE9BQ2xCO0FBQUEsK0JBQUMsYUFBVSxRQUFPLFFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0I7QUFBQSxRQUN0QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sUUFBUSxDQUFDaEIsV0FHUEEsT0FBT2lCLFNBQVNDLFVBQVVsQixPQUFPaUIsU0FBU0UsVUFBVTtBQUFBO0FBQUEsVUFMeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUc7QUFBQSxRQUVIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixRQUFRLENBQUNuQixXQUdQLENBQUNBLE9BQU9vQixNQUFNUCxNQUFNYixPQUFPb0IsTUFBTUMsUUFBUSxFQUN0Q0MsT0FBT0MsT0FBTyxFQUNkQyxLQUFLLEdBQUcsS0FBSztBQUFBO0FBQUEsVUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUc7QUFBQSxRQUVIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixRQUFRLENBQUN4QixXQUNQQSxPQUFPeUIsUUFBUXpCLE9BQU95QixLQUFLQyxTQUFTLEtBQ2hDLEdBQUcxQixPQUFPeUIsS0FBS0UsTUFBTSxHQUFHLEVBQUUsQ0FBQyxRQUMzQjNCLE9BQU95QixRQUFRO0FBQUE7QUFBQSxVQUx2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNRztBQUFBLFFBRUg7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLFFBQVEsQ0FBQ3pCLFdBQ1BBLE9BQU80QixRQUNMO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsS0FBSzVCLE9BQU80QjtBQUFBQSxnQkFDWixLQUFJO0FBQUEsZ0JBQ0osT0FBTztBQUFBLGtCQUNMQyxRQUFRO0FBQUEsa0JBQ1JDLE9BQU87QUFBQSxrQkFDUEMsV0FBVztBQUFBLGtCQUNYQyxjQUFjO0FBQUEsZ0JBQ2hCO0FBQUE7QUFBQSxjQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFJLElBR0o7QUFBQTtBQUFBLFVBZk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBaUJHO0FBQUEsUUFFSDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sUUFBUSxDQUFDaEMsV0FDUDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9BLE9BQU9LLGFBQWEsYUFBYTtBQUFBLGdCQUN4QyxPQUFPTCxPQUFPSyxhQUFhLFlBQVk7QUFBQSxnQkFDdkMsTUFBSztBQUFBO0FBQUEsY0FIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHYztBQUFBO0FBQUEsVUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUk7QUFBQSxRQUVKLHVCQUFDLGFBQVUsUUFBTyxhQUFZLE9BQU0sUUFBTyxVQUFRLFFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUNuRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sUUFBUSxDQUFDTCxXQUFXLHVCQUFDLGlCQUFjLFVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQTtBQUFBLFVBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUV3RDtBQUFBLFFBRXhELHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYTtBQUFBLFdBOURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErREE7QUFBQTtBQUFBLElBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFFQTtBQUVKO0FBQUVpQyxNQXpFV25CO0FBQVcsSUFBQW9CLElBQUFEO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJDaGlwIiwiTGlzdCIsIkRhdGFncmlkIiwiVGV4dEZpZWxkIiwiRGF0ZUZpZWxkIiwiRnVuY3Rpb25GaWVsZCIsIkRlbGV0ZUJ1dHRvbiIsInVzZVVwZGF0ZSIsInVzZU5vdGlmeSIsIlNlbGVjdElucHV0IiwiQXBwcm92ZUJ1dHRvbiIsInJlY29yZCIsIl9zIiwidXBkYXRlIiwiaXNQZW5kaW5nIiwibm90aWZ5IiwiaXNBcHByb3ZlZCIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJpZCIsImRhdGEiLCJwcmV2aW91c0RhdGEiLCJ0eXBlIiwiY29tbWVudEZpbHRlcnMiLCJuYW1lIiwiQ29tbWVudExpc3QiLCJmaWVsZCIsIm9yZGVyIiwicHJvZHVjdCIsInByTmFtZSIsImVuTmFtZSIsInVzZXIiLCJsYXN0TmFtZSIsImZpbHRlciIsIkJvb2xlYW4iLCJqb2luIiwiYm9keSIsImxlbmd0aCIsInNsaWNlIiwiaW1hZ2UiLCJoZWlnaHQiLCJ3aWR0aCIsIm9iamVjdEZpdCIsImJvcmRlclJhZGl1cyIsIl9jMiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvbW1lbnRMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL0J1dHRvblwiO1xuaW1wb3J0IENoaXAgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQ2hpcFwiO1xuaW1wb3J0IHtcbiAgTGlzdCxcbiAgRGF0YWdyaWQsXG4gIFRleHRGaWVsZCxcbiAgRGF0ZUZpZWxkLFxuICBGdW5jdGlvbkZpZWxkLFxuICBEZWxldGVCdXR0b24sXG4gIHVzZVVwZGF0ZSxcbiAgdXNlTm90aWZ5LFxuICBTZWxlY3RJbnB1dCxcbn0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5cbmNvbnN0IEFwcHJvdmVCdXR0b24gPSAoe1xuICByZWNvcmQsXG59OiB7XG4gIHJlY29yZD86IHtcbiAgICBpZDogbnVtYmVyO1xuICAgIGlzQXBwcm92ZWQ/OiBib29sZWFuO1xuICAgIGJvZHk/OiBzdHJpbmc7XG4gICAgaW1hZ2U/OiBzdHJpbmc7XG4gICAgcHJvZHVjdElkPzogbnVtYmVyO1xuICB9O1xufSkgPT4ge1xuICBjb25zdCBbdXBkYXRlLCB7IGlzUGVuZGluZyB9XSA9IHVzZVVwZGF0ZSgpO1xuICBjb25zdCBub3RpZnkgPSB1c2VOb3RpZnkoKTtcblxuICBpZiAoIXJlY29yZCB8fCByZWNvcmQuaXNBcHByb3ZlZCkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8QnV0dG9uXG4gICAgICBzaXplPVwic21hbGxcIlxuICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcbiAgICAgIGNvbG9yPVwic3VjY2Vzc1wiXG4gICAgICBkaXNhYmxlZD17aXNQZW5kaW5nfVxuICAgICAgb25DbGljaz17YXN5bmMgKGUpID0+IHtcbiAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCB1cGRhdGUoXCJjb21tZW50XCIsIHtcbiAgICAgICAgICAgIGlkOiByZWNvcmQuaWQsXG4gICAgICAgICAgICBkYXRhOiB7IGlzQXBwcm92ZWQ6IHRydWUgfSxcbiAgICAgICAgICAgIHByZXZpb3VzRGF0YTogcmVjb3JkLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIG5vdGlmeShcIkNvbW1lbnQgYXBwcm92ZWRcIiwgeyB0eXBlOiBcInN1Y2Nlc3NcIiB9KTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgbm90aWZ5KFwiRmFpbGVkIHRvIGFwcHJvdmUgY29tbWVudFwiLCB7IHR5cGU6IFwiZXJyb3JcIiB9KTtcbiAgICAgICAgfVxuICAgICAgfX1cbiAgICA+XG4gICAgICBBcHByb3ZlXG4gICAgPC9CdXR0b24+XG4gICk7XG59O1xuXG5jb25zdCBjb21tZW50RmlsdGVycyA9IFtcbiAgPFNlbGVjdElucHV0XG4gICAga2V5PVwiaXNBcHByb3ZlZFwiXG4gICAgc291cmNlPVwiaXNBcHByb3ZlZFwiXG4gICAgY2hvaWNlcz17W1xuICAgICAgeyBpZDogZmFsc2UsIG5hbWU6IFwiUGVuZGluZ1wiIH0sXG4gICAgICB7IGlkOiB0cnVlLCBuYW1lOiBcIkFwcHJvdmVkXCIgfSxcbiAgICBdfVxuICAgIGFsd2F5c09uXG4gIC8+LFxuXTtcblxuZXhwb3J0IGNvbnN0IENvbW1lbnRMaXN0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxMaXN0XG4gICAgICBmaWx0ZXJzPXtjb21tZW50RmlsdGVyc31cbiAgICAgIGZpbHRlckRlZmF1bHRWYWx1ZXM9e3sgaXNBcHByb3ZlZDogZmFsc2UgfX1cbiAgICAgIHNvcnQ9e3sgZmllbGQ6IFwiY3JlYXRlZEF0XCIsIG9yZGVyOiBcIkRFU0NcIiB9fVxuICAgID5cbiAgICAgIDxEYXRhZ3JpZCByb3dDbGljaz17ZmFsc2V9PlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cImlkXCIgLz5cbiAgICAgICAgPEZ1bmN0aW9uRmllbGRcbiAgICAgICAgICBsYWJlbD1cIlByb2R1Y3RcIlxuICAgICAgICAgIHJlbmRlcj17KHJlY29yZDoge1xuICAgICAgICAgICAgcHJvZHVjdD86IHsgcHJOYW1lPzogc3RyaW5nOyBlbk5hbWU/OiBzdHJpbmcgfTtcbiAgICAgICAgICB9KSA9PlxuICAgICAgICAgICAgcmVjb3JkLnByb2R1Y3Q/LnByTmFtZSB8fCByZWNvcmQucHJvZHVjdD8uZW5OYW1lIHx8IFwiLVwiXG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgICA8RnVuY3Rpb25GaWVsZFxuICAgICAgICAgIGxhYmVsPVwiVXNlclwiXG4gICAgICAgICAgcmVuZGVyPXsocmVjb3JkOiB7XG4gICAgICAgICAgICB1c2VyPzogeyBuYW1lPzogc3RyaW5nOyBsYXN0TmFtZT86IHN0cmluZyB9O1xuICAgICAgICAgIH0pID0+XG4gICAgICAgICAgICBbcmVjb3JkLnVzZXI/Lm5hbWUsIHJlY29yZC51c2VyPy5sYXN0TmFtZV1cbiAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAgICAgICAuam9pbihcIiBcIikgfHwgXCItXCJcbiAgICAgICAgICB9XG4gICAgICAgIC8+XG4gICAgICAgIDxGdW5jdGlvbkZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJDb21tZW50XCJcbiAgICAgICAgICByZW5kZXI9eyhyZWNvcmQ6IHsgYm9keT86IHN0cmluZyB9KSA9PlxuICAgICAgICAgICAgcmVjb3JkLmJvZHkgJiYgcmVjb3JkLmJvZHkubGVuZ3RoID4gODBcbiAgICAgICAgICAgICAgPyBgJHtyZWNvcmQuYm9keS5zbGljZSgwLCA4MCl9Li4uYFxuICAgICAgICAgICAgICA6IHJlY29yZC5ib2R5IHx8IFwiLVwiXG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgICA8RnVuY3Rpb25GaWVsZFxuICAgICAgICAgIGxhYmVsPVwiSW1hZ2VcIlxuICAgICAgICAgIHJlbmRlcj17KHJlY29yZDogeyBpbWFnZT86IHN0cmluZyB9KSA9PlxuICAgICAgICAgICAgcmVjb3JkLmltYWdlID8gKFxuICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgc3JjPXtyZWNvcmQuaW1hZ2V9XG4gICAgICAgICAgICAgICAgYWx0PVwiUmV2aWV3XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0MCxcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MCxcbiAgICAgICAgICAgICAgICAgIG9iamVjdEZpdDogXCJjb3ZlclwiLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBcIi1cIlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgICAgPEZ1bmN0aW9uRmllbGRcbiAgICAgICAgICBsYWJlbD1cIlN0YXR1c1wiXG4gICAgICAgICAgcmVuZGVyPXsocmVjb3JkOiB7IGlzQXBwcm92ZWQ/OiBib29sZWFuIH0pID0+IChcbiAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgIGxhYmVsPXtyZWNvcmQuaXNBcHByb3ZlZCA/IFwiQXBwcm92ZWRcIiA6IFwiUGVuZGluZ1wifVxuICAgICAgICAgICAgICBjb2xvcj17cmVjb3JkLmlzQXBwcm92ZWQgPyBcInN1Y2Nlc3NcIiA6IFwid2FybmluZ1wifVxuICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuICAgICAgICAvPlxuICAgICAgICA8RGF0ZUZpZWxkIHNvdXJjZT1cImNyZWF0ZWRBdFwiIGxhYmVsPVwiRGF0ZVwiIHNob3dUaW1lIC8+XG4gICAgICAgIDxGdW5jdGlvbkZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJBY3Rpb25zXCJcbiAgICAgICAgICByZW5kZXI9eyhyZWNvcmQpID0+IDxBcHByb3ZlQnV0dG9uIHJlY29yZD17cmVjb3JkfSAvPn1cbiAgICAgICAgLz5cbiAgICAgICAgPERlbGV0ZUJ1dHRvbiAvPlxuICAgICAgPC9EYXRhZ3JpZD5cbiAgICA8L0xpc3Q+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL2NvbW1lbnRzL0NvbW1lbnRMaXN0LnRzeCJ9