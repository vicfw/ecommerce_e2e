import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/Add.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var Add_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"
}), "Add");

export {
  Add_default
};
//# sourceMappingURL=chunk-TL6OEU62.js.map
