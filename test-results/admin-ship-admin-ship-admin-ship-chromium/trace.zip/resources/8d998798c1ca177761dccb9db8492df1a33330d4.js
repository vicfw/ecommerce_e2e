import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/brands/BrandList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  List,
  Datagrid,
  TextField,
  NumberField,
  EditButton,
  DeleteButton
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
export const BrandList = () => {
  return /* @__PURE__ */ jsxDEV(List, { children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "edit", children: [
    /* @__PURE__ */ jsxDEV(NumberField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
      lineNumber: 14,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "name", label: "Name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
      lineNumber: 15,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "engName", label: "English Name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "slug", label: "Slug" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(EditButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DeleteButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
};
_c = BrandList;
var _c;
$RefreshReg$(_c, "BrandList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7QUFiUjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFQSxhQUFNQyxZQUFZQSxNQUFNO0FBQzdCLFNBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxZQUFTLFVBQVMsUUFDakI7QUFBQSwyQkFBQyxlQUFZLFFBQU8sUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCLHVCQUFDLGFBQVUsUUFBTyxRQUFPLE9BQU0sVUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBQ3JDLHVCQUFDLGFBQVUsUUFBTyxXQUFVLE9BQU0sa0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Q7QUFBQSxJQUNoRCx1QkFBQyxhQUFVLFFBQU8sUUFBTyxPQUFNLFVBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxJQUNyQyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVc7QUFBQSxJQUNYLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYTtBQUFBLE9BTmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUo7QUFBRUMsS0FiV0Q7QUFBUyxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaXN0IiwiRGF0YWdyaWQiLCJUZXh0RmllbGQiLCJOdW1iZXJGaWVsZCIsIkVkaXRCdXR0b24iLCJEZWxldGVCdXR0b24iLCJCcmFuZExpc3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCcmFuZExpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIExpc3QsXG4gIERhdGFncmlkLFxuICBUZXh0RmllbGQsXG4gIE51bWJlckZpZWxkLFxuICBFZGl0QnV0dG9uLFxuICBEZWxldGVCdXR0b24sXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuXG5leHBvcnQgY29uc3QgQnJhbmRMaXN0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxMaXN0PlxuICAgICAgPERhdGFncmlkIHJvd0NsaWNrPVwiZWRpdFwiPlxuICAgICAgICA8TnVtYmVyRmllbGQgc291cmNlPVwiaWRcIiAvPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cIm5hbWVcIiBsYWJlbD1cIk5hbWVcIiAvPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cImVuZ05hbWVcIiBsYWJlbD1cIkVuZ2xpc2ggTmFtZVwiIC8+XG4gICAgICAgIDxUZXh0RmllbGQgc291cmNlPVwic2x1Z1wiIGxhYmVsPVwiU2x1Z1wiIC8+XG4gICAgICAgIDxFZGl0QnV0dG9uIC8+XG4gICAgICAgIDxEZWxldGVCdXR0b24gLz5cbiAgICAgIDwvRGF0YWdyaWQ+XG4gICAgPC9MaXN0PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9icmFuZHMvQnJhbmRMaXN0LnRzeCJ9