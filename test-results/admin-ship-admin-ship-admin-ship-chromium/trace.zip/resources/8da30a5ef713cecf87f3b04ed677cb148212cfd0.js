import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/products/ProductList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  List,
  Datagrid,
  TextField,
  NumberField,
  EditButton,
  DeleteButton,
  ReferenceField,
  FunctionField
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
export const ProductList = () => {
  return /* @__PURE__ */ jsxDEV(List, { children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "edit", children: [
    /* @__PURE__ */ jsxDEV(TextField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      FunctionField,
      {
        label: "Image",
        render: (record) => record.images?.[0] ? /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: record.images[0],
            alt: record.prName || "Product",
            style: {
              height: 44,
              width: 44,
              objectFit: "cover",
              borderRadius: 8,
              border: "1px solid #E2E8F0",
              background: "#F8FAFC"
            }
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
            lineNumber: 21,
            columnNumber: 11
          },
          this
        ) : "-"
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
        lineNumber: 17,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(TextField, { source: "prName", label: "Persian Name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 38,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TextField, { source: "enName", label: "English Name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 39,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      ReferenceField,
      {
        source: "categoryId",
        reference: "category",
        label: "Category",
        children: /* @__PURE__ */ jsxDEV(TextField, { source: "name" }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
          lineNumber: 45,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
        lineNumber: 40,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(ReferenceField, { source: "brandId", reference: "brand", label: "Brand", children: /* @__PURE__ */ jsxDEV(TextField, { source: "name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 48,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "price", label: "Price" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "discount", label: "Discount" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "quantity", label: "On hand" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 52,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(NumberField, { source: "reservedQuantity", label: "Reserved" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 53,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      FunctionField,
      {
        label: "Available",
        render: (record) => Math.max(0, (record.quantity ?? 0) - (record.reservedQuantity ?? 0))
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
        lineNumber: 54,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(EditButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 60,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DeleteButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
      lineNumber: 61,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
};
_c = ProductList;
var _c;
$RefreshReg$(_c, "ProductList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7QUFmUjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFQSxhQUFNQyxjQUFjQSxNQUFNO0FBQy9CLFNBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxZQUFTLFVBQVMsUUFDakI7QUFBQSwyQkFBQyxhQUFVLFFBQU8sUUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQjtBQUFBLElBQ3RCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixRQUFRLENBQUNDLFdBQ1BBLE9BQU9DLFNBQVMsQ0FBQyxJQUNmO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxLQUFLRCxPQUFPQyxPQUFPLENBQUM7QUFBQSxZQUNwQixLQUFLRCxPQUFPRSxVQUFVO0FBQUEsWUFDdEIsT0FBTztBQUFBLGNBQ0xDLFFBQVE7QUFBQSxjQUNSQyxPQUFPO0FBQUEsY0FDUEMsV0FBVztBQUFBLGNBQ1hDLGNBQWM7QUFBQSxjQUNkQyxRQUFRO0FBQUEsY0FDUkMsWUFBWTtBQUFBLFlBQ2Q7QUFBQTtBQUFBLFVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUksSUFHSjtBQUFBO0FBQUEsTUFqQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbUJHO0FBQUEsSUFFSCx1QkFBQyxhQUFVLFFBQU8sVUFBUyxPQUFNLGtCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStDO0FBQUEsSUFDL0MsdUJBQUMsYUFBVSxRQUFPLFVBQVMsT0FBTSxrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQy9DO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFDVixPQUFNO0FBQUEsUUFFTixpQ0FBQyxhQUFVLFFBQU8sVUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBO0FBQUEsTUFMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUE7QUFBQSxJQUNBLHVCQUFDLGtCQUFlLFFBQU8sV0FBVSxXQUFVLFNBQVEsT0FBTSxTQUN2RCxpQ0FBQyxhQUFVLFFBQU8sVUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixLQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGVBQVksUUFBTyxTQUFRLE9BQU0sV0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLElBQ3pDLHVCQUFDLGVBQVksUUFBTyxZQUFXLE9BQU0sY0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQy9DLHVCQUFDLGVBQVksUUFBTyxZQUFXLE9BQU0sYUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QztBQUFBLElBQzlDLHVCQUFDLGVBQVksUUFBTyxvQkFBbUIsT0FBTSxjQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFDdkQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFFBQVEsQ0FBQ1IsV0FDUFMsS0FBS0MsSUFBSSxJQUFJVixPQUFPVyxZQUFZLE1BQU1YLE9BQU9ZLG9CQUFvQixFQUFFO0FBQUE7QUFBQSxNQUh2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJRztBQUFBLElBRUgsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXO0FBQUEsSUFDWCx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxPQTlDZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0NBLEtBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpREE7QUFFSjtBQUFFQyxLQXJEV2Q7QUFBVyxJQUFBYztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaXN0IiwiRGF0YWdyaWQiLCJUZXh0RmllbGQiLCJOdW1iZXJGaWVsZCIsIkVkaXRCdXR0b24iLCJEZWxldGVCdXR0b24iLCJSZWZlcmVuY2VGaWVsZCIsIkZ1bmN0aW9uRmllbGQiLCJQcm9kdWN0TGlzdCIsInJlY29yZCIsImltYWdlcyIsInByTmFtZSIsImhlaWdodCIsIndpZHRoIiwib2JqZWN0Rml0IiwiYm9yZGVyUmFkaXVzIiwiYm9yZGVyIiwiYmFja2dyb3VuZCIsIk1hdGgiLCJtYXgiLCJxdWFudGl0eSIsInJlc2VydmVkUXVhbnRpdHkiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9kdWN0TGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgTGlzdCxcbiAgRGF0YWdyaWQsXG4gIFRleHRGaWVsZCxcbiAgTnVtYmVyRmllbGQsXG4gIEVkaXRCdXR0b24sXG4gIERlbGV0ZUJ1dHRvbixcbiAgUmVmZXJlbmNlRmllbGQsXG4gIEZ1bmN0aW9uRmllbGQsXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuXG5leHBvcnQgY29uc3QgUHJvZHVjdExpc3QgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPExpc3Q+XG4gICAgICA8RGF0YWdyaWQgcm93Q2xpY2s9XCJlZGl0XCI+XG4gICAgICAgIDxUZXh0RmllbGQgc291cmNlPVwiaWRcIiAvPlxuICAgICAgICA8RnVuY3Rpb25GaWVsZFxuICAgICAgICAgIGxhYmVsPVwiSW1hZ2VcIlxuICAgICAgICAgIHJlbmRlcj17KHJlY29yZDogeyBpbWFnZXM/OiBzdHJpbmdbXTsgcHJOYW1lPzogc3RyaW5nIH0pID0+XG4gICAgICAgICAgICByZWNvcmQuaW1hZ2VzPy5bMF0gPyAoXG4gICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICBzcmM9e3JlY29yZC5pbWFnZXNbMF19XG4gICAgICAgICAgICAgICAgYWx0PXtyZWNvcmQucHJOYW1lIHx8IFwiUHJvZHVjdFwifVxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQ0LFxuICAgICAgICAgICAgICAgICAgd2lkdGg6IDQ0LFxuICAgICAgICAgICAgICAgICAgb2JqZWN0Rml0OiBcImNvdmVyXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXG4gICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFMkU4RjBcIixcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI0Y4RkFGQ1wiLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBcIi1cIlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgICAgPFRleHRGaWVsZCBzb3VyY2U9XCJwck5hbWVcIiBsYWJlbD1cIlBlcnNpYW4gTmFtZVwiIC8+XG4gICAgICAgIDxUZXh0RmllbGQgc291cmNlPVwiZW5OYW1lXCIgbGFiZWw9XCJFbmdsaXNoIE5hbWVcIiAvPlxuICAgICAgICA8UmVmZXJlbmNlRmllbGRcbiAgICAgICAgICBzb3VyY2U9XCJjYXRlZ29yeUlkXCJcbiAgICAgICAgICByZWZlcmVuY2U9XCJjYXRlZ29yeVwiXG4gICAgICAgICAgbGFiZWw9XCJDYXRlZ29yeVwiXG4gICAgICAgID5cbiAgICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cIm5hbWVcIiAvPlxuICAgICAgICA8L1JlZmVyZW5jZUZpZWxkPlxuICAgICAgICA8UmVmZXJlbmNlRmllbGQgc291cmNlPVwiYnJhbmRJZFwiIHJlZmVyZW5jZT1cImJyYW5kXCIgbGFiZWw9XCJCcmFuZFwiPlxuICAgICAgICAgIDxUZXh0RmllbGQgc291cmNlPVwibmFtZVwiIC8+XG4gICAgICAgIDwvUmVmZXJlbmNlRmllbGQ+XG4gICAgICAgIDxOdW1iZXJGaWVsZCBzb3VyY2U9XCJwcmljZVwiIGxhYmVsPVwiUHJpY2VcIiAvPlxuICAgICAgICA8TnVtYmVyRmllbGQgc291cmNlPVwiZGlzY291bnRcIiBsYWJlbD1cIkRpc2NvdW50XCIgLz5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cInF1YW50aXR5XCIgbGFiZWw9XCJPbiBoYW5kXCIgLz5cbiAgICAgICAgPE51bWJlckZpZWxkIHNvdXJjZT1cInJlc2VydmVkUXVhbnRpdHlcIiBsYWJlbD1cIlJlc2VydmVkXCIgLz5cbiAgICAgICAgPEZ1bmN0aW9uRmllbGRcbiAgICAgICAgICBsYWJlbD1cIkF2YWlsYWJsZVwiXG4gICAgICAgICAgcmVuZGVyPXsocmVjb3JkOiB7IHF1YW50aXR5PzogbnVtYmVyOyByZXNlcnZlZFF1YW50aXR5PzogbnVtYmVyIH0pID0+XG4gICAgICAgICAgICBNYXRoLm1heCgwLCAocmVjb3JkLnF1YW50aXR5ID8/IDApIC0gKHJlY29yZC5yZXNlcnZlZFF1YW50aXR5ID8/IDApKVxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgICAgPEVkaXRCdXR0b24gLz5cbiAgICAgICAgPERlbGV0ZUJ1dHRvbiAvPlxuICAgICAgPC9EYXRhZ3JpZD5cbiAgICA8L0xpc3Q+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcmVzb3VyY2VzL3Byb2R1Y3RzL1Byb2R1Y3RMaXN0LnRzeCJ9