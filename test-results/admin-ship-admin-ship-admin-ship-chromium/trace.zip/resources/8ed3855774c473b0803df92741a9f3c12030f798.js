import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/AppBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { AppBar as RaAppBar, TitlePortal } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
export const AppBar = () => /* @__PURE__ */ jsxDEV(RaAppBar, { color: "inherit", alwaysOn: true, children: /* @__PURE__ */ jsxDEV(
  Box,
  {
    sx: {
      display: "flex",
      alignItems: "center",
      gap: 1.5,
      minWidth: 0,
      flex: 1
    },
    children: [
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            alignItems: "center",
            gap: 1,
            pr: 1.5,
            mr: 0.5,
            borderRight: "1px solid",
            borderColor: "divider",
            flexShrink: 0
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  width: 28,
                  height: 28,
                  borderRadius: 1.5,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  bgcolor: "primary.main",
                  color: "primary.contrastText",
                  fontSize: 13,
                  fontWeight: 800,
                  letterSpacing: "-0.04em"
                },
                children: "E"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx",
                lineNumber: 28,
                columnNumber: 9
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Typography,
              {
                variant: "subtitle1",
                sx: {
                  fontWeight: 800,
                  letterSpacing: "-0.03em",
                  color: "text.primary",
                  lineHeight: 1
                },
                children: "Ecommerce"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx",
                lineNumber: 45,
                columnNumber: 9
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx",
          lineNumber: 16,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(TitlePortal, {}, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx",
        lineNumber: 57,
        columnNumber: 7
      }, this)
    ]
  },
  void 0,
  true,
  {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx",
    lineNumber: 7,
    columnNumber: 5
  },
  this
) }, void 0, false, {
  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx",
  lineNumber: 6,
  columnNumber: 1
}, this);
_c = AppBar;
var _c;
$RefreshReg$(_c, "AppBar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/layouts/AppBar.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJRO0FBM0JSLFNBQVNBLFVBQVVDLFVBQVVDLG1CQUFtQjtBQUNoRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGdCQUFnQjtBQUVoQixhQUFNSixTQUFTQSxNQUNwQix1QkFBQyxZQUFTLE9BQU0sV0FBVSxVQUFRLE1BQ2hDO0FBQUEsRUFBQztBQUFBO0FBQUEsSUFDQyxJQUFJO0FBQUEsTUFDRkssU0FBUztBQUFBLE1BQ1RDLFlBQVk7QUFBQSxNQUNaQyxLQUFLO0FBQUEsTUFDTEMsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSO0FBQUEsSUFFQTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJO0FBQUEsWUFDRkosU0FBUztBQUFBLFlBQ1RDLFlBQVk7QUFBQSxZQUNaQyxLQUFLO0FBQUEsWUFDTEcsSUFBSTtBQUFBLFlBQ0pDLElBQUk7QUFBQSxZQUNKQyxhQUFhO0FBQUEsWUFDYkMsYUFBYTtBQUFBLFlBQ2JDLFlBQVk7QUFBQSxVQUNkO0FBQUEsVUFFQTtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSTtBQUFBLGtCQUNGQyxPQUFPO0FBQUEsa0JBQ1BDLFFBQVE7QUFBQSxrQkFDUkMsY0FBYztBQUFBLGtCQUNkWixTQUFTO0FBQUEsa0JBQ1RDLFlBQVk7QUFBQSxrQkFDWlksZ0JBQWdCO0FBQUEsa0JBQ2hCQyxTQUFTO0FBQUEsa0JBQ1RDLE9BQU87QUFBQSxrQkFDUEMsVUFBVTtBQUFBLGtCQUNWQyxZQUFZO0FBQUEsa0JBQ1pDLGVBQWU7QUFBQSxnQkFDakI7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFnQkE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLElBQUk7QUFBQSxrQkFDRkQsWUFBWTtBQUFBLGtCQUNaQyxlQUFlO0FBQUEsa0JBQ2ZILE9BQU87QUFBQSxrQkFDUEksWUFBWTtBQUFBLGdCQUNkO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQTtBQUFBO0FBQUEsUUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0NBO0FBQUEsTUFDQSx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVk7QUFBQTtBQUFBO0FBQUEsRUFsRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW1EQSxLQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BcURBO0FBQ0FDLEtBdkRXekI7QUFBTSxJQUFBeUI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQXBwQmFyIiwiUmFBcHBCYXIiLCJUaXRsZVBvcnRhbCIsIkJveCIsIlR5cG9ncmFwaHkiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIm1pbldpZHRoIiwiZmxleCIsInByIiwibXIiLCJib3JkZXJSaWdodCIsImJvcmRlckNvbG9yIiwiZmxleFNocmluayIsIndpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwianVzdGlmeUNvbnRlbnQiLCJiZ2NvbG9yIiwiY29sb3IiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJsZXR0ZXJTcGFjaW5nIiwibGluZUhlaWdodCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcEJhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwQmFyIGFzIFJhQXBwQmFyLCBUaXRsZVBvcnRhbCB9IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcbmltcG9ydCBUeXBvZ3JhcGh5IGZyb20gXCJAbXVpL21hdGVyaWFsL1R5cG9ncmFwaHlcIjtcblxuZXhwb3J0IGNvbnN0IEFwcEJhciA9ICgpID0+IChcbiAgPFJhQXBwQmFyIGNvbG9yPVwiaW5oZXJpdFwiIGFsd2F5c09uPlxuICAgIDxCb3hcbiAgICAgIHN4PXt7XG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICBnYXA6IDEuNSxcbiAgICAgICAgbWluV2lkdGg6IDAsXG4gICAgICAgIGZsZXg6IDEsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgIGdhcDogMSxcbiAgICAgICAgICBwcjogMS41LFxuICAgICAgICAgIG1yOiAwLjUsXG4gICAgICAgICAgYm9yZGVyUmlnaHQ6IFwiMXB4IHNvbGlkXCIsXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IFwiZGl2aWRlclwiLFxuICAgICAgICAgIGZsZXhTaHJpbms6IDAsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxCb3hcbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgd2lkdGg6IDI4LFxuICAgICAgICAgICAgaGVpZ2h0OiAyOCxcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogMS41LFxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICBiZ2NvbG9yOiBcInByaW1hcnkubWFpblwiLFxuICAgICAgICAgICAgY29sb3I6IFwicHJpbWFyeS5jb250cmFzdFRleHRcIixcbiAgICAgICAgICAgIGZvbnRTaXplOiAxMyxcbiAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDgwMCxcbiAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiLTAuMDRlbVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICBFXG4gICAgICAgIDwvQm94PlxuICAgICAgICA8VHlwb2dyYXBoeVxuICAgICAgICAgIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIlxuICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICBmb250V2VpZ2h0OiA4MDAsXG4gICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIi0wLjAzZW1cIixcbiAgICAgICAgICAgIGNvbG9yOiBcInRleHQucHJpbWFyeVwiLFxuICAgICAgICAgICAgbGluZUhlaWdodDogMSxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgRWNvbW1lcmNlXG4gICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgIDwvQm94PlxuICAgICAgPFRpdGxlUG9ydGFsIC8+XG4gICAgPC9Cb3g+XG4gIDwvUmFBcHBCYXI+XG4pO1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvbGF5b3V0cy9BcHBCYXIudHN4In0=