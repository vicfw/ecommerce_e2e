import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/ExpandMore.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var ExpandMore_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"
}), "ExpandMore");

export {
  ExpandMore_default
};
//# sourceMappingURL=chunk-D56GOF3O.js.map
