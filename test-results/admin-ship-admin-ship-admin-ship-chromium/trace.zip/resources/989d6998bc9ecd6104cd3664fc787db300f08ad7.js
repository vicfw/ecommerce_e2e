import {
  setRef
} from "/node_modules/.vite/deps/chunk-QTIS3M7A.js?v=49ae7072";
import {
  activeElement,
  ownerDocument
} from "/node_modules/.vite/deps/chunk-AMU7WGDT.js?v=49ae7072";
import {
  useEventCallback_default,
  useForkRef
} from "/node_modules/.vite/deps/chunk-N6SJX73J.js?v=49ae7072";
import {
  useEnhancedEffect_default
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useRovingTabIndex/RovingTabIndexContext.mjs
var React = __toESM(require_react(), 1);
var RovingTabIndexContext = React.createContext(void 0);
if (true) {
  RovingTabIndexContext.displayName = "RovingTabIndexContext";
}
function useRovingTabIndexContext() {
  const context = React.useContext(RovingTabIndexContext);
  if (context === void 0) {
    throw new Error("MUI: RovingTabIndexContext is missing. Roving tab index items must be placed within a roving tab index provider.");
  }
  return context;
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useRovingTabIndex/useRovingTabIndex.mjs
var React2 = __toESM(require_react(), 1);

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/fastObjectShallowCompare/fastObjectShallowCompare.mjs
var is = Object.is;
function fastObjectShallowCompare(a, b) {
  if (a === b) {
    return true;
  }
  if (!(a instanceof Object) || !(b instanceof Object)) {
    return false;
  }
  let aLength = 0;
  let bLength = 0;
  for (const key in a) {
    aLength += 1;
    if (!is(a[key], b[key])) {
      return false;
    }
    if (!(key in b)) {
      return false;
    }
  }
  for (const _ in b) {
    bLength += 1;
  }
  return aLength === bLength;
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useRovingTabIndex/useRovingTabIndex.mjs
var SUPPORTED_KEYS = ["ArrowRight", "ArrowLeft", "ArrowUp", "ArrowDown", "Home", "End"];
function useRovingTabIndexRoot(params) {
  const {
    activeItemId: activeItemIdProp,
    getDefaultActiveItemId,
    orientation,
    isRtl = false,
    isItemFocusable: itemFilter = isItemFocusable,
    wrap = true
  } = params;
  const [activeItemIdState, setActiveItemIdState] = React2.useState(activeItemIdProp);
  const [previousActiveItemIdProp, setPreviousActiveItemIdProp] = React2.useState(activeItemIdProp);
  let activeItemIdCandidate = activeItemIdState;
  if (activeItemIdProp !== previousActiveItemIdProp) {
    setPreviousActiveItemIdProp(activeItemIdProp);
    if (activeItemIdProp !== void 0 && activeItemIdProp !== activeItemIdState) {
      activeItemIdCandidate = activeItemIdProp;
      setActiveItemIdState(activeItemIdProp);
    }
  }
  const containerRef = React2.useRef(null);
  const itemMapRef = React2.useRef(/* @__PURE__ */ new Map());
  const [mapTick, setMapTick] = React2.useState(0);
  const orderedItems = React2.useMemo(() => {
    void mapTick;
    return getOrderedItems(itemMapRef.current);
  }, [mapTick]);
  const resolvedActiveItemId = resolveActiveItemId(activeItemIdCandidate, orderedItems, itemFilter, getDefaultActiveItemId);
  const activeItemIdRef = React2.useRef(resolvedActiveItemId);
  activeItemIdRef.current = resolvedActiveItemId;
  const getActiveItem = React2.useCallback(() => {
    const snapshot = getOrderedItems(itemMapRef.current);
    const resolvedItemId = resolveActiveItemId(activeItemIdRef.current, snapshot, itemFilter, getDefaultActiveItemId);
    return getItemById(snapshot, resolvedItemId);
  }, [getDefaultActiveItemId, itemFilter]);
  const getItemMap = React2.useCallback(() => {
    return itemMapRef.current;
  }, []);
  const registerItem = useEventCallback_default((item) => {
    const previousItem = itemMapRef.current.get(item.id);
    if (fastObjectShallowCompare(previousItem ?? null, item)) {
      return;
    }
    itemMapRef.current.set(item.id, item);
    setMapTick((value) => value + 1);
  });
  const unregisterItem = useEventCallback_default((itemId) => {
    if (itemMapRef.current.delete(itemId)) {
      setMapTick((value) => value + 1);
    }
  });
  const setActiveItemId = useEventCallback_default((itemId) => {
    setActiveItemIdState(itemId);
  });
  const isItemActive = React2.useCallback((itemId) => {
    return activeItemIdRef.current === itemId;
  }, []);
  const focusItem = React2.useCallback((currentIndex, direction, wrap2, isItemFocusableOverride) => {
    const snapshot = getNavigableItemsSnapshot(itemMapRef.current);
    const nextItem = getNextActiveItem(snapshot, currentIndex, direction, wrap2, isItemFocusableOverride ?? itemFilter);
    if (!nextItem) {
      return null;
    }
    nextItem.element?.focus();
    setActiveItemIdState(nextItem.id);
    return nextItem;
  }, [itemFilter]);
  const getContainerProps = React2.useCallback((ref, onFocusProp, onKeyDownProp) => {
    const onFocus = (event) => {
      onFocusProp?.(event);
      const snapshot = getNavigableItemsSnapshot(itemMapRef.current);
      const focusedIndex = findItemIndexByElement(snapshot, event.target);
      if (focusedIndex !== -1) {
        setActiveItemIdState(snapshot[focusedIndex].id);
      }
    };
    const onKeyDown = (event) => {
      onKeyDownProp?.(event);
      if (event.defaultPrevented || event.altKey || event.shiftKey || event.ctrlKey || event.metaKey) {
        return;
      }
      if (!SUPPORTED_KEYS.includes(event.key)) {
        return;
      }
      let previousItemKey = orientation === "horizontal" ? "ArrowLeft" : "ArrowUp";
      let nextItemKey = orientation === "horizontal" ? "ArrowRight" : "ArrowDown";
      if (orientation === "horizontal" && isRtl) {
        previousItemKey = "ArrowRight";
        nextItemKey = "ArrowLeft";
      }
      const snapshot = getNavigableItemsSnapshot(itemMapRef.current);
      const currentFocus = activeElement(ownerDocument(containerRef.current));
      const isFocusOnContainer = currentFocus === containerRef.current;
      let currentIndex = getCurrentActiveItemIndex(snapshot, currentFocus, activeItemIdRef.current);
      let direction = "next";
      switch (event.key) {
        case previousItemKey:
          direction = "previous";
          event.preventDefault();
          if (isFocusOnContainer) {
            currentIndex = snapshot.length;
          }
          break;
        case nextItemKey:
          event.preventDefault();
          if (isFocusOnContainer) {
            currentIndex = -1;
          }
          break;
        case "Home":
          event.preventDefault();
          currentIndex = -1;
          break;
        case "End":
          event.preventDefault();
          direction = "previous";
          currentIndex = snapshot.length;
          break;
        default:
          return;
      }
      focusItem(currentIndex, direction, wrap);
    };
    return {
      onFocus,
      onKeyDown,
      ref: handleRefs(ref, (elementNode) => {
        containerRef.current = elementNode;
      })
    };
  }, [focusItem, isRtl, orientation, wrap]);
  const focusNext = React2.useCallback((isItemFocusableOverride) => {
    const snapshot = getNavigableItemsSnapshot(itemMapRef.current);
    const currentFocus = activeElement(ownerDocument(containerRef.current));
    const isFocusOnContainer = currentFocus === containerRef.current;
    const currentIndex = isFocusOnContainer ? -1 : getCurrentActiveItemIndex(snapshot, currentFocus, activeItemIdRef.current);
    return focusItem(currentIndex, "next", true, isItemFocusableOverride)?.id ?? null;
  }, [focusItem]);
  return React2.useMemo(() => ({
    activeItemId: resolvedActiveItemId,
    focusNext,
    getActiveItem,
    getContainerProps,
    getItemMap,
    isItemActive,
    registerItem,
    setActiveItemId,
    unregisterItem
  }), [resolvedActiveItemId, focusNext, getActiveItem, getContainerProps, getItemMap, isItemActive, registerItem, setActiveItemId, unregisterItem]);
}
function useRovingTabIndexItem(params) {
  const rootContext = useRovingTabIndexContext();
  const {
    activeItemId,
    registerItem,
    unregisterItem
  } = rootContext;
  const elementRef = React2.useRef(null);
  const item = React2.useMemo(() => ({
    disabled: params.disabled ?? false,
    element: null,
    focusableWhenDisabled: params.focusableWhenDisabled ?? false,
    id: params.id,
    selected: params.selected ?? false,
    textValue: params.textValue
  }), [params.disabled, params.focusableWhenDisabled, params.id, params.selected, params.textValue]);
  const latestItemRef = React2.useRef(item);
  latestItemRef.current = item;
  const handleElementRef = React2.useCallback((element) => {
    elementRef.current = element;
    if (element == null) {
      queueMicrotask(() => {
        if (elementRef.current == null) {
          unregisterItem(params.id);
        }
      });
      return;
    }
    registerItem({
      ...latestItemRef.current,
      element
    });
  }, [params.id, registerItem, unregisterItem]);
  const mergedRef = useForkRef(params.ref, handleElementRef);
  useEnhancedEffect_default(() => {
    if (!elementRef.current) {
      return;
    }
    registerItem({
      ...item,
      element: elementRef.current
    });
  }, [item, registerItem]);
  useEnhancedEffect_default(() => {
    const itemId = params.id;
    return () => {
      unregisterItem(itemId);
    };
  }, [params.id, unregisterItem]);
  return {
    ref: mergedRef,
    tabIndex: activeItemId === params.id ? 0 : -1
  };
}
function resolveActiveItemId(activeItemId, items, isFocusable, getDefaultActiveItemId) {
  if (activeItemId != null) {
    return resolveRequestedItemId(activeItemId, items, isFocusable);
  }
  return resolveDefaultItemId(items, isFocusable, getDefaultActiveItemId);
}
function resolveRequestedItemId(requestedItemId, items, isFocusable) {
  const requestedItemIndex = findItemIndexById(items, requestedItemId);
  if (requestedItemIndex === -1) {
    return getFirstFocusableItemId(items, isFocusable);
  }
  if (isFocusable(items[requestedItemIndex])) {
    return items[requestedItemIndex].id;
  }
  return getNextActiveItem(items, requestedItemIndex, "next", false, isFocusable)?.id ?? null;
}
function resolveDefaultItemId(items, isFocusable, getDefaultActiveItemId) {
  const defaultItemId = getDefaultActiveItemId?.(items);
  if (defaultItemId != null) {
    const defaultItem = getItemById(items, defaultItemId);
    if (defaultItem && isFocusable(defaultItem)) {
      return defaultItem.id;
    }
  }
  return getFirstFocusableItemId(items, isFocusable);
}
function getCurrentActiveItemIndex(items, currentFocus, fallbackActiveItemId) {
  if (currentFocus) {
    const focusedIndex = findItemIndexByElement(items, currentFocus);
    if (focusedIndex !== -1) {
      return focusedIndex;
    }
  }
  return findItemIndexById(items, fallbackActiveItemId);
}
function getNextActiveItem(items, currentIndex, direction, wrap, isFocusable) {
  const lastIndex = items.length - 1;
  if (lastIndex === -1) {
    return null;
  }
  let wrappedOnce = false;
  let nextIndex = getNextIndex(currentIndex, lastIndex, direction, wrap);
  const startIndex = nextIndex;
  while (nextIndex !== -1) {
    if (nextIndex === startIndex) {
      if (wrappedOnce) {
        return null;
      }
      wrappedOnce = true;
    }
    const nextItem = items[nextIndex];
    if (!nextItem || !isFocusable(nextItem)) {
      nextIndex = getNextIndex(nextIndex, lastIndex, direction, wrap);
    } else {
      return nextItem;
    }
  }
  return null;
}
function getFirstFocusableItemId(items, isFocusable) {
  return items.find((item) => isFocusable(item))?.id ?? null;
}
function getItemById(items, itemId) {
  return itemId == null ? null : items.find((item) => item.id === itemId) ?? null;
}
function findItemIndexById(items, itemId) {
  return itemId == null ? -1 : items.findIndex((item) => item.id === itemId);
}
function findItemIndexByElement(items, element) {
  if (!element) {
    return -1;
  }
  return items.findIndex((item) => item.element === element || item.element?.contains(element));
}
function getOrderedItems(itemMap) {
  const items = Array.from(itemMap.values());
  if (items.every((item) => item.element == null)) {
    return items;
  }
  const connectedItems = items.filter(isConnectedItem).sort((itemA, itemB) => sortByDocumentPosition(itemA.element, itemB.element));
  const disconnectedItems = items.filter((item) => !isConnectedItem(item));
  return [...connectedItems, ...disconnectedItems];
}
function getNavigableItemsSnapshot(itemMap) {
  return getOrderedItems(itemMap).filter(isConnectedItem);
}
function getNextIndex(currentIndex, lastIndex, direction, wrap = true) {
  if (direction === "next") {
    if (currentIndex === lastIndex) {
      return wrap ? 0 : -1;
    }
    return currentIndex + 1;
  }
  if (currentIndex === 0) {
    return wrap ? lastIndex : -1;
  }
  return currentIndex - 1;
}
function isItemFocusable(item) {
  if (!item.element) {
    return false;
  }
  if (item.focusableWhenDisabled) {
    return true;
  }
  return !item.disabled && !item.element.hasAttribute("disabled") && item.element.getAttribute("aria-disabled") !== "true" && item.element.hasAttribute("tabindex");
}
function isConnectedItem(item) {
  return item.element != null && item.element.isConnected;
}
function sortByDocumentPosition(a, b) {
  if (a === b) {
    return 0;
  }
  const position = a.compareDocumentPosition(b);
  if (position & Node.DOCUMENT_POSITION_FOLLOWING || position & Node.DOCUMENT_POSITION_CONTAINED_BY) {
    return -1;
  }
  if (position & Node.DOCUMENT_POSITION_PRECEDING || position & Node.DOCUMENT_POSITION_CONTAINS) {
    return 1;
  }
  return 0;
}
function handleRefs(...refs) {
  return (node) => {
    refs.forEach((ref) => {
      setRef(ref ?? null, node);
    });
  };
}

export {
  RovingTabIndexContext,
  useRovingTabIndexContext,
  useRovingTabIndexRoot,
  useRovingTabIndexItem,
  isItemFocusable
};
//# sourceMappingURL=chunk-O6Z2P3CO.js.map
