import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/categories/CategoryCreate.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import {
  Create,
  SaveButton,
  SimpleForm,
  Toolbar,
  useNotify,
  useRedirect
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import {
  createChildCategory,
  createMainCategory,
  createSubChildCategory
} from "/src/api/category/index.ts";
import { CategoryForm } from "/src/resources/categories/CategoryForm.tsx";
const CategoryCreateToolbar = () => /* @__PURE__ */ jsxDEV(Toolbar, { children: /* @__PURE__ */ jsxDEV(SaveButton, {}, void 0, false, {
  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx",
  lineNumber: 19,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx",
  lineNumber: 18,
  columnNumber: 1
}, this);
_c = CategoryCreateToolbar;
export const CategoryCreate = () => {
  _s();
  const notify = useNotify();
  const redirect = useRedirect();
  const handleSave = async (data, level) => {
    try {
      if (level === 1) {
        await createMainCategory(data);
      } else if (level === 2) {
        await createChildCategory(data);
      } else if (level === 3) {
        await createSubChildCategory(data);
      } else {
        notify("Please select a valid category level", { type: "error" });
        return;
      }
      notify("Category created successfully", { type: "success" });
      redirect("list", "category");
    } catch (error) {
      const message = error.response?.data?.message || "Error creating category";
      notify(message, { type: "error" });
      throw error;
    }
  };
  return /* @__PURE__ */ jsxDEV(Create, { children: /* @__PURE__ */ jsxDEV(
    SimpleForm,
    {
      onSubmit: (data) => handleSave(data, data.level),
      toolbar: /* @__PURE__ */ jsxDEV(CategoryCreateToolbar, {}, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx",
        lineNumber: 54,
        columnNumber: 18
      }, this),
      children: /* @__PURE__ */ jsxDEV(CategoryForm, { mode: "create" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx",
      lineNumber: 52,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
};
_s(CategoryCreate, "rEtWQPOqatleYFAFIOkn1JlaD2c=", false, function() {
  return [useNotify, useRedirect];
});
_c2 = CategoryCreate;
var _c, _c2;
$RefreshReg$(_c, "CategoryCreateToolbar");
$RefreshReg$(_c2, "CategoryCreate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryCreate.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JJOztBQWxCSjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyxvQkFBb0I7QUFFN0IsTUFBTUMsd0JBQXdCQSxNQUM1Qix1QkFBQyxXQUNDLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBVyxLQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQTtBQUNBQyxLQUpJRDtBQU1DLGFBQU1FLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU1DLFNBQVNWLFVBQVU7QUFDekIsUUFBTVcsV0FBV1YsWUFBWTtBQUU3QixRQUFNVyxhQUFhLE9BQU9DLE1BQTZCQyxVQUFrQjtBQUN2RSxRQUFJO0FBQ0YsVUFBSUEsVUFBVSxHQUFHO0FBQ2YsY0FBTVgsbUJBQW1CVSxJQUFJO0FBQUEsTUFDL0IsV0FBV0MsVUFBVSxHQUFHO0FBQ3RCLGNBQU1aLG9CQUFvQlcsSUFBSTtBQUFBLE1BQ2hDLFdBQVdDLFVBQVUsR0FBRztBQUN0QixjQUFNVix1QkFBdUJTLElBQUk7QUFBQSxNQUNuQyxPQUFPO0FBQ0xILGVBQU8sd0NBQXdDLEVBQUVLLE1BQU0sUUFBUSxDQUFDO0FBQ2hFO0FBQUEsTUFDRjtBQUVBTCxhQUFPLGlDQUFpQyxFQUFFSyxNQUFNLFVBQVUsQ0FBQztBQUMzREosZUFBUyxRQUFRLFVBQVU7QUFBQSxJQUM3QixTQUFTSyxPQUFZO0FBQ25CLFlBQU1DLFVBQ0pELE1BQU1FLFVBQVVMLE1BQU1JLFdBQVc7QUFDbkNQLGFBQU9PLFNBQVMsRUFBRUYsTUFBTSxRQUFRLENBQUM7QUFDakMsWUFBTUM7QUFBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFVBQ0M7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFVBQVUsQ0FBQ0gsU0FBY0QsV0FBV0MsTUFBTUEsS0FBS0MsS0FBSztBQUFBLE1BQ3BELFNBQVMsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQjtBQUFBLE1BRS9CLGlDQUFDLGdCQUFhLE1BQUssWUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBO0FBQUEsSUFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFFTCxHQXJDV0QsZ0JBQWM7QUFBQSxVQUNWUixXQUNFQyxXQUFXO0FBQUE7QUFBQSxNQUZqQk87QUFBYyxJQUFBRCxJQUFBWTtBQUFBLGFBQUFaLElBQUE7QUFBQSxhQUFBWSxLQUFBIiwibmFtZXMiOlsiQ3JlYXRlIiwiU2F2ZUJ1dHRvbiIsIlNpbXBsZUZvcm0iLCJUb29sYmFyIiwidXNlTm90aWZ5IiwidXNlUmVkaXJlY3QiLCJjcmVhdGVDaGlsZENhdGVnb3J5IiwiY3JlYXRlTWFpbkNhdGVnb3J5IiwiY3JlYXRlU3ViQ2hpbGRDYXRlZ29yeSIsIkNhdGVnb3J5Rm9ybSIsIkNhdGVnb3J5Q3JlYXRlVG9vbGJhciIsIl9jIiwiQ2F0ZWdvcnlDcmVhdGUiLCJfcyIsIm5vdGlmeSIsInJlZGlyZWN0IiwiaGFuZGxlU2F2ZSIsImRhdGEiLCJsZXZlbCIsInR5cGUiLCJlcnJvciIsIm1lc3NhZ2UiLCJyZXNwb25zZSIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXRlZ29yeUNyZWF0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ3JlYXRlLFxuICBTYXZlQnV0dG9uLFxuICBTaW1wbGVGb3JtLFxuICBUb29sYmFyLFxuICB1c2VOb3RpZnksXG4gIHVzZVJlZGlyZWN0LFxufSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCB7XG4gIGNyZWF0ZUNoaWxkQ2F0ZWdvcnksXG4gIGNyZWF0ZU1haW5DYXRlZ29yeSxcbiAgY3JlYXRlU3ViQ2hpbGRDYXRlZ29yeSxcbn0gZnJvbSBcIi4uLy4uL2FwaS9jYXRlZ29yeVwiO1xuaW1wb3J0IHR5cGUgeyBDcmVhdGVDYXRlZ29yeVBheWxvYWQgfSBmcm9tIFwiLi4vLi4vYXBpL2NhdGVnb3J5L3R5cGVzXCI7XG5pbXBvcnQgeyBDYXRlZ29yeUZvcm0gfSBmcm9tIFwiLi9DYXRlZ29yeUZvcm1cIjtcblxuY29uc3QgQ2F0ZWdvcnlDcmVhdGVUb29sYmFyID0gKCkgPT4gKFxuICA8VG9vbGJhcj5cbiAgICA8U2F2ZUJ1dHRvbiAvPlxuICA8L1Rvb2xiYXI+XG4pO1xuXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnlDcmVhdGUgPSAoKSA9PiB7XG4gIGNvbnN0IG5vdGlmeSA9IHVzZU5vdGlmeSgpO1xuICBjb25zdCByZWRpcmVjdCA9IHVzZVJlZGlyZWN0KCk7XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChkYXRhOiBDcmVhdGVDYXRlZ29yeVBheWxvYWQsIGxldmVsOiBudW1iZXIpID0+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKGxldmVsID09PSAxKSB7XG4gICAgICAgIGF3YWl0IGNyZWF0ZU1haW5DYXRlZ29yeShkYXRhKTtcbiAgICAgIH0gZWxzZSBpZiAobGV2ZWwgPT09IDIpIHtcbiAgICAgICAgYXdhaXQgY3JlYXRlQ2hpbGRDYXRlZ29yeShkYXRhKTtcbiAgICAgIH0gZWxzZSBpZiAobGV2ZWwgPT09IDMpIHtcbiAgICAgICAgYXdhaXQgY3JlYXRlU3ViQ2hpbGRDYXRlZ29yeShkYXRhKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5vdGlmeShcIlBsZWFzZSBzZWxlY3QgYSB2YWxpZCBjYXRlZ29yeSBsZXZlbFwiLCB7IHR5cGU6IFwiZXJyb3JcIiB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBub3RpZnkoXCJDYXRlZ29yeSBjcmVhdGVkIHN1Y2Nlc3NmdWxseVwiLCB7IHR5cGU6IFwic3VjY2Vzc1wiIH0pO1xuICAgICAgcmVkaXJlY3QoXCJsaXN0XCIsIFwiY2F0ZWdvcnlcIik7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRXJyb3IgY3JlYXRpbmcgY2F0ZWdvcnlcIjtcbiAgICAgIG5vdGlmeShtZXNzYWdlLCB7IHR5cGU6IFwiZXJyb3JcIiB9KTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxDcmVhdGU+XG4gICAgICA8U2ltcGxlRm9ybVxuICAgICAgICBvblN1Ym1pdD17KGRhdGE6IGFueSkgPT4gaGFuZGxlU2F2ZShkYXRhLCBkYXRhLmxldmVsKX1cbiAgICAgICAgdG9vbGJhcj17PENhdGVnb3J5Q3JlYXRlVG9vbGJhciAvPn1cbiAgICAgID5cbiAgICAgICAgPENhdGVnb3J5Rm9ybSBtb2RlPVwiY3JlYXRlXCIgLz5cbiAgICAgIDwvU2ltcGxlRm9ybT5cbiAgICA8L0NyZWF0ZT5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9yZXNvdXJjZXMvY2F0ZWdvcmllcy9DYXRlZ29yeUNyZWF0ZS50c3gifQ==