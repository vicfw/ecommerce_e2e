import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/categories/CategoryEdit.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Edit, SimpleForm } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { CategoryForm } from "/src/resources/categories/CategoryForm.tsx";
export const CategoryEdit = () => {
  return /* @__PURE__ */ jsxDEV(Edit, { mutationMode: "pessimistic", redirect: "list", children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(CategoryForm, { mode: "edit" }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryEdit.tsx",
    lineNumber: 8,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryEdit.tsx",
    lineNumber: 7,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryEdit.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
};
_c = CategoryEdit;
var _c;
$RefreshReg$(_c, "CategoryEdit");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryEdit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryEdit.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/categories/CategoryEdit.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixTQUFTQSxNQUFNQyxrQkFBa0I7QUFDakMsU0FBU0Msb0JBQW9CO0FBRXRCLGFBQU1DLGVBQWVBLE1BQU07QUFDaEMsU0FDRSx1QkFBQyxRQUFLLGNBQWEsZUFBYyxVQUFTLFFBQ3hDLGlDQUFDLGNBQ0MsaUNBQUMsZ0JBQWEsTUFBSyxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUVDLEtBUldEO0FBQVksSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRWRpdCIsIlNpbXBsZUZvcm0iLCJDYXRlZ29yeUZvcm0iLCJDYXRlZ29yeUVkaXQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXRlZ29yeUVkaXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVkaXQsIFNpbXBsZUZvcm0gfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCB7IENhdGVnb3J5Rm9ybSB9IGZyb20gXCIuL0NhdGVnb3J5Rm9ybVwiO1xuXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnlFZGl0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxFZGl0IG11dGF0aW9uTW9kZT1cInBlc3NpbWlzdGljXCIgcmVkaXJlY3Q9XCJsaXN0XCI+XG4gICAgICA8U2ltcGxlRm9ybT5cbiAgICAgICAgPENhdGVnb3J5Rm9ybSBtb2RlPVwiZWRpdFwiIC8+XG4gICAgICA8L1NpbXBsZUZvcm0+XG4gICAgPC9FZGl0PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9jYXRlZ29yaWVzL0NhdGVnb3J5RWRpdC50c3gifQ==