import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Dashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
import Chip from "/node_modules/.vite/deps/@mui_material_Chip.js?v=49ae7072";
import Table from "/node_modules/.vite/deps/@mui_material_Table.js?v=49ae7072";
import TableBody from "/node_modules/.vite/deps/@mui_material_TableBody.js?v=49ae7072";
import TableCell from "/node_modules/.vite/deps/@mui_material_TableCell.js?v=49ae7072";
import TableHead from "/node_modules/.vite/deps/@mui_material_TableHead.js?v=49ae7072";
import TableRow from "/node_modules/.vite/deps/@mui_material_TableRow.js?v=49ae7072";
import Button from "/node_modules/.vite/deps/@mui_material_Button.js?v=49ae7072";
import __vite__cjsImport10_react from "/node_modules/.vite/deps/react.js?v=49ae7072"; const useEffect = __vite__cjsImport10_react["useEffect"]; const useState = __vite__cjsImport10_react["useState"];
import { Title, useNotify } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=49ae7072";
import { getDashboardStats } from "/src/api/admin/index.ts";
const StatCard = ({
  label,
  value
}) => /* @__PURE__ */ jsxDEV(
  Box,
  {
    sx: {
      p: 2.5,
      borderRadius: 2,
      border: "1px solid",
      borderColor: "divider",
      bgcolor: "background.paper",
      flex: 1,
      minWidth: 160
    },
    children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", gutterBottom: true, children: label }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 33,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h4", sx: { fontWeight: 800 }, children: value }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 36,
        columnNumber: 5
      }, this)
    ]
  },
  void 0,
  true,
  {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
    lineNumber: 22,
    columnNumber: 1
  },
  this
);
_c = StatCard;
export const Dashboard = () => {
  _s();
  const notify = useNotify();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    getDashboardStats().then(setStats).catch(() => notify("Failed to load dashboard", { type: "error" })).finally(() => setLoading(false));
  }, [notify]);
  if (loading) {
    return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3 }, children: [
      /* @__PURE__ */ jsxDEV(Title, { title: "Dashboard" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { children: "Loading..." }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this);
  }
  if (!stats) {
    return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3 }, children: [
      /* @__PURE__ */ jsxDEV(Title, { title: "Dashboard" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", children: "No data available" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 68,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3, display: "flex", flexDirection: "column", gap: 3 }, children: [
    /* @__PURE__ */ jsxDEV(Title, { title: "Dashboard" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 75,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", sx: { fontWeight: 800 }, children: "Overview" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          display: "flex",
          flexWrap: "wrap",
          gap: 2
        },
        children: [
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Total Orders", value: stats.totalOrders }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 88,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              label: "Total Revenue",
              value: stats.totalRevenue.toLocaleString()
            },
            void 0,
            false,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 89,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Total Users", value: stats.totalUsers }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 93,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Pending Reviews", value: stats.pendingComments }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 94,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 81,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700, mb: 1.5 }, children: "Orders by Status" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 98,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 1 }, children: Object.entries(stats.ordersByStatus).map(
        ([status, count]) => /* @__PURE__ */ jsxDEV(Chip, { label: `${status}: ${count}`, size: "small" }, status, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 103,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 101,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700, mb: 1.5 }, children: "Low Stock Products" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 109,
        columnNumber: 9
      }, this),
      stats.lowStockProducts.length === 0 ? /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "All products are well stocked" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 113,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(Table, { size: "small", children: [
        /* @__PURE__ */ jsxDEV(TableHead, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { children: "Product" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 120,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Available" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 121,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Reserved" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 122,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Action" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 123,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 119,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 118,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableBody, { children: stats.lowStockProducts.map(
          (product) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableCell, { children: product.prName }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 129,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: product.quantity }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 130,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: product.reservedQuantity ?? 0 }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 131,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "small",
                onClick: () => navigate(`/product/${product.id}`),
                children: "Edit"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
                lineNumber: 135,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 134,
              columnNumber: 19
            }, this)
          ] }, product.id, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 128,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 126,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", sx: { fontWeight: 700, mb: 1.5 }, children: "Recent Orders" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Table, { size: "small", children: [
        /* @__PURE__ */ jsxDEV(TableHead, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { children: "ID" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 156,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: "Customer" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 157,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: "Status" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 158,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Total" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 159,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: "Date" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 160,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: "Action" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 161,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 155,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 154,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TableBody, { children: stats.recentOrders.map(
          (order) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableCell, { children: order.id }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 167,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { children: [order.user?.name, order.user?.lastName].filter(Boolean).join(" ") || order.user?.phoneNumber || "-" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 168,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Chip, { label: order.status, size: "small" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 176,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 175,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: order.totalAmount.toLocaleString() }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 178,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { children: new Date(order.createdAt).toLocaleDateString() }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 181,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { align: "right", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "small",
                onClick: () => navigate(`/order/${order.id}/show`),
                children: "View"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
                lineNumber: 185,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
              lineNumber: 184,
              columnNumber: 17
            }, this)
          ] }, order.id, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
            lineNumber: 166,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
          lineNumber: 164,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
        lineNumber: 153,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
      lineNumber: 149,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx",
    lineNumber: 74,
    columnNumber: 5
  }, this);
};
_s(Dashboard, "eBWAmeATcBOV4UZpX5KlYQwwaSA=", false, function() {
  return [useNotify, useNavigate];
});
_c2 = Dashboard;
var _c, _c2;
$RefreshReg$(_c, "StatCard");
$RefreshReg$(_c2, "Dashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/pages/Dashboard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NJOztBQWhDSixPQUFPQSxTQUFTO0FBQ2hCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxPQUFPQyxpQkFBaUI7QUFDakMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUE4QztBQUV2RCxNQUFNQyxXQUFXQSxDQUFDO0FBQUEsRUFDaEJDO0FBQUFBLEVBQ0FDO0FBSUYsTUFDRTtBQUFBLEVBQUM7QUFBQTtBQUFBLElBQ0MsSUFBSTtBQUFBLE1BQ0ZDLEdBQUc7QUFBQSxNQUNIQyxjQUFjO0FBQUEsTUFDZEMsUUFBUTtBQUFBLE1BQ1JDLGFBQWE7QUFBQSxNQUNiQyxTQUFTO0FBQUEsTUFDVEMsTUFBTTtBQUFBLE1BQ05DLFVBQVU7QUFBQSxJQUNaO0FBQUEsSUFFQTtBQUFBLDZCQUFDLGNBQVcsU0FBUSxTQUFRLE9BQU0sa0JBQWlCLGNBQVksTUFDNURSLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFUyxZQUFZLElBQUksR0FDNUNSLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBO0FBQUE7QUFBQSxFQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaUJBO0FBQ0FTLEtBekJJWDtBQTJCQyxhQUFNWSxZQUFZQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTUMsU0FBU2pCLFVBQVU7QUFDekIsUUFBTWtCLFdBQVdqQixZQUFZO0FBQzdCLFFBQU0sQ0FBQ2tCLE9BQU9DLFFBQVEsSUFBSXRCLFNBQWdDLElBQUk7QUFDOUQsUUFBTSxDQUFDdUIsU0FBU0MsVUFBVSxJQUFJeEIsU0FBUyxJQUFJO0FBRTNDRCxZQUFVLE1BQU07QUFDZEssc0JBQWtCLEVBQ2ZxQixLQUFLSCxRQUFRLEVBQ2JJLE1BQU0sTUFBTVAsT0FBTyw0QkFBNEIsRUFBRVEsTUFBTSxRQUFRLENBQUMsQ0FBQyxFQUNqRUMsUUFBUSxNQUFNSixXQUFXLEtBQUssQ0FBQztBQUFBLEVBQ3BDLEdBQUcsQ0FBQ0wsTUFBTSxDQUFDO0FBRVgsTUFBSUksU0FBUztBQUNYLFdBQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVmLEdBQUcsRUFBRSxHQUNkO0FBQUEsNkJBQUMsU0FBTSxPQUFNLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLGNBQVcsMEJBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQjtBQUFBLFNBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLEVBRUo7QUFFQSxNQUFJLENBQUNhLE9BQU87QUFDVixXQUNFLHVCQUFDLE9BQUksSUFBSSxFQUFFYixHQUFHLEVBQUUsR0FDZDtBQUFBLDZCQUFDLFNBQU0sT0FBTSxlQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxjQUFXLE9BQU0sa0JBQWlCLGlDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9EO0FBQUEsU0FGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVBLEdBQUcsR0FBR3FCLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLEVBQUUsR0FDaEU7QUFBQSwyQkFBQyxTQUFNLE9BQU0sZUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFFeEIsdUJBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFaEIsWUFBWSxJQUFJLEdBQUUsd0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUk7QUFBQSxVQUNGYyxTQUFTO0FBQUEsVUFDVEcsVUFBVTtBQUFBLFVBQ1ZELEtBQUs7QUFBQSxRQUNQO0FBQUEsUUFFQTtBQUFBLGlDQUFDLFlBQVMsT0FBTSxnQkFBZSxPQUFPVixNQUFNWSxlQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPWixNQUFNYSxhQUFhQyxlQUFlO0FBQUE7QUFBQSxZQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFNkM7QUFBQSxVQUU3Qyx1QkFBQyxZQUFTLE9BQU0sZUFBYyxPQUFPZCxNQUFNZSxjQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3RELHVCQUFDLFlBQVMsT0FBTSxtQkFBa0IsT0FBT2YsTUFBTWdCLG1CQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBO0FBQUE7QUFBQSxNQWJqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQTtBQUFBLElBRUEsdUJBQUMsT0FDQztBQUFBLDZCQUFDLGNBQVcsU0FBUSxNQUFLLElBQUksRUFBRXRCLFlBQVksS0FBS3VCLElBQUksSUFBSSxHQUFFLGdDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFVCxTQUFTLFFBQVFHLFVBQVUsUUFBUUQsS0FBSyxFQUFFLEdBQ2xEUSxpQkFBT0MsUUFBUW5CLE1BQU1vQixjQUFjLEVBQUVDO0FBQUFBLFFBQUksQ0FBQyxDQUFDQyxRQUFRQyxLQUFLLE1BQ3ZELHVCQUFDLFFBQWtCLE9BQU8sR0FBR0QsTUFBTSxLQUFLQyxLQUFLLElBQUksTUFBSyxXQUEzQ0QsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsTUFDOUQsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUEsdUJBQUMsT0FDQztBQUFBLDZCQUFDLGNBQVcsU0FBUSxNQUFLLElBQUksRUFBRTVCLFlBQVksS0FBS3VCLElBQUksSUFBSSxHQUFFLGtDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDakIsTUFBTXdCLGlCQUFpQkMsV0FBVyxJQUNqQyx1QkFBQyxjQUFXLFNBQVEsU0FBUSxPQUFNLGtCQUFnQiw2Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBTSxNQUFLLFNBQ1Y7QUFBQSwrQkFBQyxhQUNDLGlDQUFDLFlBQ0M7QUFBQSxpQ0FBQyxhQUFVLHVCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFDbEIsdUJBQUMsYUFBVSxPQUFNLFNBQVEseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsVUFDbEMsdUJBQUMsYUFBVSxPQUFNLFNBQVEsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFDakMsdUJBQUMsYUFBVSxPQUFNLFNBQVEsc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsYUFKakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxhQUNFekIsZ0JBQU13QixpQkFBaUJIO0FBQUFBLFVBQUksQ0FBQ0ssWUFDM0IsdUJBQUMsWUFDQztBQUFBLG1DQUFDLGFBQVdBLGtCQUFRQyxVQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQzNCLHVCQUFDLGFBQVUsT0FBTSxTQUFTRCxrQkFBUUUsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkM7QUFBQSxZQUMzQyx1QkFBQyxhQUFVLE9BQU0sU0FDZEYsa0JBQVFHLG9CQUFvQixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxhQUFVLE9BQU0sU0FDZjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU05QixTQUFTLFlBQVkyQixRQUFRSSxFQUFFLEVBQUU7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFiYUosUUFBUUksSUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFFBQ0QsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxTQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBO0FBQUEsSUFFQSx1QkFBQyxPQUNDO0FBQUEsNkJBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFcEMsWUFBWSxLQUFLdUIsSUFBSSxJQUFJLEdBQUUsNkJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxNQUFLLFNBQ1Y7QUFBQSwrQkFBQyxhQUNDLGlDQUFDLFlBQ0M7QUFBQSxpQ0FBQyxhQUFVLGtCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWE7QUFBQSxVQUNiLHVCQUFDLGFBQVUsd0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNuQix1QkFBQyxhQUFVLHNCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFDakIsdUJBQUMsYUFBVSxPQUFNLFNBQVEscUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsYUFBVSxvQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFDZix1QkFBQyxhQUFVLE9BQU0sU0FBUSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0I7QUFBQSxhQU5qQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLGFBQ0VqQixnQkFBTStCLGFBQWFWO0FBQUFBLFVBQUksQ0FBQ1csVUFDdkIsdUJBQUMsWUFDQztBQUFBLG1DQUFDLGFBQVdBLGdCQUFNRixNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLFlBQ3JCLHVCQUFDLGFBQ0UsV0FBQ0UsTUFBTUMsTUFBTUMsTUFBTUYsTUFBTUMsTUFBTUUsUUFBUSxFQUNyQ0MsT0FBT0MsT0FBTyxFQUNkQyxLQUFLLEdBQUcsS0FDVE4sTUFBTUMsTUFBTU0sZUFDWixPQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBLHVCQUFDLGFBQ0MsaUNBQUMsUUFBSyxPQUFPUCxNQUFNVixRQUFRLE1BQUssV0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxPQUFNLFNBQ2RVLGdCQUFNUSxZQUFZMUIsZUFBZSxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxhQUNFLGNBQUkyQixLQUFLVCxNQUFNVSxTQUFTLEVBQUVDLG1CQUFtQixLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxhQUFVLE9BQU0sU0FDZjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU01QyxTQUFTLFVBQVVpQyxNQUFNRixFQUFFLE9BQU87QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUF6QmFFLE1BQU1GLElBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsUUFDRCxLQTdCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsV0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBDQTtBQUFBLFNBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQ0E7QUFBQSxPQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkhBO0FBRUo7QUFBRWpDLEdBN0pXRCxXQUFTO0FBQUEsVUFDTGYsV0FDRUMsV0FBVztBQUFBO0FBQUEsTUFGakJjO0FBQVMsSUFBQUQsSUFBQWlEO0FBQUEsYUFBQWpELElBQUE7QUFBQSxhQUFBaUQsS0FBQSIsIm5hbWVzIjpbIkJveCIsIlR5cG9ncmFwaHkiLCJDaGlwIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUNlbGwiLCJUYWJsZUhlYWQiLCJUYWJsZVJvdyIsIkJ1dHRvbiIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVGl0bGUiLCJ1c2VOb3RpZnkiLCJ1c2VOYXZpZ2F0ZSIsImdldERhc2hib2FyZFN0YXRzIiwiU3RhdENhcmQiLCJsYWJlbCIsInZhbHVlIiwicCIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsImJvcmRlckNvbG9yIiwiYmdjb2xvciIsImZsZXgiLCJtaW5XaWR0aCIsImZvbnRXZWlnaHQiLCJfYyIsIkRhc2hib2FyZCIsIl9zIiwibm90aWZ5IiwibmF2aWdhdGUiLCJzdGF0cyIsInNldFN0YXRzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ0aGVuIiwiY2F0Y2giLCJ0eXBlIiwiZmluYWxseSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiZmxleFdyYXAiLCJ0b3RhbE9yZGVycyIsInRvdGFsUmV2ZW51ZSIsInRvTG9jYWxlU3RyaW5nIiwidG90YWxVc2VycyIsInBlbmRpbmdDb21tZW50cyIsIm1iIiwiT2JqZWN0IiwiZW50cmllcyIsIm9yZGVyc0J5U3RhdHVzIiwibWFwIiwic3RhdHVzIiwiY291bnQiLCJsb3dTdG9ja1Byb2R1Y3RzIiwibGVuZ3RoIiwicHJvZHVjdCIsInByTmFtZSIsInF1YW50aXR5IiwicmVzZXJ2ZWRRdWFudGl0eSIsImlkIiwicmVjZW50T3JkZXJzIiwib3JkZXIiLCJ1c2VyIiwibmFtZSIsImxhc3ROYW1lIiwiZmlsdGVyIiwiQm9vbGVhbiIsImpvaW4iLCJwaG9uZU51bWJlciIsInRvdGFsQW1vdW50IiwiRGF0ZSIsImNyZWF0ZWRBdCIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBCb3ggZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQm94XCI7XG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UeXBvZ3JhcGh5XCI7XG5pbXBvcnQgQ2hpcCBmcm9tIFwiQG11aS9tYXRlcmlhbC9DaGlwXCI7XG5pbXBvcnQgVGFibGUgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFibGVcIjtcbmltcG9ydCBUYWJsZUJvZHkgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFibGVCb2R5XCI7XG5pbXBvcnQgVGFibGVDZWxsIGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYmxlQ2VsbFwiO1xuaW1wb3J0IFRhYmxlSGVhZCBmcm9tIFwiQG11aS9tYXRlcmlhbC9UYWJsZUhlYWRcIjtcbmltcG9ydCBUYWJsZVJvdyBmcm9tIFwiQG11aS9tYXRlcmlhbC9UYWJsZVJvd1wiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiQG11aS9tYXRlcmlhbC9CdXR0b25cIjtcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFRpdGxlLCB1c2VOb3RpZnkgfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IGdldERhc2hib2FyZFN0YXRzLCB0eXBlIERhc2hib2FyZFN0YXRzIH0gZnJvbSBcIi4uL2FwaS9hZG1pblwiO1xuXG5jb25zdCBTdGF0Q2FyZCA9ICh7XG4gIGxhYmVsLFxuICB2YWx1ZSxcbn06IHtcbiAgbGFiZWw6IHN0cmluZztcbiAgdmFsdWU6IHN0cmluZyB8IG51bWJlcjtcbn0pID0+IChcbiAgPEJveFxuICAgIHN4PXt7XG4gICAgICBwOiAyLjUsXG4gICAgICBib3JkZXJSYWRpdXM6IDIsXG4gICAgICBib3JkZXI6IFwiMXB4IHNvbGlkXCIsXG4gICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICBiZ2NvbG9yOiBcImJhY2tncm91bmQucGFwZXJcIixcbiAgICAgIGZsZXg6IDEsXG4gICAgICBtaW5XaWR0aDogMTYwLFxuICAgIH19XG4gID5cbiAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgZ3V0dGVyQm90dG9tPlxuICAgICAge2xhYmVsfVxuICAgIDwvVHlwb2dyYXBoeT5cbiAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDRcIiBzeD17eyBmb250V2VpZ2h0OiA4MDAgfX0+XG4gICAgICB7dmFsdWV9XG4gICAgPC9UeXBvZ3JhcGh5PlxuICA8L0JveD5cbik7XG5cbmV4cG9ydCBjb25zdCBEYXNoYm9hcmQgPSAoKSA9PiB7XG4gIGNvbnN0IG5vdGlmeSA9IHVzZU5vdGlmeSgpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IFtzdGF0cywgc2V0U3RhdHNdID0gdXNlU3RhdGU8RGFzaGJvYXJkU3RhdHMgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBnZXREYXNoYm9hcmRTdGF0cygpXG4gICAgICAudGhlbihzZXRTdGF0cylcbiAgICAgIC5jYXRjaCgoKSA9PiBub3RpZnkoXCJGYWlsZWQgdG8gbG9hZCBkYXNoYm9hcmRcIiwgeyB0eXBlOiBcImVycm9yXCIgfSkpXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSk7XG4gIH0sIFtub3RpZnldKTtcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8Qm94IHN4PXt7IHA6IDMgfX0+XG4gICAgICAgIDxUaXRsZSB0aXRsZT1cIkRhc2hib2FyZFwiIC8+XG4gICAgICAgIDxUeXBvZ3JhcGh5PkxvYWRpbmcuLi48L1R5cG9ncmFwaHk+XG4gICAgICA8L0JveD5cbiAgICApO1xuICB9XG5cbiAgaWYgKCFzdGF0cykge1xuICAgIHJldHVybiAoXG4gICAgICA8Qm94IHN4PXt7IHA6IDMgfX0+XG4gICAgICAgIDxUaXRsZSB0aXRsZT1cIkRhc2hib2FyZFwiIC8+XG4gICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5ObyBkYXRhIGF2YWlsYWJsZTwvVHlwb2dyYXBoeT5cbiAgICAgIDwvQm94PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxCb3ggc3g9e3sgcDogMywgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMyB9fT5cbiAgICAgIDxUaXRsZSB0aXRsZT1cIkRhc2hib2FyZFwiIC8+XG5cbiAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiIHN4PXt7IGZvbnRXZWlnaHQ6IDgwMCB9fT5cbiAgICAgICAgT3ZlcnZpZXdcbiAgICAgIDwvVHlwb2dyYXBoeT5cblxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICBnYXA6IDIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlRvdGFsIE9yZGVyc1wiIHZhbHVlPXtzdGF0cy50b3RhbE9yZGVyc30gLz5cbiAgICAgICAgPFN0YXRDYXJkXG4gICAgICAgICAgbGFiZWw9XCJUb3RhbCBSZXZlbnVlXCJcbiAgICAgICAgICB2YWx1ZT17c3RhdHMudG90YWxSZXZlbnVlLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgIC8+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlRvdGFsIFVzZXJzXCIgdmFsdWU9e3N0YXRzLnRvdGFsVXNlcnN9IC8+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlBlbmRpbmcgUmV2aWV3c1wiIHZhbHVlPXtzdGF0cy5wZW5kaW5nQ29tbWVudHN9IC8+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveD5cbiAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgc3g9e3sgZm9udFdlaWdodDogNzAwLCBtYjogMS41IH19PlxuICAgICAgICAgIE9yZGVycyBieSBTdGF0dXNcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICA8Qm94IHN4PXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4V3JhcDogXCJ3cmFwXCIsIGdhcDogMSB9fT5cbiAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoc3RhdHMub3JkZXJzQnlTdGF0dXMpLm1hcCgoW3N0YXR1cywgY291bnRdKSA9PiAoXG4gICAgICAgICAgICA8Q2hpcCBrZXk9e3N0YXR1c30gbGFiZWw9e2Ake3N0YXR1c306ICR7Y291bnR9YH0gc2l6ZT1cInNtYWxsXCIgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveD5cbiAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgc3g9e3sgZm9udFdlaWdodDogNzAwLCBtYjogMS41IH19PlxuICAgICAgICAgIExvdyBTdG9jayBQcm9kdWN0c1xuICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgIHtzdGF0cy5sb3dTdG9ja1Byb2R1Y3RzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICBBbGwgcHJvZHVjdHMgYXJlIHdlbGwgc3RvY2tlZFxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8VGFibGUgc2l6ZT1cInNtYWxsXCI+XG4gICAgICAgICAgICA8VGFibGVIZWFkPlxuICAgICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5Qcm9kdWN0PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+QXZhaWxhYmxlPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+UmVzZXJ2ZWQ8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGFsaWduPVwicmlnaHRcIj5BY3Rpb248L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICAgIDwvVGFibGVIZWFkPlxuICAgICAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICAgICAge3N0YXRzLmxvd1N0b2NrUHJvZHVjdHMubWFwKChwcm9kdWN0KSA9PiAoXG4gICAgICAgICAgICAgICAgPFRhYmxlUm93IGtleT17cHJvZHVjdC5pZH0+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPntwcm9kdWN0LnByTmFtZX08L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgYWxpZ249XCJyaWdodFwiPntwcm9kdWN0LnF1YW50aXR5fTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9kdWN0LnJlc2VydmVkUXVhbnRpdHkgPz8gMH1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YCl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBFZGl0XG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L1RhYmxlQm9keT5cbiAgICAgICAgICA8L1RhYmxlPlxuICAgICAgICApfVxuICAgICAgPC9Cb3g+XG5cbiAgICAgIDxCb3g+XG4gICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNlwiIHN4PXt7IGZvbnRXZWlnaHQ6IDcwMCwgbWI6IDEuNSB9fT5cbiAgICAgICAgICBSZWNlbnQgT3JkZXJzXG4gICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgPFRhYmxlIHNpemU9XCJzbWFsbFwiPlxuICAgICAgICAgIDxUYWJsZUhlYWQ+XG4gICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGw+SUQ8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5DdXN0b21lcjwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8VGFibGVDZWxsPlN0YXR1czwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8VGFibGVDZWxsIGFsaWduPVwicmlnaHRcIj5Ub3RhbDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8VGFibGVDZWxsPkRhdGU8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBhbGlnbj1cInJpZ2h0XCI+QWN0aW9uPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgIDwvVGFibGVIZWFkPlxuICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICB7c3RhdHMucmVjZW50T3JkZXJzLm1hcCgob3JkZXIpID0+IChcbiAgICAgICAgICAgICAgPFRhYmxlUm93IGtleT17b3JkZXIuaWR9PlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+e29yZGVyLmlkfTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICB7W29yZGVyLnVzZXI/Lm5hbWUsIG9yZGVyLnVzZXI/Lmxhc3ROYW1lXVxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgICAgICAgICAgICAgICAgIC5qb2luKFwiIFwiKSB8fFxuICAgICAgICAgICAgICAgICAgICBvcmRlci51c2VyPy5waG9uZU51bWJlciB8fFxuICAgICAgICAgICAgICAgICAgICBcIi1cIn1cbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPENoaXAgbGFiZWw9e29yZGVyLnN0YXR1c30gc2l6ZT1cInNtYWxsXCIgLz5cbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGFsaWduPVwicmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgIHtvcmRlci50b3RhbEFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICB7bmV3IERhdGUob3JkZXIuY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGFsaWduPVwicmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9vcmRlci8ke29yZGVyLmlkfS9zaG93YCl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFZpZXdcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgIDwvVGFibGU+XG4gICAgICA8L0JveD5cbiAgICA8L0JveD5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9wYWdlcy9EYXNoYm9hcmQudHN4In0=