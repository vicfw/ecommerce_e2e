import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/products/ProductEdit.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Edit, SimpleForm, useRecordContext } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { ProductForm } from "/src/resources/products/ProductForm.tsx";
import {
  normalizeProductRecord,
  transformProductData
} from "/src/resources/products/productTransform.ts";
const ProductEditForm = () => {
  _s();
  const record = useRecordContext();
  if (!record) return null;
  const formRecord = normalizeProductRecord(record);
  return /* @__PURE__ */ jsxDEV(SimpleForm, { record: formRecord, children: /* @__PURE__ */ jsxDEV(ProductForm, {}, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx",
    lineNumber: 17,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
};
_s(ProductEditForm, "vquj8sjWea6OxDri+f+hy9sTw2k=", false, function() {
  return [useRecordContext];
});
_c = ProductEditForm;
export const ProductEdit = () => {
  return /* @__PURE__ */ jsxDEV(
    Edit,
    {
      transform: transformProductData,
      mutationMode: "pessimistic",
      redirect: "list",
      children: /* @__PURE__ */ jsxDEV(ProductEditForm, {}, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx",
        lineNumber: 29,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx",
      lineNumber: 24,
      columnNumber: 5
    },
    this
  );
};
_c2 = ProductEdit;
var _c, _c2;
$RefreshReg$(_c, "ProductEditForm");
$RefreshReg$(_c2, "ProductEdit");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductEdit.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNOztBQWhCTixTQUFTQSxNQUFNQyxZQUFZQyx3QkFBd0I7QUFDbkQsU0FBU0MsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE1BQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU1DLFNBQVNOLGlCQUFpQjtBQUVoQyxNQUFJLENBQUNNLE9BQVEsUUFBTztBQUVwQixRQUFNQyxhQUFhTCx1QkFBdUJJLE1BQU07QUFFaEQsU0FDRSx1QkFBQyxjQUFXLFFBQVFDLFlBQ2xCLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUVGLEdBWklELGlCQUFlO0FBQUEsVUFDSkosZ0JBQWdCO0FBQUE7QUFBQSxLQUQzQkk7QUFjQyxhQUFNSSxjQUFjQSxNQUFNO0FBQy9CLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVdMO0FBQUFBLE1BQ1gsY0FBYTtBQUFBLE1BQ2IsVUFBUztBQUFBLE1BRVQsaUNBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBO0FBQUEsSUFMbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUE7QUFFSjtBQUFFTSxNQVZXRDtBQUFXLElBQUFFLElBQUFEO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJFZGl0IiwiU2ltcGxlRm9ybSIsInVzZVJlY29yZENvbnRleHQiLCJQcm9kdWN0Rm9ybSIsIm5vcm1hbGl6ZVByb2R1Y3RSZWNvcmQiLCJ0cmFuc2Zvcm1Qcm9kdWN0RGF0YSIsIlByb2R1Y3RFZGl0Rm9ybSIsIl9zIiwicmVjb3JkIiwiZm9ybVJlY29yZCIsIlByb2R1Y3RFZGl0IiwiX2MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEVkaXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVkaXQsIFNpbXBsZUZvcm0sIHVzZVJlY29yZENvbnRleHQgfSBmcm9tIFwicmVhY3QtYWRtaW5cIjtcbmltcG9ydCB7IFByb2R1Y3RGb3JtIH0gZnJvbSBcIi4vUHJvZHVjdEZvcm1cIjtcbmltcG9ydCB7XG4gIG5vcm1hbGl6ZVByb2R1Y3RSZWNvcmQsXG4gIHRyYW5zZm9ybVByb2R1Y3REYXRhLFxufSBmcm9tIFwiLi9wcm9kdWN0VHJhbnNmb3JtXCI7XG5cbmNvbnN0IFByb2R1Y3RFZGl0Rm9ybSA9ICgpID0+IHtcbiAgY29uc3QgcmVjb3JkID0gdXNlUmVjb3JkQ29udGV4dCgpO1xuXG4gIGlmICghcmVjb3JkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBmb3JtUmVjb3JkID0gbm9ybWFsaXplUHJvZHVjdFJlY29yZChyZWNvcmQpO1xuXG4gIHJldHVybiAoXG4gICAgPFNpbXBsZUZvcm0gcmVjb3JkPXtmb3JtUmVjb3JkfT5cbiAgICAgIDxQcm9kdWN0Rm9ybSAvPlxuICAgIDwvU2ltcGxlRm9ybT5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBQcm9kdWN0RWRpdCA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8RWRpdFxuICAgICAgdHJhbnNmb3JtPXt0cmFuc2Zvcm1Qcm9kdWN0RGF0YX1cbiAgICAgIG11dGF0aW9uTW9kZT1cInBlc3NpbWlzdGljXCJcbiAgICAgIHJlZGlyZWN0PVwibGlzdFwiXG4gICAgPlxuICAgICAgPFByb2R1Y3RFZGl0Rm9ybSAvPlxuICAgIDwvRWRpdD5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9yZXNvdXJjZXMvcHJvZHVjdHMvUHJvZHVjdEVkaXQudHN4In0=