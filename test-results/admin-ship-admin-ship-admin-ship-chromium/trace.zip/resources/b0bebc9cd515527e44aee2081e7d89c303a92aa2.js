import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/brands/BrandCreate.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Create, SimpleForm } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { BrandForm } from "/src/resources/brands/BrandForm.tsx";
export const BrandCreate = () => {
  return /* @__PURE__ */ jsxDEV(Create, { redirect: "list", children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(BrandForm, {}, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandCreate.tsx",
    lineNumber: 8,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandCreate.tsx",
    lineNumber: 7,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandCreate.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
};
_c = BrandCreate;
var _c;
$RefreshReg$(_c, "BrandCreate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandCreate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandCreate.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/brands/BrandCreate.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixTQUFTQSxRQUFRQyxrQkFBa0I7QUFDbkMsU0FBU0MsaUJBQWlCO0FBRW5CLGFBQU1DLGNBQWNBLE1BQU07QUFDL0IsU0FDRSx1QkFBQyxVQUFPLFVBQVMsUUFDZixpQ0FBQyxjQUNDLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFVLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBRUMsS0FSV0Q7QUFBVyxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDcmVhdGUiLCJTaW1wbGVGb3JtIiwiQnJhbmRGb3JtIiwiQnJhbmRDcmVhdGUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCcmFuZENyZWF0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ3JlYXRlLCBTaW1wbGVGb3JtIH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQgeyBCcmFuZEZvcm0gfSBmcm9tIFwiLi9CcmFuZEZvcm1cIjtcblxuZXhwb3J0IGNvbnN0IEJyYW5kQ3JlYXRlID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxDcmVhdGUgcmVkaXJlY3Q9XCJsaXN0XCI+XG4gICAgICA8U2ltcGxlRm9ybT5cbiAgICAgICAgPEJyYW5kRm9ybSAvPlxuICAgICAgPC9TaW1wbGVGb3JtPlxuICAgIDwvQ3JlYXRlPlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9icmFuZHMvQnJhbmRDcmVhdGUudHN4In0=