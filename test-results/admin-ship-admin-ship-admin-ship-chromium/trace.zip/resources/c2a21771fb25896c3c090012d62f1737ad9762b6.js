import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/color-images/ColorImageList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  List,
  Datagrid,
  TextField,
  NumberField,
  EditButton,
  DeleteButton,
  ReferenceField
} from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { SwatchField } from "/src/components/SwatchOption.tsx";
export const ColorImageList = () => {
  return /* @__PURE__ */ jsxDEV(List, { children: /* @__PURE__ */ jsxDEV(Datagrid, { rowClick: "edit", children: [
    /* @__PURE__ */ jsxDEV(NumberField, { source: "id" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      SwatchField,
      {
        imageSource: "colorImage",
        labelSource: "name",
        label: "Swatch"
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
        lineNumber: 17,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(TextField, { source: "name" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      ReferenceField,
      {
        source: "productId",
        reference: "product",
        label: "Product",
        emptyText: "Unassigned",
        children: /* @__PURE__ */ jsxDEV(TextField, { source: "enName" }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
          lineNumber: 29,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
        lineNumber: 23,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(EditButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
      lineNumber: 31,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DeleteButton, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
      lineNumber: 32,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
};
_c = ColorImageList;
var _c;
$RefreshReg$(_c, "ColorImageList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/color-images/ColorImageList.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7QUFmUjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsaUJBQWlCQSxNQUFNO0FBQ2xDLFNBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxZQUFTLFVBQVMsUUFDakI7QUFBQSwyQkFBQyxlQUFZLFFBQU8sUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxhQUFZO0FBQUEsUUFDWixhQUFZO0FBQUEsUUFDWixPQUFNO0FBQUE7QUFBQSxNQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdnQjtBQUFBLElBRWhCLHVCQUFDLGFBQVUsUUFBTyxVQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFDeEI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFFBQU87QUFBQSxRQUNQLFdBQVU7QUFBQSxRQUNWLE9BQU07QUFBQSxRQUNOLFdBQVU7QUFBQSxRQUVWLGlDQUFDLGFBQVUsUUFBTyxZQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUE7QUFBQSxNQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLElBQ0EsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXO0FBQUEsSUFDWCx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxPQWpCZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkE7QUFFSjtBQUFFQyxLQXhCV0Q7QUFBYyxJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaXN0IiwiRGF0YWdyaWQiLCJUZXh0RmllbGQiLCJOdW1iZXJGaWVsZCIsIkVkaXRCdXR0b24iLCJEZWxldGVCdXR0b24iLCJSZWZlcmVuY2VGaWVsZCIsIlN3YXRjaEZpZWxkIiwiQ29sb3JJbWFnZUxpc3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb2xvckltYWdlTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgTGlzdCxcbiAgRGF0YWdyaWQsXG4gIFRleHRGaWVsZCxcbiAgTnVtYmVyRmllbGQsXG4gIEVkaXRCdXR0b24sXG4gIERlbGV0ZUJ1dHRvbixcbiAgUmVmZXJlbmNlRmllbGQsXG59IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IHsgU3dhdGNoRmllbGQgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9Td2F0Y2hPcHRpb25cIjtcblxuZXhwb3J0IGNvbnN0IENvbG9ySW1hZ2VMaXN0ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxMaXN0PlxuICAgICAgPERhdGFncmlkIHJvd0NsaWNrPVwiZWRpdFwiPlxuICAgICAgICA8TnVtYmVyRmllbGQgc291cmNlPVwiaWRcIiAvPlxuICAgICAgICA8U3dhdGNoRmllbGRcbiAgICAgICAgICBpbWFnZVNvdXJjZT1cImNvbG9ySW1hZ2VcIlxuICAgICAgICAgIGxhYmVsU291cmNlPVwibmFtZVwiXG4gICAgICAgICAgbGFiZWw9XCJTd2F0Y2hcIlxuICAgICAgICAvPlxuICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cIm5hbWVcIiAvPlxuICAgICAgICA8UmVmZXJlbmNlRmllbGRcbiAgICAgICAgICBzb3VyY2U9XCJwcm9kdWN0SWRcIlxuICAgICAgICAgIHJlZmVyZW5jZT1cInByb2R1Y3RcIlxuICAgICAgICAgIGxhYmVsPVwiUHJvZHVjdFwiXG4gICAgICAgICAgZW1wdHlUZXh0PVwiVW5hc3NpZ25lZFwiXG4gICAgICAgID5cbiAgICAgICAgICA8VGV4dEZpZWxkIHNvdXJjZT1cImVuTmFtZVwiIC8+XG4gICAgICAgIDwvUmVmZXJlbmNlRmllbGQ+XG4gICAgICAgIDxFZGl0QnV0dG9uIC8+XG4gICAgICAgIDxEZWxldGVCdXR0b24gLz5cbiAgICAgIDwvRGF0YWdyaWQ+XG4gICAgPC9MaXN0PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9jb2xvci1pbWFnZXMvQ29sb3JJbWFnZUxpc3QudHN4In0=