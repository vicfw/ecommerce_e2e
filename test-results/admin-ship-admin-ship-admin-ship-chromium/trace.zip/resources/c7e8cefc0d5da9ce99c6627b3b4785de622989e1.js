import {
  generateUtilityClass,
  generateUtilityClasses
} from "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";

// node_modules/.pnpm/@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2.18_react@19.2.8__@emotion+_d854b6513d956bcf53bbf4ed5999c6d1/node_modules/@mui/material/ToggleButton/toggleButtonClasses.mjs
function getToggleButtonUtilityClass(slot) {
  return generateUtilityClass("MuiToggleButton", slot);
}
var toggleButtonClasses = generateUtilityClasses("MuiToggleButton", ["root", "disabled", "selected", "standard", "primary", "secondary", "sizeSmall", "sizeMedium", "sizeLarge", "fullWidth"]);
var toggleButtonClasses_default = toggleButtonClasses;

export {
  getToggleButtonUtilityClass,
  toggleButtonClasses_default
};
//# sourceMappingURL=chunk-NS7DFSYZ.js.map
