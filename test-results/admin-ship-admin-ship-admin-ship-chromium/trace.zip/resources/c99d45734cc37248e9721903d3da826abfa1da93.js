import {
  useLazyRef
} from "/node_modules/.vite/deps/chunk-HFNW56X4.js?v=49ae7072";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useOnMount/useOnMount.mjs
var React = __toESM(require_react(), 1);
var EMPTY = [];
function useOnMount(fn) {
  React.useEffect(fn, EMPTY);
}

// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/useTimeout/useTimeout.mjs
var Timeout = class _Timeout {
  static create() {
    return new _Timeout();
  }
  currentId = null;
  /**
   * Executes `fn` after `delay`, clearing any previously scheduled call.
   */
  start(delay, fn) {
    this.clear();
    this.currentId = setTimeout(() => {
      this.currentId = null;
      fn();
    }, delay);
  }
  clear = () => {
    if (this.currentId !== null) {
      clearTimeout(this.currentId);
      this.currentId = null;
    }
  };
  disposeEffect = () => {
    return this.clear;
  };
};
function useTimeout() {
  const timeout = useLazyRef(Timeout.create).current;
  useOnMount(timeout.disposeEffect);
  return timeout;
}

export {
  useOnMount,
  Timeout,
  useTimeout
};
//# sourceMappingURL=chunk-XNALUJNS.js.map
