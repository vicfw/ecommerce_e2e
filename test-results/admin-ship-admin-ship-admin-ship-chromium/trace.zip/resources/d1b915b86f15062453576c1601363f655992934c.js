// node_modules/.pnpm/@mui+utils@9.3.0_@types+react@19.2.18_react@19.2.8/node_modules/@mui/utils/setRef/setRef.mjs
function setRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
}

export {
  setRef
};
//# sourceMappingURL=chunk-QTIS3M7A.js.map
