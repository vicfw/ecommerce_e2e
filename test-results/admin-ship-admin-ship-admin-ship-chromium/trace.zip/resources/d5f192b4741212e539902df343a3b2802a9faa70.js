import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HomepageEditor.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import Typography from "/node_modules/.vite/deps/@mui_material_Typography.js?v=49ae7072";
import Button from "/node_modules/.vite/deps/@mui_material_Button.js?v=49ae7072";
import TextField from "/node_modules/.vite/deps/@mui_material_TextField.js?v=49ae7072";
import IconButton from "/node_modules/.vite/deps/@mui_material_IconButton.js?v=49ae7072";
import Chip from "/node_modules/.vite/deps/@mui_material_Chip.js?v=49ae7072";
import Autocomplete from "/node_modules/.vite/deps/@mui_material_Autocomplete.js?v=49ae7072";
import CircularProgress from "/node_modules/.vite/deps/@mui_material_CircularProgress.js?v=49ae7072";
import Collapse from "/node_modules/.vite/deps/@mui_material_Collapse.js?v=49ae7072";
import Tabs from "/node_modules/.vite/deps/@mui_material_Tabs.js?v=49ae7072";
import Tab from "/node_modules/.vite/deps/@mui_material_Tab.js?v=49ae7072";
import ToggleButton from "/node_modules/.vite/deps/@mui_material_ToggleButton.js?v=49ae7072";
import ToggleButtonGroup from "/node_modules/.vite/deps/@mui_material_ToggleButtonGroup.js?v=49ae7072";
import DeleteOutlinedIcon from "/node_modules/.vite/deps/@mui_icons-material_DeleteOutlined.js?v=49ae7072";
import ExpandMoreIcon from "/node_modules/.vite/deps/@mui_icons-material_ExpandMore.js?v=49ae7072";
import ExpandLessIcon from "/node_modules/.vite/deps/@mui_icons-material_ExpandLess.js?v=49ae7072";
import ImageIcon from "/node_modules/.vite/deps/@mui_icons-material_Image.js?v=49ae7072";
import ViewCarouselIcon from "/node_modules/.vite/deps/@mui_icons-material_ViewCarousel.js?v=49ae7072";
import ViewWeekIcon from "/node_modules/.vite/deps/@mui_icons-material_ViewWeek.js?v=49ae7072";
import DragIndicatorIcon from "/node_modules/.vite/deps/@mui_icons-material_DragIndicator.js?v=49ae7072";
import ContentCopyIcon from "/node_modules/.vite/deps/@mui_icons-material_ContentCopy.js?v=49ae7072";
import ComputerIcon from "/node_modules/.vite/deps/@mui_icons-material_Computer.js?v=49ae7072";
import SmartphoneIcon from "/node_modules/.vite/deps/@mui_icons-material_Smartphone.js?v=49ae7072";
import CollectionsIcon from "/node_modules/.vite/deps/@mui_icons-material_Collections.js?v=49ae7072";
import CircleOutlinedIcon from "/node_modules/.vite/deps/@mui_icons-material_CircleOutlined.js?v=49ae7072";
import AddIcon from "/node_modules/.vite/deps/@mui_icons-material_Add.js?v=49ae7072";
import ArrowUpwardIcon from "/node_modules/.vite/deps/@mui_icons-material_ArrowUpward.js?v=49ae7072";
import ArrowDownwardIcon from "/node_modules/.vite/deps/@mui_icons-material_ArrowDownward.js?v=49ae7072";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors
} from "/node_modules/.vite/deps/@dnd-kit_core.js?v=49ae7072";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy
} from "/node_modules/.vite/deps/@dnd-kit_sortable.js?v=49ae7072";
import { CSS } from "/node_modules/.vite/deps/@dnd-kit_utilities.js?v=49ae7072";
import __vite__cjsImport32_react from "/node_modules/.vite/deps/react.js?v=49ae7072"; const useCallback = __vite__cjsImport32_react["useCallback"]; const useEffect = __vite__cjsImport32_react["useEffect"]; const useMemo = __vite__cjsImport32_react["useMemo"]; const useRef = __vite__cjsImport32_react["useRef"]; const useState = __vite__cjsImport32_react["useState"];
import { Title, useDataProvider, useNotify } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import {
  emptyHomepageLayout,
  getHomepageAdmin,
  normalizeHomepageLayout,
  updateHomepage,
  uploadImages
} from "/src/api/admin/index.ts";
const HEX_COLOR_RE = /^#[0-9A-Fa-f]{6}$/;
const newId = () => typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `section-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const createBanner = () => ({
  id: newId(),
  type: "banner",
  imageUrl: "",
  href: "",
  alt: ""
});
const createSlider = () => ({
  id: newId(),
  type: "product_slider",
  title: "",
  productIds: [],
  backgroundColor: ""
});
const createStoryItem = () => ({
  id: newId(),
  imageUrl: "",
  label: "",
  href: ""
});
const createStoryLinks = () => ({
  id: newId(),
  type: "story_links",
  items: [createStoryItem()]
});
const createImageSlide = () => ({
  id: newId(),
  imageUrl: "",
  href: "",
  alt: ""
});
const createImageSlider = () => ({
  id: newId(),
  type: "image_slider",
  slides: [createImageSlide()]
});
const createRow = (columnCount = 2) => ({
  id: newId(),
  type: "row",
  columns: Array.from({ length: columnCount }, () => createBanner())
});
const mergeProductOptions = (current, incoming) => {
  const map = /* @__PURE__ */ new Map();
  for (const item of [...current, ...incoming]) {
    map.set(item.id, item);
  }
  return Array.from(map.values());
};
const collectLayoutProductIds = (layout) => Array.from(
  new Set(
    [...layout.desktop, ...layout.mobile].flatMap((section) => {
      if (section.type === "product_slider") return section.productIds;
      if (section.type === "row") {
        return section.columns.flatMap(
          (column) => column.type === "product_slider" ? column.productIds : []
        );
      }
      return [];
    })
  )
);
const cloneSectionsWithNewIds = (sections) => sections.map((section) => {
  if (section.type === "row") {
    return {
      ...section,
      id: newId(),
      columns: section.columns.map((column) => ({
        ...column,
        id: newId()
      }))
    };
  }
  if (section.type === "story_links") {
    return {
      ...section,
      id: newId(),
      items: section.items.map((item) => ({ ...item, id: newId() }))
    };
  }
  if (section.type === "image_slider") {
    return {
      ...section,
      id: newId(),
      slides: section.slides.map((slide) => ({ ...slide, id: newId() }))
    };
  }
  return { ...section, id: newId() };
});
const sanitizeContentBlock = (block) => {
  if (block.type === "banner") {
    return {
      id: block.id,
      type: "banner",
      imageUrl: block.imageUrl.trim(),
      ...block.href?.trim() ? { href: block.href.trim() } : {},
      ...block.alt?.trim() ? { alt: block.alt.trim() } : {}
    };
  }
  const backgroundColor = block.backgroundColor?.trim();
  return {
    id: block.id,
    type: "product_slider",
    title: block.title.trim(),
    productIds: block.productIds,
    ...backgroundColor && HEX_COLOR_RE.test(backgroundColor) ? { backgroundColor } : {}
  };
};
const sanitizeSections = (sections) => sections.map((section) => {
  if (section.type === "row") {
    return {
      id: section.id,
      type: "row",
      columns: section.columns.map(sanitizeContentBlock)
    };
  }
  if (section.type === "story_links") {
    return {
      id: section.id,
      type: "story_links",
      items: section.items.map((item) => ({
        id: item.id,
        imageUrl: item.imageUrl.trim(),
        label: item.label.trim(),
        href: item.href.trim()
      }))
    };
  }
  if (section.type === "image_slider") {
    return {
      id: section.id,
      type: "image_slider",
      slides: section.slides.map((slide) => ({
        id: slide.id,
        imageUrl: slide.imageUrl.trim(),
        ...slide.href?.trim() ? { href: slide.href.trim() } : {},
        ...slide.alt?.trim() ? { alt: slide.alt.trim() } : {}
      }))
    };
  }
  return sanitizeContentBlock(section);
});
const findFirstInvalidMessage = (sections, deviceLabel) => {
  for (let i = 0; i < sections.length; i += 1) {
    const section = sections[i];
    const position = `${deviceLabel} #${i + 1}`;
    if (section.type === "row") {
      if (section.columns.length < 1 || section.columns.length > 4) {
        return `${position} (row): must have between 1 and 4 columns`;
      }
      for (let c = 0; c < section.columns.length; c += 1) {
        const column = section.columns[c];
        if (column.type === "banner" && !column.imageUrl.trim()) {
          return `${position} row column ${c + 1}: banner needs an image URL`;
        }
        if (column.type === "product_slider" && !column.title.trim()) {
          return `${position} row column ${c + 1}: product slider needs a title`;
        }
        if (column.type === "product_slider" && column.backgroundColor?.trim() && !HEX_COLOR_RE.test(column.backgroundColor.trim())) {
          return `${position} row column ${c + 1}: background color must be #RRGGBB`;
        }
      }
      continue;
    }
    if (section.type === "banner" && !section.imageUrl.trim()) {
      return `${position} (banner): needs an image URL`;
    }
    if (section.type === "product_slider" && !section.title.trim()) {
      return `${position} (slider): needs a title`;
    }
    if (section.type === "product_slider" && section.backgroundColor?.trim() && !HEX_COLOR_RE.test(section.backgroundColor.trim())) {
      return `${position} (slider): background color must be #RRGGBB`;
    }
    if (section.type === "story_links") {
      if (section.items.length < 1) {
        return `${position} (stories): needs at least one item`;
      }
      for (let j = 0; j < section.items.length; j += 1) {
        const item = section.items[j];
        if (!item.imageUrl.trim()) {
          return `${position} story item ${j + 1}: needs an image`;
        }
        if (!item.label.trim()) {
          return `${position} story item ${j + 1}: needs a label`;
        }
        if (!item.href.trim()) {
          return `${position} story item ${j + 1}: needs a link`;
        }
      }
    }
    if (section.type === "image_slider") {
      if (section.slides.length < 1) {
        return `${position} (image slider): needs at least one slide`;
      }
      for (let j = 0; j < section.slides.length; j += 1) {
        if (!section.slides[j].imageUrl.trim()) {
          return `${position} slide ${j + 1}: needs an image URL`;
        }
      }
    }
  }
  return null;
};
const ContentBlockEditor = ({
  block,
  onChange,
  onProductsResolved,
  productOptions,
  productLoading,
  onProductSearch,
  onUploadError,
  compact = false,
  allowTypeSwitch = false
}) => {
  _s();
  const [uploading, setUploading] = useState(false);
  const selectedProducts = useMemo(() => {
    if (block.type !== "product_slider") return [];
    return block.productIds.map(
      (id) => productOptions.find((p) => p.id === id) ?? {
        id,
        enName: `Product #${id}`
      }
    );
  }, [block, productOptions]);
  const autocompleteOptions = useMemo(
    () => mergeProductOptions(productOptions, selectedProducts),
    [productOptions, selectedProducts]
  );
  return /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexDirection: "column", gap: 2 }, children: [
    allowTypeSwitch && /* @__PURE__ */ jsxDEV(
      ToggleButtonGroup,
      {
        exclusive: true,
        size: "small",
        value: block.type,
        onChange: (_, value) => {
          if (!value || value === block.type) return;
          onChange(
            (prev) => value === "banner" ? { ...createBanner(), id: prev.id } : { ...createSlider(), id: prev.id }
          );
        },
        children: [
          /* @__PURE__ */ jsxDEV(ToggleButton, { value: "banner", children: "Banner" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 383,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(ToggleButton, { value: "product_slider", children: "Product slider" }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 384,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 370,
        columnNumber: 7
      },
      this
    ),
    block.type === "banner" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            flexWrap: "wrap",
            gap: 2,
            alignItems: "flex-start"
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  width: { xs: "100%", md: compact ? 140 : 220 },
                  height: compact ? 90 : 120,
                  borderRadius: 1,
                  border: "1px dashed",
                  borderColor: "divider",
                  overflow: "hidden",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  bgcolor: "background.default"
                },
                children: block.imageUrl ? /* @__PURE__ */ jsxDEV(
                  Box,
                  {
                    component: "img",
                    src: block.imageUrl,
                    alt: block.alt || "Banner preview",
                    sx: { width: "100%", height: "100%", objectFit: "cover" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 413,
                    columnNumber: 13
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "No image" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 420,
                  columnNumber: 13
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 398,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  flex: 1,
                  minWidth: compact ? 160 : 220,
                  display: "flex",
                  flexDirection: "column",
                  gap: 1.5
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "outlined",
                      component: "label",
                      disabled: uploading,
                      size: compact ? "small" : "medium",
                      children: [
                        uploading ? "Uploading…" : "Upload image",
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "file",
                            hidden: true,
                            accept: "image/*",
                            onChange: async (e) => {
                              const file = e.target.files?.[0];
                              e.target.value = "";
                              if (!file) return;
                              setUploading(true);
                              try {
                                const urls = await uploadImages([file]);
                                if (urls?.[0]) {
                                  onChange(
                                    (prev) => prev.type === "banner" ? { ...prev, imageUrl: urls[0] } : prev
                                  );
                                }
                              } catch {
                                onUploadError();
                              } finally {
                                setUploading(false);
                              }
                            }
                          },
                          void 0,
                          false,
                          {
                            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                            lineNumber: 442,
                            columnNumber: 17
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 435,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    TextField,
                    {
                      label: "Image URL",
                      value: block.imageUrl,
                      onChange: (e) => {
                        const imageUrl = e.target.value;
                        onChange(
                          (prev) => prev.type === "banner" ? { ...prev, imageUrl } : prev
                        );
                      },
                      fullWidth: true,
                      size: "small",
                      helperText: "Upload or paste a Cloudinary URL"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 469,
                      columnNumber: 15
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 426,
                columnNumber: 13
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 390,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 2 }, children: [
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Link URL (optional)",
            value: block.href ?? "",
            onChange: (e) => {
              const href = e.target.value;
              onChange(
                (prev) => prev.type === "banner" ? { ...prev, href } : prev
              );
            },
            fullWidth: true,
            size: "small"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 487,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 486,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
          TextField,
          {
            label: "Alt text (optional)",
            value: block.alt ?? "",
            onChange: (e) => {
              const alt = e.target.value;
              onChange(
                (prev) => prev.type === "banner" ? { ...prev, alt } : prev
              );
            },
            fullWidth: true,
            size: "small"
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 501,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 500,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 485,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
      lineNumber: 389,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        TextField,
        {
          label: "Slider title",
          value: block.title,
          onChange: (e) => {
            const title = e.target.value;
            onChange(
              (prev) => prev.type === "product_slider" ? { ...prev, title } : prev
            );
          },
          fullWidth: true,
          size: "small",
          required: true
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 518,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            flexWrap: "wrap",
            gap: 2,
            alignItems: "center"
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  width: 40,
                  height: 40,
                  borderRadius: 1,
                  border: "1px solid",
                  borderColor: "divider",
                  bgcolor: HEX_COLOR_RE.test(block.backgroundColor?.trim() ?? "") ? block.backgroundColor : "transparent",
                  backgroundImage: !HEX_COLOR_RE.test(
                    block.backgroundColor?.trim() ?? ""
                  ) ? "linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)" : void 0,
                  backgroundSize: "8px 8px",
                  backgroundPosition: "0 0, 0 4px, 4px -4px, -4px 0"
                }
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 540,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                component: "input",
                type: "color",
                value: HEX_COLOR_RE.test(block.backgroundColor?.trim() ?? "") ? block.backgroundColor.trim() : "#e91e8c",
                onChange: (e) => {
                  const backgroundColor = e.target.value;
                  onChange(
                    (prev) => prev.type === "product_slider" ? { ...prev, backgroundColor } : prev
                  );
                },
                sx: {
                  width: 48,
                  height: 40,
                  p: 0,
                  border: "1px solid",
                  borderColor: "divider",
                  borderRadius: 1,
                  cursor: "pointer",
                  bgcolor: "transparent"
                }
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 559,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Box, { sx: { flex: 1, minWidth: 140 }, children: /* @__PURE__ */ jsxDEV(
              TextField,
              {
                label: "Background color (optional)",
                value: block.backgroundColor ?? "",
                onChange: (e) => {
                  const backgroundColor = e.target.value;
                  onChange(
                    (prev) => prev.type === "product_slider" ? { ...prev, backgroundColor } : prev
                  );
                },
                fullWidth: true,
                size: "small",
                placeholder: "#E91E8C",
                helperText: "Hex #RRGGBB — leave empty for none"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 587,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 586,
              columnNumber: 13
            }, this),
            (block.backgroundColor ?? "").trim() !== "" && /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "small",
                onClick: () => onChange(
                  (prev) => prev.type === "product_slider" ? { ...prev, backgroundColor: "" } : prev
                ),
                children: "Clear"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 605,
                columnNumber: 11
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 532,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Autocomplete,
        {
          multiple: true,
          options: autocompleteOptions,
          loading: productLoading,
          value: selectedProducts,
          filterSelectedOptions: true,
          filterOptions: (options) => options,
          getOptionLabel: (option) => option.enName || option.prName || `#${option.id}`,
          isOptionEqualToValue: (a, b) => a.id === b.id,
          onInputChange: (_, value, reason) => {
            if (reason === "input") onProductSearch(value);
          },
          onChange: (_, value) => {
            onProductsResolved(value);
            const productIds = value.map((p) => p.id);
            onChange(
              (prev) => prev.type === "product_slider" ? { ...prev, productIds } : prev
            );
          },
          renderInput: (params) => /* @__PURE__ */ jsxDEV(
            TextField,
            {
              ...params,
              label: "Products",
              size: "small",
              helperText: "Search and pick products in display order"
            },
            void 0,
            false,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 644,
              columnNumber: 11
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 620,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
      lineNumber: 517,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
    lineNumber: 368,
    columnNumber: 5
  }, this);
};
_s(ContentBlockEditor, "YfVXuBSp8OLoiNdAAgd9gbVyf0A=");
_c = ContentBlockEditor;
const StoryLinksEditor = ({
  section,
  onChange,
  onUploadError
}) => {
  _s2();
  const [uploadingId, setUploadingId] = useState(null);
  const updateItem = (itemId, patch) => {
    onChange((prev) => {
      if (prev.type !== "story_links") return prev;
      return {
        ...prev,
        items: prev.items.map(
          (item) => item.id === itemId ? { ...item, ...patch } : item
        )
      };
    });
  };
  const moveItem = (index, direction) => {
    onChange((prev) => {
      if (prev.type !== "story_links") return prev;
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= prev.items.length) return prev;
      return { ...prev, items: arrayMove(prev.items, index, nextIndex) };
    });
  };
  return /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexDirection: "column", gap: 2 }, children: [
    section.items.map(
      (item, index) => /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            flexDirection: "column",
            gap: 1.5,
            p: 1.5,
            borderRadius: 1.5,
            border: "1px solid",
            borderColor: "divider",
            bgcolor: "background.default"
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 1
                },
                children: [
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: { fontWeight: 600 }, children: [
                    "Item ",
                    index + 1
                  ] }, void 0, true, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 719,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", gap: 0.5 }, children: [
                    /* @__PURE__ */ jsxDEV(
                      IconButton,
                      {
                        size: "small",
                        disabled: index === 0,
                        onClick: () => moveItem(index, -1),
                        "aria-label": "Move up",
                        children: /* @__PURE__ */ jsxDEV(ArrowUpwardIcon, { fontSize: "small" }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 729,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 723,
                        columnNumber: 15
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      IconButton,
                      {
                        size: "small",
                        disabled: index === section.items.length - 1,
                        onClick: () => moveItem(index, 1),
                        "aria-label": "Move down",
                        children: /* @__PURE__ */ jsxDEV(ArrowDownwardIcon, { fontSize: "small" }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 737,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 731,
                        columnNumber: 15
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      IconButton,
                      {
                        size: "small",
                        color: "error",
                        disabled: section.items.length <= 1,
                        onClick: () => onChange(
                          (prev) => prev.type === "story_links" ? {
                            ...prev,
                            items: prev.items.filter((i) => i.id !== item.id)
                          } : prev
                        ),
                        "aria-label": "Remove item",
                        children: /* @__PURE__ */ jsxDEV(DeleteOutlinedIcon, { fontSize: "small" }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 755,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 739,
                        columnNumber: 15
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 722,
                    columnNumber: 13
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 711,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 2,
                  alignItems: "flex-start"
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Box,
                    {
                      sx: {
                        width: 80,
                        height: 80,
                        borderRadius: "50%",
                        border: "1px dashed",
                        borderColor: "divider",
                        overflow: "hidden",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        bgcolor: "background.paper",
                        flexShrink: 0
                      },
                      children: item.imageUrl ? /* @__PURE__ */ jsxDEV(
                        Box,
                        {
                          component: "img",
                          src: item.imageUrl,
                          alt: item.label || "Story preview",
                          sx: { width: "100%", height: "100%", objectFit: "cover" }
                        },
                        void 0,
                        false,
                        {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 784,
                          columnNumber: 13
                        },
                        this
                      ) : /* @__PURE__ */ jsxDEV(CircleOutlinedIcon, { color: "disabled" }, void 0, false, {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 791,
                        columnNumber: 13
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 768,
                      columnNumber: 13
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Box,
                    {
                      sx: {
                        flex: 1,
                        minWidth: 200,
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5
                      },
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            variant: "outlined",
                            component: "label",
                            disabled: uploadingId === item.id,
                            size: "small",
                            children: [
                              uploadingId === item.id ? "Uploading…" : "Upload image",
                              /* @__PURE__ */ jsxDEV(
                                "input",
                                {
                                  type: "file",
                                  hidden: true,
                                  accept: "image/*",
                                  onChange: async (e) => {
                                    const file = e.target.files?.[0];
                                    e.target.value = "";
                                    if (!file) return;
                                    setUploadingId(item.id);
                                    try {
                                      const urls = await uploadImages([file]);
                                      if (urls?.[0]) updateItem(item.id, { imageUrl: urls[0] });
                                    } catch {
                                      onUploadError();
                                    } finally {
                                      setUploadingId(null);
                                    }
                                  }
                                },
                                void 0,
                                false,
                                {
                                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                                  lineNumber: 811,
                                  columnNumber: 17
                                },
                                this
                              )
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                            lineNumber: 804,
                            columnNumber: 15
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          TextField,
                          {
                            label: "Image URL",
                            value: item.imageUrl,
                            onChange: (e) => updateItem(item.id, { imageUrl: e.target.value }),
                            fullWidth: true,
                            size: "small"
                          },
                          void 0,
                          false,
                          {
                            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                            lineNumber: 831,
                            columnNumber: 15
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 795,
                      columnNumber: 13
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 760,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 2 }, children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextField,
                {
                  label: "Label",
                  value: item.label,
                  onChange: (e) => updateItem(item.id, { label: e.target.value }),
                  fullWidth: true,
                  size: "small",
                  required: true
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 845,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 844,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextField,
                {
                  label: "Link URL",
                  value: item.href,
                  onChange: (e) => updateItem(item.id, { href: e.target.value }),
                  fullWidth: true,
                  size: "small",
                  required: true
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 855,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 854,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 843,
              columnNumber: 11
            }, this)
          ]
        },
        item.id,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 698,
          columnNumber: 7
        },
        this
      )
    ),
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "outlined",
        startIcon: /* @__PURE__ */ jsxDEV(AddIcon, {}, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 870,
          columnNumber: 20
        }, this),
        onClick: () => onChange(
          (prev) => prev.type === "story_links" ? { ...prev, items: [...prev.items, createStoryItem()] } : prev
        ),
        children: "Add story item"
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 868,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
    lineNumber: 696,
    columnNumber: 5
  }, this);
};
_s2(StoryLinksEditor, "eCQM4Fw/SIauKI5jpSqinpxGTQ4=");
_c2 = StoryLinksEditor;
const ImageSliderEditor = ({
  section,
  onChange,
  onUploadError
}) => {
  _s3();
  const [uploadingId, setUploadingId] = useState(null);
  const updateSlide = (slideId, patch) => {
    onChange((prev) => {
      if (prev.type !== "image_slider") return prev;
      return {
        ...prev,
        slides: prev.slides.map(
          (slide) => slide.id === slideId ? { ...slide, ...patch } : slide
        )
      };
    });
  };
  const moveSlide = (index, direction) => {
    onChange((prev) => {
      if (prev.type !== "image_slider") return prev;
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= prev.slides.length) return prev;
      return { ...prev, slides: arrayMove(prev.slides, index, nextIndex) };
    });
  };
  return /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexDirection: "column", gap: 2 }, children: [
    section.slides.map(
      (slide, index) => /* @__PURE__ */ jsxDEV(
        Box,
        {
          sx: {
            display: "flex",
            flexDirection: "column",
            gap: 1.5,
            p: 1.5,
            borderRadius: 1.5,
            border: "1px solid",
            borderColor: "divider",
            bgcolor: "background.default"
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 1
                },
                children: [
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: { fontWeight: 600 }, children: [
                    "Slide ",
                    index + 1
                  ] }, void 0, true, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 943,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", gap: 0.5 }, children: [
                    /* @__PURE__ */ jsxDEV(
                      IconButton,
                      {
                        size: "small",
                        disabled: index === 0,
                        onClick: () => moveSlide(index, -1),
                        "aria-label": "Move up",
                        children: /* @__PURE__ */ jsxDEV(ArrowUpwardIcon, { fontSize: "small" }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 953,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 947,
                        columnNumber: 15
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      IconButton,
                      {
                        size: "small",
                        disabled: index === section.slides.length - 1,
                        onClick: () => moveSlide(index, 1),
                        "aria-label": "Move down",
                        children: /* @__PURE__ */ jsxDEV(ArrowDownwardIcon, { fontSize: "small" }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 961,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 955,
                        columnNumber: 15
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      IconButton,
                      {
                        size: "small",
                        color: "error",
                        disabled: section.slides.length <= 1,
                        onClick: () => onChange(
                          (prev) => prev.type === "image_slider" ? {
                            ...prev,
                            slides: prev.slides.filter((s) => s.id !== slide.id)
                          } : prev
                        ),
                        "aria-label": "Remove slide",
                        children: /* @__PURE__ */ jsxDEV(DeleteOutlinedIcon, { fontSize: "small" }, void 0, false, {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 979,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 963,
                        columnNumber: 15
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 946,
                    columnNumber: 13
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 935,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 2,
                  alignItems: "flex-start"
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Box,
                    {
                      sx: {
                        width: { xs: "100%", md: 220 },
                        height: 120,
                        borderRadius: 1,
                        border: "1px dashed",
                        borderColor: "divider",
                        overflow: "hidden",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        bgcolor: "background.paper"
                      },
                      children: slide.imageUrl ? /* @__PURE__ */ jsxDEV(
                        Box,
                        {
                          component: "img",
                          src: slide.imageUrl,
                          alt: slide.alt || "Slide preview",
                          sx: { width: "100%", height: "100%", objectFit: "cover" }
                        },
                        void 0,
                        false,
                        {
                          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                          lineNumber: 1007,
                          columnNumber: 13
                        },
                        this
                      ) : /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "No image" }, void 0, false, {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 1014,
                        columnNumber: 13
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 992,
                      columnNumber: 13
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Box,
                    {
                      sx: {
                        flex: 1,
                        minWidth: 220,
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5
                      },
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            variant: "outlined",
                            component: "label",
                            disabled: uploadingId === slide.id,
                            size: "small",
                            children: [
                              uploadingId === slide.id ? "Uploading…" : "Upload image",
                              /* @__PURE__ */ jsxDEV(
                                "input",
                                {
                                  type: "file",
                                  hidden: true,
                                  accept: "image/*",
                                  onChange: async (e) => {
                                    const file = e.target.files?.[0];
                                    e.target.value = "";
                                    if (!file) return;
                                    setUploadingId(slide.id);
                                    try {
                                      const urls = await uploadImages([file]);
                                      if (urls?.[0])
                                        updateSlide(slide.id, { imageUrl: urls[0] });
                                    } catch {
                                      onUploadError();
                                    } finally {
                                      setUploadingId(null);
                                    }
                                  }
                                },
                                void 0,
                                false,
                                {
                                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                                  lineNumber: 1036,
                                  columnNumber: 17
                                },
                                this
                              )
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                            lineNumber: 1029,
                            columnNumber: 15
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          TextField,
                          {
                            label: "Image URL",
                            value: slide.imageUrl,
                            onChange: (e) => updateSlide(slide.id, { imageUrl: e.target.value }),
                            fullWidth: true,
                            size: "small"
                          },
                          void 0,
                          false,
                          {
                            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                            lineNumber: 1057,
                            columnNumber: 15
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 1020,
                      columnNumber: 13
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 984,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 2 }, children: [
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextField,
                {
                  label: "Link URL (optional)",
                  value: slide.href ?? "",
                  onChange: (e) => updateSlide(slide.id, { href: e.target.value }),
                  fullWidth: true,
                  size: "small"
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1071,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1070,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Box, { sx: { width: { xs: "100%", md: "calc(50% - 8px)" } }, children: /* @__PURE__ */ jsxDEV(
                TextField,
                {
                  label: "Alt text (optional)",
                  value: slide.alt ?? "",
                  onChange: (e) => updateSlide(slide.id, { alt: e.target.value }),
                  fullWidth: true,
                  size: "small"
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1082,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1081,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1069,
              columnNumber: 11
            }, this)
          ]
        },
        slide.id,
        true,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 922,
          columnNumber: 7
        },
        this
      )
    ),
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "outlined",
        startIcon: /* @__PURE__ */ jsxDEV(AddIcon, {}, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 1096,
          columnNumber: 20
        }, this),
        onClick: () => onChange(
          (prev) => prev.type === "image_slider" ? { ...prev, slides: [...prev.slides, createImageSlide()] } : prev
        ),
        children: "Add slide"
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 1094,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
    lineNumber: 920,
    columnNumber: 5
  }, this);
};
_s3(ImageSliderEditor, "eCQM4Fw/SIauKI5jpSqinpxGTQ4=");
_c3 = ImageSliderEditor;
const sectionLabel = (section) => {
  if (section.type === "banner") return "Banner";
  if (section.type === "product_slider") {
    return section.title || "Product slider";
  }
  if (section.type === "story_links") return "Story links";
  if (section.type === "image_slider") {
    return `Image slider (${section.slides.length})`;
  }
  return `Row (${section.columns.length} columns)`;
};
const sectionChip = (section) => {
  if (section.type === "banner") return "Banner";
  if (section.type === "product_slider") return "Slider";
  if (section.type === "story_links") return "Stories";
  if (section.type === "image_slider") return "Images";
  return "Row";
};
const SortableSection = ({
  section,
  expanded,
  onToggle,
  onChange,
  onRemove,
  onProductsResolved,
  productOptions,
  productLoading,
  onProductSearch,
  onUploadError
}) => {
  _s4();
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: section.id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.7 : 1
  };
  const setColumnCount = (count) => {
    onChange((prev) => {
      if (prev.type !== "row") return prev;
      const nextColumns = [...prev.columns];
      while (nextColumns.length < count) {
        nextColumns.push(createBanner());
      }
      while (nextColumns.length > count) {
        nextColumns.pop();
      }
      return { ...prev, columns: nextColumns };
    });
  };
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      ref: setNodeRef,
      style,
      sx: {
        overflow: "hidden",
        borderRadius: 2,
        border: "1px solid",
        borderColor: isDragging ? "primary.main" : "divider",
        bgcolor: "background.paper",
        boxShadow: isDragging ? 2 : 0
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          Box,
          {
            sx: {
              display: "flex",
              alignItems: "center",
              gap: 1,
              px: 1.5,
              py: 1,
              borderBottom: expanded ? "1px solid" : "none",
              borderColor: "divider",
              bgcolor: (theme) => theme.palette.mode === "dark" ? "action.hover" : "background.default"
            },
            children: [
              /* @__PURE__ */ jsxDEV(
                IconButton,
                {
                  size: "small",
                  ...attributes,
                  ...listeners,
                  "aria-label": "Drag to reorder",
                  sx: { cursor: "grab", color: "text.secondary" },
                  children: /* @__PURE__ */ jsxDEV(DragIndicatorIcon, {}, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1220,
                    columnNumber: 11
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1213,
                  columnNumber: 9
                },
                this
              ),
              section.type === "banner" ? /* @__PURE__ */ jsxDEV(ImageIcon, { fontSize: "small", sx: { color: "text.secondary" } }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1224,
                columnNumber: 9
              }, this) : section.type === "product_slider" ? /* @__PURE__ */ jsxDEV(ViewCarouselIcon, { fontSize: "small", sx: { color: "text.secondary" } }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1226,
                columnNumber: 9
              }, this) : section.type === "story_links" ? /* @__PURE__ */ jsxDEV(
                CircleOutlinedIcon,
                {
                  fontSize: "small",
                  sx: { color: "text.secondary" }
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1228,
                  columnNumber: 9
                },
                this
              ) : section.type === "image_slider" ? /* @__PURE__ */ jsxDEV(CollectionsIcon, { fontSize: "small", sx: { color: "text.secondary" } }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1233,
                columnNumber: 9
              }, this) : /* @__PURE__ */ jsxDEV(ViewWeekIcon, { fontSize: "small", sx: { color: "text.secondary" } }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1235,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Typography, { sx: { flex: 1, fontWeight: 600, color: "text.primary" }, children: sectionLabel(section) }, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1238,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(
                Chip,
                {
                  size: "small",
                  label: sectionChip(section),
                  variant: "outlined",
                  color: "primary"
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1242,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                IconButton,
                {
                  size: "small",
                  onClick: onToggle,
                  "aria-label": "Toggle section",
                  sx: { color: "text.secondary" },
                  children: expanded ? /* @__PURE__ */ jsxDEV(ExpandLessIcon, {}, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1255,
                    columnNumber: 23
                  }, this) : /* @__PURE__ */ jsxDEV(ExpandMoreIcon, {}, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1255,
                    columnNumber: 44
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1249,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                IconButton,
                {
                  size: "small",
                  color: "error",
                  onClick: onRemove,
                  "aria-label": "Remove section",
                  children: /* @__PURE__ */ jsxDEV(DeleteOutlinedIcon, {}, void 0, false, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1263,
                    columnNumber: 11
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1257,
                  columnNumber: 9
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1198,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Collapse, { in: expanded, children: /* @__PURE__ */ jsxDEV(Box, { sx: { p: 2, display: "flex", flexDirection: "column", gap: 2 }, children: section.type === "row" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            Box,
            {
              sx: {
                display: "flex",
                flexWrap: "wrap",
                alignItems: "center",
                gap: 2
              },
              children: [
                /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Columns (equal width)" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1279,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  ToggleButtonGroup,
                  {
                    exclusive: true,
                    size: "small",
                    value: section.columns.length,
                    onChange: (_, value) => {
                      if (value) setColumnCount(value);
                    },
                    children: [2, 3, 4].map(
                      (count) => /* @__PURE__ */ jsxDEV(ToggleButton, { value: count, children: count }, count, false, {
                        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                        lineNumber: 1291,
                        columnNumber: 17
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1282,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1271,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexWrap: "wrap", gap: 2 }, children: section.columns.map(
            (column, index) => /* @__PURE__ */ jsxDEV(
              Box,
              {
                sx: {
                  width: {
                    xs: "100%",
                    md: `calc(${100 / section.columns.length}% - ${(section.columns.length - 1) * 16 / section.columns.length}px)`
                  },
                  p: 1.5,
                  borderRadius: 1.5,
                  border: "1px solid",
                  borderColor: "divider",
                  bgcolor: "background.default",
                  display: "flex",
                  flexDirection: "column",
                  gap: 1.5
                },
                children: [
                  /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", sx: { fontWeight: 600 }, children: [
                    "Column ",
                    index + 1
                  ] }, void 0, true, {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1320,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    ContentBlockEditor,
                    {
                      block: column,
                      compact: true,
                      allowTypeSwitch: true,
                      onChange: (updater) => {
                        onChange((prev) => {
                          if (prev.type !== "row") return prev;
                          return {
                            ...prev,
                            columns: prev.columns.map(
                              (col, i) => i === index ? updater(col) : col
                            )
                          };
                        });
                      },
                      onProductsResolved,
                      productOptions,
                      productLoading,
                      onProductSearch,
                      onUploadError
                    },
                    void 0,
                    false,
                    {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 1323,
                      columnNumber: 21
                    },
                    this
                  )
                ]
              },
              column.id,
              true,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1300,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1298,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 1270,
          columnNumber: 11
        }, this) : section.type === "story_links" ? /* @__PURE__ */ jsxDEV(
          StoryLinksEditor,
          {
            section,
            onChange,
            onUploadError
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1349,
            columnNumber: 11
          },
          this
        ) : section.type === "image_slider" ? /* @__PURE__ */ jsxDEV(
          ImageSliderEditor,
          {
            section,
            onChange,
            onUploadError
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1355,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          ContentBlockEditor,
          {
            block: section,
            onChange: (updater) => {
              onChange(
                (prev) => prev.type === "banner" || prev.type === "product_slider" ? updater(prev) : prev
              );
            },
            onProductsResolved,
            productOptions,
            productLoading,
            onProductSearch,
            onUploadError
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1361,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 1268,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
          lineNumber: 1267,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
      lineNumber: 1186,
      columnNumber: 5
    },
    this
  );
};
_s4(SortableSection, "iTIyvp0X9kMGpdHRsWsr2+tGbVI=", false, function() {
  return [useSortable];
});
_c4 = SortableSection;
export const HomepageEditor = () => {
  _s5();
  const notify = useNotify();
  const dataProvider = useDataProvider();
  const searchTimer = useRef(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates
    })
  );
  const [layout, setLayout] = useState(emptyHomepageLayout);
  const [deviceTab, setDeviceTab] = useState("desktop");
  const [expandedIds, setExpandedIds] = useState(/* @__PURE__ */ new Set());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [productOptions, setProductOptions] = useState([]);
  const [productLoading, setProductLoading] = useState(false);
  const layoutRef = useRef(layout);
  layoutRef.current = layout;
  const deviceTabRef = useRef(deviceTab);
  deviceTabRef.current = deviceTab;
  const sections = layout[deviceTab];
  const loadProducts = useCallback(
    async (search = "", keepIds = []) => {
      setProductLoading(true);
      try {
        const result = await dataProvider.getList("product", {
          pagination: { page: 1, perPage: 50 },
          sort: { field: "id", order: "DESC" },
          filter: search ? { q: search } : {}
        });
        const mapped = result.data.map((p) => ({
          id: Number(p.id),
          enName: p.enName,
          prName: p.prName
        }));
        setProductOptions((prev) => {
          const kept = prev.filter((p) => keepIds.includes(p.id));
          return mergeProductOptions(kept, mapped);
        });
      } catch {
        notify("Failed to load products", { type: "error" });
      } finally {
        setProductLoading(false);
      }
    },
    [dataProvider, notify]
  );
  const hydrateSelectedProducts = useCallback(
    async (ids) => {
      if (ids.length === 0) return;
      try {
        const result = await dataProvider.getMany("product", { ids });
        const mapped = result.data.map((p) => ({
          id: Number(p.id),
          enName: p.enName,
          prName: p.prName
        }));
        setProductOptions((prev) => mergeProductOptions(prev, mapped));
      } catch {
      }
    },
    [dataProvider]
  );
  const loadHomepage = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getHomepageAdmin();
      const nextLayout = normalizeHomepageLayout(data.sections);
      setLayout(nextLayout);
      setExpandedIds(
        /* @__PURE__ */ new Set(
          [
            ...nextLayout.desktop.map((s) => s.id),
            ...nextLayout.mobile.map((s) => s.id)
          ]
        )
      );
      setDirty(false);
      const selectedIds = collectLayoutProductIds(nextLayout);
      await hydrateSelectedProducts(selectedIds);
      await loadProducts("", selectedIds);
    } catch {
      notify("Failed to load homepage", { type: "error" });
    } finally {
      setLoading(false);
    }
  }, [hydrateSelectedProducts, loadProducts, notify]);
  useEffect(() => {
    void loadHomepage();
  }, [loadHomepage]);
  useEffect(() => {
    return () => {
      if (searchTimer.current) clearTimeout(searchTimer.current);
    };
  }, []);
  const onProductSearch = (query) => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      void loadProducts(
        query.trim(),
        collectLayoutProductIds(layoutRef.current)
      );
    }, 300);
  };
  const setDeviceSections = (updater) => {
    const tab = deviceTabRef.current;
    setLayout((prev) => ({
      ...prev,
      [tab]: updater(prev[tab])
    }));
    setDirty(true);
  };
  const updateSection = (id, updater) => {
    setDeviceSections(
      (prev) => prev.map((s) => s.id === id ? updater(s) : s)
    );
  };
  const removeSection = (id) => {
    setDeviceSections((prev) => prev.filter((s) => s.id !== id));
    setExpandedIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  };
  const addSection = (section) => {
    setDeviceSections((prev) => [...prev, section]);
    setExpandedIds((prev) => new Set(prev).add(section.id));
  };
  const onDragEnd = (event) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    setDeviceSections((prev) => {
      const oldIndex = prev.findIndex((s) => s.id === active.id);
      const newIndex = prev.findIndex((s) => s.id === over.id);
      if (oldIndex < 0 || newIndex < 0) return prev;
      return arrayMove(prev, oldIndex, newIndex);
    });
  };
  const copyDesktopToMobile = () => {
    const mobile = cloneSectionsWithNewIds(layoutRef.current.desktop);
    setLayout((prev) => ({
      ...prev,
      mobile
    }));
    setExpandedIds((prev) => {
      const next = new Set(prev);
      for (const section of mobile) {
        next.add(section.id);
      }
      return next;
    });
    setDeviceTab("mobile");
    setDirty(true);
    notify("Copied desktop layout to mobile", { type: "info" });
  };
  const handleSave = async () => {
    const current = layoutRef.current;
    const desktopError = findFirstInvalidMessage(current.desktop, "Desktop");
    if (desktopError) {
      setDeviceTab("desktop");
      notify(desktopError, { type: "warning" });
      return;
    }
    const mobileError = findFirstInvalidMessage(current.mobile, "Mobile");
    if (mobileError) {
      setDeviceTab("mobile");
      notify(mobileError, { type: "warning" });
      return;
    }
    const payload = {
      desktop: sanitizeSections(current.desktop),
      mobile: sanitizeSections(current.mobile)
    };
    setSaving(true);
    try {
      const data = await updateHomepage(payload);
      setLayout(normalizeHomepageLayout(data.sections));
      setDirty(false);
      notify("Homepage saved", { type: "success" });
    } catch {
      notify("Failed to save homepage", { type: "error" });
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Box, { sx: { p: 3, pb: 10 }, children: [
    /* @__PURE__ */ jsxDEV(Title, { title: "Homepage" }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
      lineNumber: 1598,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 2,
          mb: 2
        },
        children: [
          /* @__PURE__ */ jsxDEV(Box, { children: [
            /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", sx: { fontWeight: 700 }, children: "Homepage builder" }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1611,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", children: "Build separate desktop and mobile layouts. Use rows for equal-width side-by-side banners or sliders." }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1614,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1610,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", gap: 1, flexWrap: "wrap" }, children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "outlined",
                onClick: () => addSection(createBanner()),
                startIcon: /* @__PURE__ */ jsxDEV(ImageIcon, {}, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1624,
                  columnNumber: 24
                }, this),
                children: "Add banner"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1621,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "outlined",
                onClick: () => addSection(createImageSlider()),
                startIcon: /* @__PURE__ */ jsxDEV(CollectionsIcon, {}, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1631,
                  columnNumber: 24
                }, this),
                children: "Add image slider"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1628,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "outlined",
                onClick: () => addSection(createStoryLinks()),
                startIcon: /* @__PURE__ */ jsxDEV(CircleOutlinedIcon, {}, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1638,
                  columnNumber: 24
                }, this),
                children: "Add story links"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1635,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "outlined",
                onClick: () => addSection(createSlider()),
                startIcon: /* @__PURE__ */ jsxDEV(ViewCarouselIcon, {}, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1645,
                  columnNumber: 24
                }, this),
                children: "Add product slider"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1642,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: "outlined",
                onClick: () => addSection(createRow(2)),
                startIcon: /* @__PURE__ */ jsxDEV(ViewWeekIcon, {}, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1652,
                  columnNumber: 24
                }, this),
                children: "Add row"
              },
              void 0,
              false,
              {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1649,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1620,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 1600,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 1,
          mb: 3,
          borderBottom: 1,
          borderColor: "divider"
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            Tabs,
            {
              value: deviceTab,
              onChange: (_, value) => setDeviceTab(value),
              children: [
                /* @__PURE__ */ jsxDEV(
                  Tab,
                  {
                    value: "desktop",
                    label: "Desktop",
                    icon: /* @__PURE__ */ jsxDEV(ComputerIcon, {}, void 0, false, {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 1678,
                      columnNumber: 19
                    }, this),
                    iconPosition: "start"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1675,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Tab,
                  {
                    value: "mobile",
                    label: "Mobile",
                    icon: /* @__PURE__ */ jsxDEV(SmartphoneIcon, {}, void 0, false, {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 1684,
                      columnNumber: 19
                    }, this),
                    iconPosition: "start"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1681,
                    columnNumber: 11
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1671,
              columnNumber: 9
            },
            this
          ),
          deviceTab === "mobile" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "small",
              variant: "text",
              startIcon: /* @__PURE__ */ jsxDEV(ContentCopyIcon, {}, void 0, false, {
                fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                lineNumber: 1693,
                columnNumber: 22
              }, this),
              onClick: copyDesktopToMobile,
              disabled: layout.desktop.length === 0,
              children: "Copy desktop → mobile"
            },
            void 0,
            false,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1690,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 1659,
        columnNumber: 7
      },
      this
    ),
    loading ? /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", justifyContent: "center", py: 8 }, children: /* @__PURE__ */ jsxDEV(CircularProgress, {}, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
      lineNumber: 1704,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
      lineNumber: 1703,
      columnNumber: 7
    }, this) : sections.length === 0 ? /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          p: 4,
          textAlign: "center",
          borderRadius: 2,
          border: "1px solid",
          borderColor: "divider",
          bgcolor: "background.paper"
        },
        children: [
          /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", sx: { mb: 2 }, children: deviceTab === "mobile" ? "Mobile layout is empty. Add sections or copy from desktop so mobile visitors are not left with a blank homepage." : "No sections yet. Add a banner, image slider, story links, product slider, or row to get started." }, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1717,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            Box,
            {
              sx: {
                display: "flex",
                gap: 1,
                justifyContent: "center",
                flexWrap: "wrap"
              },
              children: [
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "contained",
                    onClick: () => addSection(createBanner()),
                    children: "Add banner"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1730,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "outlined",
                    onClick: () => addSection(createImageSlider()),
                    children: "Add image slider"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1736,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "outlined",
                    onClick: () => addSection(createStoryLinks()),
                    children: "Add story links"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1742,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "outlined",
                    onClick: () => addSection(createSlider()),
                    children: "Add product slider"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1748,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", onClick: () => addSection(createRow(2)), children: "Add row" }, void 0, false, {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1754,
                  columnNumber: 13
                }, this),
                deviceTab === "mobile" && layout.desktop.length > 0 && /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "outlined",
                    startIcon: /* @__PURE__ */ jsxDEV(ContentCopyIcon, {}, void 0, false, {
                      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                      lineNumber: 1760,
                      columnNumber: 24
                    }, this),
                    onClick: copyDesktopToMobile,
                    children: "Copy desktop → mobile"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                    lineNumber: 1758,
                    columnNumber: 11
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1722,
              columnNumber: 11
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 1707,
        columnNumber: 7
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      DndContext,
      {
        sensors,
        collisionDetection: closestCenter,
        onDragEnd,
        children: /* @__PURE__ */ jsxDEV(
          SortableContext,
          {
            items: sections.map((s) => s.id),
            strategy: verticalListSortingStrategy,
            children: /* @__PURE__ */ jsxDEV(Box, { sx: { display: "flex", flexDirection: "column", gap: 2 }, children: sections.map(
              (section) => /* @__PURE__ */ jsxDEV(
                SortableSection,
                {
                  section,
                  expanded: expandedIds.has(section.id),
                  onToggle: () => setExpandedIds((prev) => {
                    const next = new Set(prev);
                    if (next.has(section.id)) next.delete(section.id);
                    else
                      next.add(section.id);
                    return next;
                  }),
                  onChange: (updater) => updateSection(section.id, updater),
                  onRemove: () => removeSection(section.id),
                  onProductsResolved: (products) => setProductOptions(
                    (prev) => mergeProductOptions(prev, products)
                  ),
                  productOptions,
                  productLoading,
                  onProductSearch,
                  onUploadError: () => notify("Image upload failed", { type: "error" })
                },
                section.id,
                false,
                {
                  fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
                  lineNumber: 1780,
                  columnNumber: 13
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1778,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
            lineNumber: 1774,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 1769,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        sx: {
          position: "sticky",
          bottom: 16,
          mt: 3,
          display: "flex",
          justifyContent: "flex-end",
          gap: 1,
          zIndex: 2,
          p: 1.5,
          borderRadius: 2,
          border: "1px solid",
          borderColor: "divider",
          bgcolor: "background.paper"
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "outlined",
              onClick: () => void loadHomepage(),
              disabled: loading || saving,
              children: "Reset"
            },
            void 0,
            false,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1828,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "contained",
              onClick: () => void handleSave(),
              disabled: loading || saving || !dirty,
              children: saving ? "Saving…" : "Save homepage"
            },
            void 0,
            false,
            {
              fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
              lineNumber: 1835,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
        lineNumber: 1812,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx",
    lineNumber: 1597,
    columnNumber: 5
  }, this);
};
_s5(HomepageEditor, "4+T3isE/BRtqN80sZwaezMpXwEw=", false, function() {
  return [useNotify, useDataProvider, useSensors, useSensor, useSensor];
});
_c5 = HomepageEditor;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "ContentBlockEditor");
$RefreshReg$(_c2, "StoryLinksEditor");
$RefreshReg$(_c3, "ImageSliderEditor");
$RefreshReg$(_c4, "SortableSection");
$RefreshReg$(_c5, "HomepageEditor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/pages/HomepageEditor.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOFhVLFNBTUYsVUFORTs7QUE5WFYsT0FBT0EsU0FBUztBQUNoQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MsdUJBQXVCO0FBQzlCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsYUFBYUMsV0FBV0MsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBRWxFLFNBQVNDLE9BQU9DLGlCQUFpQkMsaUJBQWlCO0FBQ2xEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FXSztBQUVQLE1BQU1DLGVBQWU7QUFhckIsTUFBTUMsUUFBUUEsTUFDWixPQUFPQyxXQUFXLGVBQWUsZ0JBQWdCQSxTQUM3Q0EsT0FBT0MsV0FBVyxJQUNsQixXQUFXQyxLQUFLQyxJQUFJLENBQUMsSUFBSUMsS0FBS0MsT0FBTyxFQUFFQyxTQUFTLEVBQUUsRUFBRUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUVyRSxNQUFNQyxlQUFlQSxPQUE4QjtBQUFBLEVBQ2pEQyxJQUFJVixNQUFNO0FBQUEsRUFDVlcsTUFBTTtBQUFBLEVBQ05DLFVBQVU7QUFBQSxFQUNWQyxNQUFNO0FBQUEsRUFDTkMsS0FBSztBQUNQO0FBRUEsTUFBTUMsZUFBZUEsT0FBcUM7QUFBQSxFQUN4REwsSUFBSVYsTUFBTTtBQUFBLEVBQ1ZXLE1BQU07QUFBQSxFQUNOSyxPQUFPO0FBQUEsRUFDUEMsWUFBWTtBQUFBLEVBQ1pDLGlCQUFpQjtBQUNuQjtBQUVBLE1BQU1DLGtCQUFrQkEsT0FBOEI7QUFBQSxFQUNwRFQsSUFBSVYsTUFBTTtBQUFBLEVBQ1ZZLFVBQVU7QUFBQSxFQUNWUSxPQUFPO0FBQUEsRUFDUFAsTUFBTTtBQUNSO0FBRUEsTUFBTVEsbUJBQW1CQSxPQUFrQztBQUFBLEVBQ3pEWCxJQUFJVixNQUFNO0FBQUEsRUFDVlcsTUFBTTtBQUFBLEVBQ05XLE9BQU8sQ0FBQ0gsZ0JBQWdCLENBQUM7QUFDM0I7QUFFQSxNQUFNSSxtQkFBbUJBLE9BQTJCO0FBQUEsRUFDbERiLElBQUlWLE1BQU07QUFBQSxFQUNWWSxVQUFVO0FBQUEsRUFDVkMsTUFBTTtBQUFBLEVBQ05DLEtBQUs7QUFDUDtBQUVBLE1BQU1VLG9CQUFvQkEsT0FBbUM7QUFBQSxFQUMzRGQsSUFBSVYsTUFBTTtBQUFBLEVBQ1ZXLE1BQU07QUFBQSxFQUNOYyxRQUFRLENBQUNGLGlCQUFpQixDQUFDO0FBQzdCO0FBRUEsTUFBTUcsWUFBWUEsQ0FBQ0MsY0FBYyxPQUEyQjtBQUFBLEVBQzFEakIsSUFBSVYsTUFBTTtBQUFBLEVBQ1ZXLE1BQU07QUFBQSxFQUNOaUIsU0FBU0MsTUFBTUMsS0FBSyxFQUFFQyxRQUFRSixZQUFZLEdBQUcsTUFBTWxCLGFBQWEsQ0FBQztBQUNuRTtBQUVBLE1BQU11QixzQkFBc0JBLENBQzFCQyxTQUNBQyxhQUNHO0FBQ0gsUUFBTUMsTUFBTSxvQkFBSUMsSUFBMkI7QUFDM0MsYUFBV0MsUUFBUSxDQUFDLEdBQUdKLFNBQVMsR0FBR0MsUUFBUSxHQUFHO0FBQzVDQyxRQUFJRyxJQUFJRCxLQUFLM0IsSUFBSTJCLElBQUk7QUFBQSxFQUN2QjtBQUNBLFNBQU9SLE1BQU1DLEtBQUtLLElBQUlJLE9BQU8sQ0FBQztBQUNoQztBQUVBLE1BQU1DLDBCQUEwQkEsQ0FBQ0MsV0FDL0JaLE1BQU1DO0FBQUFBLEVBQ0osSUFBSVk7QUFBQUEsSUFDRixDQUFDLEdBQUdELE9BQU9FLFNBQVMsR0FBR0YsT0FBT0csTUFBTSxFQUFFQyxRQUFRLENBQUNDLFlBQVk7QUFDekQsVUFBSUEsUUFBUW5DLFNBQVMsaUJBQWtCLFFBQU9tQyxRQUFRN0I7QUFDdEQsVUFBSTZCLFFBQVFuQyxTQUFTLE9BQU87QUFDMUIsZUFBT21DLFFBQVFsQixRQUFRaUI7QUFBQUEsVUFBUSxDQUFDRSxXQUM5QkEsT0FBT3BDLFNBQVMsbUJBQW1Cb0MsT0FBTzlCLGFBQWE7QUFBQSxRQUN6RDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUYsTUFBTStCLDBCQUEwQkEsQ0FDOUJDLGFBRUFBLFNBQVNkLElBQUksQ0FBQ1csWUFBWTtBQUN4QixNQUFJQSxRQUFRbkMsU0FBUyxPQUFPO0FBQzFCLFdBQU87QUFBQSxNQUNMLEdBQUdtQztBQUFBQSxNQUNIcEMsSUFBSVYsTUFBTTtBQUFBLE1BQ1Y0QixTQUFTa0IsUUFBUWxCLFFBQVFPLElBQUksQ0FBQ1ksWUFBWTtBQUFBLFFBQ3hDLEdBQUdBO0FBQUFBLFFBQ0hyQyxJQUFJVixNQUFNO0FBQUEsTUFDWixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFDQSxNQUFJOEMsUUFBUW5DLFNBQVMsZUFBZTtBQUNsQyxXQUFPO0FBQUEsTUFDTCxHQUFHbUM7QUFBQUEsTUFDSHBDLElBQUlWLE1BQU07QUFBQSxNQUNWc0IsT0FBT3dCLFFBQVF4QixNQUFNYSxJQUFJLENBQUNFLFVBQVUsRUFBRSxHQUFHQSxNQUFNM0IsSUFBSVYsTUFBTSxFQUFFLEVBQUU7QUFBQSxJQUMvRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJOEMsUUFBUW5DLFNBQVMsZ0JBQWdCO0FBQ25DLFdBQU87QUFBQSxNQUNMLEdBQUdtQztBQUFBQSxNQUNIcEMsSUFBSVYsTUFBTTtBQUFBLE1BQ1Z5QixRQUFRcUIsUUFBUXJCLE9BQU9VLElBQUksQ0FBQ2UsV0FBVyxFQUFFLEdBQUdBLE9BQU94QyxJQUFJVixNQUFNLEVBQUUsRUFBRTtBQUFBLElBQ25FO0FBQUEsRUFDRjtBQUNBLFNBQU8sRUFBRSxHQUFHOEMsU0FBU3BDLElBQUlWLE1BQU0sRUFBRTtBQUNuQyxDQUFDO0FBRUgsTUFBTW1ELHVCQUF1QkEsQ0FDM0JDLFVBQ3lCO0FBQ3pCLE1BQUlBLE1BQU16QyxTQUFTLFVBQVU7QUFDM0IsV0FBTztBQUFBLE1BQ0xELElBQUkwQyxNQUFNMUM7QUFBQUEsTUFDVkMsTUFBTTtBQUFBLE1BQ05DLFVBQVV3QyxNQUFNeEMsU0FBU3lDLEtBQUs7QUFBQSxNQUM5QixHQUFJRCxNQUFNdkMsTUFBTXdDLEtBQUssSUFBSSxFQUFFeEMsTUFBTXVDLE1BQU12QyxLQUFLd0MsS0FBSyxFQUFFLElBQUksQ0FBQztBQUFBLE1BQ3hELEdBQUlELE1BQU10QyxLQUFLdUMsS0FBSyxJQUFJLEVBQUV2QyxLQUFLc0MsTUFBTXRDLElBQUl1QyxLQUFLLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBRUEsUUFBTW5DLGtCQUFrQmtDLE1BQU1sQyxpQkFBaUJtQyxLQUFLO0FBQ3BELFNBQU87QUFBQSxJQUNMM0MsSUFBSTBDLE1BQU0xQztBQUFBQSxJQUNWQyxNQUFNO0FBQUEsSUFDTkssT0FBT29DLE1BQU1wQyxNQUFNcUMsS0FBSztBQUFBLElBQ3hCcEMsWUFBWW1DLE1BQU1uQztBQUFBQSxJQUNsQixHQUFJQyxtQkFBbUJuQixhQUFhdUQsS0FBS3BDLGVBQWUsSUFDcEQsRUFBRUEsZ0JBQWdCLElBQ2xCLENBQUM7QUFBQSxFQUNQO0FBQ0Y7QUFFQSxNQUFNcUMsbUJBQW1CQSxDQUFDTixhQUN4QkEsU0FBU2QsSUFBSSxDQUFDVyxZQUFZO0FBQ3hCLE1BQUlBLFFBQVFuQyxTQUFTLE9BQU87QUFDMUIsV0FBTztBQUFBLE1BQ0xELElBQUlvQyxRQUFRcEM7QUFBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05pQixTQUFTa0IsUUFBUWxCLFFBQVFPLElBQUlnQixvQkFBb0I7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJTCxRQUFRbkMsU0FBUyxlQUFlO0FBQ2xDLFdBQU87QUFBQSxNQUNMRCxJQUFJb0MsUUFBUXBDO0FBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOVyxPQUFPd0IsUUFBUXhCLE1BQU1hLElBQUksQ0FBQ0UsVUFBVTtBQUFBLFFBQ2xDM0IsSUFBSTJCLEtBQUszQjtBQUFBQSxRQUNURSxVQUFVeUIsS0FBS3pCLFNBQVN5QyxLQUFLO0FBQUEsUUFDN0JqQyxPQUFPaUIsS0FBS2pCLE1BQU1pQyxLQUFLO0FBQUEsUUFDdkJ4QyxNQUFNd0IsS0FBS3hCLEtBQUt3QyxLQUFLO0FBQUEsTUFDdkIsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBQ0EsTUFBSVAsUUFBUW5DLFNBQVMsZ0JBQWdCO0FBQ25DLFdBQU87QUFBQSxNQUNMRCxJQUFJb0MsUUFBUXBDO0FBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOYyxRQUFRcUIsUUFBUXJCLE9BQU9VLElBQUksQ0FBQ2UsV0FBVztBQUFBLFFBQ3JDeEMsSUFBSXdDLE1BQU14QztBQUFBQSxRQUNWRSxVQUFVc0MsTUFBTXRDLFNBQVN5QyxLQUFLO0FBQUEsUUFDOUIsR0FBSUgsTUFBTXJDLE1BQU13QyxLQUFLLElBQUksRUFBRXhDLE1BQU1xQyxNQUFNckMsS0FBS3dDLEtBQUssRUFBRSxJQUFJLENBQUM7QUFBQSxRQUN4RCxHQUFJSCxNQUFNcEMsS0FBS3VDLEtBQUssSUFBSSxFQUFFdkMsS0FBS29DLE1BQU1wQyxJQUFJdUMsS0FBSyxFQUFFLElBQUksQ0FBQztBQUFBLE1BQ3ZELEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUNBLFNBQU9GLHFCQUFxQkwsT0FBTztBQUNyQyxDQUFDO0FBRUgsTUFBTVUsMEJBQTBCQSxDQUM5QlAsVUFDQVEsZ0JBQ2tCO0FBQ2xCLFdBQVNDLElBQUksR0FBR0EsSUFBSVQsU0FBU2xCLFFBQVEyQixLQUFLLEdBQUc7QUFDM0MsVUFBTVosVUFBVUcsU0FBU1MsQ0FBQztBQUMxQixVQUFNQyxXQUFXLEdBQUdGLFdBQVcsS0FBS0MsSUFBSSxDQUFDO0FBRXpDLFFBQUlaLFFBQVFuQyxTQUFTLE9BQU87QUFDMUIsVUFBSW1DLFFBQVFsQixRQUFRRyxTQUFTLEtBQUtlLFFBQVFsQixRQUFRRyxTQUFTLEdBQUc7QUFDNUQsZUFBTyxHQUFHNEIsUUFBUTtBQUFBLE1BQ3BCO0FBQ0EsZUFBU0MsSUFBSSxHQUFHQSxJQUFJZCxRQUFRbEIsUUFBUUcsUUFBUTZCLEtBQUssR0FBRztBQUNsRCxjQUFNYixTQUFTRCxRQUFRbEIsUUFBUWdDLENBQUM7QUFDaEMsWUFBSWIsT0FBT3BDLFNBQVMsWUFBWSxDQUFDb0MsT0FBT25DLFNBQVN5QyxLQUFLLEdBQUc7QUFDdkQsaUJBQU8sR0FBR00sUUFBUSxlQUFlQyxJQUFJLENBQUM7QUFBQSxRQUN4QztBQUNBLFlBQUliLE9BQU9wQyxTQUFTLG9CQUFvQixDQUFDb0MsT0FBTy9CLE1BQU1xQyxLQUFLLEdBQUc7QUFDNUQsaUJBQU8sR0FBR00sUUFBUSxlQUFlQyxJQUFJLENBQUM7QUFBQSxRQUN4QztBQUNBLFlBQ0ViLE9BQU9wQyxTQUFTLG9CQUNoQm9DLE9BQU83QixpQkFBaUJtQyxLQUFLLEtBQzdCLENBQUN0RCxhQUFhdUQsS0FBS1AsT0FBTzdCLGdCQUFnQm1DLEtBQUssQ0FBQyxHQUNoRDtBQUNBLGlCQUFPLEdBQUdNLFFBQVEsZUFBZUMsSUFBSSxDQUFDO0FBQUEsUUFDeEM7QUFBQSxNQUNGO0FBQ0E7QUFBQSxJQUNGO0FBRUEsUUFBSWQsUUFBUW5DLFNBQVMsWUFBWSxDQUFDbUMsUUFBUWxDLFNBQVN5QyxLQUFLLEdBQUc7QUFDekQsYUFBTyxHQUFHTSxRQUFRO0FBQUEsSUFDcEI7QUFDQSxRQUFJYixRQUFRbkMsU0FBUyxvQkFBb0IsQ0FBQ21DLFFBQVE5QixNQUFNcUMsS0FBSyxHQUFHO0FBQzlELGFBQU8sR0FBR00sUUFBUTtBQUFBLElBQ3BCO0FBQ0EsUUFDRWIsUUFBUW5DLFNBQVMsb0JBQ2pCbUMsUUFBUTVCLGlCQUFpQm1DLEtBQUssS0FDOUIsQ0FBQ3RELGFBQWF1RCxLQUFLUixRQUFRNUIsZ0JBQWdCbUMsS0FBSyxDQUFDLEdBQ2pEO0FBQ0EsYUFBTyxHQUFHTSxRQUFRO0FBQUEsSUFDcEI7QUFDQSxRQUFJYixRQUFRbkMsU0FBUyxlQUFlO0FBQ2xDLFVBQUltQyxRQUFReEIsTUFBTVMsU0FBUyxHQUFHO0FBQzVCLGVBQU8sR0FBRzRCLFFBQVE7QUFBQSxNQUNwQjtBQUNBLGVBQVNFLElBQUksR0FBR0EsSUFBSWYsUUFBUXhCLE1BQU1TLFFBQVE4QixLQUFLLEdBQUc7QUFDaEQsY0FBTXhCLE9BQU9TLFFBQVF4QixNQUFNdUMsQ0FBQztBQUM1QixZQUFJLENBQUN4QixLQUFLekIsU0FBU3lDLEtBQUssR0FBRztBQUN6QixpQkFBTyxHQUFHTSxRQUFRLGVBQWVFLElBQUksQ0FBQztBQUFBLFFBQ3hDO0FBQ0EsWUFBSSxDQUFDeEIsS0FBS2pCLE1BQU1pQyxLQUFLLEdBQUc7QUFDdEIsaUJBQU8sR0FBR00sUUFBUSxlQUFlRSxJQUFJLENBQUM7QUFBQSxRQUN4QztBQUNBLFlBQUksQ0FBQ3hCLEtBQUt4QixLQUFLd0MsS0FBSyxHQUFHO0FBQ3JCLGlCQUFPLEdBQUdNLFFBQVEsZUFBZUUsSUFBSSxDQUFDO0FBQUEsUUFDeEM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUlmLFFBQVFuQyxTQUFTLGdCQUFnQjtBQUNuQyxVQUFJbUMsUUFBUXJCLE9BQU9NLFNBQVMsR0FBRztBQUM3QixlQUFPLEdBQUc0QixRQUFRO0FBQUEsTUFDcEI7QUFDQSxlQUFTRSxJQUFJLEdBQUdBLElBQUlmLFFBQVFyQixPQUFPTSxRQUFROEIsS0FBSyxHQUFHO0FBQ2pELFlBQUksQ0FBQ2YsUUFBUXJCLE9BQU9vQyxDQUFDLEVBQUVqRCxTQUFTeUMsS0FBSyxHQUFHO0FBQ3RDLGlCQUFPLEdBQUdNLFFBQVEsVUFBVUUsSUFBSSxDQUFDO0FBQUEsUUFDbkM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFjQSxNQUFNQyxxQkFBcUJBLENBQUM7QUFBQSxFQUMxQlY7QUFBQUEsRUFDQVc7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsVUFBVTtBQUFBLEVBQ1ZDLGtCQUFrQjtBQUNLLE1BQU07QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSW5GLFNBQVMsS0FBSztBQUVoRCxRQUFNb0YsbUJBQW1CdEYsUUFBUSxNQUFNO0FBQ3JDLFFBQUlnRSxNQUFNekMsU0FBUyxpQkFBa0IsUUFBTztBQUM1QyxXQUFPeUMsTUFBTW5DLFdBQVdrQjtBQUFBQSxNQUN0QixDQUFDekIsT0FDQ3VELGVBQWVVLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRWxFLE9BQU9BLEVBQUUsS0FBSztBQUFBLFFBQ3pDQTtBQUFBQSxRQUNBbUUsUUFBUSxZQUFZbkUsRUFBRTtBQUFBLE1BQ3hCO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDMEMsT0FBT2EsY0FBYyxDQUFDO0FBRTFCLFFBQU1hLHNCQUFzQjFGO0FBQUFBLElBQzFCLE1BQU00QyxvQkFBb0JpQyxnQkFBZ0JTLGdCQUFnQjtBQUFBLElBQzFELENBQUNULGdCQUFnQlMsZ0JBQWdCO0FBQUEsRUFDbkM7QUFFQSxTQUNFLHVCQUFDLE9BQUksSUFBSSxFQUFFSyxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxFQUFFLEdBQ3pEWDtBQUFBQSx1QkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLE1BQUs7QUFBQSxRQUNMLE9BQU9sQixNQUFNekM7QUFBQUEsUUFDYixVQUFVLENBQUN1RSxHQUFHQyxVQUErQztBQUMzRCxjQUFJLENBQUNBLFNBQVNBLFVBQVUvQixNQUFNekMsS0FBTTtBQUNwQ29EO0FBQUFBLFlBQVMsQ0FBQ3FCLFNBQ1JELFVBQVUsV0FDTixFQUFFLEdBQUcxRSxhQUFhLEdBQUdDLElBQUkwRSxLQUFLMUUsR0FBRyxJQUNqQyxFQUFFLEdBQUdLLGFBQWEsR0FBR0wsSUFBSTBFLEtBQUsxRSxHQUFHO0FBQUEsVUFDdkM7QUFBQSxRQUNGO0FBQUEsUUFFQTtBQUFBLGlDQUFDLGdCQUFhLE9BQU0sVUFBUyxzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUM7QUFBQSxVQUNuQyx1QkFBQyxnQkFBYSxPQUFNLGtCQUFpQiw4QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQTtBQUFBO0FBQUEsTUFkckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZUE7QUFBQSxJQUdEMEMsTUFBTXpDLFNBQVMsV0FDZCxtQ0FDRTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJO0FBQUEsWUFDRm9FLFNBQVM7QUFBQSxZQUNUTSxVQUFVO0FBQUEsWUFDVkosS0FBSztBQUFBLFlBQ0xLLFlBQVk7QUFBQSxVQUNkO0FBQUEsVUFFQTtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSTtBQUFBLGtCQUNGQyxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSXBCLFVBQVUsTUFBTSxJQUFJO0FBQUEsa0JBQzdDcUIsUUFBUXJCLFVBQVUsS0FBSztBQUFBLGtCQUN2QnNCLGNBQWM7QUFBQSxrQkFDZEMsUUFBUTtBQUFBLGtCQUNSQyxhQUFhO0FBQUEsa0JBQ2JDLFVBQVU7QUFBQSxrQkFDVmYsU0FBUztBQUFBLGtCQUNUTyxZQUFZO0FBQUEsa0JBQ1pTLGdCQUFnQjtBQUFBLGtCQUNoQkMsU0FBUztBQUFBLGdCQUNYO0FBQUEsZ0JBRUM1QyxnQkFBTXhDLFdBQ0w7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLEtBQUt3QyxNQUFNeEM7QUFBQUEsb0JBQ1gsS0FBS3dDLE1BQU10QyxPQUFPO0FBQUEsb0JBQ2xCLElBQUksRUFBRXlFLE9BQU8sUUFBUUcsUUFBUSxRQUFRTyxXQUFXLFFBQVE7QUFBQTtBQUFBLGtCQUoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSTRELElBRzVELHVCQUFDLGNBQVcsU0FBUSxTQUFRLE9BQU0sa0JBQWdCLHdCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUE7QUFBQSxjQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUEwQkE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSTtBQUFBLGtCQUNGQyxNQUFNO0FBQUEsa0JBQ05DLFVBQVU5QixVQUFVLE1BQU07QUFBQSxrQkFDMUJVLFNBQVM7QUFBQSxrQkFDVEMsZUFBZTtBQUFBLGtCQUNmQyxLQUFLO0FBQUEsZ0JBQ1A7QUFBQSxnQkFFQTtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVE7QUFBQSxzQkFDUixXQUFVO0FBQUEsc0JBQ1YsVUFBVVQ7QUFBQUEsc0JBQ1YsTUFBTUgsVUFBVSxVQUFVO0FBQUEsc0JBRXpCRztBQUFBQSxvQ0FBWSxlQUFlO0FBQUEsd0JBQzVCO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTDtBQUFBLDRCQUNBLFFBQU87QUFBQSw0QkFDUCxVQUFVLE9BQU80QixNQUFNO0FBQ3JCLG9DQUFNQyxPQUFPRCxFQUFFRSxPQUFPQyxRQUFRLENBQUM7QUFDL0JILGdDQUFFRSxPQUFPbkIsUUFBUTtBQUNqQixrQ0FBSSxDQUFDa0IsS0FBTTtBQUNYNUIsMkNBQWEsSUFBSTtBQUNqQixrQ0FBSTtBQUNGLHNDQUFNK0IsT0FBTyxNQUFNMUcsYUFBYSxDQUFDdUcsSUFBSSxDQUFDO0FBQ3RDLG9DQUFJRyxPQUFPLENBQUMsR0FBRztBQUViekM7QUFBQUEsb0NBQVMsQ0FBQ3FCLFNBQ1JBLEtBQUt6RSxTQUFTLFdBQ1YsRUFBRSxHQUFHeUUsTUFBTXhFLFVBQVU0RixLQUFLLENBQUMsRUFBRSxJQUM3QnBCO0FBQUFBLGtDQUNOO0FBQUEsZ0NBQ0Y7QUFBQSw4QkFDRixRQUFRO0FBQ05oQiw4Q0FBYztBQUFBLDhCQUNoQixVQUFDO0FBQ0NLLDZDQUFhLEtBQUs7QUFBQSw4QkFDcEI7QUFBQSw0QkFDRjtBQUFBO0FBQUEsMEJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF3Qkk7QUFBQTtBQUFBO0FBQUEsb0JBL0JOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQ0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT3JCLE1BQU14QztBQUFBQSxzQkFDYixVQUFVLENBQUN3RixNQUFNO0FBQ2YsOEJBQU14RixXQUFXd0YsRUFBRUUsT0FBT25CO0FBQzFCcEI7QUFBQUEsMEJBQVMsQ0FBQ3FCLFNBQ1JBLEtBQUt6RSxTQUFTLFdBQVcsRUFBRSxHQUFHeUUsTUFBTXhFLFNBQVMsSUFBSXdFO0FBQUFBLHdCQUNuRDtBQUFBLHNCQUNGO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQSxNQUFLO0FBQUEsc0JBQ0wsWUFBVztBQUFBO0FBQUEsb0JBWGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVcrQztBQUFBO0FBQUE7QUFBQSxjQXREakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd0RBO0FBQUE7QUFBQTtBQUFBLFFBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTZGQTtBQUFBLE1BRUEsdUJBQUMsT0FBSSxJQUFJLEVBQUVMLFNBQVMsUUFBUU0sVUFBVSxRQUFRSixLQUFLLEVBQUUsR0FDbkQ7QUFBQSwrQkFBQyxPQUFJLElBQUksRUFBRU0sT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9yQyxNQUFNdkMsUUFBUTtBQUFBLFlBQ3JCLFVBQVUsQ0FBQ3VGLE1BQU07QUFDZixvQkFBTXZGLE9BQU91RixFQUFFRSxPQUFPbkI7QUFDdEJwQjtBQUFBQSxnQkFBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsV0FBVyxFQUFFLEdBQUd5RSxNQUFNdkUsS0FBSyxJQUFJdUU7QUFBQUEsY0FDL0M7QUFBQSxZQUNGO0FBQUEsWUFDQTtBQUFBLFlBQ0EsTUFBSztBQUFBO0FBQUEsVUFWUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVYyxLQVhoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFRyxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT3JDLE1BQU10QyxPQUFPO0FBQUEsWUFDcEIsVUFBVSxDQUFDc0YsTUFBTTtBQUNmLG9CQUFNdEYsTUFBTXNGLEVBQUVFLE9BQU9uQjtBQUNyQnBCO0FBQUFBLGdCQUFTLENBQUNxQixTQUNSQSxLQUFLekUsU0FBUyxXQUFXLEVBQUUsR0FBR3lFLE1BQU10RSxJQUFJLElBQUlzRTtBQUFBQSxjQUM5QztBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsWUFDQSxNQUFLO0FBQUE7QUFBQSxVQVZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVjLEtBWGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxTQTdIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEhBLElBRUEsbUNBQ0U7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBT2hDLE1BQU1wQztBQUFBQSxVQUNiLFVBQVUsQ0FBQ29GLE1BQU07QUFDZixrQkFBTXBGLFFBQVFvRixFQUFFRSxPQUFPbkI7QUFDdkJwQjtBQUFBQSxjQUFTLENBQUNxQixTQUNSQSxLQUFLekUsU0FBUyxtQkFBbUIsRUFBRSxHQUFHeUUsTUFBTXBFLE1BQU0sSUFBSW9FO0FBQUFBLFlBQ3hEO0FBQUEsVUFDRjtBQUFBLFVBQ0E7QUFBQSxVQUNBLE1BQUs7QUFBQSxVQUNMLFVBQVE7QUFBQTtBQUFBLFFBWFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BV1U7QUFBQSxNQUdWO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJO0FBQUEsWUFDRkwsU0FBUztBQUFBLFlBQ1RNLFVBQVU7QUFBQSxZQUNWSixLQUFLO0FBQUEsWUFDTEssWUFBWTtBQUFBLFVBQ2Q7QUFBQSxVQUVBO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFJO0FBQUEsa0JBQ0ZDLE9BQU87QUFBQSxrQkFDUEcsUUFBUTtBQUFBLGtCQUNSQyxjQUFjO0FBQUEsa0JBQ2RDLFFBQVE7QUFBQSxrQkFDUkMsYUFBYTtBQUFBLGtCQUNiRyxTQUFTakcsYUFBYXVELEtBQUtGLE1BQU1sQyxpQkFBaUJtQyxLQUFLLEtBQUssRUFBRSxJQUMxREQsTUFBTWxDLGtCQUNOO0FBQUEsa0JBQ0p1RixpQkFBaUIsQ0FBQzFHLGFBQWF1RDtBQUFBQSxvQkFDN0JGLE1BQU1sQyxpQkFBaUJtQyxLQUFLLEtBQUs7QUFBQSxrQkFDbkMsSUFDSSxpTkFDQXFEO0FBQUFBLGtCQUNKQyxnQkFBZ0I7QUFBQSxrQkFDaEJDLG9CQUFvQjtBQUFBLGdCQUN0QjtBQUFBO0FBQUEsY0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaUJJO0FBQUEsWUFFSjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsT0FDRTdHLGFBQWF1RCxLQUFLRixNQUFNbEMsaUJBQWlCbUMsS0FBSyxLQUFLLEVBQUUsSUFDakRELE1BQU1sQyxnQkFBaUJtQyxLQUFLLElBQzVCO0FBQUEsZ0JBRU4sVUFBVSxDQUFDK0MsTUFBcUM7QUFDOUMsd0JBQU1sRixrQkFBa0JrRixFQUFFRSxPQUFPbkI7QUFDakNwQjtBQUFBQSxvQkFBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsbUJBQ1YsRUFBRSxHQUFHeUUsTUFBTWxFLGdCQUFnQixJQUMzQmtFO0FBQUFBLGtCQUNOO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxJQUFJO0FBQUEsa0JBQ0ZHLE9BQU87QUFBQSxrQkFDUEcsUUFBUTtBQUFBLGtCQUNSZCxHQUFHO0FBQUEsa0JBQ0hnQixRQUFRO0FBQUEsa0JBQ1JDLGFBQWE7QUFBQSxrQkFDYkYsY0FBYztBQUFBLGtCQUNka0IsUUFBUTtBQUFBLGtCQUNSYixTQUFTO0FBQUEsZ0JBQ1g7QUFBQTtBQUFBLGNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXlCSTtBQUFBLFlBRUosdUJBQUMsT0FBSSxJQUFJLEVBQUVFLE1BQU0sR0FBR0MsVUFBVSxJQUFJLEdBQ2hDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE9BQU8vQyxNQUFNbEMsbUJBQW1CO0FBQUEsZ0JBQ2hDLFVBQVUsQ0FBQ2tGLE1BQU07QUFDZix3QkFBTWxGLGtCQUFrQmtGLEVBQUVFLE9BQU9uQjtBQUNqQ3BCO0FBQUFBLG9CQUFTLENBQUNxQixTQUNSQSxLQUFLekUsU0FBUyxtQkFDVixFQUFFLEdBQUd5RSxNQUFNbEUsZ0JBQWdCLElBQzNCa0U7QUFBQUEsa0JBQ047QUFBQSxnQkFDRjtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixZQUFXO0FBQUE7QUFBQSxjQWRiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNpRCxLQWZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGFBQ0VoQyxNQUFNbEMsbUJBQW1CLElBQUltQyxLQUFLLE1BQU0sTUFDeEM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUNQVTtBQUFBQSxrQkFBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsbUJBQ1YsRUFBRSxHQUFHeUUsTUFBTWxFLGlCQUFpQixHQUFHLElBQy9Ca0U7QUFBQUEsZ0JBQ047QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBO0FBQUE7QUFBQSxRQXBGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzRkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsU0FBU047QUFBQUEsVUFDVCxTQUFTWjtBQUFBQSxVQUNULE9BQU9RO0FBQUFBLFVBQ1A7QUFBQSxVQUNBLGVBQWUsQ0FBQ29DLFlBQVlBO0FBQUFBLFVBQzVCLGdCQUFnQixDQUFDQyxXQUNmQSxPQUFPbEMsVUFBVWtDLE9BQU9DLFVBQVUsSUFBSUQsT0FBT3JHLEVBQUU7QUFBQSxVQUVqRCxzQkFBc0IsQ0FBQ3VHLEdBQUdDLE1BQU1ELEVBQUV2RyxPQUFPd0csRUFBRXhHO0FBQUFBLFVBQzNDLGVBQWUsQ0FBQ3dFLEdBQUdDLE9BQU9nQyxXQUFXO0FBQ25DLGdCQUFJQSxXQUFXLFFBQVNoRCxpQkFBZ0JnQixLQUFLO0FBQUEsVUFDL0M7QUFBQSxVQUNBLFVBQVUsQ0FBQ0QsR0FBR0MsVUFBVTtBQUN0Qm5CLCtCQUFtQm1CLEtBQUs7QUFDeEIsa0JBQU1sRSxhQUFha0UsTUFBTWhELElBQUksQ0FBQ3lDLE1BQU1BLEVBQUVsRSxFQUFFO0FBQ3hDcUQ7QUFBQUEsY0FBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsbUJBQ1YsRUFBRSxHQUFHeUUsTUFBTW5FLFdBQVcsSUFDdEJtRTtBQUFBQSxZQUNOO0FBQUEsVUFDRjtBQUFBLFVBQ0EsYUFBYSxDQUFDZ0MsV0FDWjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsR0FBSUE7QUFBQUEsY0FDSixPQUFNO0FBQUEsY0FDTixNQUFLO0FBQUEsY0FDTCxZQUFXO0FBQUE7QUFBQSxZQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl3RDtBQUFBO0FBQUEsUUE1QjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQThCSTtBQUFBLFNBcklOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1SUE7QUFBQSxPQTVSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOFJBO0FBRUo7QUFBRTdDLEdBOVRJVCxvQkFBa0I7QUFBQSxLQUFsQkE7QUFzVU4sTUFBTXVELG1CQUFtQkEsQ0FBQztBQUFBLEVBQ3hCdkU7QUFBQUEsRUFDQWlCO0FBQUFBLEVBQ0FLO0FBQ3FCLE1BQU07QUFBQWtELE1BQUE7QUFDM0IsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlsSSxTQUF3QixJQUFJO0FBRWxFLFFBQU1tSSxhQUFhQSxDQUNqQkMsUUFDQUMsVUFDRztBQUNINUQsYUFBUyxDQUFDcUIsU0FBUztBQUNqQixVQUFJQSxLQUFLekUsU0FBUyxjQUFlLFFBQU95RTtBQUN4QyxhQUFPO0FBQUEsUUFDTCxHQUFHQTtBQUFBQSxRQUNIOUQsT0FBTzhELEtBQUs5RCxNQUFNYTtBQUFBQSxVQUFJLENBQUNFLFNBQ3JCQSxLQUFLM0IsT0FBT2dILFNBQVMsRUFBRSxHQUFHckYsTUFBTSxHQUFHc0YsTUFBTSxJQUFJdEY7QUFBQUEsUUFDL0M7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU11RixXQUFXQSxDQUFDQyxPQUFlQyxjQUFzQjtBQUNyRC9ELGFBQVMsQ0FBQ3FCLFNBQVM7QUFDakIsVUFBSUEsS0FBS3pFLFNBQVMsY0FBZSxRQUFPeUU7QUFDeEMsWUFBTTJDLFlBQVlGLFFBQVFDO0FBQzFCLFVBQUlDLFlBQVksS0FBS0EsYUFBYTNDLEtBQUs5RCxNQUFNUyxPQUFRLFFBQU9xRDtBQUM1RCxhQUFPLEVBQUUsR0FBR0EsTUFBTTlELE9BQU8xQyxVQUFVd0csS0FBSzlELE9BQU91RyxPQUFPRSxTQUFTLEVBQUU7QUFBQSxJQUNuRSxDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVoRCxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxFQUFFLEdBQ3pEbkM7QUFBQUEsWUFBUXhCLE1BQU1hO0FBQUFBLE1BQUksQ0FBQ0UsTUFBTXdGLFVBQ3hCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxJQUFJO0FBQUEsWUFDRjlDLFNBQVM7QUFBQSxZQUNUQyxlQUFlO0FBQUEsWUFDZkMsS0FBSztBQUFBLFlBQ0xMLEdBQUc7QUFBQSxZQUNIZSxjQUFjO0FBQUEsWUFDZEMsUUFBUTtBQUFBLFlBQ1JDLGFBQWE7QUFBQSxZQUNiRyxTQUFTO0FBQUEsVUFDWDtBQUFBLFVBRUE7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUk7QUFBQSxrQkFDRmpCLFNBQVM7QUFBQSxrQkFDVE8sWUFBWTtBQUFBLGtCQUNaUyxnQkFBZ0I7QUFBQSxrQkFDaEJkLEtBQUs7QUFBQSxnQkFDUDtBQUFBLGdCQUVBO0FBQUEseUNBQUMsY0FBVyxTQUFRLGFBQVksSUFBSSxFQUFFK0MsWUFBWSxJQUFJLEdBQUU7QUFBQTtBQUFBLG9CQUNoREgsUUFBUTtBQUFBLHVCQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBSSxJQUFJLEVBQUU5QyxTQUFTLFFBQVFFLEtBQUssSUFBSSxHQUNuQztBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxVQUFVNEMsVUFBVTtBQUFBLHdCQUNwQixTQUFTLE1BQU1ELFNBQVNDLE9BQU8sRUFBRTtBQUFBLHdCQUNqQyxjQUFXO0FBQUEsd0JBRVgsaUNBQUMsbUJBQWdCLFVBQVMsV0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBLHNCQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsVUFBVUEsVUFBVS9FLFFBQVF4QixNQUFNUyxTQUFTO0FBQUEsd0JBQzNDLFNBQVMsTUFBTTZGLFNBQVNDLE9BQU8sQ0FBQztBQUFBLHdCQUNoQyxjQUFXO0FBQUEsd0JBRVgsaUNBQUMscUJBQWtCLFVBQVMsV0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUM7QUFBQTtBQUFBLHNCQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsT0FBTTtBQUFBLHdCQUNOLFVBQVUvRSxRQUFReEIsTUFBTVMsVUFBVTtBQUFBLHdCQUNsQyxTQUFTLE1BQ1BnQztBQUFBQSwwQkFBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsZ0JBQ1Y7QUFBQSw0QkFDRSxHQUFHeUU7QUFBQUEsNEJBQ0g5RCxPQUFPOEQsS0FBSzlELE1BQU0yRyxPQUFPLENBQUN2RSxNQUFNQSxFQUFFaEQsT0FBTzJCLEtBQUszQixFQUFFO0FBQUEsMEJBQ2xELElBQ0EwRTtBQUFBQSx3QkFDTjtBQUFBLHdCQUVGLGNBQVc7QUFBQSx3QkFFWCxpQ0FBQyxzQkFBbUIsVUFBUyxXQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFvQztBQUFBO0FBQUEsc0JBaEJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaUJBO0FBQUEsdUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUNBO0FBQUE7QUFBQTtBQUFBLGNBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQStDQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFJO0FBQUEsa0JBQ0ZMLFNBQVM7QUFBQSxrQkFDVE0sVUFBVTtBQUFBLGtCQUNWSixLQUFLO0FBQUEsa0JBQ0xLLFlBQVk7QUFBQSxnQkFDZDtBQUFBLGdCQUVBO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSTtBQUFBLHdCQUNGQyxPQUFPO0FBQUEsd0JBQ1BHLFFBQVE7QUFBQSx3QkFDUkMsY0FBYztBQUFBLHdCQUNkQyxRQUFRO0FBQUEsd0JBQ1JDLGFBQWE7QUFBQSx3QkFDYkMsVUFBVTtBQUFBLHdCQUNWZixTQUFTO0FBQUEsd0JBQ1RPLFlBQVk7QUFBQSx3QkFDWlMsZ0JBQWdCO0FBQUEsd0JBQ2hCQyxTQUFTO0FBQUEsd0JBQ1RrQyxZQUFZO0FBQUEsc0JBQ2Q7QUFBQSxzQkFFQzdGLGVBQUt6QixXQUNKO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixLQUFLeUIsS0FBS3pCO0FBQUFBLDBCQUNWLEtBQUt5QixLQUFLakIsU0FBUztBQUFBLDBCQUNuQixJQUFJLEVBQUVtRSxPQUFPLFFBQVFHLFFBQVEsUUFBUU8sV0FBVyxRQUFRO0FBQUE7QUFBQSx3QkFKMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUk0RCxJQUc1RCx1QkFBQyxzQkFBbUIsT0FBTSxjQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQztBQUFBO0FBQUEsb0JBdkJ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBeUJBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSTtBQUFBLHdCQUNGQyxNQUFNO0FBQUEsd0JBQ05DLFVBQVU7QUFBQSx3QkFDVnBCLFNBQVM7QUFBQSx3QkFDVEMsZUFBZTtBQUFBLHdCQUNmQyxLQUFLO0FBQUEsc0JBQ1A7QUFBQSxzQkFFQTtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFNBQVE7QUFBQSw0QkFDUixXQUFVO0FBQUEsNEJBQ1YsVUFBVXNDLGdCQUFnQmxGLEtBQUszQjtBQUFBQSw0QkFDL0IsTUFBSztBQUFBLDRCQUVKNkc7QUFBQUEsOENBQWdCbEYsS0FBSzNCLEtBQUssZUFBZTtBQUFBLDhCQUMxQztBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxNQUFLO0FBQUEsa0NBQ0w7QUFBQSxrQ0FDQSxRQUFPO0FBQUEsa0NBQ1AsVUFBVSxPQUFPMEYsTUFBTTtBQUNyQiwwQ0FBTUMsT0FBT0QsRUFBRUUsT0FBT0MsUUFBUSxDQUFDO0FBQy9CSCxzQ0FBRUUsT0FBT25CLFFBQVE7QUFDakIsd0NBQUksQ0FBQ2tCLEtBQU07QUFDWG1CLG1EQUFlbkYsS0FBSzNCLEVBQUU7QUFDdEIsd0NBQUk7QUFDRiw0Q0FBTThGLE9BQU8sTUFBTTFHLGFBQWEsQ0FBQ3VHLElBQUksQ0FBQztBQUN0QywwQ0FBSUcsT0FBTyxDQUFDLEVBQUdpQixZQUFXcEYsS0FBSzNCLElBQUksRUFBRUUsVUFBVTRGLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFBQSxvQ0FDMUQsUUFBUTtBQUNOcEMsb0RBQWM7QUFBQSxvQ0FDaEIsVUFBQztBQUNDb0QscURBQWUsSUFBSTtBQUFBLG9DQUNyQjtBQUFBLGtDQUNGO0FBQUE7QUFBQSxnQ0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQWlCSTtBQUFBO0FBQUE7QUFBQSwwQkF4Qk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTBCQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE9BQU07QUFBQSw0QkFDTixPQUFPbkYsS0FBS3pCO0FBQUFBLDRCQUNaLFVBQVUsQ0FBQ3dGLE1BQ1RxQixXQUFXcEYsS0FBSzNCLElBQUksRUFBRUUsVUFBVXdGLEVBQUVFLE9BQU9uQixNQUFNLENBQUM7QUFBQSw0QkFFbEQ7QUFBQSw0QkFDQSxNQUFLO0FBQUE7QUFBQSwwQkFQUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT2M7QUFBQTtBQUFBO0FBQUEsb0JBM0NoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBNkNBO0FBQUE7QUFBQTtBQUFBLGNBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlGQTtBQUFBLFlBRUEsdUJBQUMsT0FBSSxJQUFJLEVBQUVKLFNBQVMsUUFBUU0sVUFBVSxRQUFRSixLQUFLLEVBQUUsR0FDbkQ7QUFBQSxxQ0FBQyxPQUFJLElBQUksRUFBRU0sT0FBTyxFQUFFQyxJQUFJLFFBQVFDLElBQUksa0JBQWtCLEVBQUUsR0FDdEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLE9BQU9wRCxLQUFLakI7QUFBQUEsa0JBQ1osVUFBVSxDQUFDZ0YsTUFBTXFCLFdBQVdwRixLQUFLM0IsSUFBSSxFQUFFVSxPQUFPZ0YsRUFBRUUsT0FBT25CLE1BQU0sQ0FBQztBQUFBLGtCQUM5RDtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxVQUFRO0FBQUE7QUFBQSxnQkFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNVSxLQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFSSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBT3BELEtBQUt4QjtBQUFBQSxrQkFDWixVQUFVLENBQUN1RixNQUFNcUIsV0FBV3BGLEtBQUszQixJQUFJLEVBQUVHLE1BQU11RixFQUFFRSxPQUFPbkIsTUFBTSxDQUFDO0FBQUEsa0JBQzdEO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLFVBQVE7QUFBQTtBQUFBLGdCQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1VLEtBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBO0FBQUE7QUFBQSxRQXJLSzlDLEtBQUszQjtBQUFBQSxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUF1S0E7QUFBQSxJQUNEO0FBQUEsSUFFRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsV0FBVyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUTtBQUFBLFFBQ25CLFNBQVMsTUFDUHFEO0FBQUFBLFVBQVMsQ0FBQ3FCLFNBQ1JBLEtBQUt6RSxTQUFTLGdCQUNWLEVBQUUsR0FBR3lFLE1BQU05RCxPQUFPLENBQUMsR0FBRzhELEtBQUs5RCxPQUFPSCxnQkFBZ0IsQ0FBQyxFQUFFLElBQ3JEaUU7QUFBQUEsUUFDTjtBQUFBLFFBQ0Q7QUFBQTtBQUFBLE1BVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUE7QUFBQSxPQXhMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUxBO0FBRUo7QUFBRWtDLElBM05JRCxrQkFBZ0I7QUFBQSxNQUFoQkE7QUFtT04sTUFBTWMsb0JBQW9CQSxDQUFDO0FBQUEsRUFDekJyRjtBQUFBQSxFQUNBaUI7QUFBQUEsRUFDQUs7QUFDc0IsTUFBTTtBQUFBZ0UsTUFBQTtBQUM1QixRQUFNLENBQUNiLGFBQWFDLGNBQWMsSUFBSWxJLFNBQXdCLElBQUk7QUFFbEUsUUFBTStJLGNBQWNBLENBQUNDLFNBQWlCWCxVQUF1QztBQUMzRTVELGFBQVMsQ0FBQ3FCLFNBQVM7QUFDakIsVUFBSUEsS0FBS3pFLFNBQVMsZUFBZ0IsUUFBT3lFO0FBQ3pDLGFBQU87QUFBQSxRQUNMLEdBQUdBO0FBQUFBLFFBQ0gzRCxRQUFRMkQsS0FBSzNELE9BQU9VO0FBQUFBLFVBQUksQ0FBQ2UsVUFDdkJBLE1BQU14QyxPQUFPNEgsVUFBVSxFQUFFLEdBQUdwRixPQUFPLEdBQUd5RSxNQUFNLElBQUl6RTtBQUFBQSxRQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTXFGLFlBQVlBLENBQUNWLE9BQWVDLGNBQXNCO0FBQ3REL0QsYUFBUyxDQUFDcUIsU0FBUztBQUNqQixVQUFJQSxLQUFLekUsU0FBUyxlQUFnQixRQUFPeUU7QUFDekMsWUFBTTJDLFlBQVlGLFFBQVFDO0FBQzFCLFVBQUlDLFlBQVksS0FBS0EsYUFBYTNDLEtBQUszRCxPQUFPTSxPQUFRLFFBQU9xRDtBQUM3RCxhQUFPLEVBQUUsR0FBR0EsTUFBTTNELFFBQVE3QyxVQUFVd0csS0FBSzNELFFBQVFvRyxPQUFPRSxTQUFTLEVBQUU7QUFBQSxJQUNyRSxDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQ0UsdUJBQUMsT0FBSSxJQUFJLEVBQUVoRCxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxFQUFFLEdBQ3pEbkM7QUFBQUEsWUFBUXJCLE9BQU9VO0FBQUFBLE1BQUksQ0FBQ2UsT0FBTzJFLFVBQzFCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxJQUFJO0FBQUEsWUFDRjlDLFNBQVM7QUFBQSxZQUNUQyxlQUFlO0FBQUEsWUFDZkMsS0FBSztBQUFBLFlBQ0xMLEdBQUc7QUFBQSxZQUNIZSxjQUFjO0FBQUEsWUFDZEMsUUFBUTtBQUFBLFlBQ1JDLGFBQWE7QUFBQSxZQUNiRyxTQUFTO0FBQUEsVUFDWDtBQUFBLFVBRUE7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUk7QUFBQSxrQkFDRmpCLFNBQVM7QUFBQSxrQkFDVE8sWUFBWTtBQUFBLGtCQUNaUyxnQkFBZ0I7QUFBQSxrQkFDaEJkLEtBQUs7QUFBQSxnQkFDUDtBQUFBLGdCQUVBO0FBQUEseUNBQUMsY0FBVyxTQUFRLGFBQVksSUFBSSxFQUFFK0MsWUFBWSxJQUFJLEdBQUU7QUFBQTtBQUFBLG9CQUMvQ0gsUUFBUTtBQUFBLHVCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBSSxJQUFJLEVBQUU5QyxTQUFTLFFBQVFFLEtBQUssSUFBSSxHQUNuQztBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxVQUFVNEMsVUFBVTtBQUFBLHdCQUNwQixTQUFTLE1BQU1VLFVBQVVWLE9BQU8sRUFBRTtBQUFBLHdCQUNsQyxjQUFXO0FBQUEsd0JBRVgsaUNBQUMsbUJBQWdCLFVBQVMsV0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBLHNCQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsVUFBVUEsVUFBVS9FLFFBQVFyQixPQUFPTSxTQUFTO0FBQUEsd0JBQzVDLFNBQVMsTUFBTXdHLFVBQVVWLE9BQU8sQ0FBQztBQUFBLHdCQUNqQyxjQUFXO0FBQUEsd0JBRVgsaUNBQUMscUJBQWtCLFVBQVMsV0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUM7QUFBQTtBQUFBLHNCQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsT0FBTTtBQUFBLHdCQUNOLFVBQVUvRSxRQUFRckIsT0FBT00sVUFBVTtBQUFBLHdCQUNuQyxTQUFTLE1BQ1BnQztBQUFBQSwwQkFBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsaUJBQ1Y7QUFBQSw0QkFDRSxHQUFHeUU7QUFBQUEsNEJBQ0gzRCxRQUFRMkQsS0FBSzNELE9BQU93RyxPQUFPLENBQUNPLE1BQU1BLEVBQUU5SCxPQUFPd0MsTUFBTXhDLEVBQUU7QUFBQSwwQkFDckQsSUFDQTBFO0FBQUFBLHdCQUNOO0FBQUEsd0JBRUYsY0FBVztBQUFBLHdCQUVYLGlDQUFDLHNCQUFtQixVQUFTLFdBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9DO0FBQUE7QUFBQSxzQkFoQnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFpQkE7QUFBQSx1QkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQ0E7QUFBQTtBQUFBO0FBQUEsY0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBK0NBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUk7QUFBQSxrQkFDRkwsU0FBUztBQUFBLGtCQUNUTSxVQUFVO0FBQUEsa0JBQ1ZKLEtBQUs7QUFBQSxrQkFDTEssWUFBWTtBQUFBLGdCQUNkO0FBQUEsZ0JBRUE7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxJQUFJO0FBQUEsd0JBQ0ZDLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLElBQUk7QUFBQSx3QkFDN0JDLFFBQVE7QUFBQSx3QkFDUkMsY0FBYztBQUFBLHdCQUNkQyxRQUFRO0FBQUEsd0JBQ1JDLGFBQWE7QUFBQSx3QkFDYkMsVUFBVTtBQUFBLHdCQUNWZixTQUFTO0FBQUEsd0JBQ1RPLFlBQVk7QUFBQSx3QkFDWlMsZ0JBQWdCO0FBQUEsd0JBQ2hCQyxTQUFTO0FBQUEsc0JBQ1g7QUFBQSxzQkFFQzlDLGdCQUFNdEMsV0FDTDtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsS0FBS3NDLE1BQU10QztBQUFBQSwwQkFDWCxLQUFLc0MsTUFBTXBDLE9BQU87QUFBQSwwQkFDbEIsSUFBSSxFQUFFeUUsT0FBTyxRQUFRRyxRQUFRLFFBQVFPLFdBQVcsUUFBUTtBQUFBO0FBQUEsd0JBSjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJNEQsSUFHNUQsdUJBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBZ0Isd0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQTtBQUFBLG9CQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBMEJBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSTtBQUFBLHdCQUNGQyxNQUFNO0FBQUEsd0JBQ05DLFVBQVU7QUFBQSx3QkFDVnBCLFNBQVM7QUFBQSx3QkFDVEMsZUFBZTtBQUFBLHdCQUNmQyxLQUFLO0FBQUEsc0JBQ1A7QUFBQSxzQkFFQTtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFNBQVE7QUFBQSw0QkFDUixXQUFVO0FBQUEsNEJBQ1YsVUFBVXNDLGdCQUFnQnJFLE1BQU14QztBQUFBQSw0QkFDaEMsTUFBSztBQUFBLDRCQUVKNkc7QUFBQUEsOENBQWdCckUsTUFBTXhDLEtBQUssZUFBZTtBQUFBLDhCQUMzQztBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxNQUFLO0FBQUEsa0NBQ0w7QUFBQSxrQ0FDQSxRQUFPO0FBQUEsa0NBQ1AsVUFBVSxPQUFPMEYsTUFBTTtBQUNyQiwwQ0FBTUMsT0FBT0QsRUFBRUUsT0FBT0MsUUFBUSxDQUFDO0FBQy9CSCxzQ0FBRUUsT0FBT25CLFFBQVE7QUFDakIsd0NBQUksQ0FBQ2tCLEtBQU07QUFDWG1CLG1EQUFldEUsTUFBTXhDLEVBQUU7QUFDdkIsd0NBQUk7QUFDRiw0Q0FBTThGLE9BQU8sTUFBTTFHLGFBQWEsQ0FBQ3VHLElBQUksQ0FBQztBQUN0QywwQ0FBSUcsT0FBTyxDQUFDO0FBQ1Y2QixvREFBWW5GLE1BQU14QyxJQUFJLEVBQUVFLFVBQVU0RixLQUFLLENBQUMsRUFBRSxDQUFDO0FBQUEsb0NBQy9DLFFBQVE7QUFDTnBDLG9EQUFjO0FBQUEsb0NBQ2hCLFVBQUM7QUFDQ29ELHFEQUFlLElBQUk7QUFBQSxvQ0FDckI7QUFBQSxrQ0FDRjtBQUFBO0FBQUEsZ0NBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFrQkk7QUFBQTtBQUFBO0FBQUEsMEJBekJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkEyQkE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFNO0FBQUEsNEJBQ04sT0FBT3RFLE1BQU10QztBQUFBQSw0QkFDYixVQUFVLENBQUN3RixNQUNUaUMsWUFBWW5GLE1BQU14QyxJQUFJLEVBQUVFLFVBQVV3RixFQUFFRSxPQUFPbkIsTUFBTSxDQUFDO0FBQUEsNEJBRXBEO0FBQUEsNEJBQ0EsTUFBSztBQUFBO0FBQUEsMEJBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU9jO0FBQUE7QUFBQTtBQUFBLG9CQTVDaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQThDQTtBQUFBO0FBQUE7QUFBQSxjQWxGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtRkE7QUFBQSxZQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFSixTQUFTLFFBQVFNLFVBQVUsUUFBUUosS0FBSyxFQUFFLEdBQ25EO0FBQUEscUNBQUMsT0FBSSxJQUFJLEVBQUVNLE9BQU8sRUFBRUMsSUFBSSxRQUFRQyxJQUFJLGtCQUFrQixFQUFFLEdBQ3REO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixPQUFPdkMsTUFBTXJDLFFBQVE7QUFBQSxrQkFDckIsVUFBVSxDQUFDdUYsTUFDVGlDLFlBQVluRixNQUFNeEMsSUFBSSxFQUFFRyxNQUFNdUYsRUFBRUUsT0FBT25CLE1BQU0sQ0FBQztBQUFBLGtCQUVoRDtBQUFBLGtCQUNBLE1BQUs7QUFBQTtBQUFBLGdCQVBQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9jLEtBUmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLE9BQUksSUFBSSxFQUFFSSxPQUFPLEVBQUVDLElBQUksUUFBUUMsSUFBSSxrQkFBa0IsRUFBRSxHQUN0RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBT3ZDLE1BQU1wQyxPQUFPO0FBQUEsa0JBQ3BCLFVBQVUsQ0FBQ3NGLE1BQU1pQyxZQUFZbkYsTUFBTXhDLElBQUksRUFBRUksS0FBS3NGLEVBQUVFLE9BQU9uQixNQUFNLENBQUM7QUFBQSxrQkFDOUQ7QUFBQSxrQkFDQSxNQUFLO0FBQUE7QUFBQSxnQkFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLYyxLQU5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUE7QUFBQTtBQUFBLFFBdktLakMsTUFBTXhDO0FBQUFBLFFBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXlLQTtBQUFBLElBQ0Q7QUFBQSxJQUVEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixXQUFXLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFRO0FBQUEsUUFDbkIsU0FBUyxNQUNQcUQ7QUFBQUEsVUFBUyxDQUFDcUIsU0FDUkEsS0FBS3pFLFNBQVMsaUJBQ1YsRUFBRSxHQUFHeUUsTUFBTTNELFFBQVEsQ0FBQyxHQUFHMkQsS0FBSzNELFFBQVFGLGlCQUFpQixDQUFDLEVBQUUsSUFDeEQ2RDtBQUFBQSxRQUNOO0FBQUEsUUFDRDtBQUFBO0FBQUEsTUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZQTtBQUFBLE9BMUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyTEE7QUFFSjtBQUFFZ0QsSUExTklELG1CQUFpQjtBQUFBLE1BQWpCQTtBQXlPTixNQUFNTSxlQUFlQSxDQUFDM0YsWUFBNkI7QUFDakQsTUFBSUEsUUFBUW5DLFNBQVMsU0FBVSxRQUFPO0FBQ3RDLE1BQUltQyxRQUFRbkMsU0FBUyxrQkFBa0I7QUFDckMsV0FBT21DLFFBQVE5QixTQUFTO0FBQUEsRUFDMUI7QUFDQSxNQUFJOEIsUUFBUW5DLFNBQVMsY0FBZSxRQUFPO0FBQzNDLE1BQUltQyxRQUFRbkMsU0FBUyxnQkFBZ0I7QUFDbkMsV0FBTyxpQkFBaUJtQyxRQUFRckIsT0FBT00sTUFBTTtBQUFBLEVBQy9DO0FBQ0EsU0FBTyxRQUFRZSxRQUFRbEIsUUFBUUcsTUFBTTtBQUN2QztBQUVBLE1BQU0yRyxjQUFjQSxDQUFDNUYsWUFBNkI7QUFDaEQsTUFBSUEsUUFBUW5DLFNBQVMsU0FBVSxRQUFPO0FBQ3RDLE1BQUltQyxRQUFRbkMsU0FBUyxpQkFBa0IsUUFBTztBQUM5QyxNQUFJbUMsUUFBUW5DLFNBQVMsY0FBZSxRQUFPO0FBQzNDLE1BQUltQyxRQUFRbkMsU0FBUyxlQUFnQixRQUFPO0FBQzVDLFNBQU87QUFDVDtBQUVBLE1BQU1nSSxrQkFBa0JBLENBQUM7QUFBQSxFQUN2QjdGO0FBQUFBLEVBQ0E4RjtBQUFBQSxFQUNBQztBQUFBQSxFQUNBOUU7QUFBQUEsRUFDQStFO0FBQUFBLEVBQ0E5RTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNvQixNQUFNO0FBQUEyRSxNQUFBO0FBQzFCLFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUl0SyxZQUFZLEVBQUUyQixJQUFJb0MsUUFBUXBDLEdBQUcsQ0FBQztBQUVsQyxRQUFNNEksUUFBUTtBQUFBLElBQ1pILFdBQVdsSyxJQUFJc0ssVUFBVWhKLFNBQVM0SSxTQUFTO0FBQUEsSUFDM0NDO0FBQUFBLElBQ0FJLFNBQVNILGFBQWEsTUFBTTtBQUFBLEVBQzlCO0FBRUEsUUFBTUksaUJBQWlCQSxDQUFDQyxVQUFrQjtBQUN4QzNGLGFBQVMsQ0FBQ3FCLFNBQVM7QUFDakIsVUFBSUEsS0FBS3pFLFNBQVMsTUFBTyxRQUFPeUU7QUFDaEMsWUFBTXVFLGNBQWMsQ0FBQyxHQUFHdkUsS0FBS3hELE9BQU87QUFDcEMsYUFBTytILFlBQVk1SCxTQUFTMkgsT0FBTztBQUNqQ0Msb0JBQVlDLEtBQUtuSixhQUFhLENBQUM7QUFBQSxNQUNqQztBQUNBLGFBQU9rSixZQUFZNUgsU0FBUzJILE9BQU87QUFDakNDLG9CQUFZRSxJQUFJO0FBQUEsTUFDbEI7QUFDQSxhQUFPLEVBQUUsR0FBR3pFLE1BQU14RCxTQUFTK0gsWUFBWTtBQUFBLElBQ3pDLENBQUM7QUFBQSxFQUNIO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsS0FBS1Q7QUFBQUEsTUFDTDtBQUFBLE1BQ0EsSUFBSTtBQUFBLFFBQ0ZwRCxVQUFVO0FBQUEsUUFDVkgsY0FBYztBQUFBLFFBQ2RDLFFBQVE7QUFBQSxRQUNSQyxhQUFhd0QsYUFBYSxpQkFBaUI7QUFBQSxRQUMzQ3JELFNBQVM7QUFBQSxRQUNUOEQsV0FBV1QsYUFBYSxJQUFJO0FBQUEsTUFDOUI7QUFBQSxNQUVBO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxjQUNGdEUsU0FBUztBQUFBLGNBQ1RPLFlBQVk7QUFBQSxjQUNaTCxLQUFLO0FBQUEsY0FDTDhFLElBQUk7QUFBQSxjQUNKQyxJQUFJO0FBQUEsY0FDSkMsY0FBY3JCLFdBQVcsY0FBYztBQUFBLGNBQ3ZDL0MsYUFBYTtBQUFBLGNBQ2JHLFNBQVNBLENBQUNrRSxVQUNSQSxNQUFNQyxRQUFRQyxTQUFTLFNBQ25CLGlCQUNBO0FBQUEsWUFDUjtBQUFBLFlBRUE7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsR0FBSXBCO0FBQUFBLGtCQUNKLEdBQUlDO0FBQUFBLGtCQUNKLGNBQVc7QUFBQSxrQkFDWCxJQUFJLEVBQUVwQyxRQUFRLFFBQVF3RCxPQUFPLGlCQUFpQjtBQUFBLGtCQUU5QyxpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQjtBQUFBO0FBQUEsZ0JBUHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsY0FFQ3ZILFFBQVFuQyxTQUFTLFdBQ2hCLHVCQUFDLGFBQVUsVUFBUyxTQUFRLElBQUksRUFBRTBKLE9BQU8saUJBQWlCLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRELElBQzFEdkgsUUFBUW5DLFNBQVMsbUJBQ25CLHVCQUFDLG9CQUFpQixVQUFTLFNBQVEsSUFBSSxFQUFFMEosT0FBTyxpQkFBaUIsS0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUUsSUFDakV2SCxRQUFRbkMsU0FBUyxnQkFDbkI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsVUFBUztBQUFBLGtCQUNULElBQUksRUFBRTBKLE9BQU8saUJBQWlCO0FBQUE7QUFBQSxnQkFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRWtDLElBRWhDdkgsUUFBUW5DLFNBQVMsaUJBQ25CLHVCQUFDLG1CQUFnQixVQUFTLFNBQVEsSUFBSSxFQUFFMEosT0FBTyxpQkFBaUIsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0UsSUFFbEUsdUJBQUMsZ0JBQWEsVUFBUyxTQUFRLElBQUksRUFBRUEsT0FBTyxpQkFBaUIsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Q7QUFBQSxjQUdqRSx1QkFBQyxjQUFXLElBQUksRUFBRW5FLE1BQU0sR0FBRzhCLFlBQVksS0FBS3FDLE9BQU8sZUFBZSxHQUMvRDVCLHVCQUFhM0YsT0FBTyxLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBTzRGLFlBQVk1RixPQUFPO0FBQUEsa0JBQzFCLFNBQVE7QUFBQSxrQkFDUixPQUFNO0FBQUE7QUFBQSxnQkFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJaUI7QUFBQSxjQUdqQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUytGO0FBQUFBLGtCQUNULGNBQVc7QUFBQSxrQkFDWCxJQUFJLEVBQUV3QixPQUFPLGlCQUFpQjtBQUFBLGtCQUU3QnpCLHFCQUFXLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWUsSUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUE7QUFBQSxnQkFObEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFNO0FBQUEsa0JBQ04sU0FBU0U7QUFBQUEsa0JBQ1QsY0FBVztBQUFBLGtCQUVYLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUE7QUFBQSxnQkFOckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQTtBQUFBO0FBQUEsVUFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUVBO0FBQUEsUUFFQSx1QkFBQyxZQUFTLElBQUlGLFVBQ1osaUNBQUMsT0FBSSxJQUFJLEVBQUVoRSxHQUFHLEdBQUdHLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLEVBQUUsR0FDL0RuQyxrQkFBUW5DLFNBQVMsUUFDaEIsbUNBQ0U7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBSTtBQUFBLGdCQUNGb0UsU0FBUztBQUFBLGdCQUNUTSxVQUFVO0FBQUEsZ0JBQ1ZDLFlBQVk7QUFBQSxnQkFDWkwsS0FBSztBQUFBLGNBQ1A7QUFBQSxjQUVBO0FBQUEsdUNBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxrQkFBZ0IscUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQztBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxPQUFPbkMsUUFBUWxCLFFBQVFHO0FBQUFBLG9CQUN2QixVQUFVLENBQUNtRCxHQUFHQyxVQUF5QjtBQUNyQywwQkFBSUEsTUFBT3NFLGdCQUFldEUsS0FBSztBQUFBLG9CQUNqQztBQUFBLG9CQUVDLFdBQUMsR0FBRyxHQUFHLENBQUMsRUFBRWhEO0FBQUFBLHNCQUFJLENBQUN1SCxVQUNkLHVCQUFDLGdCQUF5QixPQUFPQSxPQUM5QkEsbUJBRGdCQSxPQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBO0FBQUE7QUFBQSxZQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF5QkE7QUFBQSxVQUVBLHVCQUFDLE9BQUksSUFBSSxFQUFFM0UsU0FBUyxRQUFRTSxVQUFVLFFBQVFKLEtBQUssRUFBRSxHQUNsRG5DLGtCQUFRbEIsUUFBUU87QUFBQUEsWUFBSSxDQUFDWSxRQUFROEUsVUFDNUI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxJQUFJO0FBQUEsa0JBQ0Z0QyxPQUFPO0FBQUEsb0JBQ0xDLElBQUk7QUFBQSxvQkFDSkMsSUFBSSxRQUFRLE1BQU0zQyxRQUFRbEIsUUFBUUcsTUFBTSxRQUNwQ2UsUUFBUWxCLFFBQVFHLFNBQVMsS0FBSyxLQUNoQ2UsUUFBUWxCLFFBQVFHLE1BQU07QUFBQSxrQkFFMUI7QUFBQSxrQkFDQTZDLEdBQUc7QUFBQSxrQkFDSGUsY0FBYztBQUFBLGtCQUNkQyxRQUFRO0FBQUEsa0JBQ1JDLGFBQWE7QUFBQSxrQkFDYkcsU0FBUztBQUFBLGtCQUNUakIsU0FBUztBQUFBLGtCQUNUQyxlQUFlO0FBQUEsa0JBQ2ZDLEtBQUs7QUFBQSxnQkFDUDtBQUFBLGdCQUVBO0FBQUEseUNBQUMsY0FBVyxTQUFRLGFBQVksSUFBSSxFQUFFK0MsWUFBWSxJQUFJLEdBQUU7QUFBQTtBQUFBLG9CQUM5Q0gsUUFBUTtBQUFBLHVCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTzlFO0FBQUFBLHNCQUNQO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQSxVQUFVLENBQUN1SCxZQUFZO0FBQ3JCdkcsaUNBQVMsQ0FBQ3FCLFNBQVM7QUFDakIsOEJBQUlBLEtBQUt6RSxTQUFTLE1BQU8sUUFBT3lFO0FBQ2hDLGlDQUFPO0FBQUEsNEJBQ0wsR0FBR0E7QUFBQUEsNEJBQ0h4RCxTQUFTd0QsS0FBS3hELFFBQVFPO0FBQUFBLDhCQUFJLENBQUNvSSxLQUFLN0csTUFDOUJBLE1BQU1tRSxRQUFReUMsUUFBUUMsR0FBRyxJQUFJQTtBQUFBQSw0QkFDL0I7QUFBQSwwQkFDRjtBQUFBLHdCQUNGLENBQUM7QUFBQSxzQkFDSDtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQTtBQUFBLG9CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBbUIrQjtBQUFBO0FBQUE7QUFBQSxjQXpDMUJ4SCxPQUFPckM7QUFBQUEsY0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBNENBO0FBQUEsVUFDRCxLQS9DSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdEQTtBQUFBLGFBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2RUEsSUFDRW9DLFFBQVFuQyxTQUFTLGdCQUNuQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBO0FBQUEsVUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHK0IsSUFFN0JtQyxRQUFRbkMsU0FBUyxpQkFDbkI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQTtBQUFBLFVBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRytCLElBRy9CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPbUM7QUFBQUEsWUFDUCxVQUFVLENBQUN3SCxZQUFZO0FBQ3JCdkc7QUFBQUEsZ0JBQVMsQ0FBQ3FCLFNBQ1JBLEtBQUt6RSxTQUFTLFlBQVl5RSxLQUFLekUsU0FBUyxtQkFDcEMySixRQUFRbEYsSUFBSSxJQUNaQTtBQUFBQSxjQUNOO0FBQUEsWUFDRjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUE7QUFBQSxVQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWErQixLQTFHbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZHQSxLQTlHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0dBO0FBQUE7QUFBQTtBQUFBLElBaE1GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlNQTtBQUVKO0FBQUUyRCxJQTdPSUosaUJBQWU7QUFBQSxVQW1CZjVKLFdBQVc7QUFBQTtBQUFBLE1BbkJYNEo7QUErT0MsYUFBTTZCLGlCQUFpQkEsTUFBTTtBQUFBQyxNQUFBO0FBQ2xDLFFBQU1DLFNBQVNqTCxVQUFVO0FBQ3pCLFFBQU1rTCxlQUFlbkwsZ0JBQWdCO0FBQ3JDLFFBQU1vTCxjQUFjdkwsT0FBNkMsSUFBSTtBQUNyRSxRQUFNd0wsVUFBVWxNO0FBQUFBLElBQ2RELFVBQVVELGVBQWUsRUFBRXFNLHNCQUFzQixFQUFFQyxVQUFVLEVBQUUsRUFBRSxDQUFDO0FBQUEsSUFDbEVyTSxVQUFVRixnQkFBZ0I7QUFBQSxNQUN4QndNLGtCQUFrQmxNO0FBQUFBLElBQ3BCLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTSxDQUFDMkQsUUFBUXdJLFNBQVMsSUFBSTNMLFNBQXlCSSxtQkFBbUI7QUFDeEUsUUFBTSxDQUFDd0wsV0FBV0MsWUFBWSxJQUFJN0wsU0FBb0IsU0FBUztBQUMvRCxRQUFNLENBQUM4TCxhQUFhQyxjQUFjLElBQUkvTCxTQUFzQixvQkFBSW9ELElBQUksQ0FBQztBQUNyRSxRQUFNLENBQUM0SSxTQUFTQyxVQUFVLElBQUlqTSxTQUFTLElBQUk7QUFDM0MsUUFBTSxDQUFDa00sUUFBUUMsU0FBUyxJQUFJbk0sU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ29NLE9BQU9DLFFBQVEsSUFBSXJNLFNBQVMsS0FBSztBQUN4QyxRQUFNLENBQUMyRSxnQkFBZ0IySCxpQkFBaUIsSUFBSXRNLFNBQTBCLEVBQUU7QUFDeEUsUUFBTSxDQUFDNEUsZ0JBQWdCMkgsaUJBQWlCLElBQUl2TSxTQUFTLEtBQUs7QUFFMUQsUUFBTXdNLFlBQVl6TSxPQUFPb0QsTUFBTTtBQUMvQnFKLFlBQVU3SixVQUFVUTtBQUNwQixRQUFNc0osZUFBZTFNLE9BQU82TCxTQUFTO0FBQ3JDYSxlQUFhOUosVUFBVWlKO0FBRXZCLFFBQU1qSSxXQUFXUixPQUFPeUksU0FBUztBQUVqQyxRQUFNYyxlQUFlOU07QUFBQUEsSUFDbkIsT0FBTytNLFNBQVMsSUFBSUMsVUFBb0IsT0FBTztBQUM3Q0wsd0JBQWtCLElBQUk7QUFDdEIsVUFBSTtBQUNGLGNBQU1NLFNBQVMsTUFBTXhCLGFBQWF5QixRQUFRLFdBQVc7QUFBQSxVQUNuREMsWUFBWSxFQUFFQyxNQUFNLEdBQUdDLFNBQVMsR0FBRztBQUFBLFVBQ25DQyxNQUFNLEVBQUVDLE9BQU8sTUFBTUMsT0FBTyxPQUFPO0FBQUEsVUFDbkN6RSxRQUFRZ0UsU0FBUyxFQUFFVSxHQUFHVixPQUFPLElBQUksQ0FBQztBQUFBLFFBQ3BDLENBQUM7QUFDRCxjQUFNVyxTQUFVVCxPQUFPVSxLQUF5QjFLLElBQUksQ0FBQ3lDLE9BQU87QUFBQSxVQUMxRGxFLElBQUlvTSxPQUFPbEksRUFBRWxFLEVBQUU7QUFBQSxVQUNmbUUsUUFBUUQsRUFBRUM7QUFBQUEsVUFDVm1DLFFBQVFwQyxFQUFFb0M7QUFBQUEsUUFDWixFQUFFO0FBRUY0RSwwQkFBa0IsQ0FBQ3hHLFNBQVM7QUFDMUIsZ0JBQU0ySCxPQUFPM0gsS0FBSzZDLE9BQU8sQ0FBQ3JELE1BQU1zSCxRQUFRYyxTQUFTcEksRUFBRWxFLEVBQUUsQ0FBQztBQUN0RCxpQkFBT3NCLG9CQUFvQitLLE1BQU1ILE1BQU07QUFBQSxRQUN6QyxDQUFDO0FBQUEsTUFDSCxRQUFRO0FBQ05sQyxlQUFPLDJCQUEyQixFQUFFL0osTUFBTSxRQUFRLENBQUM7QUFBQSxNQUNyRCxVQUFDO0FBQ0NrTCwwQkFBa0IsS0FBSztBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUFBLElBQ0EsQ0FBQ2xCLGNBQWNELE1BQU07QUFBQSxFQUN2QjtBQUVBLFFBQU11QywwQkFBMEIvTjtBQUFBQSxJQUM5QixPQUFPZ08sUUFBa0I7QUFDdkIsVUFBSUEsSUFBSW5MLFdBQVcsRUFBRztBQUN0QixVQUFJO0FBQ0YsY0FBTW9LLFNBQVMsTUFBTXhCLGFBQWF3QyxRQUFRLFdBQVcsRUFBRUQsSUFBSSxDQUFDO0FBQzVELGNBQU1OLFNBQVVULE9BQU9VLEtBQXlCMUssSUFBSSxDQUFDeUMsT0FBTztBQUFBLFVBQzFEbEUsSUFBSW9NLE9BQU9sSSxFQUFFbEUsRUFBRTtBQUFBLFVBQ2ZtRSxRQUFRRCxFQUFFQztBQUFBQSxVQUNWbUMsUUFBUXBDLEVBQUVvQztBQUFBQSxRQUNaLEVBQUU7QUFDRjRFLDBCQUFrQixDQUFDeEcsU0FBU3BELG9CQUFvQm9ELE1BQU13SCxNQUFNLENBQUM7QUFBQSxNQUMvRCxRQUFRO0FBQUEsTUFDTjtBQUFBLElBRUo7QUFBQSxJQUNBLENBQUNqQyxZQUFZO0FBQUEsRUFDZjtBQUVBLFFBQU15QyxlQUFlbE8sWUFBWSxZQUFZO0FBQzNDcU0sZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFlBQU1zQixPQUFPLE1BQU1sTixpQkFBaUI7QUFDcEMsWUFBTTBOLGFBQWF6Tix3QkFBd0JpTixLQUFLNUosUUFBUTtBQUN4RGdJLGdCQUFVb0MsVUFBVTtBQUNwQmhDO0FBQUFBLFFBQ0Usb0JBQUkzSTtBQUFBQSxVQUFJO0FBQUEsWUFDTixHQUFHMkssV0FBVzFLLFFBQVFSLElBQUksQ0FBQ3FHLE1BQU1BLEVBQUU5SCxFQUFFO0FBQUEsWUFDckMsR0FBRzJNLFdBQVd6SyxPQUFPVCxJQUFJLENBQUNxRyxNQUFNQSxFQUFFOUgsRUFBRTtBQUFBLFVBQUM7QUFBQSxRQUN0QztBQUFBLE1BQ0g7QUFDQWlMLGVBQVMsS0FBSztBQUVkLFlBQU0yQixjQUFjOUssd0JBQXdCNkssVUFBVTtBQUN0RCxZQUFNSix3QkFBd0JLLFdBQVc7QUFDekMsWUFBTXRCLGFBQWEsSUFBSXNCLFdBQVc7QUFBQSxJQUNwQyxRQUFRO0FBQ041QyxhQUFPLDJCQUEyQixFQUFFL0osTUFBTSxRQUFRLENBQUM7QUFBQSxJQUNyRCxVQUFDO0FBQ0M0SyxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsQ0FBQzBCLHlCQUF5QmpCLGNBQWN0QixNQUFNLENBQUM7QUFFbER2TCxZQUFVLE1BQU07QUFDZCxTQUFLaU8sYUFBYTtBQUFBLEVBQ3BCLEdBQUcsQ0FBQ0EsWUFBWSxDQUFDO0FBRWpCak8sWUFBVSxNQUFNO0FBQ2QsV0FBTyxNQUFNO0FBQ1gsVUFBSXlMLFlBQVkzSSxRQUFTc0wsY0FBYTNDLFlBQVkzSSxPQUFPO0FBQUEsSUFDM0Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1rQyxrQkFBa0JBLENBQUNxSixVQUFrQjtBQUN6QyxRQUFJNUMsWUFBWTNJLFFBQVNzTCxjQUFhM0MsWUFBWTNJLE9BQU87QUFDekQySSxnQkFBWTNJLFVBQVV3TCxXQUFXLE1BQU07QUFDckMsV0FBS3pCO0FBQUFBLFFBQ0h3QixNQUFNbkssS0FBSztBQUFBLFFBQ1hiLHdCQUF3QnNKLFVBQVU3SixPQUFPO0FBQUEsTUFDM0M7QUFBQSxJQUNGLEdBQUcsR0FBRztBQUFBLEVBQ1I7QUFFQSxRQUFNeUwsb0JBQW9CQSxDQUN4QnBELFlBQ0c7QUFDSCxVQUFNcUQsTUFBTTVCLGFBQWE5SjtBQUN6QmdKLGNBQVUsQ0FBQzdGLFVBQVU7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNILENBQUN1SSxHQUFHLEdBQUdyRCxRQUFRbEYsS0FBS3VJLEdBQUcsQ0FBQztBQUFBLElBQzFCLEVBQUU7QUFDRmhDLGFBQVMsSUFBSTtBQUFBLEVBQ2Y7QUFFQSxRQUFNaUMsZ0JBQWdCQSxDQUFDbE4sSUFBWTRKLFlBQTRCO0FBQzdEb0Q7QUFBQUEsTUFBa0IsQ0FBQ3RJLFNBQ2pCQSxLQUFLakQsSUFBSSxDQUFDcUcsTUFBT0EsRUFBRTlILE9BQU9BLEtBQUs0SixRQUFROUIsQ0FBQyxJQUFJQSxDQUFFO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTXFGLGdCQUFnQkEsQ0FBQ25OLE9BQWU7QUFDcENnTixzQkFBa0IsQ0FBQ3RJLFNBQVNBLEtBQUs2QyxPQUFPLENBQUNPLE1BQU1BLEVBQUU5SCxPQUFPQSxFQUFFLENBQUM7QUFDM0QySyxtQkFBZSxDQUFDakcsU0FBUztBQUN2QixZQUFNMEksT0FBTyxJQUFJcEwsSUFBSTBDLElBQUk7QUFDekIwSSxXQUFLQyxPQUFPck4sRUFBRTtBQUNkLGFBQU9vTjtBQUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUUsYUFBYUEsQ0FBQ2xMLFlBQTZCO0FBQy9DNEssc0JBQWtCLENBQUN0SSxTQUFTLENBQUMsR0FBR0EsTUFBTXRDLE9BQU8sQ0FBQztBQUM5Q3VJLG1CQUFlLENBQUNqRyxTQUFTLElBQUkxQyxJQUFJMEMsSUFBSSxFQUFFNkksSUFBSW5MLFFBQVFwQyxFQUFFLENBQUM7QUFBQSxFQUN4RDtBQUVBLFFBQU13TixZQUFZQSxDQUFDQyxVQUF3QjtBQUN6QyxVQUFNLEVBQUVDLFFBQVFDLEtBQUssSUFBSUY7QUFDekIsUUFBSSxDQUFDRSxRQUFRRCxPQUFPMU4sT0FBTzJOLEtBQUszTixHQUFJO0FBRXBDZ04sc0JBQWtCLENBQUN0SSxTQUFTO0FBQzFCLFlBQU1rSixXQUFXbEosS0FBS21KLFVBQVUsQ0FBQy9GLE1BQU1BLEVBQUU5SCxPQUFPME4sT0FBTzFOLEVBQUU7QUFDekQsWUFBTThOLFdBQVdwSixLQUFLbUosVUFBVSxDQUFDL0YsTUFBTUEsRUFBRTlILE9BQU8yTixLQUFLM04sRUFBRTtBQUN2RCxVQUFJNE4sV0FBVyxLQUFLRSxXQUFXLEVBQUcsUUFBT3BKO0FBQ3pDLGFBQU94RyxVQUFVd0csTUFBTWtKLFVBQVVFLFFBQVE7QUFBQSxJQUMzQyxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1DLHNCQUFzQkEsTUFBTTtBQUNoQyxVQUFNN0wsU0FBU0ksd0JBQXdCOEksVUFBVTdKLFFBQVFVLE9BQU87QUFDaEVzSSxjQUFVLENBQUM3RixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSHhDO0FBQUFBLElBQ0YsRUFBRTtBQUNGeUksbUJBQWUsQ0FBQ2pHLFNBQVM7QUFDdkIsWUFBTTBJLE9BQU8sSUFBSXBMLElBQUkwQyxJQUFJO0FBQ3pCLGlCQUFXdEMsV0FBV0YsUUFBUTtBQUM1QmtMLGFBQUtHLElBQUluTCxRQUFRcEMsRUFBRTtBQUFBLE1BQ3JCO0FBQ0EsYUFBT29OO0FBQUFBLElBQ1QsQ0FBQztBQUNEM0MsaUJBQWEsUUFBUTtBQUNyQlEsYUFBUyxJQUFJO0FBQ2JqQixXQUFPLG1DQUFtQyxFQUFFL0osTUFBTSxPQUFPLENBQUM7QUFBQSxFQUM1RDtBQUVBLFFBQU0rTixhQUFhLFlBQVk7QUFDN0IsVUFBTXpNLFVBQVU2SixVQUFVN0o7QUFFMUIsVUFBTTBNLGVBQWVuTCx3QkFBd0J2QixRQUFRVSxTQUFTLFNBQVM7QUFDdkUsUUFBSWdNLGNBQWM7QUFDaEJ4RCxtQkFBYSxTQUFTO0FBQ3RCVCxhQUFPaUUsY0FBYyxFQUFFaE8sTUFBTSxVQUFVLENBQUM7QUFDeEM7QUFBQSxJQUNGO0FBRUEsVUFBTWlPLGNBQWNwTCx3QkFBd0J2QixRQUFRVyxRQUFRLFFBQVE7QUFDcEUsUUFBSWdNLGFBQWE7QUFDZnpELG1CQUFhLFFBQVE7QUFDckJULGFBQU9rRSxhQUFhLEVBQUVqTyxNQUFNLFVBQVUsQ0FBQztBQUN2QztBQUFBLElBQ0Y7QUFFQSxVQUFNa08sVUFBMEI7QUFBQSxNQUM5QmxNLFNBQVNZLGlCQUFpQnRCLFFBQVFVLE9BQU87QUFBQSxNQUN6Q0MsUUFBUVcsaUJBQWlCdEIsUUFBUVcsTUFBTTtBQUFBLElBQ3pDO0FBRUE2SSxjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTW9CLE9BQU8sTUFBTWhOLGVBQWVnUCxPQUFPO0FBQ3pDNUQsZ0JBQVVyTCx3QkFBd0JpTixLQUFLNUosUUFBUSxDQUFDO0FBQ2hEMEksZUFBUyxLQUFLO0FBQ2RqQixhQUFPLGtCQUFrQixFQUFFL0osTUFBTSxVQUFVLENBQUM7QUFBQSxJQUM5QyxRQUFRO0FBQ04rSixhQUFPLDJCQUEyQixFQUFFL0osTUFBTSxRQUFRLENBQUM7QUFBQSxJQUNyRCxVQUFDO0FBQ0M4SyxnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxPQUFJLElBQUksRUFBRTdHLEdBQUcsR0FBR2tLLElBQUksR0FBRyxHQUN0QjtBQUFBLDJCQUFDLFNBQU0sT0FBTSxjQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxJQUV2QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBSTtBQUFBLFVBQ0YvSixTQUFTO0FBQUEsVUFDVE0sVUFBVTtBQUFBLFVBQ1ZDLFlBQVk7QUFBQSxVQUNaUyxnQkFBZ0I7QUFBQSxVQUNoQmQsS0FBSztBQUFBLFVBQ0w4SixJQUFJO0FBQUEsUUFDTjtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxPQUNDO0FBQUEsbUNBQUMsY0FBVyxTQUFRLE1BQUssSUFBSSxFQUFFL0csWUFBWSxJQUFJLEdBQUUsZ0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGNBQVcsU0FBUSxTQUFRLE9BQU0sa0JBQWdCLG9IQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLElBQUksRUFBRWpELFNBQVMsUUFBUUUsS0FBSyxHQUFHSSxVQUFVLE9BQU8sR0FDbkQ7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixTQUFTLE1BQU0ySSxXQUFXdk4sYUFBYSxDQUFDO0FBQUEsZ0JBQ3hDLFdBQVcsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFVO0FBQUEsZ0JBQUk7QUFBQTtBQUFBLGNBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixTQUFTLE1BQU11TixXQUFXeE0sa0JBQWtCLENBQUM7QUFBQSxnQkFDN0MsV0FBVyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQjtBQUFBLGdCQUFJO0FBQUE7QUFBQSxjQUhqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsU0FBUyxNQUFNd00sV0FBVzNNLGlCQUFpQixDQUFDO0FBQUEsZ0JBQzVDLFdBQVcsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUI7QUFBQSxnQkFBSTtBQUFBO0FBQUEsY0FIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFNBQVMsTUFBTTJNLFdBQVdqTixhQUFhLENBQUM7QUFBQSxnQkFDeEMsV0FBVyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQjtBQUFBLGdCQUFJO0FBQUE7QUFBQSxjQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsU0FBUyxNQUFNaU4sV0FBV3RNLFVBQVUsQ0FBQyxDQUFDO0FBQUEsZ0JBQ3RDLFdBQVcsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYTtBQUFBLGdCQUFJO0FBQUE7QUFBQSxjQUg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUE7QUFBQTtBQUFBLE1BeERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlEQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUk7QUFBQSxVQUNGcUQsU0FBUztBQUFBLFVBQ1RNLFVBQVU7QUFBQSxVQUNWQyxZQUFZO0FBQUEsVUFDWlMsZ0JBQWdCO0FBQUEsVUFDaEJkLEtBQUs7QUFBQSxVQUNMOEosSUFBSTtBQUFBLFVBQ0o5RSxjQUFjO0FBQUEsVUFDZHBFLGFBQWE7QUFBQSxRQUNmO0FBQUEsUUFFQTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPcUY7QUFBQUEsY0FDUCxVQUFVLENBQUNoRyxHQUFHQyxVQUFxQmdHLGFBQWFoRyxLQUFLO0FBQUEsY0FFckQ7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFNO0FBQUEsb0JBQ04sT0FBTTtBQUFBLG9CQUNOLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBYTtBQUFBLG9CQUNuQixjQUFhO0FBQUE7QUFBQSxrQkFKZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXNCO0FBQUEsZ0JBRXRCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU07QUFBQSxvQkFDTixPQUFNO0FBQUEsb0JBQ04sTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFlO0FBQUEsb0JBQ3JCLGNBQWE7QUFBQTtBQUFBLGtCQUpmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJc0I7QUFBQTtBQUFBO0FBQUEsWUFkeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0JBO0FBQUEsVUFFQytGLGNBQWMsWUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsV0FBVyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQzNCLFNBQVN1RDtBQUFBQSxjQUNULFVBQVVoTSxPQUFPRSxRQUFRWixXQUFXO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFMeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQTtBQUFBO0FBQUEsTUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBeUNBO0FBQUEsSUFFQ3VKLFVBQ0MsdUJBQUMsT0FBSSxJQUFJLEVBQUV2RyxTQUFTLFFBQVFnQixnQkFBZ0IsVUFBVWlFLElBQUksRUFBRSxHQUMxRCxpQ0FBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUNFL0csU0FBU2xCLFdBQVcsSUFDdEI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUk7QUFBQSxVQUNGNkMsR0FBRztBQUFBLFVBQ0hvSyxXQUFXO0FBQUEsVUFDWHJKLGNBQWM7QUFBQSxVQUNkQyxRQUFRO0FBQUEsVUFDUkMsYUFBYTtBQUFBLFVBQ2JHLFNBQVM7QUFBQSxRQUNYO0FBQUEsUUFFQTtBQUFBLGlDQUFDLGNBQVcsT0FBTSxrQkFBaUIsSUFBSSxFQUFFK0ksSUFBSSxFQUFFLEdBQzVDN0Qsd0JBQWMsV0FDWCxxSEFDQSxzR0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBSTtBQUFBLGdCQUNGbkcsU0FBUztBQUFBLGdCQUNURSxLQUFLO0FBQUEsZ0JBQ0xjLGdCQUFnQjtBQUFBLGdCQUNoQlYsVUFBVTtBQUFBLGNBQ1o7QUFBQSxjQUVBO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUTtBQUFBLG9CQUNSLFNBQVMsTUFBTTJJLFdBQVd2TixhQUFhLENBQUM7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVE7QUFBQSxvQkFDUixTQUFTLE1BQU11TixXQUFXeE0sa0JBQWtCLENBQUM7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVE7QUFBQSxvQkFDUixTQUFTLE1BQU13TSxXQUFXM00saUJBQWlCLENBQUM7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVE7QUFBQSxvQkFDUixTQUFTLE1BQU0yTSxXQUFXak4sYUFBYSxDQUFDO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQSx1QkFBQyxVQUFPLFNBQVEsWUFBVyxTQUFTLE1BQU1pTixXQUFXdE0sVUFBVSxDQUFDLENBQUMsR0FBRSx1QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDd0osY0FBYyxZQUFZekksT0FBT0UsUUFBUVosU0FBUyxLQUNqRDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFRO0FBQUEsb0JBQ1IsV0FBVyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQjtBQUFBLG9CQUMzQixTQUFTME07QUFBQUEsb0JBQW9CO0FBQUE7QUFBQSxrQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTRDQTtBQUFBO0FBQUE7QUFBQSxNQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUE0REEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLG9CQUFvQmxRO0FBQUFBLFFBQ3BCO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTzBFLFNBQVNkLElBQUksQ0FBQ3FHLE1BQU1BLEVBQUU5SCxFQUFFO0FBQUEsWUFDL0IsVUFBVTFCO0FBQUFBLFlBRVYsaUNBQUMsT0FBSSxJQUFJLEVBQUUrRixTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxFQUFFLEdBQ3pEaEMsbUJBQVNkO0FBQUFBLGNBQUksQ0FBQ1csWUFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQztBQUFBLGtCQUNBLFVBQVVzSSxZQUFZNkQsSUFBSW5NLFFBQVFwQyxFQUFFO0FBQUEsa0JBQ3BDLFVBQVUsTUFDUjJLLGVBQWUsQ0FBQ2pHLFNBQVM7QUFDdkIsMEJBQU0wSSxPQUFPLElBQUlwTCxJQUFJMEMsSUFBSTtBQUN6Qix3QkFBSTBJLEtBQUttQixJQUFJbk0sUUFBUXBDLEVBQUUsRUFBR29OLE1BQUtDLE9BQU9qTCxRQUFRcEMsRUFBRTtBQUFBO0FBQzNDb04sMkJBQUtHLElBQUluTCxRQUFRcEMsRUFBRTtBQUN4QiwyQkFBT29OO0FBQUFBLGtCQUNULENBQUM7QUFBQSxrQkFFSCxVQUFVLENBQUN4RCxZQUFZc0QsY0FBYzlLLFFBQVFwQyxJQUFJNEosT0FBTztBQUFBLGtCQUN4RCxVQUFVLE1BQU11RCxjQUFjL0ssUUFBUXBDLEVBQUU7QUFBQSxrQkFDeEMsb0JBQW9CLENBQUN3TyxhQUNuQnREO0FBQUFBLG9CQUFrQixDQUFDeEcsU0FDakJwRCxvQkFBb0JvRCxNQUFNOEosUUFBUTtBQUFBLGtCQUNwQztBQUFBLGtCQUVGO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLGVBQWUsTUFDYnhFLE9BQU8sdUJBQXVCLEVBQUUvSixNQUFNLFFBQVEsQ0FBQztBQUFBO0FBQUEsZ0JBdEI1Q21DLFFBQVFwQztBQUFBQSxnQkFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBd0JHO0FBQUEsWUFFSixLQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBO0FBQUEsVUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0NBO0FBQUE7QUFBQSxNQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF3Q0E7QUFBQSxJQUdGO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxJQUFJO0FBQUEsVUFDRmlELFVBQVU7QUFBQSxVQUNWd0wsUUFBUTtBQUFBLFVBQ1JDLElBQUk7QUFBQSxVQUNKckssU0FBUztBQUFBLFVBQ1RnQixnQkFBZ0I7QUFBQSxVQUNoQmQsS0FBSztBQUFBLFVBQ0xvSyxRQUFRO0FBQUEsVUFDUnpLLEdBQUc7QUFBQSxVQUNIZSxjQUFjO0FBQUEsVUFDZEMsUUFBUTtBQUFBLFVBQ1JDLGFBQWE7QUFBQSxVQUNiRyxTQUFTO0FBQUEsUUFDWDtBQUFBLFFBRUE7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsU0FBUyxNQUFNLEtBQUtvSCxhQUFhO0FBQUEsY0FDakMsVUFBVTlCLFdBQVdFO0FBQUFBLGNBQU87QUFBQTtBQUFBLFlBSDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsU0FBUyxNQUFNLEtBQUtrRCxXQUFXO0FBQUEsY0FDL0IsVUFBVXBELFdBQVdFLFVBQVUsQ0FBQ0U7QUFBQUEsY0FFL0JGLG1CQUFTLFlBQVk7QUFBQTtBQUFBLFlBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUE7QUFBQTtBQUFBLE1BN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQThCQTtBQUFBLE9BclBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzUEE7QUFFSjtBQUFFZixJQTljV0QsZ0JBQWM7QUFBQSxVQUNWL0ssV0FDTUQsaUJBRUxiLFlBQ2RELFdBQ0FBLFNBQVM7QUFBQTtBQUFBLE1BTkE4TDtBQUFjLElBQUE4RSxJQUFBQyxLQUFBQyxLQUFBQyxLQUFBQztBQUFBLGFBQUFKLElBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiQm94IiwiVHlwb2dyYXBoeSIsIkJ1dHRvbiIsIlRleHRGaWVsZCIsIkljb25CdXR0b24iLCJDaGlwIiwiQXV0b2NvbXBsZXRlIiwiQ2lyY3VsYXJQcm9ncmVzcyIsIkNvbGxhcHNlIiwiVGFicyIsIlRhYiIsIlRvZ2dsZUJ1dHRvbiIsIlRvZ2dsZUJ1dHRvbkdyb3VwIiwiRGVsZXRlT3V0bGluZWRJY29uIiwiRXhwYW5kTW9yZUljb24iLCJFeHBhbmRMZXNzSWNvbiIsIkltYWdlSWNvbiIsIlZpZXdDYXJvdXNlbEljb24iLCJWaWV3V2Vla0ljb24iLCJEcmFnSW5kaWNhdG9ySWNvbiIsIkNvbnRlbnRDb3B5SWNvbiIsIkNvbXB1dGVySWNvbiIsIlNtYXJ0cGhvbmVJY29uIiwiQ29sbGVjdGlvbnNJY29uIiwiQ2lyY2xlT3V0bGluZWRJY29uIiwiQWRkSWNvbiIsIkFycm93VXB3YXJkSWNvbiIsIkFycm93RG93bndhcmRJY29uIiwiRG5kQ29udGV4dCIsImNsb3Nlc3RDZW50ZXIiLCJLZXlib2FyZFNlbnNvciIsIlBvaW50ZXJTZW5zb3IiLCJ1c2VTZW5zb3IiLCJ1c2VTZW5zb3JzIiwiYXJyYXlNb3ZlIiwiU29ydGFibGVDb250ZXh0Iiwic29ydGFibGVLZXlib2FyZENvb3JkaW5hdGVzIiwidXNlU29ydGFibGUiLCJ2ZXJ0aWNhbExpc3RTb3J0aW5nU3RyYXRlZ3kiLCJDU1MiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIlRpdGxlIiwidXNlRGF0YVByb3ZpZGVyIiwidXNlTm90aWZ5IiwiZW1wdHlIb21lcGFnZUxheW91dCIsImdldEhvbWVwYWdlQWRtaW4iLCJub3JtYWxpemVIb21lcGFnZUxheW91dCIsInVwZGF0ZUhvbWVwYWdlIiwidXBsb2FkSW1hZ2VzIiwiSEVYX0NPTE9SX1JFIiwibmV3SWQiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiRGF0ZSIsIm5vdyIsIk1hdGgiLCJyYW5kb20iLCJ0b1N0cmluZyIsInNsaWNlIiwiY3JlYXRlQmFubmVyIiwiaWQiLCJ0eXBlIiwiaW1hZ2VVcmwiLCJocmVmIiwiYWx0IiwiY3JlYXRlU2xpZGVyIiwidGl0bGUiLCJwcm9kdWN0SWRzIiwiYmFja2dyb3VuZENvbG9yIiwiY3JlYXRlU3RvcnlJdGVtIiwibGFiZWwiLCJjcmVhdGVTdG9yeUxpbmtzIiwiaXRlbXMiLCJjcmVhdGVJbWFnZVNsaWRlIiwiY3JlYXRlSW1hZ2VTbGlkZXIiLCJzbGlkZXMiLCJjcmVhdGVSb3ciLCJjb2x1bW5Db3VudCIsImNvbHVtbnMiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJtZXJnZVByb2R1Y3RPcHRpb25zIiwiY3VycmVudCIsImluY29taW5nIiwibWFwIiwiTWFwIiwiaXRlbSIsInNldCIsInZhbHVlcyIsImNvbGxlY3RMYXlvdXRQcm9kdWN0SWRzIiwibGF5b3V0IiwiU2V0IiwiZGVza3RvcCIsIm1vYmlsZSIsImZsYXRNYXAiLCJzZWN0aW9uIiwiY29sdW1uIiwiY2xvbmVTZWN0aW9uc1dpdGhOZXdJZHMiLCJzZWN0aW9ucyIsInNsaWRlIiwic2FuaXRpemVDb250ZW50QmxvY2siLCJibG9jayIsInRyaW0iLCJ0ZXN0Iiwic2FuaXRpemVTZWN0aW9ucyIsImZpbmRGaXJzdEludmFsaWRNZXNzYWdlIiwiZGV2aWNlTGFiZWwiLCJpIiwicG9zaXRpb24iLCJjIiwiaiIsIkNvbnRlbnRCbG9ja0VkaXRvciIsIm9uQ2hhbmdlIiwib25Qcm9kdWN0c1Jlc29sdmVkIiwicHJvZHVjdE9wdGlvbnMiLCJwcm9kdWN0TG9hZGluZyIsIm9uUHJvZHVjdFNlYXJjaCIsIm9uVXBsb2FkRXJyb3IiLCJjb21wYWN0IiwiYWxsb3dUeXBlU3dpdGNoIiwiX3MiLCJ1cGxvYWRpbmciLCJzZXRVcGxvYWRpbmciLCJzZWxlY3RlZFByb2R1Y3RzIiwiZmluZCIsInAiLCJlbk5hbWUiLCJhdXRvY29tcGxldGVPcHRpb25zIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJnYXAiLCJfIiwidmFsdWUiLCJwcmV2IiwiZmxleFdyYXAiLCJhbGlnbkl0ZW1zIiwid2lkdGgiLCJ4cyIsIm1kIiwiaGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwiYm9yZGVyIiwiYm9yZGVyQ29sb3IiLCJvdmVyZmxvdyIsImp1c3RpZnlDb250ZW50IiwiYmdjb2xvciIsIm9iamVjdEZpdCIsImZsZXgiLCJtaW5XaWR0aCIsImUiLCJmaWxlIiwidGFyZ2V0IiwiZmlsZXMiLCJ1cmxzIiwiYmFja2dyb3VuZEltYWdlIiwidW5kZWZpbmVkIiwiYmFja2dyb3VuZFNpemUiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJjdXJzb3IiLCJvcHRpb25zIiwib3B0aW9uIiwicHJOYW1lIiwiYSIsImIiLCJyZWFzb24iLCJwYXJhbXMiLCJTdG9yeUxpbmtzRWRpdG9yIiwiX3MyIiwidXBsb2FkaW5nSWQiLCJzZXRVcGxvYWRpbmdJZCIsInVwZGF0ZUl0ZW0iLCJpdGVtSWQiLCJwYXRjaCIsIm1vdmVJdGVtIiwiaW5kZXgiLCJkaXJlY3Rpb24iLCJuZXh0SW5kZXgiLCJmb250V2VpZ2h0IiwiZmlsdGVyIiwiZmxleFNocmluayIsIkltYWdlU2xpZGVyRWRpdG9yIiwiX3MzIiwidXBkYXRlU2xpZGUiLCJzbGlkZUlkIiwibW92ZVNsaWRlIiwicyIsInNlY3Rpb25MYWJlbCIsInNlY3Rpb25DaGlwIiwiU29ydGFibGVTZWN0aW9uIiwiZXhwYW5kZWQiLCJvblRvZ2dsZSIsIm9uUmVtb3ZlIiwiX3M0IiwiYXR0cmlidXRlcyIsImxpc3RlbmVycyIsInNldE5vZGVSZWYiLCJ0cmFuc2Zvcm0iLCJ0cmFuc2l0aW9uIiwiaXNEcmFnZ2luZyIsInN0eWxlIiwiVHJhbnNmb3JtIiwib3BhY2l0eSIsInNldENvbHVtbkNvdW50IiwiY291bnQiLCJuZXh0Q29sdW1ucyIsInB1c2giLCJwb3AiLCJib3hTaGFkb3ciLCJweCIsInB5IiwiYm9yZGVyQm90dG9tIiwidGhlbWUiLCJwYWxldHRlIiwibW9kZSIsImNvbG9yIiwidXBkYXRlciIsImNvbCIsIkhvbWVwYWdlRWRpdG9yIiwiX3M1Iiwibm90aWZ5IiwiZGF0YVByb3ZpZGVyIiwic2VhcmNoVGltZXIiLCJzZW5zb3JzIiwiYWN0aXZhdGlvbkNvbnN0cmFpbnQiLCJkaXN0YW5jZSIsImNvb3JkaW5hdGVHZXR0ZXIiLCJzZXRMYXlvdXQiLCJkZXZpY2VUYWIiLCJzZXREZXZpY2VUYWIiLCJleHBhbmRlZElkcyIsInNldEV4cGFuZGVkSWRzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzYXZpbmciLCJzZXRTYXZpbmciLCJkaXJ0eSIsInNldERpcnR5Iiwic2V0UHJvZHVjdE9wdGlvbnMiLCJzZXRQcm9kdWN0TG9hZGluZyIsImxheW91dFJlZiIsImRldmljZVRhYlJlZiIsImxvYWRQcm9kdWN0cyIsInNlYXJjaCIsImtlZXBJZHMiLCJyZXN1bHQiLCJnZXRMaXN0IiwicGFnaW5hdGlvbiIsInBhZ2UiLCJwZXJQYWdlIiwic29ydCIsImZpZWxkIiwib3JkZXIiLCJxIiwibWFwcGVkIiwiZGF0YSIsIk51bWJlciIsImtlcHQiLCJpbmNsdWRlcyIsImh5ZHJhdGVTZWxlY3RlZFByb2R1Y3RzIiwiaWRzIiwiZ2V0TWFueSIsImxvYWRIb21lcGFnZSIsIm5leHRMYXlvdXQiLCJzZWxlY3RlZElkcyIsImNsZWFyVGltZW91dCIsInF1ZXJ5Iiwic2V0VGltZW91dCIsInNldERldmljZVNlY3Rpb25zIiwidGFiIiwidXBkYXRlU2VjdGlvbiIsInJlbW92ZVNlY3Rpb24iLCJuZXh0IiwiZGVsZXRlIiwiYWRkU2VjdGlvbiIsImFkZCIsIm9uRHJhZ0VuZCIsImV2ZW50IiwiYWN0aXZlIiwib3ZlciIsIm9sZEluZGV4IiwiZmluZEluZGV4IiwibmV3SW5kZXgiLCJjb3B5RGVza3RvcFRvTW9iaWxlIiwiaGFuZGxlU2F2ZSIsImRlc2t0b3BFcnJvciIsIm1vYmlsZUVycm9yIiwicGF5bG9hZCIsInBiIiwibWIiLCJ0ZXh0QWxpZ24iLCJoYXMiLCJwcm9kdWN0cyIsImJvdHRvbSIsIm10IiwiekluZGV4IiwiX2MiLCJfYzIiLCJfYzMiLCJfYzQiLCJfYzUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSG9tZXBhZ2VFZGl0b3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBCb3ggZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQm94XCI7XG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tIFwiQG11aS9tYXRlcmlhbC9UeXBvZ3JhcGh5XCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL0J1dHRvblwiO1xuaW1wb3J0IFRleHRGaWVsZCBmcm9tIFwiQG11aS9tYXRlcmlhbC9UZXh0RmllbGRcIjtcbmltcG9ydCBJY29uQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL0ljb25CdXR0b25cIjtcbmltcG9ydCBDaGlwIGZyb20gXCJAbXVpL21hdGVyaWFsL0NoaXBcIjtcbmltcG9ydCBBdXRvY29tcGxldGUgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQXV0b2NvbXBsZXRlXCI7XG5pbXBvcnQgQ2lyY3VsYXJQcm9ncmVzcyBmcm9tIFwiQG11aS9tYXRlcmlhbC9DaXJjdWxhclByb2dyZXNzXCI7XG5pbXBvcnQgQ29sbGFwc2UgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQ29sbGFwc2VcIjtcbmltcG9ydCBUYWJzIGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYnNcIjtcbmltcG9ydCBUYWIgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFiXCI7XG5pbXBvcnQgVG9nZ2xlQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL1RvZ2dsZUJ1dHRvblwiO1xuaW1wb3J0IFRvZ2dsZUJ1dHRvbkdyb3VwIGZyb20gXCJAbXVpL21hdGVyaWFsL1RvZ2dsZUJ1dHRvbkdyb3VwXCI7XG5pbXBvcnQgRGVsZXRlT3V0bGluZWRJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0RlbGV0ZU91dGxpbmVkXCI7XG5pbXBvcnQgRXhwYW5kTW9yZUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvRXhwYW5kTW9yZVwiO1xuaW1wb3J0IEV4cGFuZExlc3NJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0V4cGFuZExlc3NcIjtcbmltcG9ydCBJbWFnZUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvSW1hZ2VcIjtcbmltcG9ydCBWaWV3Q2Fyb3VzZWxJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL1ZpZXdDYXJvdXNlbFwiO1xuaW1wb3J0IFZpZXdXZWVrSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9WaWV3V2Vla1wiO1xuaW1wb3J0IERyYWdJbmRpY2F0b3JJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0RyYWdJbmRpY2F0b3JcIjtcbmltcG9ydCBDb250ZW50Q29weUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvQ29udGVudENvcHlcIjtcbmltcG9ydCBDb21wdXRlckljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvQ29tcHV0ZXJcIjtcbmltcG9ydCBTbWFydHBob25lSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9TbWFydHBob25lXCI7XG5pbXBvcnQgQ29sbGVjdGlvbnNJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0NvbGxlY3Rpb25zXCI7XG5pbXBvcnQgQ2lyY2xlT3V0bGluZWRJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0NpcmNsZU91dGxpbmVkXCI7XG5pbXBvcnQgQWRkSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9BZGRcIjtcbmltcG9ydCBBcnJvd1Vwd2FyZEljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvQXJyb3dVcHdhcmRcIjtcbmltcG9ydCBBcnJvd0Rvd253YXJkSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9BcnJvd0Rvd253YXJkXCI7XG5pbXBvcnQge1xuICBEbmRDb250ZXh0LFxuICBjbG9zZXN0Q2VudGVyLFxuICBLZXlib2FyZFNlbnNvcixcbiAgUG9pbnRlclNlbnNvcixcbiAgdXNlU2Vuc29yLFxuICB1c2VTZW5zb3JzLFxuICB0eXBlIERyYWdFbmRFdmVudCxcbn0gZnJvbSBcIkBkbmQta2l0L2NvcmVcIjtcbmltcG9ydCB7XG4gIGFycmF5TW92ZSxcbiAgU29ydGFibGVDb250ZXh0LFxuICBzb3J0YWJsZUtleWJvYXJkQ29vcmRpbmF0ZXMsXG4gIHVzZVNvcnRhYmxlLFxuICB2ZXJ0aWNhbExpc3RTb3J0aW5nU3RyYXRlZ3ksXG59IGZyb20gXCJAZG5kLWtpdC9zb3J0YWJsZVwiO1xuaW1wb3J0IHsgQ1NTIH0gZnJvbSBcIkBkbmQta2l0L3V0aWxpdGllc1wiO1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBDaGFuZ2VFdmVudCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgVGl0bGUsIHVzZURhdGFQcm92aWRlciwgdXNlTm90aWZ5IH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQge1xuICBlbXB0eUhvbWVwYWdlTGF5b3V0LFxuICBnZXRIb21lcGFnZUFkbWluLFxuICBub3JtYWxpemVIb21lcGFnZUxheW91dCxcbiAgdXBkYXRlSG9tZXBhZ2UsXG4gIHVwbG9hZEltYWdlcyxcbiAgdHlwZSBIb21lcGFnZUJhbm5lclNlY3Rpb24sXG4gIHR5cGUgSG9tZXBhZ2VDb250ZW50QmxvY2ssXG4gIHR5cGUgSG9tZXBhZ2VJbWFnZVNsaWRlLFxuICB0eXBlIEhvbWVwYWdlSW1hZ2VTbGlkZXJTZWN0aW9uLFxuICB0eXBlIEhvbWVwYWdlTGF5b3V0LFxuICB0eXBlIEhvbWVwYWdlUHJvZHVjdFNsaWRlclNlY3Rpb24sXG4gIHR5cGUgSG9tZXBhZ2VSb3dTZWN0aW9uLFxuICB0eXBlIEhvbWVwYWdlU2VjdGlvbixcbiAgdHlwZSBIb21lcGFnZVN0b3J5TGlua0l0ZW0sXG4gIHR5cGUgSG9tZXBhZ2VTdG9yeUxpbmtzU2VjdGlvbixcbn0gZnJvbSBcIi4uL2FwaS9hZG1pblwiO1xuXG5jb25zdCBIRVhfQ09MT1JfUkUgPSAvXiNbMC05QS1GYS1mXXs2fSQvO1xuXG50eXBlIERldmljZVRhYiA9IFwiZGVza3RvcFwiIHwgXCJtb2JpbGVcIjtcblxudHlwZSBQcm9kdWN0T3B0aW9uID0ge1xuICBpZDogbnVtYmVyO1xuICBlbk5hbWU6IHN0cmluZztcbiAgcHJOYW1lPzogc3RyaW5nO1xufTtcblxudHlwZSBTZWN0aW9uVXBkYXRlciA9IChwcmV2OiBIb21lcGFnZVNlY3Rpb24pID0+IEhvbWVwYWdlU2VjdGlvbjtcbnR5cGUgQmxvY2tVcGRhdGVyID0gKHByZXY6IEhvbWVwYWdlQ29udGVudEJsb2NrKSA9PiBIb21lcGFnZUNvbnRlbnRCbG9jaztcblxuY29uc3QgbmV3SWQgPSAoKSA9PlxuICB0eXBlb2YgY3J5cHRvICE9PSBcInVuZGVmaW5lZFwiICYmIFwicmFuZG9tVVVJRFwiIGluIGNyeXB0b1xuICAgID8gY3J5cHRvLnJhbmRvbVVVSUQoKVxuICAgIDogYHNlY3Rpb24tJHtEYXRlLm5vdygpfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIsIDgpfWA7XG5cbmNvbnN0IGNyZWF0ZUJhbm5lciA9ICgpOiBIb21lcGFnZUJhbm5lclNlY3Rpb24gPT4gKHtcbiAgaWQ6IG5ld0lkKCksXG4gIHR5cGU6IFwiYmFubmVyXCIsXG4gIGltYWdlVXJsOiBcIlwiLFxuICBocmVmOiBcIlwiLFxuICBhbHQ6IFwiXCIsXG59KTtcblxuY29uc3QgY3JlYXRlU2xpZGVyID0gKCk6IEhvbWVwYWdlUHJvZHVjdFNsaWRlclNlY3Rpb24gPT4gKHtcbiAgaWQ6IG5ld0lkKCksXG4gIHR5cGU6IFwicHJvZHVjdF9zbGlkZXJcIixcbiAgdGl0bGU6IFwiXCIsXG4gIHByb2R1Y3RJZHM6IFtdLFxuICBiYWNrZ3JvdW5kQ29sb3I6IFwiXCIsXG59KTtcblxuY29uc3QgY3JlYXRlU3RvcnlJdGVtID0gKCk6IEhvbWVwYWdlU3RvcnlMaW5rSXRlbSA9PiAoe1xuICBpZDogbmV3SWQoKSxcbiAgaW1hZ2VVcmw6IFwiXCIsXG4gIGxhYmVsOiBcIlwiLFxuICBocmVmOiBcIlwiLFxufSk7XG5cbmNvbnN0IGNyZWF0ZVN0b3J5TGlua3MgPSAoKTogSG9tZXBhZ2VTdG9yeUxpbmtzU2VjdGlvbiA9PiAoe1xuICBpZDogbmV3SWQoKSxcbiAgdHlwZTogXCJzdG9yeV9saW5rc1wiLFxuICBpdGVtczogW2NyZWF0ZVN0b3J5SXRlbSgpXSxcbn0pO1xuXG5jb25zdCBjcmVhdGVJbWFnZVNsaWRlID0gKCk6IEhvbWVwYWdlSW1hZ2VTbGlkZSA9PiAoe1xuICBpZDogbmV3SWQoKSxcbiAgaW1hZ2VVcmw6IFwiXCIsXG4gIGhyZWY6IFwiXCIsXG4gIGFsdDogXCJcIixcbn0pO1xuXG5jb25zdCBjcmVhdGVJbWFnZVNsaWRlciA9ICgpOiBIb21lcGFnZUltYWdlU2xpZGVyU2VjdGlvbiA9PiAoe1xuICBpZDogbmV3SWQoKSxcbiAgdHlwZTogXCJpbWFnZV9zbGlkZXJcIixcbiAgc2xpZGVzOiBbY3JlYXRlSW1hZ2VTbGlkZSgpXSxcbn0pO1xuXG5jb25zdCBjcmVhdGVSb3cgPSAoY29sdW1uQ291bnQgPSAyKTogSG9tZXBhZ2VSb3dTZWN0aW9uID0+ICh7XG4gIGlkOiBuZXdJZCgpLFxuICB0eXBlOiBcInJvd1wiLFxuICBjb2x1bW5zOiBBcnJheS5mcm9tKHsgbGVuZ3RoOiBjb2x1bW5Db3VudCB9LCAoKSA9PiBjcmVhdGVCYW5uZXIoKSksXG59KTtcblxuY29uc3QgbWVyZ2VQcm9kdWN0T3B0aW9ucyA9IChcbiAgY3VycmVudDogUHJvZHVjdE9wdGlvbltdLFxuICBpbmNvbWluZzogUHJvZHVjdE9wdGlvbltdXG4pID0+IHtcbiAgY29uc3QgbWFwID0gbmV3IE1hcDxudW1iZXIsIFByb2R1Y3RPcHRpb24+KCk7XG4gIGZvciAoY29uc3QgaXRlbSBvZiBbLi4uY3VycmVudCwgLi4uaW5jb21pbmddKSB7XG4gICAgbWFwLnNldChpdGVtLmlkLCBpdGVtKTtcbiAgfVxuICByZXR1cm4gQXJyYXkuZnJvbShtYXAudmFsdWVzKCkpO1xufTtcblxuY29uc3QgY29sbGVjdExheW91dFByb2R1Y3RJZHMgPSAobGF5b3V0OiBIb21lcGFnZUxheW91dCkgPT5cbiAgQXJyYXkuZnJvbShcbiAgICBuZXcgU2V0KFxuICAgICAgWy4uLmxheW91dC5kZXNrdG9wLCAuLi5sYXlvdXQubW9iaWxlXS5mbGF0TWFwKChzZWN0aW9uKSA9PiB7XG4gICAgICAgIGlmIChzZWN0aW9uLnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIikgcmV0dXJuIHNlY3Rpb24ucHJvZHVjdElkcztcbiAgICAgICAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJyb3dcIikge1xuICAgICAgICAgIHJldHVybiBzZWN0aW9uLmNvbHVtbnMuZmxhdE1hcCgoY29sdW1uKSA9PlxuICAgICAgICAgICAgY29sdW1uLnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIiA/IGNvbHVtbi5wcm9kdWN0SWRzIDogW11cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH0pXG4gICAgKVxuICApO1xuXG5jb25zdCBjbG9uZVNlY3Rpb25zV2l0aE5ld0lkcyA9IChcbiAgc2VjdGlvbnM6IEhvbWVwYWdlU2VjdGlvbltdXG4pOiBIb21lcGFnZVNlY3Rpb25bXSA9PlxuICBzZWN0aW9ucy5tYXAoKHNlY3Rpb24pID0+IHtcbiAgICBpZiAoc2VjdGlvbi50eXBlID09PSBcInJvd1wiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5zZWN0aW9uLFxuICAgICAgICBpZDogbmV3SWQoKSxcbiAgICAgICAgY29sdW1uczogc2VjdGlvbi5jb2x1bW5zLm1hcCgoY29sdW1uKSA9PiAoe1xuICAgICAgICAgIC4uLmNvbHVtbixcbiAgICAgICAgICBpZDogbmV3SWQoKSxcbiAgICAgICAgfSkpLFxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJzdG9yeV9saW5rc1wiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5zZWN0aW9uLFxuICAgICAgICBpZDogbmV3SWQoKSxcbiAgICAgICAgaXRlbXM6IHNlY3Rpb24uaXRlbXMubWFwKChpdGVtKSA9PiAoeyAuLi5pdGVtLCBpZDogbmV3SWQoKSB9KSksXG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAoc2VjdGlvbi50eXBlID09PSBcImltYWdlX3NsaWRlclwiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5zZWN0aW9uLFxuICAgICAgICBpZDogbmV3SWQoKSxcbiAgICAgICAgc2xpZGVzOiBzZWN0aW9uLnNsaWRlcy5tYXAoKHNsaWRlKSA9PiAoeyAuLi5zbGlkZSwgaWQ6IG5ld0lkKCkgfSkpLFxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHsgLi4uc2VjdGlvbiwgaWQ6IG5ld0lkKCkgfTtcbiAgfSk7XG5cbmNvbnN0IHNhbml0aXplQ29udGVudEJsb2NrID0gKFxuICBibG9jazogSG9tZXBhZ2VDb250ZW50QmxvY2tcbik6IEhvbWVwYWdlQ29udGVudEJsb2NrID0+IHtcbiAgaWYgKGJsb2NrLnR5cGUgPT09IFwiYmFubmVyXCIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgaWQ6IGJsb2NrLmlkLFxuICAgICAgdHlwZTogXCJiYW5uZXJcIixcbiAgICAgIGltYWdlVXJsOiBibG9jay5pbWFnZVVybC50cmltKCksXG4gICAgICAuLi4oYmxvY2suaHJlZj8udHJpbSgpID8geyBocmVmOiBibG9jay5ocmVmLnRyaW0oKSB9IDoge30pLFxuICAgICAgLi4uKGJsb2NrLmFsdD8udHJpbSgpID8geyBhbHQ6IGJsb2NrLmFsdC50cmltKCkgfSA6IHt9KSxcbiAgICB9O1xuICB9XG5cbiAgY29uc3QgYmFja2dyb3VuZENvbG9yID0gYmxvY2suYmFja2dyb3VuZENvbG9yPy50cmltKCk7XG4gIHJldHVybiB7XG4gICAgaWQ6IGJsb2NrLmlkLFxuICAgIHR5cGU6IFwicHJvZHVjdF9zbGlkZXJcIixcbiAgICB0aXRsZTogYmxvY2sudGl0bGUudHJpbSgpLFxuICAgIHByb2R1Y3RJZHM6IGJsb2NrLnByb2R1Y3RJZHMsXG4gICAgLi4uKGJhY2tncm91bmRDb2xvciAmJiBIRVhfQ09MT1JfUkUudGVzdChiYWNrZ3JvdW5kQ29sb3IpXG4gICAgICA/IHsgYmFja2dyb3VuZENvbG9yIH1cbiAgICAgIDoge30pLFxuICB9O1xufTtcblxuY29uc3Qgc2FuaXRpemVTZWN0aW9ucyA9IChzZWN0aW9uczogSG9tZXBhZ2VTZWN0aW9uW10pOiBIb21lcGFnZVNlY3Rpb25bXSA9PlxuICBzZWN0aW9ucy5tYXAoKHNlY3Rpb24pID0+IHtcbiAgICBpZiAoc2VjdGlvbi50eXBlID09PSBcInJvd1wiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogc2VjdGlvbi5pZCxcbiAgICAgICAgdHlwZTogXCJyb3dcIiBhcyBjb25zdCxcbiAgICAgICAgY29sdW1uczogc2VjdGlvbi5jb2x1bW5zLm1hcChzYW5pdGl6ZUNvbnRlbnRCbG9jayksXG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAoc2VjdGlvbi50eXBlID09PSBcInN0b3J5X2xpbmtzXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGlkOiBzZWN0aW9uLmlkLFxuICAgICAgICB0eXBlOiBcInN0b3J5X2xpbmtzXCIgYXMgY29uc3QsXG4gICAgICAgIGl0ZW1zOiBzZWN0aW9uLml0ZW1zLm1hcCgoaXRlbSkgPT4gKHtcbiAgICAgICAgICBpZDogaXRlbS5pZCxcbiAgICAgICAgICBpbWFnZVVybDogaXRlbS5pbWFnZVVybC50cmltKCksXG4gICAgICAgICAgbGFiZWw6IGl0ZW0ubGFiZWwudHJpbSgpLFxuICAgICAgICAgIGhyZWY6IGl0ZW0uaHJlZi50cmltKCksXG4gICAgICAgIH0pKSxcbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChzZWN0aW9uLnR5cGUgPT09IFwiaW1hZ2Vfc2xpZGVyXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGlkOiBzZWN0aW9uLmlkLFxuICAgICAgICB0eXBlOiBcImltYWdlX3NsaWRlclwiIGFzIGNvbnN0LFxuICAgICAgICBzbGlkZXM6IHNlY3Rpb24uc2xpZGVzLm1hcCgoc2xpZGUpID0+ICh7XG4gICAgICAgICAgaWQ6IHNsaWRlLmlkLFxuICAgICAgICAgIGltYWdlVXJsOiBzbGlkZS5pbWFnZVVybC50cmltKCksXG4gICAgICAgICAgLi4uKHNsaWRlLmhyZWY/LnRyaW0oKSA/IHsgaHJlZjogc2xpZGUuaHJlZi50cmltKCkgfSA6IHt9KSxcbiAgICAgICAgICAuLi4oc2xpZGUuYWx0Py50cmltKCkgPyB7IGFsdDogc2xpZGUuYWx0LnRyaW0oKSB9IDoge30pLFxuICAgICAgICB9KSksXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gc2FuaXRpemVDb250ZW50QmxvY2soc2VjdGlvbik7XG4gIH0pO1xuXG5jb25zdCBmaW5kRmlyc3RJbnZhbGlkTWVzc2FnZSA9IChcbiAgc2VjdGlvbnM6IEhvbWVwYWdlU2VjdGlvbltdLFxuICBkZXZpY2VMYWJlbDogc3RyaW5nXG4pOiBzdHJpbmcgfCBudWxsID0+IHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWN0aW9ucy5sZW5ndGg7IGkgKz0gMSkge1xuICAgIGNvbnN0IHNlY3Rpb24gPSBzZWN0aW9uc1tpXTtcbiAgICBjb25zdCBwb3NpdGlvbiA9IGAke2RldmljZUxhYmVsfSAjJHtpICsgMX1gO1xuXG4gICAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJyb3dcIikge1xuICAgICAgaWYgKHNlY3Rpb24uY29sdW1ucy5sZW5ndGggPCAxIHx8IHNlY3Rpb24uY29sdW1ucy5sZW5ndGggPiA0KSB7XG4gICAgICAgIHJldHVybiBgJHtwb3NpdGlvbn0gKHJvdyk6IG11c3QgaGF2ZSBiZXR3ZWVuIDEgYW5kIDQgY29sdW1uc2A7XG4gICAgICB9XG4gICAgICBmb3IgKGxldCBjID0gMDsgYyA8IHNlY3Rpb24uY29sdW1ucy5sZW5ndGg7IGMgKz0gMSkge1xuICAgICAgICBjb25zdCBjb2x1bW4gPSBzZWN0aW9uLmNvbHVtbnNbY107XG4gICAgICAgIGlmIChjb2x1bW4udHlwZSA9PT0gXCJiYW5uZXJcIiAmJiAhY29sdW1uLmltYWdlVXJsLnRyaW0oKSkge1xuICAgICAgICAgIHJldHVybiBgJHtwb3NpdGlvbn0gcm93IGNvbHVtbiAke2MgKyAxfTogYmFubmVyIG5lZWRzIGFuIGltYWdlIFVSTGA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbHVtbi50eXBlID09PSBcInByb2R1Y3Rfc2xpZGVyXCIgJiYgIWNvbHVtbi50aXRsZS50cmltKCkpIHtcbiAgICAgICAgICByZXR1cm4gYCR7cG9zaXRpb259IHJvdyBjb2x1bW4gJHtjICsgMX06IHByb2R1Y3Qgc2xpZGVyIG5lZWRzIGEgdGl0bGVgO1xuICAgICAgICB9XG4gICAgICAgIGlmIChcbiAgICAgICAgICBjb2x1bW4udHlwZSA9PT0gXCJwcm9kdWN0X3NsaWRlclwiICYmXG4gICAgICAgICAgY29sdW1uLmJhY2tncm91bmRDb2xvcj8udHJpbSgpICYmXG4gICAgICAgICAgIUhFWF9DT0xPUl9SRS50ZXN0KGNvbHVtbi5iYWNrZ3JvdW5kQ29sb3IudHJpbSgpKVxuICAgICAgICApIHtcbiAgICAgICAgICByZXR1cm4gYCR7cG9zaXRpb259IHJvdyBjb2x1bW4gJHtjICsgMX06IGJhY2tncm91bmQgY29sb3IgbXVzdCBiZSAjUlJHR0JCYDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJiYW5uZXJcIiAmJiAhc2VjdGlvbi5pbWFnZVVybC50cmltKCkpIHtcbiAgICAgIHJldHVybiBgJHtwb3NpdGlvbn0gKGJhbm5lcik6IG5lZWRzIGFuIGltYWdlIFVSTGA7XG4gICAgfVxuICAgIGlmIChzZWN0aW9uLnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIiAmJiAhc2VjdGlvbi50aXRsZS50cmltKCkpIHtcbiAgICAgIHJldHVybiBgJHtwb3NpdGlvbn0gKHNsaWRlcik6IG5lZWRzIGEgdGl0bGVgO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICBzZWN0aW9uLnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIiAmJlxuICAgICAgc2VjdGlvbi5iYWNrZ3JvdW5kQ29sb3I/LnRyaW0oKSAmJlxuICAgICAgIUhFWF9DT0xPUl9SRS50ZXN0KHNlY3Rpb24uYmFja2dyb3VuZENvbG9yLnRyaW0oKSlcbiAgICApIHtcbiAgICAgIHJldHVybiBgJHtwb3NpdGlvbn0gKHNsaWRlcik6IGJhY2tncm91bmQgY29sb3IgbXVzdCBiZSAjUlJHR0JCYDtcbiAgICB9XG4gICAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJzdG9yeV9saW5rc1wiKSB7XG4gICAgICBpZiAoc2VjdGlvbi5pdGVtcy5sZW5ndGggPCAxKSB7XG4gICAgICAgIHJldHVybiBgJHtwb3NpdGlvbn0gKHN0b3JpZXMpOiBuZWVkcyBhdCBsZWFzdCBvbmUgaXRlbWA7XG4gICAgICB9XG4gICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHNlY3Rpb24uaXRlbXMubGVuZ3RoOyBqICs9IDEpIHtcbiAgICAgICAgY29uc3QgaXRlbSA9IHNlY3Rpb24uaXRlbXNbal07XG4gICAgICAgIGlmICghaXRlbS5pbWFnZVVybC50cmltKCkpIHtcbiAgICAgICAgICByZXR1cm4gYCR7cG9zaXRpb259IHN0b3J5IGl0ZW0gJHtqICsgMX06IG5lZWRzIGFuIGltYWdlYDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWl0ZW0ubGFiZWwudHJpbSgpKSB7XG4gICAgICAgICAgcmV0dXJuIGAke3Bvc2l0aW9ufSBzdG9yeSBpdGVtICR7aiArIDF9OiBuZWVkcyBhIGxhYmVsYDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWl0ZW0uaHJlZi50cmltKCkpIHtcbiAgICAgICAgICByZXR1cm4gYCR7cG9zaXRpb259IHN0b3J5IGl0ZW0gJHtqICsgMX06IG5lZWRzIGEgbGlua2A7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJpbWFnZV9zbGlkZXJcIikge1xuICAgICAgaWYgKHNlY3Rpb24uc2xpZGVzLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgcmV0dXJuIGAke3Bvc2l0aW9ufSAoaW1hZ2Ugc2xpZGVyKTogbmVlZHMgYXQgbGVhc3Qgb25lIHNsaWRlYDtcbiAgICAgIH1cbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgc2VjdGlvbi5zbGlkZXMubGVuZ3RoOyBqICs9IDEpIHtcbiAgICAgICAgaWYgKCFzZWN0aW9uLnNsaWRlc1tqXS5pbWFnZVVybC50cmltKCkpIHtcbiAgICAgICAgICByZXR1cm4gYCR7cG9zaXRpb259IHNsaWRlICR7aiArIDF9OiBuZWVkcyBhbiBpbWFnZSBVUkxgO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufTtcblxudHlwZSBDb250ZW50QmxvY2tFZGl0b3JQcm9wcyA9IHtcbiAgYmxvY2s6IEhvbWVwYWdlQ29udGVudEJsb2NrO1xuICBvbkNoYW5nZTogKHVwZGF0ZXI6IEJsb2NrVXBkYXRlcikgPT4gdm9pZDtcbiAgb25Qcm9kdWN0c1Jlc29sdmVkOiAocHJvZHVjdHM6IFByb2R1Y3RPcHRpb25bXSkgPT4gdm9pZDtcbiAgcHJvZHVjdE9wdGlvbnM6IFByb2R1Y3RPcHRpb25bXTtcbiAgcHJvZHVjdExvYWRpbmc6IGJvb2xlYW47XG4gIG9uUHJvZHVjdFNlYXJjaDogKHF1ZXJ5OiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uVXBsb2FkRXJyb3I6ICgpID0+IHZvaWQ7XG4gIGNvbXBhY3Q/OiBib29sZWFuO1xuICBhbGxvd1R5cGVTd2l0Y2g/OiBib29sZWFuO1xufTtcblxuY29uc3QgQ29udGVudEJsb2NrRWRpdG9yID0gKHtcbiAgYmxvY2ssXG4gIG9uQ2hhbmdlLFxuICBvblByb2R1Y3RzUmVzb2x2ZWQsXG4gIHByb2R1Y3RPcHRpb25zLFxuICBwcm9kdWN0TG9hZGluZyxcbiAgb25Qcm9kdWN0U2VhcmNoLFxuICBvblVwbG9hZEVycm9yLFxuICBjb21wYWN0ID0gZmFsc2UsXG4gIGFsbG93VHlwZVN3aXRjaCA9IGZhbHNlLFxufTogQ29udGVudEJsb2NrRWRpdG9yUHJvcHMpID0+IHtcbiAgY29uc3QgW3VwbG9hZGluZywgc2V0VXBsb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBzZWxlY3RlZFByb2R1Y3RzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKGJsb2NrLnR5cGUgIT09IFwicHJvZHVjdF9zbGlkZXJcIikgcmV0dXJuIFtdO1xuICAgIHJldHVybiBibG9jay5wcm9kdWN0SWRzLm1hcChcbiAgICAgIChpZCkgPT5cbiAgICAgICAgcHJvZHVjdE9wdGlvbnMuZmluZCgocCkgPT4gcC5pZCA9PT0gaWQpID8/IHtcbiAgICAgICAgICBpZCxcbiAgICAgICAgICBlbk5hbWU6IGBQcm9kdWN0ICMke2lkfWAsXG4gICAgICAgIH1cbiAgICApO1xuICB9LCBbYmxvY2ssIHByb2R1Y3RPcHRpb25zXSk7XG5cbiAgY29uc3QgYXV0b2NvbXBsZXRlT3B0aW9ucyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gbWVyZ2VQcm9kdWN0T3B0aW9ucyhwcm9kdWN0T3B0aW9ucywgc2VsZWN0ZWRQcm9kdWN0cyksXG4gICAgW3Byb2R1Y3RPcHRpb25zLCBzZWxlY3RlZFByb2R1Y3RzXVxuICApO1xuXG4gIHJldHVybiAoXG4gICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgZ2FwOiAyIH19PlxuICAgICAge2FsbG93VHlwZVN3aXRjaCAmJiAoXG4gICAgICAgIDxUb2dnbGVCdXR0b25Hcm91cFxuICAgICAgICAgIGV4Y2x1c2l2ZVxuICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgdmFsdWU9e2Jsb2NrLnR5cGV9XG4gICAgICAgICAgb25DaGFuZ2U9eyhfLCB2YWx1ZTogSG9tZXBhZ2VDb250ZW50QmxvY2tbXCJ0eXBlXCJdIHwgbnVsbCkgPT4ge1xuICAgICAgICAgICAgaWYgKCF2YWx1ZSB8fCB2YWx1ZSA9PT0gYmxvY2sudHlwZSkgcmV0dXJuO1xuICAgICAgICAgICAgb25DaGFuZ2UoKHByZXYpID0+XG4gICAgICAgICAgICAgIHZhbHVlID09PSBcImJhbm5lclwiXG4gICAgICAgICAgICAgICAgPyB7IC4uLmNyZWF0ZUJhbm5lcigpLCBpZDogcHJldi5pZCB9XG4gICAgICAgICAgICAgICAgOiB7IC4uLmNyZWF0ZVNsaWRlcigpLCBpZDogcHJldi5pZCB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8VG9nZ2xlQnV0dG9uIHZhbHVlPVwiYmFubmVyXCI+QmFubmVyPC9Ub2dnbGVCdXR0b24+XG4gICAgICAgICAgPFRvZ2dsZUJ1dHRvbiB2YWx1ZT1cInByb2R1Y3Rfc2xpZGVyXCI+UHJvZHVjdCBzbGlkZXI8L1RvZ2dsZUJ1dHRvbj5cbiAgICAgICAgPC9Ub2dnbGVCdXR0b25Hcm91cD5cbiAgICAgICl9XG5cbiAgICAgIHtibG9jay50eXBlID09PSBcImJhbm5lclwiID8gKFxuICAgICAgICA8PlxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgICAgIGdhcDogMixcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJmbGV4LXN0YXJ0XCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBjb21wYWN0ID8gMTQwIDogMjIwIH0sXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiBjb21wYWN0ID8gOTAgOiAxMjAsXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggZGFzaGVkXCIsXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I6IFwiZGl2aWRlclwiLFxuICAgICAgICAgICAgICAgIG92ZXJmbG93OiBcImhpZGRlblwiLFxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgYmdjb2xvcjogXCJiYWNrZ3JvdW5kLmRlZmF1bHRcIixcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2Jsb2NrLmltYWdlVXJsID8gKFxuICAgICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImltZ1wiXG4gICAgICAgICAgICAgICAgICBzcmM9e2Jsb2NrLmltYWdlVXJsfVxuICAgICAgICAgICAgICAgICAgYWx0PXtibG9jay5hbHQgfHwgXCJCYW5uZXIgcHJldmlld1wifVxuICAgICAgICAgICAgICAgICAgc3g9e3sgd2lkdGg6IFwiMTAwJVwiLCBoZWlnaHQ6IFwiMTAwJVwiLCBvYmplY3RGaXQ6IFwiY292ZXJcIiB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgICAgTm8gaW1hZ2VcbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L0JveD5cblxuICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgICAgIGZsZXg6IDEsXG4gICAgICAgICAgICAgICAgbWluV2lkdGg6IGNvbXBhY3QgPyAxNjAgOiAyMjAsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgICAgICBnYXA6IDEuNSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICAgICAgY29tcG9uZW50PVwibGFiZWxcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXt1cGxvYWRpbmd9XG4gICAgICAgICAgICAgICAgc2l6ZT17Y29tcGFjdCA/IFwic21hbGxcIiA6IFwibWVkaXVtXCJ9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dXBsb2FkaW5nID8gXCJVcGxvYWRpbmfigKZcIiA6IFwiVXBsb2FkIGltYWdlXCJ9XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICBoaWRkZW5cbiAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2FzeW5jIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZmlsZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICBzZXRVcGxvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXJscyA9IGF3YWl0IHVwbG9hZEltYWdlcyhbZmlsZV0pO1xuICAgICAgICAgICAgICAgICAgICAgIGlmICh1cmxzPy5bMF0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZ1bmN0aW9uYWwgdXBkYXRlIHNvIGNvbmN1cnJlbnQgZmllbGQgZWRpdHMgYXJlIG5vdCB3aXBlZC5cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKChwcmV2KSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwiYmFubmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4ucHJldiwgaW1hZ2VVcmw6IHVybHNbMF0gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcHJldlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgICAgICAgIG9uVXBsb2FkRXJyb3IoKTtcbiAgICAgICAgICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGxvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJJbWFnZSBVUkxcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtibG9jay5pbWFnZVVybH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGltYWdlVXJsID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZSgocHJldikgPT5cbiAgICAgICAgICAgICAgICAgICAgcHJldi50eXBlID09PSBcImJhbm5lclwiID8geyAuLi5wcmV2LCBpbWFnZVVybCB9IDogcHJldlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgaGVscGVyVGV4dD1cIlVwbG9hZCBvciBwYXN0ZSBhIENsb3VkaW5hcnkgVVJMXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvQm94PlxuXG4gICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleFdyYXA6IFwid3JhcFwiLCBnYXA6IDIgfX0+XG4gICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiTGluayBVUkwgKG9wdGlvbmFsKVwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Jsb2NrLmhyZWYgPz8gXCJcIn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGhyZWYgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKChwcmV2KSA9PlxuICAgICAgICAgICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwiYmFubmVyXCIgPyB7IC4uLnByZXYsIGhyZWYgfSA6IHByZXZcbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQWx0IHRleHQgKG9wdGlvbmFsKVwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Jsb2NrLmFsdCA/PyBcIlwifVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgYWx0ID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZSgocHJldikgPT5cbiAgICAgICAgICAgICAgICAgICAgcHJldi50eXBlID09PSBcImJhbm5lclwiID8geyAuLi5wcmV2LCBhbHQgfSA6IHByZXZcbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgPC9Cb3g+XG4gICAgICAgIDwvPlxuICAgICAgKSA6IChcbiAgICAgICAgPD5cbiAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICBsYWJlbD1cIlNsaWRlciB0aXRsZVwiXG4gICAgICAgICAgICB2YWx1ZT17YmxvY2sudGl0bGV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgdGl0bGUgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgb25DaGFuZ2UoKHByZXYpID0+XG4gICAgICAgICAgICAgICAgcHJldi50eXBlID09PSBcInByb2R1Y3Rfc2xpZGVyXCIgPyB7IC4uLnByZXYsIHRpdGxlIH0gOiBwcmV2XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgPEJveFxuICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDQwLFxuICAgICAgICAgICAgICAgIGhlaWdodDogNDAsXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICAgICAgYmdjb2xvcjogSEVYX0NPTE9SX1JFLnRlc3QoYmxvY2suYmFja2dyb3VuZENvbG9yPy50cmltKCkgPz8gXCJcIilcbiAgICAgICAgICAgICAgICAgID8gYmxvY2suYmFja2dyb3VuZENvbG9yXG4gICAgICAgICAgICAgICAgICA6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6ICFIRVhfQ09MT1JfUkUudGVzdChcbiAgICAgICAgICAgICAgICAgIGJsb2NrLmJhY2tncm91bmRDb2xvcj8udHJpbSgpID8/IFwiXCJcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICA/IFwibGluZWFyLWdyYWRpZW50KDQ1ZGVnLCAjY2NjIDI1JSwgdHJhbnNwYXJlbnQgMjUlKSwgbGluZWFyLWdyYWRpZW50KC00NWRlZywgI2NjYyAyNSUsIHRyYW5zcGFyZW50IDI1JSksIGxpbmVhci1ncmFkaWVudCg0NWRlZywgdHJhbnNwYXJlbnQgNzUlLCAjY2NjIDc1JSksIGxpbmVhci1ncmFkaWVudCgtNDVkZWcsIHRyYW5zcGFyZW50IDc1JSwgI2NjYyA3NSUpXCJcbiAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRTaXplOiBcIjhweCA4cHhcIixcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kUG9zaXRpb246IFwiMCAwLCAwIDRweCwgNHB4IC00cHgsIC00cHggMFwiLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgY29tcG9uZW50PVwiaW5wdXRcIlxuICAgICAgICAgICAgICB0eXBlPVwiY29sb3JcIlxuICAgICAgICAgICAgICB2YWx1ZT17XG4gICAgICAgICAgICAgICAgSEVYX0NPTE9SX1JFLnRlc3QoYmxvY2suYmFja2dyb3VuZENvbG9yPy50cmltKCkgPz8gXCJcIilcbiAgICAgICAgICAgICAgICAgID8gYmxvY2suYmFja2dyb3VuZENvbG9yIS50cmltKClcbiAgICAgICAgICAgICAgICAgIDogXCIjZTkxZThjXCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGU6IENoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgYmFja2dyb3VuZENvbG9yID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgb25DaGFuZ2UoKHByZXYpID0+XG4gICAgICAgICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIlxuICAgICAgICAgICAgICAgICAgICA/IHsgLi4ucHJldiwgYmFja2dyb3VuZENvbG9yIH1cbiAgICAgICAgICAgICAgICAgICAgOiBwcmV2XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogNDgsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA0MCxcbiAgICAgICAgICAgICAgICBwOiAwLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxLFxuICAgICAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgICAgICAgICAgICAgYmdjb2xvcjogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgZmxleDogMSwgbWluV2lkdGg6IDE0MCB9fT5cbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQmFja2dyb3VuZCBjb2xvciAob3B0aW9uYWwpXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YmxvY2suYmFja2dyb3VuZENvbG9yID8/IFwiXCJ9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBiYWNrZ3JvdW5kQ29sb3IgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKChwcmV2KSA9PlxuICAgICAgICAgICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5wcmV2LCBiYWNrZ3JvdW5kQ29sb3IgfVxuICAgICAgICAgICAgICAgICAgICAgIDogcHJldlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIjRTkxRThDXCJcbiAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PVwiSGV4ICNSUkdHQkIg4oCUIGxlYXZlIGVtcHR5IGZvciBub25lXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgeyhibG9jay5iYWNrZ3JvdW5kQ29sb3IgPz8gXCJcIikudHJpbSgpICE9PSBcIlwiICYmIChcbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKChwcmV2KSA9PlxuICAgICAgICAgICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5wcmV2LCBiYWNrZ3JvdW5kQ29sb3I6IFwiXCIgfVxuICAgICAgICAgICAgICAgICAgICAgIDogcHJldlxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENsZWFyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0JveD5cblxuICAgICAgICAgIDxBdXRvY29tcGxldGVcbiAgICAgICAgICAgIG11bHRpcGxlXG4gICAgICAgICAgICBvcHRpb25zPXthdXRvY29tcGxldGVPcHRpb25zfVxuICAgICAgICAgICAgbG9hZGluZz17cHJvZHVjdExvYWRpbmd9XG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQcm9kdWN0c31cbiAgICAgICAgICAgIGZpbHRlclNlbGVjdGVkT3B0aW9uc1xuICAgICAgICAgICAgZmlsdGVyT3B0aW9ucz17KG9wdGlvbnMpID0+IG9wdGlvbnN9XG4gICAgICAgICAgICBnZXRPcHRpb25MYWJlbD17KG9wdGlvbikgPT5cbiAgICAgICAgICAgICAgb3B0aW9uLmVuTmFtZSB8fCBvcHRpb24ucHJOYW1lIHx8IGAjJHtvcHRpb24uaWR9YFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaXNPcHRpb25FcXVhbFRvVmFsdWU9eyhhLCBiKSA9PiBhLmlkID09PSBiLmlkfVxuICAgICAgICAgICAgb25JbnB1dENoYW5nZT17KF8sIHZhbHVlLCByZWFzb24pID0+IHtcbiAgICAgICAgICAgICAgaWYgKHJlYXNvbiA9PT0gXCJpbnB1dFwiKSBvblByb2R1Y3RTZWFyY2godmFsdWUpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoXywgdmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgb25Qcm9kdWN0c1Jlc29sdmVkKHZhbHVlKTtcbiAgICAgICAgICAgICAgY29uc3QgcHJvZHVjdElkcyA9IHZhbHVlLm1hcCgocCkgPT4gcC5pZCk7XG4gICAgICAgICAgICAgIG9uQ2hhbmdlKChwcmV2KSA9PlxuICAgICAgICAgICAgICAgIHByZXYudHlwZSA9PT0gXCJwcm9kdWN0X3NsaWRlclwiXG4gICAgICAgICAgICAgICAgICA/IHsgLi4ucHJldiwgcHJvZHVjdElkcyB9XG4gICAgICAgICAgICAgICAgICA6IHByZXZcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICByZW5kZXJJbnB1dD17KHBhcmFtcykgPT4gKFxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICAgICAgey4uLnBhcmFtc31cbiAgICAgICAgICAgICAgICBsYWJlbD1cIlByb2R1Y3RzXCJcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgIGhlbHBlclRleHQ9XCJTZWFyY2ggYW5kIHBpY2sgcHJvZHVjdHMgaW4gZGlzcGxheSBvcmRlclwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L0JveD5cbiAgKTtcbn07XG5cbnR5cGUgU3RvcnlMaW5rc0VkaXRvclByb3BzID0ge1xuICBzZWN0aW9uOiBIb21lcGFnZVN0b3J5TGlua3NTZWN0aW9uO1xuICBvbkNoYW5nZTogKHVwZGF0ZXI6IFNlY3Rpb25VcGRhdGVyKSA9PiB2b2lkO1xuICBvblVwbG9hZEVycm9yOiAoKSA9PiB2b2lkO1xufTtcblxuY29uc3QgU3RvcnlMaW5rc0VkaXRvciA9ICh7XG4gIHNlY3Rpb24sXG4gIG9uQ2hhbmdlLFxuICBvblVwbG9hZEVycm9yLFxufTogU3RvcnlMaW5rc0VkaXRvclByb3BzKSA9PiB7XG4gIGNvbnN0IFt1cGxvYWRpbmdJZCwgc2V0VXBsb2FkaW5nSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgdXBkYXRlSXRlbSA9IChcbiAgICBpdGVtSWQ6IHN0cmluZyxcbiAgICBwYXRjaDogUGFydGlhbDxIb21lcGFnZVN0b3J5TGlua0l0ZW0+XG4gICkgPT4ge1xuICAgIG9uQ2hhbmdlKChwcmV2KSA9PiB7XG4gICAgICBpZiAocHJldi50eXBlICE9PSBcInN0b3J5X2xpbmtzXCIpIHJldHVybiBwcmV2O1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgaXRlbXM6IHByZXYuaXRlbXMubWFwKChpdGVtKSA9PlxuICAgICAgICAgIGl0ZW0uaWQgPT09IGl0ZW1JZCA/IHsgLi4uaXRlbSwgLi4ucGF0Y2ggfSA6IGl0ZW1cbiAgICAgICAgKSxcbiAgICAgIH07XG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgbW92ZUl0ZW0gPSAoaW5kZXg6IG51bWJlciwgZGlyZWN0aW9uOiAtMSB8IDEpID0+IHtcbiAgICBvbkNoYW5nZSgocHJldikgPT4ge1xuICAgICAgaWYgKHByZXYudHlwZSAhPT0gXCJzdG9yeV9saW5rc1wiKSByZXR1cm4gcHJldjtcbiAgICAgIGNvbnN0IG5leHRJbmRleCA9IGluZGV4ICsgZGlyZWN0aW9uO1xuICAgICAgaWYgKG5leHRJbmRleCA8IDAgfHwgbmV4dEluZGV4ID49IHByZXYuaXRlbXMubGVuZ3RoKSByZXR1cm4gcHJldjtcbiAgICAgIHJldHVybiB7IC4uLnByZXYsIGl0ZW1zOiBhcnJheU1vdmUocHJldi5pdGVtcywgaW5kZXgsIG5leHRJbmRleCkgfTtcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMiB9fT5cbiAgICAgIHtzZWN0aW9uLml0ZW1zLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgPEJveFxuICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgZ2FwOiAxLjUsXG4gICAgICAgICAgICBwOiAxLjUsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEuNSxcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgIGJnY29sb3I6IFwiYmFja2dyb3VuZC5kZWZhdWx0XCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXG4gICAgICAgICAgICAgIGdhcDogMSxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMlwiIHN4PXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT5cbiAgICAgICAgICAgICAgSXRlbSB7aW5kZXggKyAxfVxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxuICAgICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiAwLjUgfX0+XG4gICAgICAgICAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aW5kZXggPT09IDB9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbW92ZUl0ZW0oaW5kZXgsIC0xKX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTW92ZSB1cFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QXJyb3dVcHdhcmRJY29uIGZvbnRTaXplPVwic21hbGxcIiAvPlxuICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgICAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aW5kZXggPT09IHNlY3Rpb24uaXRlbXMubGVuZ3RoIC0gMX1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtb3ZlSXRlbShpbmRleCwgMSl9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk1vdmUgZG93blwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QXJyb3dEb3dud2FyZEljb24gZm9udFNpemU9XCJzbWFsbFwiIC8+XG4gICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgIGNvbG9yPVwiZXJyb3JcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZWN0aW9uLml0ZW1zLmxlbmd0aCA8PSAxfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZSgocHJldikgPT5cbiAgICAgICAgICAgICAgICAgICAgcHJldi50eXBlID09PSBcInN0b3J5X2xpbmtzXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IHByZXYuaXRlbXMuZmlsdGVyKChpKSA9PiBpLmlkICE9PSBpdGVtLmlkKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICA6IHByZXZcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZSBpdGVtXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxEZWxldGVPdXRsaW5lZEljb24gZm9udFNpemU9XCJzbWFsbFwiIC8+XG4gICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvQm94PlxuXG4gICAgICAgICAgPEJveFxuICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImZsZXgtc3RhcnRcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgICAgIHdpZHRoOiA4MCxcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDgwLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCI1MCVcIixcbiAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IGRhc2hlZFwiLFxuICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICAgIGJnY29sb3I6IFwiYmFja2dyb3VuZC5wYXBlclwiLFxuICAgICAgICAgICAgICAgIGZsZXhTaHJpbms6IDAsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpdGVtLmltYWdlVXJsID8gKFxuICAgICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImltZ1wiXG4gICAgICAgICAgICAgICAgICBzcmM9e2l0ZW0uaW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgICBhbHQ9e2l0ZW0ubGFiZWwgfHwgXCJTdG9yeSBwcmV2aWV3XCJ9XG4gICAgICAgICAgICAgICAgICBzeD17eyB3aWR0aDogXCIxMDAlXCIsIGhlaWdodDogXCIxMDAlXCIsIG9iamVjdEZpdDogXCJjb3ZlclwiIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8Q2lyY2xlT3V0bGluZWRJY29uIGNvbG9yPVwiZGlzYWJsZWRcIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICBmbGV4OiAxLFxuICAgICAgICAgICAgICAgIG1pbldpZHRoOiAyMDAsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgICAgICBnYXA6IDEuNSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICAgICAgY29tcG9uZW50PVwibGFiZWxcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXt1cGxvYWRpbmdJZCA9PT0gaXRlbS5pZH1cbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3VwbG9hZGluZ0lkID09PSBpdGVtLmlkID8gXCJVcGxvYWRpbmfigKZcIiA6IFwiVXBsb2FkIGltYWdlXCJ9XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICBoaWRkZW5cbiAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2FzeW5jIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZmlsZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICBzZXRVcGxvYWRpbmdJZChpdGVtLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cmxzID0gYXdhaXQgdXBsb2FkSW1hZ2VzKFtmaWxlXSk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHVybHM/LlswXSkgdXBkYXRlSXRlbShpdGVtLmlkLCB7IGltYWdlVXJsOiB1cmxzWzBdIH0pO1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAgICAgICBvblVwbG9hZEVycm9yKCk7XG4gICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBsb2FkaW5nSWQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkltYWdlIFVSTFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0uaW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgdXBkYXRlSXRlbShpdGVtLmlkLCB7IGltYWdlVXJsOiBlLnRhcmdldC52YWx1ZSB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgICA8Qm94IHN4PXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4V3JhcDogXCJ3cmFwXCIsIGdhcDogMiB9fT5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgd2lkdGg6IHsgeHM6IFwiMTAwJVwiLCBtZDogXCJjYWxjKDUwJSAtIDhweClcIiB9IH19PlxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJMYWJlbFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVJdGVtKGl0ZW0uaWQsIHsgbGFiZWw6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPEJveCBzeD17eyB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiBcImNhbGMoNTAlIC0gOHB4KVwiIH0gfX0+XG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkxpbmsgVVJMXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS5ocmVmfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlSXRlbShpdGVtLmlkLCB7IGhyZWY6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L0JveD5cbiAgICAgICkpfVxuXG4gICAgICA8QnV0dG9uXG4gICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgIHN0YXJ0SWNvbj17PEFkZEljb24gLz59XG4gICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgb25DaGFuZ2UoKHByZXYpID0+XG4gICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwic3RvcnlfbGlua3NcIlxuICAgICAgICAgICAgICA/IHsgLi4ucHJldiwgaXRlbXM6IFsuLi5wcmV2Lml0ZW1zLCBjcmVhdGVTdG9yeUl0ZW0oKV0gfVxuICAgICAgICAgICAgICA6IHByZXZcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgID5cbiAgICAgICAgQWRkIHN0b3J5IGl0ZW1cbiAgICAgIDwvQnV0dG9uPlxuICAgIDwvQm94PlxuICApO1xufTtcblxudHlwZSBJbWFnZVNsaWRlckVkaXRvclByb3BzID0ge1xuICBzZWN0aW9uOiBIb21lcGFnZUltYWdlU2xpZGVyU2VjdGlvbjtcbiAgb25DaGFuZ2U6ICh1cGRhdGVyOiBTZWN0aW9uVXBkYXRlcikgPT4gdm9pZDtcbiAgb25VcGxvYWRFcnJvcjogKCkgPT4gdm9pZDtcbn07XG5cbmNvbnN0IEltYWdlU2xpZGVyRWRpdG9yID0gKHtcbiAgc2VjdGlvbixcbiAgb25DaGFuZ2UsXG4gIG9uVXBsb2FkRXJyb3IsXG59OiBJbWFnZVNsaWRlckVkaXRvclByb3BzKSA9PiB7XG4gIGNvbnN0IFt1cGxvYWRpbmdJZCwgc2V0VXBsb2FkaW5nSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgdXBkYXRlU2xpZGUgPSAoc2xpZGVJZDogc3RyaW5nLCBwYXRjaDogUGFydGlhbDxIb21lcGFnZUltYWdlU2xpZGU+KSA9PiB7XG4gICAgb25DaGFuZ2UoKHByZXYpID0+IHtcbiAgICAgIGlmIChwcmV2LnR5cGUgIT09IFwiaW1hZ2Vfc2xpZGVyXCIpIHJldHVybiBwcmV2O1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgc2xpZGVzOiBwcmV2LnNsaWRlcy5tYXAoKHNsaWRlKSA9PlxuICAgICAgICAgIHNsaWRlLmlkID09PSBzbGlkZUlkID8geyAuLi5zbGlkZSwgLi4ucGF0Y2ggfSA6IHNsaWRlXG4gICAgICAgICksXG4gICAgICB9O1xuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IG1vdmVTbGlkZSA9IChpbmRleDogbnVtYmVyLCBkaXJlY3Rpb246IC0xIHwgMSkgPT4ge1xuICAgIG9uQ2hhbmdlKChwcmV2KSA9PiB7XG4gICAgICBpZiAocHJldi50eXBlICE9PSBcImltYWdlX3NsaWRlclwiKSByZXR1cm4gcHJldjtcbiAgICAgIGNvbnN0IG5leHRJbmRleCA9IGluZGV4ICsgZGlyZWN0aW9uO1xuICAgICAgaWYgKG5leHRJbmRleCA8IDAgfHwgbmV4dEluZGV4ID49IHByZXYuc2xpZGVzLmxlbmd0aCkgcmV0dXJuIHByZXY7XG4gICAgICByZXR1cm4geyAuLi5wcmV2LCBzbGlkZXM6IGFycmF5TW92ZShwcmV2LnNsaWRlcywgaW5kZXgsIG5leHRJbmRleCkgfTtcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMiB9fT5cbiAgICAgIHtzZWN0aW9uLnNsaWRlcy5tYXAoKHNsaWRlLCBpbmRleCkgPT4gKFxuICAgICAgICA8Qm94XG4gICAgICAgICAga2V5PXtzbGlkZS5pZH1cbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgZ2FwOiAxLjUsXG4gICAgICAgICAgICBwOiAxLjUsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEuNSxcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgIGJnY29sb3I6IFwiYmFja2dyb3VuZC5kZWZhdWx0XCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXG4gICAgICAgICAgICAgIGdhcDogMSxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMlwiIHN4PXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT5cbiAgICAgICAgICAgICAgU2xpZGUge2luZGV4ICsgMX1cbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMC41IH19PlxuICAgICAgICAgICAgICA8SWNvbkJ1dHRvblxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2luZGV4ID09PSAwfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG1vdmVTbGlkZShpbmRleCwgLTEpfVxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNb3ZlIHVwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBcnJvd1Vwd2FyZEljb24gZm9udFNpemU9XCJzbWFsbFwiIC8+XG4gICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpbmRleCA9PT0gc2VjdGlvbi5zbGlkZXMubGVuZ3RoIC0gMX1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtb3ZlU2xpZGUoaW5kZXgsIDEpfVxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNb3ZlIGRvd25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEFycm93RG93bndhcmRJY29uIGZvbnRTaXplPVwic21hbGxcIiAvPlxuICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgICAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICBjb2xvcj1cImVycm9yXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2VjdGlvbi5zbGlkZXMubGVuZ3RoIDw9IDF9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlKChwcmV2KSA9PlxuICAgICAgICAgICAgICAgICAgICBwcmV2LnR5cGUgPT09IFwiaW1hZ2Vfc2xpZGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2xpZGVzOiBwcmV2LnNsaWRlcy5maWx0ZXIoKHMpID0+IHMuaWQgIT09IHNsaWRlLmlkKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICA6IHByZXZcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZSBzbGlkZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8RGVsZXRlT3V0bGluZWRJY29uIGZvbnRTaXplPVwic21hbGxcIiAvPlxuICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICA8L0JveD5cblxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgICAgIGdhcDogMixcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJmbGV4LXN0YXJ0XCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgc3g9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogeyB4czogXCIxMDAlXCIsIG1kOiAyMjAgfSxcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEyMCxcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEsXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBkYXNoZWRcIixcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogXCJkaXZpZGVyXCIsXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6IFwiaGlkZGVuXCIsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICBiZ2NvbG9yOiBcImJhY2tncm91bmQucGFwZXJcIixcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3NsaWRlLmltYWdlVXJsID8gKFxuICAgICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImltZ1wiXG4gICAgICAgICAgICAgICAgICBzcmM9e3NsaWRlLmltYWdlVXJsfVxuICAgICAgICAgICAgICAgICAgYWx0PXtzbGlkZS5hbHQgfHwgXCJTbGlkZSBwcmV2aWV3XCJ9XG4gICAgICAgICAgICAgICAgICBzeD17eyB3aWR0aDogXCIxMDAlXCIsIGhlaWdodDogXCIxMDAlXCIsIG9iamVjdEZpdDogXCJjb3ZlclwiIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICBObyBpbWFnZVxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQm94PlxuXG4gICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgZmxleDogMSxcbiAgICAgICAgICAgICAgICBtaW5XaWR0aDogMjIwLFxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICAgICAgZ2FwOiAxLjUsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImxhYmVsXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXBsb2FkaW5nSWQgPT09IHNsaWRlLmlkfVxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dXBsb2FkaW5nSWQgPT09IHNsaWRlLmlkID8gXCJVcGxvYWRpbmfigKZcIiA6IFwiVXBsb2FkIGltYWdlXCJ9XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICBoaWRkZW5cbiAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2FzeW5jIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZmlsZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICBzZXRVcGxvYWRpbmdJZChzbGlkZS5pZCk7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXJscyA9IGF3YWl0IHVwbG9hZEltYWdlcyhbZmlsZV0pO1xuICAgICAgICAgICAgICAgICAgICAgIGlmICh1cmxzPy5bMF0pXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVTbGlkZShzbGlkZS5pZCwgeyBpbWFnZVVybDogdXJsc1swXSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgICAgICAgb25VcGxvYWRFcnJvcigpO1xuICAgICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICAgIHNldFVwbG9hZGluZ0lkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJJbWFnZSBVUkxcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzbGlkZS5pbWFnZVVybH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICB1cGRhdGVTbGlkZShzbGlkZS5pZCwgeyBpbWFnZVVybDogZS50YXJnZXQudmFsdWUgfSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvQm94PlxuXG4gICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleFdyYXA6IFwid3JhcFwiLCBnYXA6IDIgfX0+XG4gICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiTGluayBVUkwgKG9wdGlvbmFsKVwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NsaWRlLmhyZWYgPz8gXCJcIn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICB1cGRhdGVTbGlkZShzbGlkZS5pZCwgeyBocmVmOiBlLnRhcmdldC52YWx1ZSB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8Qm94IHN4PXt7IHdpZHRoOiB7IHhzOiBcIjEwMCVcIiwgbWQ6IFwiY2FsYyg1MCUgLSA4cHgpXCIgfSB9fT5cbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQWx0IHRleHQgKG9wdGlvbmFsKVwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NsaWRlLmFsdCA/PyBcIlwifVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlU2xpZGUoc2xpZGUuaWQsIHsgYWx0OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgPC9Cb3g+XG4gICAgICAgIDwvQm94PlxuICAgICAgKSl9XG5cbiAgICAgIDxCdXR0b25cbiAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcbiAgICAgICAgc3RhcnRJY29uPXs8QWRkSWNvbiAvPn1cbiAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICBvbkNoYW5nZSgocHJldikgPT5cbiAgICAgICAgICAgIHByZXYudHlwZSA9PT0gXCJpbWFnZV9zbGlkZXJcIlxuICAgICAgICAgICAgICA/IHsgLi4ucHJldiwgc2xpZGVzOiBbLi4ucHJldi5zbGlkZXMsIGNyZWF0ZUltYWdlU2xpZGUoKV0gfVxuICAgICAgICAgICAgICA6IHByZXZcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgID5cbiAgICAgICAgQWRkIHNsaWRlXG4gICAgICA8L0J1dHRvbj5cbiAgICA8L0JveD5cbiAgKTtcbn07XG5cbnR5cGUgU29ydGFibGVTZWN0aW9uUHJvcHMgPSB7XG4gIHNlY3Rpb246IEhvbWVwYWdlU2VjdGlvbjtcbiAgZXhwYW5kZWQ6IGJvb2xlYW47XG4gIG9uVG9nZ2xlOiAoKSA9PiB2b2lkO1xuICBvbkNoYW5nZTogKHVwZGF0ZXI6IFNlY3Rpb25VcGRhdGVyKSA9PiB2b2lkO1xuICBvblJlbW92ZTogKCkgPT4gdm9pZDtcbiAgb25Qcm9kdWN0c1Jlc29sdmVkOiAocHJvZHVjdHM6IFByb2R1Y3RPcHRpb25bXSkgPT4gdm9pZDtcbiAgcHJvZHVjdE9wdGlvbnM6IFByb2R1Y3RPcHRpb25bXTtcbiAgcHJvZHVjdExvYWRpbmc6IGJvb2xlYW47XG4gIG9uUHJvZHVjdFNlYXJjaDogKHF1ZXJ5OiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uVXBsb2FkRXJyb3I6ICgpID0+IHZvaWQ7XG59O1xuXG5jb25zdCBzZWN0aW9uTGFiZWwgPSAoc2VjdGlvbjogSG9tZXBhZ2VTZWN0aW9uKSA9PiB7XG4gIGlmIChzZWN0aW9uLnR5cGUgPT09IFwiYmFubmVyXCIpIHJldHVybiBcIkJhbm5lclwiO1xuICBpZiAoc2VjdGlvbi50eXBlID09PSBcInByb2R1Y3Rfc2xpZGVyXCIpIHtcbiAgICByZXR1cm4gc2VjdGlvbi50aXRsZSB8fCBcIlByb2R1Y3Qgc2xpZGVyXCI7XG4gIH1cbiAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJzdG9yeV9saW5rc1wiKSByZXR1cm4gXCJTdG9yeSBsaW5rc1wiO1xuICBpZiAoc2VjdGlvbi50eXBlID09PSBcImltYWdlX3NsaWRlclwiKSB7XG4gICAgcmV0dXJuIGBJbWFnZSBzbGlkZXIgKCR7c2VjdGlvbi5zbGlkZXMubGVuZ3RofSlgO1xuICB9XG4gIHJldHVybiBgUm93ICgke3NlY3Rpb24uY29sdW1ucy5sZW5ndGh9IGNvbHVtbnMpYDtcbn07XG5cbmNvbnN0IHNlY3Rpb25DaGlwID0gKHNlY3Rpb246IEhvbWVwYWdlU2VjdGlvbikgPT4ge1xuICBpZiAoc2VjdGlvbi50eXBlID09PSBcImJhbm5lclwiKSByZXR1cm4gXCJCYW5uZXJcIjtcbiAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJwcm9kdWN0X3NsaWRlclwiKSByZXR1cm4gXCJTbGlkZXJcIjtcbiAgaWYgKHNlY3Rpb24udHlwZSA9PT0gXCJzdG9yeV9saW5rc1wiKSByZXR1cm4gXCJTdG9yaWVzXCI7XG4gIGlmIChzZWN0aW9uLnR5cGUgPT09IFwiaW1hZ2Vfc2xpZGVyXCIpIHJldHVybiBcIkltYWdlc1wiO1xuICByZXR1cm4gXCJSb3dcIjtcbn07XG5cbmNvbnN0IFNvcnRhYmxlU2VjdGlvbiA9ICh7XG4gIHNlY3Rpb24sXG4gIGV4cGFuZGVkLFxuICBvblRvZ2dsZSxcbiAgb25DaGFuZ2UsXG4gIG9uUmVtb3ZlLFxuICBvblByb2R1Y3RzUmVzb2x2ZWQsXG4gIHByb2R1Y3RPcHRpb25zLFxuICBwcm9kdWN0TG9hZGluZyxcbiAgb25Qcm9kdWN0U2VhcmNoLFxuICBvblVwbG9hZEVycm9yLFxufTogU29ydGFibGVTZWN0aW9uUHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIGF0dHJpYnV0ZXMsXG4gICAgbGlzdGVuZXJzLFxuICAgIHNldE5vZGVSZWYsXG4gICAgdHJhbnNmb3JtLFxuICAgIHRyYW5zaXRpb24sXG4gICAgaXNEcmFnZ2luZyxcbiAgfSA9IHVzZVNvcnRhYmxlKHsgaWQ6IHNlY3Rpb24uaWQgfSk7XG5cbiAgY29uc3Qgc3R5bGUgPSB7XG4gICAgdHJhbnNmb3JtOiBDU1MuVHJhbnNmb3JtLnRvU3RyaW5nKHRyYW5zZm9ybSksXG4gICAgdHJhbnNpdGlvbixcbiAgICBvcGFjaXR5OiBpc0RyYWdnaW5nID8gMC43IDogMSxcbiAgfTtcblxuICBjb25zdCBzZXRDb2x1bW5Db3VudCA9IChjb3VudDogbnVtYmVyKSA9PiB7XG4gICAgb25DaGFuZ2UoKHByZXYpID0+IHtcbiAgICAgIGlmIChwcmV2LnR5cGUgIT09IFwicm93XCIpIHJldHVybiBwcmV2O1xuICAgICAgY29uc3QgbmV4dENvbHVtbnMgPSBbLi4ucHJldi5jb2x1bW5zXTtcbiAgICAgIHdoaWxlIChuZXh0Q29sdW1ucy5sZW5ndGggPCBjb3VudCkge1xuICAgICAgICBuZXh0Q29sdW1ucy5wdXNoKGNyZWF0ZUJhbm5lcigpKTtcbiAgICAgIH1cbiAgICAgIHdoaWxlIChuZXh0Q29sdW1ucy5sZW5ndGggPiBjb3VudCkge1xuICAgICAgICBuZXh0Q29sdW1ucy5wb3AoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IC4uLnByZXYsIGNvbHVtbnM6IG5leHRDb2x1bW5zIH07XG4gICAgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8Qm94XG4gICAgICByZWY9e3NldE5vZGVSZWZ9XG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgICBzeD17e1xuICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAyLFxuICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkXCIsXG4gICAgICAgIGJvcmRlckNvbG9yOiBpc0RyYWdnaW5nID8gXCJwcmltYXJ5Lm1haW5cIiA6IFwiZGl2aWRlclwiLFxuICAgICAgICBiZ2NvbG9yOiBcImJhY2tncm91bmQucGFwZXJcIixcbiAgICAgICAgYm94U2hhZG93OiBpc0RyYWdnaW5nID8gMiA6IDAsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgIGdhcDogMSxcbiAgICAgICAgICBweDogMS41LFxuICAgICAgICAgIHB5OiAxLFxuICAgICAgICAgIGJvcmRlckJvdHRvbTogZXhwYW5kZWQgPyBcIjFweCBzb2xpZFwiIDogXCJub25lXCIsXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IFwiZGl2aWRlclwiLFxuICAgICAgICAgIGJnY29sb3I6ICh0aGVtZSkgPT5cbiAgICAgICAgICAgIHRoZW1lLnBhbGV0dGUubW9kZSA9PT0gXCJkYXJrXCJcbiAgICAgICAgICAgICAgPyBcImFjdGlvbi5ob3ZlclwiXG4gICAgICAgICAgICAgIDogXCJiYWNrZ3JvdW5kLmRlZmF1bHRcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgIHsuLi5hdHRyaWJ1dGVzfVxuICAgICAgICAgIHsuLi5saXN0ZW5lcnN9XG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkRyYWcgdG8gcmVvcmRlclwiXG4gICAgICAgICAgc3g9e3sgY3Vyc29yOiBcImdyYWJcIiwgY29sb3I6IFwidGV4dC5zZWNvbmRhcnlcIiB9fVxuICAgICAgICA+XG4gICAgICAgICAgPERyYWdJbmRpY2F0b3JJY29uIC8+XG4gICAgICAgIDwvSWNvbkJ1dHRvbj5cblxuICAgICAgICB7c2VjdGlvbi50eXBlID09PSBcImJhbm5lclwiID8gKFxuICAgICAgICAgIDxJbWFnZUljb24gZm9udFNpemU9XCJzbWFsbFwiIHN4PXt7IGNvbG9yOiBcInRleHQuc2Vjb25kYXJ5XCIgfX0gLz5cbiAgICAgICAgKSA6IHNlY3Rpb24udHlwZSA9PT0gXCJwcm9kdWN0X3NsaWRlclwiID8gKFxuICAgICAgICAgIDxWaWV3Q2Fyb3VzZWxJY29uIGZvbnRTaXplPVwic21hbGxcIiBzeD17eyBjb2xvcjogXCJ0ZXh0LnNlY29uZGFyeVwiIH19IC8+XG4gICAgICAgICkgOiBzZWN0aW9uLnR5cGUgPT09IFwic3RvcnlfbGlua3NcIiA/IChcbiAgICAgICAgICA8Q2lyY2xlT3V0bGluZWRJY29uXG4gICAgICAgICAgICBmb250U2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgIHN4PXt7IGNvbG9yOiBcInRleHQuc2Vjb25kYXJ5XCIgfX1cbiAgICAgICAgICAvPlxuICAgICAgICApIDogc2VjdGlvbi50eXBlID09PSBcImltYWdlX3NsaWRlclwiID8gKFxuICAgICAgICAgIDxDb2xsZWN0aW9uc0ljb24gZm9udFNpemU9XCJzbWFsbFwiIHN4PXt7IGNvbG9yOiBcInRleHQuc2Vjb25kYXJ5XCIgfX0gLz5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8Vmlld1dlZWtJY29uIGZvbnRTaXplPVwic21hbGxcIiBzeD17eyBjb2xvcjogXCJ0ZXh0LnNlY29uZGFyeVwiIH19IC8+XG4gICAgICAgICl9XG5cbiAgICAgICAgPFR5cG9ncmFwaHkgc3g9e3sgZmxleDogMSwgZm9udFdlaWdodDogNjAwLCBjb2xvcjogXCJ0ZXh0LnByaW1hcnlcIiB9fT5cbiAgICAgICAgICB7c2VjdGlvbkxhYmVsKHNlY3Rpb24pfVxuICAgICAgICA8L1R5cG9ncmFwaHk+XG5cbiAgICAgICAgPENoaXBcbiAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgIGxhYmVsPXtzZWN0aW9uQ2hpcChzZWN0aW9uKX1cbiAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXG4gICAgICAgIC8+XG5cbiAgICAgICAgPEljb25CdXR0b25cbiAgICAgICAgICBzaXplPVwic21hbGxcIlxuICAgICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlfVxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgc2VjdGlvblwiXG4gICAgICAgICAgc3g9e3sgY29sb3I6IFwidGV4dC5zZWNvbmRhcnlcIiB9fVxuICAgICAgICA+XG4gICAgICAgICAge2V4cGFuZGVkID8gPEV4cGFuZExlc3NJY29uIC8+IDogPEV4cGFuZE1vcmVJY29uIC8+fVxuICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICAgIDxJY29uQnV0dG9uXG4gICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICBjb2xvcj1cImVycm9yXCJcbiAgICAgICAgICBvbkNsaWNrPXtvblJlbW92ZX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUmVtb3ZlIHNlY3Rpb25cIlxuICAgICAgICA+XG4gICAgICAgICAgPERlbGV0ZU91dGxpbmVkSWNvbiAvPlxuICAgICAgICA8L0ljb25CdXR0b24+XG4gICAgICA8L0JveD5cblxuICAgICAgPENvbGxhcHNlIGluPXtleHBhbmRlZH0+XG4gICAgICAgIDxCb3ggc3g9e3sgcDogMiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIGdhcDogMiB9fT5cbiAgICAgICAgICB7c2VjdGlvbi50eXBlID09PSBcInJvd1wiID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgICBnYXA6IDIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MlwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgIENvbHVtbnMgKGVxdWFsIHdpZHRoKVxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICA8VG9nZ2xlQnV0dG9uR3JvdXBcbiAgICAgICAgICAgICAgICAgIGV4Y2x1c2l2ZVxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWN0aW9uLmNvbHVtbnMubGVuZ3RofVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhfLCB2YWx1ZTogbnVtYmVyIHwgbnVsbCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUpIHNldENvbHVtbkNvdW50KHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge1syLCAzLCA0XS5tYXAoKGNvdW50KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxUb2dnbGVCdXR0b24ga2V5PXtjb3VudH0gdmFsdWU9e2NvdW50fT5cbiAgICAgICAgICAgICAgICAgICAgICB7Y291bnR9XG4gICAgICAgICAgICAgICAgICAgIDwvVG9nZ2xlQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9Ub2dnbGVCdXR0b25Hcm91cD5cbiAgICAgICAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleFdyYXA6IFwid3JhcFwiLCBnYXA6IDIgfX0+XG4gICAgICAgICAgICAgICAge3NlY3Rpb24uY29sdW1ucy5tYXAoKGNvbHVtbiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICAgICAga2V5PXtjb2x1bW4uaWR9XG4gICAgICAgICAgICAgICAgICAgIHN4PXt7XG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHhzOiBcIjEwMCVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIG1kOiBgY2FsYygkezEwMCAvIHNlY3Rpb24uY29sdW1ucy5sZW5ndGh9JSAtICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICgoc2VjdGlvbi5jb2x1bW5zLmxlbmd0aCAtIDEpICogMTYpIC9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbi5jb2x1bW5zLmxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgfXB4KWAsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICBwOiAxLjUsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxLjUsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZFwiLFxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICBiZ2NvbG9yOiBcImJhY2tncm91bmQuZGVmYXVsdFwiLFxuICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgZ2FwOiAxLjUsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIiBzeD17eyBmb250V2VpZ2h0OiA2MDAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgQ29sdW1uIHtpbmRleCArIDF9XG4gICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICAgICAgICAgICAgPENvbnRlbnRCbG9ja0VkaXRvclxuICAgICAgICAgICAgICAgICAgICAgIGJsb2NrPXtjb2x1bW59XG4gICAgICAgICAgICAgICAgICAgICAgY29tcGFjdFxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93VHlwZVN3aXRjaFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodXBkYXRlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2UoKHByZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXYudHlwZSAhPT0gXCJyb3dcIikgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBwcmV2LmNvbHVtbnMubWFwKChjb2wsIGkpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpID09PSBpbmRleCA/IHVwZGF0ZXIoY29sKSA6IGNvbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIG9uUHJvZHVjdHNSZXNvbHZlZD17b25Qcm9kdWN0c1Jlc29sdmVkfVxuICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3RPcHRpb25zPXtwcm9kdWN0T3B0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0TG9hZGluZz17cHJvZHVjdExvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgb25Qcm9kdWN0U2VhcmNoPXtvblByb2R1Y3RTZWFyY2h9XG4gICAgICAgICAgICAgICAgICAgICAgb25VcGxvYWRFcnJvcj17b25VcGxvYWRFcnJvcn1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiBzZWN0aW9uLnR5cGUgPT09IFwic3RvcnlfbGlua3NcIiA/IChcbiAgICAgICAgICAgIDxTdG9yeUxpbmtzRWRpdG9yXG4gICAgICAgICAgICAgIHNlY3Rpb249e3NlY3Rpb259XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoYW5nZX1cbiAgICAgICAgICAgICAgb25VcGxvYWRFcnJvcj17b25VcGxvYWRFcnJvcn1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSA6IHNlY3Rpb24udHlwZSA9PT0gXCJpbWFnZV9zbGlkZXJcIiA/IChcbiAgICAgICAgICAgIDxJbWFnZVNsaWRlckVkaXRvclxuICAgICAgICAgICAgICBzZWN0aW9uPXtzZWN0aW9ufVxuICAgICAgICAgICAgICBvbkNoYW5nZT17b25DaGFuZ2V9XG4gICAgICAgICAgICAgIG9uVXBsb2FkRXJyb3I9e29uVXBsb2FkRXJyb3J9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8Q29udGVudEJsb2NrRWRpdG9yXG4gICAgICAgICAgICAgIGJsb2NrPXtzZWN0aW9ufVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KHVwZGF0ZXIpID0+IHtcbiAgICAgICAgICAgICAgICBvbkNoYW5nZSgocHJldikgPT5cbiAgICAgICAgICAgICAgICAgIHByZXYudHlwZSA9PT0gXCJiYW5uZXJcIiB8fCBwcmV2LnR5cGUgPT09IFwicHJvZHVjdF9zbGlkZXJcIlxuICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZXIocHJldilcbiAgICAgICAgICAgICAgICAgICAgOiBwcmV2XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgb25Qcm9kdWN0c1Jlc29sdmVkPXtvblByb2R1Y3RzUmVzb2x2ZWR9XG4gICAgICAgICAgICAgIHByb2R1Y3RPcHRpb25zPXtwcm9kdWN0T3B0aW9uc31cbiAgICAgICAgICAgICAgcHJvZHVjdExvYWRpbmc9e3Byb2R1Y3RMb2FkaW5nfVxuICAgICAgICAgICAgICBvblByb2R1Y3RTZWFyY2g9e29uUHJvZHVjdFNlYXJjaH1cbiAgICAgICAgICAgICAgb25VcGxvYWRFcnJvcj17b25VcGxvYWRFcnJvcn1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0NvbGxhcHNlPlxuICAgIDwvQm94PlxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IEhvbWVwYWdlRWRpdG9yID0gKCkgPT4ge1xuICBjb25zdCBub3RpZnkgPSB1c2VOb3RpZnkoKTtcbiAgY29uc3QgZGF0YVByb3ZpZGVyID0gdXNlRGF0YVByb3ZpZGVyKCk7XG4gIGNvbnN0IHNlYXJjaFRpbWVyID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNlbnNvcnMgPSB1c2VTZW5zb3JzKFxuICAgIHVzZVNlbnNvcihQb2ludGVyU2Vuc29yLCB7IGFjdGl2YXRpb25Db25zdHJhaW50OiB7IGRpc3RhbmNlOiA2IH0gfSksXG4gICAgdXNlU2Vuc29yKEtleWJvYXJkU2Vuc29yLCB7XG4gICAgICBjb29yZGluYXRlR2V0dGVyOiBzb3J0YWJsZUtleWJvYXJkQ29vcmRpbmF0ZXMsXG4gICAgfSlcbiAgKTtcblxuICBjb25zdCBbbGF5b3V0LCBzZXRMYXlvdXRdID0gdXNlU3RhdGU8SG9tZXBhZ2VMYXlvdXQ+KGVtcHR5SG9tZXBhZ2VMYXlvdXQpO1xuICBjb25zdCBbZGV2aWNlVGFiLCBzZXREZXZpY2VUYWJdID0gdXNlU3RhdGU8RGV2aWNlVGFiPihcImRlc2t0b3BcIik7XG4gIGNvbnN0IFtleHBhbmRlZElkcywgc2V0RXhwYW5kZWRJZHNdID0gdXNlU3RhdGU8U2V0PHN0cmluZz4+KG5ldyBTZXQoKSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZGlydHksIHNldERpcnR5XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Byb2R1Y3RPcHRpb25zLCBzZXRQcm9kdWN0T3B0aW9uc10gPSB1c2VTdGF0ZTxQcm9kdWN0T3B0aW9uW10+KFtdKTtcbiAgY29uc3QgW3Byb2R1Y3RMb2FkaW5nLCBzZXRQcm9kdWN0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgbGF5b3V0UmVmID0gdXNlUmVmKGxheW91dCk7XG4gIGxheW91dFJlZi5jdXJyZW50ID0gbGF5b3V0O1xuICBjb25zdCBkZXZpY2VUYWJSZWYgPSB1c2VSZWYoZGV2aWNlVGFiKTtcbiAgZGV2aWNlVGFiUmVmLmN1cnJlbnQgPSBkZXZpY2VUYWI7XG5cbiAgY29uc3Qgc2VjdGlvbnMgPSBsYXlvdXRbZGV2aWNlVGFiXTtcblxuICBjb25zdCBsb2FkUHJvZHVjdHMgPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAoc2VhcmNoID0gXCJcIiwga2VlcElkczogbnVtYmVyW10gPSBbXSkgPT4ge1xuICAgICAgc2V0UHJvZHVjdExvYWRpbmcodHJ1ZSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkYXRhUHJvdmlkZXIuZ2V0TGlzdChcInByb2R1Y3RcIiwge1xuICAgICAgICAgIHBhZ2luYXRpb246IHsgcGFnZTogMSwgcGVyUGFnZTogNTAgfSxcbiAgICAgICAgICBzb3J0OiB7IGZpZWxkOiBcImlkXCIsIG9yZGVyOiBcIkRFU0NcIiB9LFxuICAgICAgICAgIGZpbHRlcjogc2VhcmNoID8geyBxOiBzZWFyY2ggfSA6IHt9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgbWFwcGVkID0gKHJlc3VsdC5kYXRhIGFzIFByb2R1Y3RPcHRpb25bXSkubWFwKChwKSA9PiAoe1xuICAgICAgICAgIGlkOiBOdW1iZXIocC5pZCksXG4gICAgICAgICAgZW5OYW1lOiBwLmVuTmFtZSxcbiAgICAgICAgICBwck5hbWU6IHAucHJOYW1lLFxuICAgICAgICB9KSk7XG5cbiAgICAgICAgc2V0UHJvZHVjdE9wdGlvbnMoKHByZXYpID0+IHtcbiAgICAgICAgICBjb25zdCBrZXB0ID0gcHJldi5maWx0ZXIoKHApID0+IGtlZXBJZHMuaW5jbHVkZXMocC5pZCkpO1xuICAgICAgICAgIHJldHVybiBtZXJnZVByb2R1Y3RPcHRpb25zKGtlcHQsIG1hcHBlZCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIG5vdGlmeShcIkZhaWxlZCB0byBsb2FkIHByb2R1Y3RzXCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0UHJvZHVjdExvYWRpbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW2RhdGFQcm92aWRlciwgbm90aWZ5XVxuICApO1xuXG4gIGNvbnN0IGh5ZHJhdGVTZWxlY3RlZFByb2R1Y3RzID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKGlkczogbnVtYmVyW10pID0+IHtcbiAgICAgIGlmIChpZHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkYXRhUHJvdmlkZXIuZ2V0TWFueShcInByb2R1Y3RcIiwgeyBpZHMgfSk7XG4gICAgICAgIGNvbnN0IG1hcHBlZCA9IChyZXN1bHQuZGF0YSBhcyBQcm9kdWN0T3B0aW9uW10pLm1hcCgocCkgPT4gKHtcbiAgICAgICAgICBpZDogTnVtYmVyKHAuaWQpLFxuICAgICAgICAgIGVuTmFtZTogcC5lbk5hbWUsXG4gICAgICAgICAgcHJOYW1lOiBwLnByTmFtZSxcbiAgICAgICAgfSkpO1xuICAgICAgICBzZXRQcm9kdWN0T3B0aW9ucygocHJldikgPT4gbWVyZ2VQcm9kdWN0T3B0aW9ucyhwcmV2LCBtYXBwZWQpKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBMYWJlbHMgZmFsbCBiYWNrIHRvIFByb2R1Y3QgI2lkXG4gICAgICB9XG4gICAgfSxcbiAgICBbZGF0YVByb3ZpZGVyXVxuICApO1xuXG4gIGNvbnN0IGxvYWRIb21lcGFnZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0SG9tZXBhZ2VBZG1pbigpO1xuICAgICAgY29uc3QgbmV4dExheW91dCA9IG5vcm1hbGl6ZUhvbWVwYWdlTGF5b3V0KGRhdGEuc2VjdGlvbnMpO1xuICAgICAgc2V0TGF5b3V0KG5leHRMYXlvdXQpO1xuICAgICAgc2V0RXhwYW5kZWRJZHMoXG4gICAgICAgIG5ldyBTZXQoW1xuICAgICAgICAgIC4uLm5leHRMYXlvdXQuZGVza3RvcC5tYXAoKHMpID0+IHMuaWQpLFxuICAgICAgICAgIC4uLm5leHRMYXlvdXQubW9iaWxlLm1hcCgocykgPT4gcy5pZCksXG4gICAgICAgIF0pXG4gICAgICApO1xuICAgICAgc2V0RGlydHkoZmFsc2UpO1xuXG4gICAgICBjb25zdCBzZWxlY3RlZElkcyA9IGNvbGxlY3RMYXlvdXRQcm9kdWN0SWRzKG5leHRMYXlvdXQpO1xuICAgICAgYXdhaXQgaHlkcmF0ZVNlbGVjdGVkUHJvZHVjdHMoc2VsZWN0ZWRJZHMpO1xuICAgICAgYXdhaXQgbG9hZFByb2R1Y3RzKFwiXCIsIHNlbGVjdGVkSWRzKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIG5vdGlmeShcIkZhaWxlZCB0byBsb2FkIGhvbWVwYWdlXCIsIHsgdHlwZTogXCJlcnJvclwiIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtoeWRyYXRlU2VsZWN0ZWRQcm9kdWN0cywgbG9hZFByb2R1Y3RzLCBub3RpZnldKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHZvaWQgbG9hZEhvbWVwYWdlKCk7XG4gIH0sIFtsb2FkSG9tZXBhZ2VdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoc2VhcmNoVGltZXIuY3VycmVudCkgY2xlYXJUaW1lb3V0KHNlYXJjaFRpbWVyLmN1cnJlbnQpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICBjb25zdCBvblByb2R1Y3RTZWFyY2ggPSAocXVlcnk6IHN0cmluZykgPT4ge1xuICAgIGlmIChzZWFyY2hUaW1lci5jdXJyZW50KSBjbGVhclRpbWVvdXQoc2VhcmNoVGltZXIuY3VycmVudCk7XG4gICAgc2VhcmNoVGltZXIuY3VycmVudCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdm9pZCBsb2FkUHJvZHVjdHMoXG4gICAgICAgIHF1ZXJ5LnRyaW0oKSxcbiAgICAgICAgY29sbGVjdExheW91dFByb2R1Y3RJZHMobGF5b3V0UmVmLmN1cnJlbnQpXG4gICAgICApO1xuICAgIH0sIDMwMCk7XG4gIH07XG5cbiAgY29uc3Qgc2V0RGV2aWNlU2VjdGlvbnMgPSAoXG4gICAgdXBkYXRlcjogKHByZXY6IEhvbWVwYWdlU2VjdGlvbltdKSA9PiBIb21lcGFnZVNlY3Rpb25bXVxuICApID0+IHtcbiAgICBjb25zdCB0YWIgPSBkZXZpY2VUYWJSZWYuY3VycmVudDtcbiAgICBzZXRMYXlvdXQoKHByZXYpID0+ICh7XG4gICAgICAuLi5wcmV2LFxuICAgICAgW3RhYl06IHVwZGF0ZXIocHJldlt0YWJdKSxcbiAgICB9KSk7XG4gICAgc2V0RGlydHkodHJ1ZSk7XG4gIH07XG5cbiAgY29uc3QgdXBkYXRlU2VjdGlvbiA9IChpZDogc3RyaW5nLCB1cGRhdGVyOiBTZWN0aW9uVXBkYXRlcikgPT4ge1xuICAgIHNldERldmljZVNlY3Rpb25zKChwcmV2KSA9PlxuICAgICAgcHJldi5tYXAoKHMpID0+IChzLmlkID09PSBpZCA/IHVwZGF0ZXIocykgOiBzKSlcbiAgICApO1xuICB9O1xuXG4gIGNvbnN0IHJlbW92ZVNlY3Rpb24gPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgIHNldERldmljZVNlY3Rpb25zKChwcmV2KSA9PiBwcmV2LmZpbHRlcigocykgPT4gcy5pZCAhPT0gaWQpKTtcbiAgICBzZXRFeHBhbmRlZElkcygocHJldikgPT4ge1xuICAgICAgY29uc3QgbmV4dCA9IG5ldyBTZXQocHJldik7XG4gICAgICBuZXh0LmRlbGV0ZShpZCk7XG4gICAgICByZXR1cm4gbmV4dDtcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBhZGRTZWN0aW9uID0gKHNlY3Rpb246IEhvbWVwYWdlU2VjdGlvbikgPT4ge1xuICAgIHNldERldmljZVNlY3Rpb25zKChwcmV2KSA9PiBbLi4ucHJldiwgc2VjdGlvbl0pO1xuICAgIHNldEV4cGFuZGVkSWRzKChwcmV2KSA9PiBuZXcgU2V0KHByZXYpLmFkZChzZWN0aW9uLmlkKSk7XG4gIH07XG5cbiAgY29uc3Qgb25EcmFnRW5kID0gKGV2ZW50OiBEcmFnRW5kRXZlbnQpID0+IHtcbiAgICBjb25zdCB7IGFjdGl2ZSwgb3ZlciB9ID0gZXZlbnQ7XG4gICAgaWYgKCFvdmVyIHx8IGFjdGl2ZS5pZCA9PT0gb3Zlci5pZCkgcmV0dXJuO1xuXG4gICAgc2V0RGV2aWNlU2VjdGlvbnMoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IG9sZEluZGV4ID0gcHJldi5maW5kSW5kZXgoKHMpID0+IHMuaWQgPT09IGFjdGl2ZS5pZCk7XG4gICAgICBjb25zdCBuZXdJbmRleCA9IHByZXYuZmluZEluZGV4KChzKSA9PiBzLmlkID09PSBvdmVyLmlkKTtcbiAgICAgIGlmIChvbGRJbmRleCA8IDAgfHwgbmV3SW5kZXggPCAwKSByZXR1cm4gcHJldjtcbiAgICAgIHJldHVybiBhcnJheU1vdmUocHJldiwgb2xkSW5kZXgsIG5ld0luZGV4KTtcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBjb3B5RGVza3RvcFRvTW9iaWxlID0gKCkgPT4ge1xuICAgIGNvbnN0IG1vYmlsZSA9IGNsb25lU2VjdGlvbnNXaXRoTmV3SWRzKGxheW91dFJlZi5jdXJyZW50LmRlc2t0b3ApO1xuICAgIHNldExheW91dCgocHJldikgPT4gKHtcbiAgICAgIC4uLnByZXYsXG4gICAgICBtb2JpbGUsXG4gICAgfSkpO1xuICAgIHNldEV4cGFuZGVkSWRzKChwcmV2KSA9PiB7XG4gICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KTtcbiAgICAgIGZvciAoY29uc3Qgc2VjdGlvbiBvZiBtb2JpbGUpIHtcbiAgICAgICAgbmV4dC5hZGQoc2VjdGlvbi5pZCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV4dDtcbiAgICB9KTtcbiAgICBzZXREZXZpY2VUYWIoXCJtb2JpbGVcIik7XG4gICAgc2V0RGlydHkodHJ1ZSk7XG4gICAgbm90aWZ5KFwiQ29waWVkIGRlc2t0b3AgbGF5b3V0IHRvIG1vYmlsZVwiLCB7IHR5cGU6IFwiaW5mb1wiIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgY3VycmVudCA9IGxheW91dFJlZi5jdXJyZW50O1xuXG4gICAgY29uc3QgZGVza3RvcEVycm9yID0gZmluZEZpcnN0SW52YWxpZE1lc3NhZ2UoY3VycmVudC5kZXNrdG9wLCBcIkRlc2t0b3BcIik7XG4gICAgaWYgKGRlc2t0b3BFcnJvcikge1xuICAgICAgc2V0RGV2aWNlVGFiKFwiZGVza3RvcFwiKTtcbiAgICAgIG5vdGlmeShkZXNrdG9wRXJyb3IsIHsgdHlwZTogXCJ3YXJuaW5nXCIgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgbW9iaWxlRXJyb3IgPSBmaW5kRmlyc3RJbnZhbGlkTWVzc2FnZShjdXJyZW50Lm1vYmlsZSwgXCJNb2JpbGVcIik7XG4gICAgaWYgKG1vYmlsZUVycm9yKSB7XG4gICAgICBzZXREZXZpY2VUYWIoXCJtb2JpbGVcIik7XG4gICAgICBub3RpZnkobW9iaWxlRXJyb3IsIHsgdHlwZTogXCJ3YXJuaW5nXCIgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcGF5bG9hZDogSG9tZXBhZ2VMYXlvdXQgPSB7XG4gICAgICBkZXNrdG9wOiBzYW5pdGl6ZVNlY3Rpb25zKGN1cnJlbnQuZGVza3RvcCksXG4gICAgICBtb2JpbGU6IHNhbml0aXplU2VjdGlvbnMoY3VycmVudC5tb2JpbGUpLFxuICAgIH07XG5cbiAgICBzZXRTYXZpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB1cGRhdGVIb21lcGFnZShwYXlsb2FkKTtcbiAgICAgIHNldExheW91dChub3JtYWxpemVIb21lcGFnZUxheW91dChkYXRhLnNlY3Rpb25zKSk7XG4gICAgICBzZXREaXJ0eShmYWxzZSk7XG4gICAgICBub3RpZnkoXCJIb21lcGFnZSBzYXZlZFwiLCB7IHR5cGU6IFwic3VjY2Vzc1wiIH0pO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbm90aWZ5KFwiRmFpbGVkIHRvIHNhdmUgaG9tZXBhZ2VcIiwgeyB0eXBlOiBcImVycm9yXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPEJveCBzeD17eyBwOiAzLCBwYjogMTAgfX0+XG4gICAgICA8VGl0bGUgdGl0bGU9XCJIb21lcGFnZVwiIC8+XG5cbiAgICAgIDxCb3hcbiAgICAgICAgc3g9e3tcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXG4gICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsXG4gICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgIG1iOiAyLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8Qm94PlxuICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiIHN4PXt7IGZvbnRXZWlnaHQ6IDcwMCB9fT5cbiAgICAgICAgICAgIEhvbWVwYWdlIGJ1aWxkZXJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiPlxuICAgICAgICAgICAgQnVpbGQgc2VwYXJhdGUgZGVza3RvcCBhbmQgbW9iaWxlIGxheW91dHMuIFVzZSByb3dzIGZvciBlcXVhbC13aWR0aFxuICAgICAgICAgICAgc2lkZS1ieS1zaWRlIGJhbm5lcnMgb3Igc2xpZGVycy5cbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XG4gICAgICAgIDwvQm94PlxuXG4gICAgICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMSwgZmxleFdyYXA6IFwid3JhcFwiIH19PlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhZGRTZWN0aW9uKGNyZWF0ZUJhbm5lcigpKX1cbiAgICAgICAgICAgIHN0YXJ0SWNvbj17PEltYWdlSWNvbiAvPn1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBBZGQgYmFubmVyXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZFNlY3Rpb24oY3JlYXRlSW1hZ2VTbGlkZXIoKSl9XG4gICAgICAgICAgICBzdGFydEljb249ezxDb2xsZWN0aW9uc0ljb24gLz59XG4gICAgICAgICAgPlxuICAgICAgICAgICAgQWRkIGltYWdlIHNsaWRlclxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhZGRTZWN0aW9uKGNyZWF0ZVN0b3J5TGlua3MoKSl9XG4gICAgICAgICAgICBzdGFydEljb249ezxDaXJjbGVPdXRsaW5lZEljb24gLz59XG4gICAgICAgICAgPlxuICAgICAgICAgICAgQWRkIHN0b3J5IGxpbmtzXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZFNlY3Rpb24oY3JlYXRlU2xpZGVyKCkpfVxuICAgICAgICAgICAgc3RhcnRJY29uPXs8Vmlld0Nhcm91c2VsSWNvbiAvPn1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBBZGQgcHJvZHVjdCBzbGlkZXJcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWRkU2VjdGlvbihjcmVhdGVSb3coMikpfVxuICAgICAgICAgICAgc3RhcnRJY29uPXs8Vmlld1dlZWtJY29uIC8+fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIEFkZCByb3dcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9Cb3g+XG4gICAgICA8L0JveD5cblxuICAgICAgPEJveFxuICAgICAgICBzeD17e1xuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgIGZsZXhXcmFwOiBcIndyYXBcIixcbiAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIixcbiAgICAgICAgICBnYXA6IDEsXG4gICAgICAgICAgbWI6IDMsXG4gICAgICAgICAgYm9yZGVyQm90dG9tOiAxLFxuICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPFRhYnNcbiAgICAgICAgICB2YWx1ZT17ZGV2aWNlVGFifVxuICAgICAgICAgIG9uQ2hhbmdlPXsoXywgdmFsdWU6IERldmljZVRhYikgPT4gc2V0RGV2aWNlVGFiKHZhbHVlKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxUYWJcbiAgICAgICAgICAgIHZhbHVlPVwiZGVza3RvcFwiXG4gICAgICAgICAgICBsYWJlbD1cIkRlc2t0b3BcIlxuICAgICAgICAgICAgaWNvbj17PENvbXB1dGVySWNvbiAvPn1cbiAgICAgICAgICAgIGljb25Qb3NpdGlvbj1cInN0YXJ0XCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxUYWJcbiAgICAgICAgICAgIHZhbHVlPVwibW9iaWxlXCJcbiAgICAgICAgICAgIGxhYmVsPVwiTW9iaWxlXCJcbiAgICAgICAgICAgIGljb249ezxTbWFydHBob25lSWNvbiAvPn1cbiAgICAgICAgICAgIGljb25Qb3NpdGlvbj1cInN0YXJ0XCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L1RhYnM+XG5cbiAgICAgICAge2RldmljZVRhYiA9PT0gXCJtb2JpbGVcIiAmJiAoXG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHN0YXJ0SWNvbj17PENvbnRlbnRDb3B5SWNvbiAvPn1cbiAgICAgICAgICAgIG9uQ2xpY2s9e2NvcHlEZXNrdG9wVG9Nb2JpbGV9XG4gICAgICAgICAgICBkaXNhYmxlZD17bGF5b3V0LmRlc2t0b3AubGVuZ3RoID09PSAwfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIENvcHkgZGVza3RvcCDihpIgbW9iaWxlXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L0JveD5cblxuICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLCBweTogOCB9fT5cbiAgICAgICAgICA8Q2lyY3VsYXJQcm9ncmVzcyAvPlxuICAgICAgICA8L0JveD5cbiAgICAgICkgOiBzZWN0aW9ucy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxCb3hcbiAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgcDogNCxcbiAgICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogMixcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWRcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcImRpdmlkZXJcIixcbiAgICAgICAgICAgIGJnY29sb3I6IFwiYmFja2dyb3VuZC5wYXBlclwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cInRleHQuc2Vjb25kYXJ5XCIgc3g9e3sgbWI6IDIgfX0+XG4gICAgICAgICAgICB7ZGV2aWNlVGFiID09PSBcIm1vYmlsZVwiXG4gICAgICAgICAgICAgID8gXCJNb2JpbGUgbGF5b3V0IGlzIGVtcHR5LiBBZGQgc2VjdGlvbnMgb3IgY29weSBmcm9tIGRlc2t0b3Agc28gbW9iaWxlIHZpc2l0b3JzIGFyZSBub3QgbGVmdCB3aXRoIGEgYmxhbmsgaG9tZXBhZ2UuXCJcbiAgICAgICAgICAgICAgOiBcIk5vIHNlY3Rpb25zIHlldC4gQWRkIGEgYmFubmVyLCBpbWFnZSBzbGlkZXIsIHN0b3J5IGxpbmtzLCBwcm9kdWN0IHNsaWRlciwgb3Igcm93IHRvIGdldCBzdGFydGVkLlwifVxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cbiAgICAgICAgICA8Qm94XG4gICAgICAgICAgICBzeD17e1xuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgZ2FwOiAxLFxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgZmxleFdyYXA6IFwid3JhcFwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhZGRTZWN0aW9uKGNyZWF0ZUJhbm5lcigpKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQWRkIGJhbm5lclxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZFNlY3Rpb24oY3JlYXRlSW1hZ2VTbGlkZXIoKSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEFkZCBpbWFnZSBzbGlkZXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhZGRTZWN0aW9uKGNyZWF0ZVN0b3J5TGlua3MoKSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEFkZCBzdG9yeSBsaW5rc1xuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZFNlY3Rpb24oY3JlYXRlU2xpZGVyKCkpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBBZGQgcHJvZHVjdCBzbGlkZXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZWRcIiBvbkNsaWNrPXsoKSA9PiBhZGRTZWN0aW9uKGNyZWF0ZVJvdygyKSl9PlxuICAgICAgICAgICAgICBBZGQgcm93XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIHtkZXZpY2VUYWIgPT09IFwibW9iaWxlXCIgJiYgbGF5b3V0LmRlc2t0b3AubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxuICAgICAgICAgICAgICAgIHN0YXJ0SWNvbj17PENvbnRlbnRDb3B5SWNvbiAvPn1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtjb3B5RGVza3RvcFRvTW9iaWxlfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ29weSBkZXNrdG9wIOKGkiBtb2JpbGVcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L0JveD5cbiAgICAgICkgOiAoXG4gICAgICAgIDxEbmRDb250ZXh0XG4gICAgICAgICAgc2Vuc29ycz17c2Vuc29yc31cbiAgICAgICAgICBjb2xsaXNpb25EZXRlY3Rpb249e2Nsb3Nlc3RDZW50ZXJ9XG4gICAgICAgICAgb25EcmFnRW5kPXtvbkRyYWdFbmR9XG4gICAgICAgID5cbiAgICAgICAgICA8U29ydGFibGVDb250ZXh0XG4gICAgICAgICAgICBpdGVtcz17c2VjdGlvbnMubWFwKChzKSA9PiBzLmlkKX1cbiAgICAgICAgICAgIHN0cmF0ZWd5PXt2ZXJ0aWNhbExpc3RTb3J0aW5nU3RyYXRlZ3l9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgZ2FwOiAyIH19PlxuICAgICAgICAgICAgICB7c2VjdGlvbnMubWFwKChzZWN0aW9uKSA9PiAoXG4gICAgICAgICAgICAgICAgPFNvcnRhYmxlU2VjdGlvblxuICAgICAgICAgICAgICAgICAga2V5PXtzZWN0aW9uLmlkfVxuICAgICAgICAgICAgICAgICAgc2VjdGlvbj17c2VjdGlvbn1cbiAgICAgICAgICAgICAgICAgIGV4cGFuZGVkPXtleHBhbmRlZElkcy5oYXMoc2VjdGlvbi5pZCl9XG4gICAgICAgICAgICAgICAgICBvblRvZ2dsZT17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgc2V0RXhwYW5kZWRJZHMoKHByZXYpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFNldChwcmV2KTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobmV4dC5oYXMoc2VjdGlvbi5pZCkpIG5leHQuZGVsZXRlKHNlY3Rpb24uaWQpO1xuICAgICAgICAgICAgICAgICAgICAgIGVsc2UgbmV4dC5hZGQoc2VjdGlvbi5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHVwZGF0ZXIpID0+IHVwZGF0ZVNlY3Rpb24oc2VjdGlvbi5pZCwgdXBkYXRlcil9XG4gICAgICAgICAgICAgICAgICBvblJlbW92ZT17KCkgPT4gcmVtb3ZlU2VjdGlvbihzZWN0aW9uLmlkKX1cbiAgICAgICAgICAgICAgICAgIG9uUHJvZHVjdHNSZXNvbHZlZD17KHByb2R1Y3RzKSA9PlxuICAgICAgICAgICAgICAgICAgICBzZXRQcm9kdWN0T3B0aW9ucygocHJldikgPT5cbiAgICAgICAgICAgICAgICAgICAgICBtZXJnZVByb2R1Y3RPcHRpb25zKHByZXYsIHByb2R1Y3RzKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBwcm9kdWN0T3B0aW9ucz17cHJvZHVjdE9wdGlvbnN9XG4gICAgICAgICAgICAgICAgICBwcm9kdWN0TG9hZGluZz17cHJvZHVjdExvYWRpbmd9XG4gICAgICAgICAgICAgICAgICBvblByb2R1Y3RTZWFyY2g9e29uUHJvZHVjdFNlYXJjaH1cbiAgICAgICAgICAgICAgICAgIG9uVXBsb2FkRXJyb3I9eygpID0+XG4gICAgICAgICAgICAgICAgICAgIG5vdGlmeShcIkltYWdlIHVwbG9hZCBmYWlsZWRcIiwgeyB0eXBlOiBcImVycm9yXCIgfSlcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgIDwvU29ydGFibGVDb250ZXh0PlxuICAgICAgICA8L0RuZENvbnRleHQ+XG4gICAgICApfVxuXG4gICAgICA8Qm94XG4gICAgICAgIHN4PXt7XG4gICAgICAgICAgcG9zaXRpb246IFwic3RpY2t5XCIsXG4gICAgICAgICAgYm90dG9tOiAxNixcbiAgICAgICAgICBtdDogMyxcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiLFxuICAgICAgICAgIGdhcDogMSxcbiAgICAgICAgICB6SW5kZXg6IDIsXG4gICAgICAgICAgcDogMS41LFxuICAgICAgICAgIGJvcmRlclJhZGl1czogMixcbiAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkXCIsXG4gICAgICAgICAgYm9yZGVyQ29sb3I6IFwiZGl2aWRlclwiLFxuICAgICAgICAgIGJnY29sb3I6IFwiYmFja2dyb3VuZC5wYXBlclwiLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGxvYWRIb21lcGFnZSgpfVxuICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8IHNhdmluZ31cbiAgICAgICAgPlxuICAgICAgICAgIFJlc2V0XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5kbGVTYXZlKCl9XG4gICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgc2F2aW5nIHx8ICFkaXJ0eX1cbiAgICAgICAgPlxuICAgICAgICAgIHtzYXZpbmcgPyBcIlNhdmluZ+KAplwiIDogXCJTYXZlIGhvbWVwYWdlXCJ9XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9Cb3g+XG4gICAgPC9Cb3g+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvcGFnZXMvSG9tZXBhZ2VFZGl0b3IudHN4In0=