"use client";
import "/node_modules/.vite/deps/chunk-BWL3NMBV.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-2CTOBPYC.js?v=49ae7072";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-ZMHT7GOB.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-B2OBFM6G.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-YIMRGSOF.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-IMIYNVOF.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import "/node_modules/.vite/deps/chunk-3FIS7OEG.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/CircleOutlined.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var CircleOutlined_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2m0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8"
}), "CircleOutlined");
export {
  CircleOutlined_default as default
};
//# sourceMappingURL=@mui_icons-material_CircleOutlined.js.map
