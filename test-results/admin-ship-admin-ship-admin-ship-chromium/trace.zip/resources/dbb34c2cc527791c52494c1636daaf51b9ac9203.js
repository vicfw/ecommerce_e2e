import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ColorSwatch.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const ColorSwatch = ({
  src,
  alt = "Color",
  size = 24
}) => {
  if (!src) return null;
  return /* @__PURE__ */ jsxDEV(
    "img",
    {
      src,
      alt,
      style: {
        height: size,
        width: size,
        objectFit: "cover",
        borderRadius: "50%",
        border: "1px solid #E2E8F0",
        background: "#F8FAFC",
        flexShrink: 0
      }
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/components/ColorSwatch.tsx",
      lineNumber: 15,
      columnNumber: 5
    },
    this
  );
};
_c = ColorSwatch;
var _c;
$RefreshReg$(_c, "ColorSwatch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/components/ColorSwatch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/components/ColorSwatch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/components/ColorSwatch.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0k7QUFSRyxhQUFNQSxjQUFjQSxDQUFDO0FBQUEsRUFDMUJDO0FBQUFBLEVBQ0FDLE1BQU07QUFBQSxFQUNOQyxPQUFPO0FBQ1MsTUFBTTtBQUN0QixNQUFJLENBQUNGLElBQUssUUFBTztBQUVqQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0E7QUFBQSxNQUNBLE9BQU87QUFBQSxRQUNMRyxRQUFRRDtBQUFBQSxRQUNSRSxPQUFPRjtBQUFBQSxRQUNQRyxXQUFXO0FBQUEsUUFDWEMsY0FBYztBQUFBLFFBQ2RDLFFBQVE7QUFBQSxRQUNSQyxZQUFZO0FBQUEsUUFDWkMsWUFBWTtBQUFBLE1BQ2Q7QUFBQTtBQUFBLElBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0k7QUFHUjtBQUFFQyxLQXRCV1g7QUFBVyxJQUFBVztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDb2xvclN3YXRjaCIsInNyYyIsImFsdCIsInNpemUiLCJoZWlnaHQiLCJ3aWR0aCIsIm9iamVjdEZpdCIsImJvcmRlclJhZGl1cyIsImJvcmRlciIsImJhY2tncm91bmQiLCJmbGV4U2hyaW5rIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29sb3JTd2F0Y2gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbInR5cGUgQ29sb3JTd2F0Y2hQcm9wcyA9IHtcbiAgc3JjPzogc3RyaW5nIHwgbnVsbDtcbiAgYWx0Pzogc3RyaW5nO1xuICBzaXplPzogbnVtYmVyO1xufTtcblxuZXhwb3J0IGNvbnN0IENvbG9yU3dhdGNoID0gKHtcbiAgc3JjLFxuICBhbHQgPSBcIkNvbG9yXCIsXG4gIHNpemUgPSAyNCxcbn06IENvbG9yU3dhdGNoUHJvcHMpID0+IHtcbiAgaWYgKCFzcmMpIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGltZ1xuICAgICAgc3JjPXtzcmN9XG4gICAgICBhbHQ9e2FsdH1cbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIGhlaWdodDogc2l6ZSxcbiAgICAgICAgd2lkdGg6IHNpemUsXG4gICAgICAgIG9iamVjdEZpdDogXCJjb3ZlclwiLFxuICAgICAgICBib3JkZXJSYWRpdXM6IFwiNTAlXCIsXG4gICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgI0UyRThGMFwiLFxuICAgICAgICBiYWNrZ3JvdW5kOiBcIiNGOEZBRkNcIixcbiAgICAgICAgZmxleFNocmluazogMCxcbiAgICAgIH19XG4gICAgLz5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9tbnQvZGF0YS9lY29tbWVyY2UvZWNvbW1lcmNlX2FkbWluL3NyYy9jb21wb25lbnRzL0NvbG9yU3dhdGNoLnRzeCJ9