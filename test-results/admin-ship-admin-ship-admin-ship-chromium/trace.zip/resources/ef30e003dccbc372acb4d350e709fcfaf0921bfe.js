import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/resources/products/ProductCreate.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Create, SimpleForm } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import { ProductForm } from "/src/resources/products/ProductForm.tsx";
import { transformProductData } from "/src/resources/products/productTransform.ts";
export const ProductCreate = () => {
  return /* @__PURE__ */ jsxDEV(
    Create,
    {
      mutationMode: "pessimistic",
      transform: transformProductData,
      redirect: "list",
      children: /* @__PURE__ */ jsxDEV(SimpleForm, { children: /* @__PURE__ */ jsxDEV(ProductForm, {}, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductCreate.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductCreate.tsx",
        lineNumber: 12,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductCreate.tsx",
      lineNumber: 7,
      columnNumber: 5
    },
    this
  );
};
_c = ProductCreate;
var _c;
$RefreshReg$(_c, "ProductCreate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductCreate.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductCreate.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/resources/products/ProductCreate.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7QUFaUixTQUFTQSxRQUFRQyxrQkFBa0I7QUFDbkMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDRCQUE0QjtBQUU5QixhQUFNQyxnQkFBZ0JBLE1BQU07QUFDakMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsY0FBYTtBQUFBLE1BQ2IsV0FBV0Q7QUFBQUEsTUFDWCxVQUFTO0FBQUEsTUFFVCxpQ0FBQyxjQUNDLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBO0FBQUEsSUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQTtBQUVKO0FBQUVFLEtBWldEO0FBQWEsSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQ3JlYXRlIiwiU2ltcGxlRm9ybSIsIlByb2R1Y3RGb3JtIiwidHJhbnNmb3JtUHJvZHVjdERhdGEiLCJQcm9kdWN0Q3JlYXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZHVjdENyZWF0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ3JlYXRlLCBTaW1wbGVGb3JtIH0gZnJvbSBcInJlYWN0LWFkbWluXCI7XG5pbXBvcnQgeyBQcm9kdWN0Rm9ybSB9IGZyb20gXCIuL1Byb2R1Y3RGb3JtXCI7XG5pbXBvcnQgeyB0cmFuc2Zvcm1Qcm9kdWN0RGF0YSB9IGZyb20gXCIuL3Byb2R1Y3RUcmFuc2Zvcm1cIjtcblxuZXhwb3J0IGNvbnN0IFByb2R1Y3RDcmVhdGUgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPENyZWF0ZVxuICAgICAgbXV0YXRpb25Nb2RlPVwicGVzc2ltaXN0aWNcIlxuICAgICAgdHJhbnNmb3JtPXt0cmFuc2Zvcm1Qcm9kdWN0RGF0YX1cbiAgICAgIHJlZGlyZWN0PVwibGlzdFwiXG4gICAgPlxuICAgICAgPFNpbXBsZUZvcm0+XG4gICAgICAgIDxQcm9kdWN0Rm9ybSAvPlxuICAgICAgPC9TaW1wbGVGb3JtPlxuICAgIDwvQ3JlYXRlPlxuICApO1xufTtcbiJdLCJmaWxlIjoiL21udC9kYXRhL2Vjb21tZXJjZS9lY29tbWVyY2VfYWRtaW4vc3JjL3Jlc291cmNlcy9wcm9kdWN0cy9Qcm9kdWN0Q3JlYXRlLnRzeCJ9