import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-5JR34MBT.js?v=49ae7072";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-QYJG2MMW.js?v=49ae7072";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-PX6F3LHL.js?v=49ae7072";

// node_modules/.pnpm/@mui+icons-material@9.3.1_@mui+material@9.3.1_@emotion+react@11.14.0_@types+react@19.2._a8eaa20cd24d3de1dbe0ed83c50e9a61/node_modules/@mui/icons-material/DeleteOutlined.mjs
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var DeleteOutlined_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M16 9v10H8V9zm-1.5-6h-5l-1 1H5v2h14V4h-3.5zM18 7H6v12c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2z"
}), "DeleteOutlined");

export {
  DeleteOutlined_default
};
//# sourceMappingURL=chunk-OPG2BALX.js.map
