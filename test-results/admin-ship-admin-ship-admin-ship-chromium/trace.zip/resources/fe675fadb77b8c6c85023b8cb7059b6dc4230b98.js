import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/Menu.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=49ae7072"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Menu as RaMenu } from "/node_modules/.vite/deps/react-admin.js?v=49ae7072";
import Box from "/node_modules/.vite/deps/@mui_material_Box.js?v=49ae7072";
import ListSubheader from "/node_modules/.vite/deps/@mui_material_ListSubheader.js?v=49ae7072";
import CategoryIcon from "/node_modules/.vite/deps/@mui_icons-material_Category.js?v=49ae7072";
import InventoryIcon from "/node_modules/.vite/deps/@mui_icons-material_Inventory.js?v=49ae7072";
import BrandingWatermarkIcon from "/node_modules/.vite/deps/@mui_icons-material_BrandingWatermark.js?v=49ae7072";
import PaletteIcon from "/node_modules/.vite/deps/@mui_icons-material_Palette.js?v=49ae7072";
import LocalOfferIcon from "/node_modules/.vite/deps/@mui_icons-material_LocalOffer.js?v=49ae7072";
import DashboardIcon from "/node_modules/.vite/deps/@mui_icons-material_Dashboard.js?v=49ae7072";
import ShoppingCartIcon from "/node_modules/.vite/deps/@mui_icons-material_ShoppingCart.js?v=49ae7072";
import PeopleIcon from "/node_modules/.vite/deps/@mui_icons-material_People.js?v=49ae7072";
import RateReviewIcon from "/node_modules/.vite/deps/@mui_icons-material_RateReview.js?v=49ae7072";
import LocalShippingIcon from "/node_modules/.vite/deps/@mui_icons-material_LocalShipping.js?v=49ae7072";
import HomeIcon from "/node_modules/.vite/deps/@mui_icons-material_Home.js?v=49ae7072";
import ImageIcon from "/node_modules/.vite/deps/@mui_icons-material_Image.js?v=49ae7072";
const sectionHeaderSx = {
  px: 2.5,
  pb: 1,
  pt: 1.5,
  color: "text.secondary",
  fontWeight: 700,
  letterSpacing: "0.08em",
  textTransform: "uppercase",
  lineHeight: 1.2
};
export const Menu = () => /* @__PURE__ */ jsxDEV(
  Box,
  {
    sx: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      pt: 1,
      pb: 2
    },
    children: /* @__PURE__ */ jsxDEV(RaMenu, { children: [
      /* @__PURE__ */ jsxDEV(ListSubheader, { sx: sectionHeaderSx, children: "Catalog" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
        lineNumber: 39,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/category",
          primaryText: "Categories",
          leftIcon: /* @__PURE__ */ jsxDEV(CategoryIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 43,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 40,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/product",
          primaryText: "Products",
          leftIcon: /* @__PURE__ */ jsxDEV(InventoryIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 48,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 45,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/brand",
          primaryText: "Brands",
          leftIcon: /* @__PURE__ */ jsxDEV(BrandingWatermarkIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 53,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 50,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/colorImage",
          primaryText: "Color Images",
          leftIcon: /* @__PURE__ */ jsxDEV(PaletteIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 58,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 55,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/badge",
          primaryText: "Badges",
          leftIcon: /* @__PURE__ */ jsxDEV(LocalOfferIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 63,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 60,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(ListSubheader, { sx: sectionHeaderSx, children: "Sales" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
        lineNumber: 66,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/",
          primaryText: "Dashboard",
          leftIcon: /* @__PURE__ */ jsxDEV(DashboardIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 70,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 67,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/order",
          primaryText: "Orders",
          leftIcon: /* @__PURE__ */ jsxDEV(ShoppingCartIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 75,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 72,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(ListSubheader, { sx: sectionHeaderSx, children: "Customers" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
        lineNumber: 78,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/users",
          primaryText: "Users",
          leftIcon: /* @__PURE__ */ jsxDEV(PeopleIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 82,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 79,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/comment",
          primaryText: "Reviews",
          leftIcon: /* @__PURE__ */ jsxDEV(RateReviewIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 87,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 84,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(ListSubheader, { sx: sectionHeaderSx, children: "Settings" }, void 0, false, {
        fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
        lineNumber: 90,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/homepage",
          primaryText: "Homepage",
          leftIcon: /* @__PURE__ */ jsxDEV(HomeIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 94,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 91,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/site-logo",
          primaryText: "Site Logo",
          leftIcon: /* @__PURE__ */ jsxDEV(ImageIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 99,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 96,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RaMenu.Item,
        {
          to: "/delivery-cost",
          primaryText: "Delivery Cost",
          leftIcon: /* @__PURE__ */ jsxDEV(LocalShippingIcon, {}, void 0, false, {
            fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
            lineNumber: 104,
            columnNumber: 17
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
          lineNumber: 101,
          columnNumber: 7
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
      lineNumber: 38,
      columnNumber: 5
    }, this)
  },
  void 0,
  false,
  {
    fileName: "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx",
    lineNumber: 29,
    columnNumber: 1
  },
  this
);
_c = Menu;
var _c;
$RefreshReg$(_c, "Menu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/mnt/data/ecommerce/ecommerce_admin/src/layouts/Menu.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NNO0FBdENOLFNBQVNBLFFBQVFDLGNBQWM7QUFDL0IsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQywyQkFBMkI7QUFDbEMsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxrQkFBa0I7QUFBQSxFQUN0QkMsSUFBSTtBQUFBLEVBQ0pDLElBQUk7QUFBQSxFQUNKQyxJQUFJO0FBQUEsRUFDSkMsT0FBTztBQUFBLEVBQ1BDLFlBQVk7QUFBQSxFQUNaQyxlQUFlO0FBQUEsRUFDZkMsZUFBZTtBQUFBLEVBQ2ZDLFlBQVk7QUFDZDtBQUVPLGFBQU14QixPQUFPQSxNQUNsQjtBQUFBLEVBQUM7QUFBQTtBQUFBLElBQ0MsSUFBSTtBQUFBLE1BQ0Z5QixTQUFTO0FBQUEsTUFDVEMsZUFBZTtBQUFBLE1BQ2ZDLFFBQVE7QUFBQSxNQUNSUixJQUFJO0FBQUEsTUFDSkQsSUFBSTtBQUFBLElBQ047QUFBQSxJQUVBLGlDQUFDLFVBQ0M7QUFBQSw2QkFBQyxpQkFBYyxJQUFJRixpQkFBaUIsdUJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxNQUMzQztBQUFBLFFBQUMsT0FBTztBQUFBLFFBQVA7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILGFBQVk7QUFBQSxVQUNaLFVBQVUsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBO0FBQUEsUUFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzZCO0FBQUEsTUFFN0I7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxhQUFZO0FBQUEsVUFDWixVQUFVLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQTtBQUFBLFFBSDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc4QjtBQUFBLE1BRTlCO0FBQUEsUUFBQyxPQUFPO0FBQUEsUUFBUDtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsYUFBWTtBQUFBLFVBQ1osVUFBVSx1QkFBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBO0FBQUEsUUFIbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3NDO0FBQUEsTUFFdEM7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxhQUFZO0FBQUEsVUFDWixVQUFVLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQTtBQUFBLFFBSHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc0QjtBQUFBLE1BRTVCO0FBQUEsUUFBQyxPQUFPO0FBQUEsUUFBUDtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsYUFBWTtBQUFBLFVBQ1osVUFBVSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUE7QUFBQSxRQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHK0I7QUFBQSxNQUcvQix1QkFBQyxpQkFBYyxJQUFJQSxpQkFBaUIscUJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxNQUN6QztBQUFBLFFBQUMsT0FBTztBQUFBLFFBQVA7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILGFBQVk7QUFBQSxVQUNaLFVBQVUsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYztBQUFBO0FBQUEsUUFIMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzhCO0FBQUEsTUFFOUI7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxhQUFZO0FBQUEsVUFDWixVQUFVLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUE7QUFBQSxRQUg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHaUM7QUFBQSxNQUdqQyx1QkFBQyxpQkFBYyxJQUFJQSxpQkFBaUIseUJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkM7QUFBQSxNQUM3QztBQUFBLFFBQUMsT0FBTztBQUFBLFFBQVA7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILGFBQVk7QUFBQSxVQUNaLFVBQVUsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBO0FBQUEsUUFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzJCO0FBQUEsTUFFM0I7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxhQUFZO0FBQUEsVUFDWixVQUFVLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQTtBQUFBLFFBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrQjtBQUFBLE1BRy9CLHVCQUFDLGlCQUFjLElBQUlBLGlCQUFpQix3QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLE1BQzVDO0FBQUEsUUFBQyxPQUFPO0FBQUEsUUFBUDtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsYUFBWTtBQUFBLFVBQ1osVUFBVSx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVM7QUFBQTtBQUFBLFFBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUd5QjtBQUFBLE1BRXpCO0FBQUEsUUFBQyxPQUFPO0FBQUEsUUFBUDtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsYUFBWTtBQUFBLFVBQ1osVUFBVSx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQTtBQUFBLFFBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcwQjtBQUFBLE1BRTFCO0FBQUEsUUFBQyxPQUFPO0FBQUEsUUFBUDtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsYUFBWTtBQUFBLFVBQ1osVUFBVSx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBO0FBQUEsUUFIOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR2tDO0FBQUEsU0FsRXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRUE7QUFBQTtBQUFBLEVBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE4RUE7QUFDQVksS0FoRlc1QjtBQUFJLElBQUE0QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJNZW51IiwiUmFNZW51IiwiQm94IiwiTGlzdFN1YmhlYWRlciIsIkNhdGVnb3J5SWNvbiIsIkludmVudG9yeUljb24iLCJCcmFuZGluZ1dhdGVybWFya0ljb24iLCJQYWxldHRlSWNvbiIsIkxvY2FsT2ZmZXJJY29uIiwiRGFzaGJvYXJkSWNvbiIsIlNob3BwaW5nQ2FydEljb24iLCJQZW9wbGVJY29uIiwiUmF0ZVJldmlld0ljb24iLCJMb2NhbFNoaXBwaW5nSWNvbiIsIkhvbWVJY29uIiwiSW1hZ2VJY29uIiwic2VjdGlvbkhlYWRlclN4IiwicHgiLCJwYiIsInB0IiwiY29sb3IiLCJmb250V2VpZ2h0IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJsaW5lSGVpZ2h0IiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJoZWlnaHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNZW51LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZW51IGFzIFJhTWVudSB9IGZyb20gXCJyZWFjdC1hZG1pblwiO1xuaW1wb3J0IEJveCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Cb3hcIjtcbmltcG9ydCBMaXN0U3ViaGVhZGVyIGZyb20gXCJAbXVpL21hdGVyaWFsL0xpc3RTdWJoZWFkZXJcIjtcbmltcG9ydCBDYXRlZ29yeUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvQ2F0ZWdvcnlcIjtcbmltcG9ydCBJbnZlbnRvcnlJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0ludmVudG9yeVwiO1xuaW1wb3J0IEJyYW5kaW5nV2F0ZXJtYXJrSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9CcmFuZGluZ1dhdGVybWFya1wiO1xuaW1wb3J0IFBhbGV0dGVJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL1BhbGV0dGVcIjtcbmltcG9ydCBMb2NhbE9mZmVySWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9Mb2NhbE9mZmVyXCI7XG5pbXBvcnQgRGFzaGJvYXJkSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9EYXNoYm9hcmRcIjtcbmltcG9ydCBTaG9wcGluZ0NhcnRJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL1Nob3BwaW5nQ2FydFwiO1xuaW1wb3J0IFBlb3BsZUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvUGVvcGxlXCI7XG5pbXBvcnQgUmF0ZVJldmlld0ljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvUmF0ZVJldmlld1wiO1xuaW1wb3J0IExvY2FsU2hpcHBpbmdJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0xvY2FsU2hpcHBpbmdcIjtcbmltcG9ydCBIb21lSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9Ib21lXCI7XG5pbXBvcnQgSW1hZ2VJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0ltYWdlXCI7XG5cbmNvbnN0IHNlY3Rpb25IZWFkZXJTeCA9IHtcbiAgcHg6IDIuNSxcbiAgcGI6IDEsXG4gIHB0OiAxLjUsXG4gIGNvbG9yOiBcInRleHQuc2Vjb25kYXJ5XCIsXG4gIGZvbnRXZWlnaHQ6IDcwMCxcbiAgbGV0dGVyU3BhY2luZzogXCIwLjA4ZW1cIixcbiAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcbiAgbGluZUhlaWdodDogMS4yLFxufTtcblxuZXhwb3J0IGNvbnN0IE1lbnUgPSAoKSA9PiAoXG4gIDxCb3hcbiAgICBzeD17e1xuICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgaGVpZ2h0OiBcIjEwMCVcIixcbiAgICAgIHB0OiAxLFxuICAgICAgcGI6IDIsXG4gICAgfX1cbiAgPlxuICAgIDxSYU1lbnU+XG4gICAgICA8TGlzdFN1YmhlYWRlciBzeD17c2VjdGlvbkhlYWRlclN4fT5DYXRhbG9nPC9MaXN0U3ViaGVhZGVyPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL2NhdGVnb3J5XCJcbiAgICAgICAgcHJpbWFyeVRleHQ9XCJDYXRlZ29yaWVzXCJcbiAgICAgICAgbGVmdEljb249ezxDYXRlZ29yeUljb24gLz59XG4gICAgICAvPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL3Byb2R1Y3RcIlxuICAgICAgICBwcmltYXJ5VGV4dD1cIlByb2R1Y3RzXCJcbiAgICAgICAgbGVmdEljb249ezxJbnZlbnRvcnlJY29uIC8+fVxuICAgICAgLz5cbiAgICAgIDxSYU1lbnUuSXRlbVxuICAgICAgICB0bz1cIi9icmFuZFwiXG4gICAgICAgIHByaW1hcnlUZXh0PVwiQnJhbmRzXCJcbiAgICAgICAgbGVmdEljb249ezxCcmFuZGluZ1dhdGVybWFya0ljb24gLz59XG4gICAgICAvPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL2NvbG9ySW1hZ2VcIlxuICAgICAgICBwcmltYXJ5VGV4dD1cIkNvbG9yIEltYWdlc1wiXG4gICAgICAgIGxlZnRJY29uPXs8UGFsZXR0ZUljb24gLz59XG4gICAgICAvPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL2JhZGdlXCJcbiAgICAgICAgcHJpbWFyeVRleHQ9XCJCYWRnZXNcIlxuICAgICAgICBsZWZ0SWNvbj17PExvY2FsT2ZmZXJJY29uIC8+fVxuICAgICAgLz5cblxuICAgICAgPExpc3RTdWJoZWFkZXIgc3g9e3NlY3Rpb25IZWFkZXJTeH0+U2FsZXM8L0xpc3RTdWJoZWFkZXI+XG4gICAgICA8UmFNZW51Lkl0ZW1cbiAgICAgICAgdG89XCIvXCJcbiAgICAgICAgcHJpbWFyeVRleHQ9XCJEYXNoYm9hcmRcIlxuICAgICAgICBsZWZ0SWNvbj17PERhc2hib2FyZEljb24gLz59XG4gICAgICAvPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL29yZGVyXCJcbiAgICAgICAgcHJpbWFyeVRleHQ9XCJPcmRlcnNcIlxuICAgICAgICBsZWZ0SWNvbj17PFNob3BwaW5nQ2FydEljb24gLz59XG4gICAgICAvPlxuXG4gICAgICA8TGlzdFN1YmhlYWRlciBzeD17c2VjdGlvbkhlYWRlclN4fT5DdXN0b21lcnM8L0xpc3RTdWJoZWFkZXI+XG4gICAgICA8UmFNZW51Lkl0ZW1cbiAgICAgICAgdG89XCIvdXNlcnNcIlxuICAgICAgICBwcmltYXJ5VGV4dD1cIlVzZXJzXCJcbiAgICAgICAgbGVmdEljb249ezxQZW9wbGVJY29uIC8+fVxuICAgICAgLz5cbiAgICAgIDxSYU1lbnUuSXRlbVxuICAgICAgICB0bz1cIi9jb21tZW50XCJcbiAgICAgICAgcHJpbWFyeVRleHQ9XCJSZXZpZXdzXCJcbiAgICAgICAgbGVmdEljb249ezxSYXRlUmV2aWV3SWNvbiAvPn1cbiAgICAgIC8+XG5cbiAgICAgIDxMaXN0U3ViaGVhZGVyIHN4PXtzZWN0aW9uSGVhZGVyU3h9PlNldHRpbmdzPC9MaXN0U3ViaGVhZGVyPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL2hvbWVwYWdlXCJcbiAgICAgICAgcHJpbWFyeVRleHQ9XCJIb21lcGFnZVwiXG4gICAgICAgIGxlZnRJY29uPXs8SG9tZUljb24gLz59XG4gICAgICAvPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL3NpdGUtbG9nb1wiXG4gICAgICAgIHByaW1hcnlUZXh0PVwiU2l0ZSBMb2dvXCJcbiAgICAgICAgbGVmdEljb249ezxJbWFnZUljb24gLz59XG4gICAgICAvPlxuICAgICAgPFJhTWVudS5JdGVtXG4gICAgICAgIHRvPVwiL2RlbGl2ZXJ5LWNvc3RcIlxuICAgICAgICBwcmltYXJ5VGV4dD1cIkRlbGl2ZXJ5IENvc3RcIlxuICAgICAgICBsZWZ0SWNvbj17PExvY2FsU2hpcHBpbmdJY29uIC8+fVxuICAgICAgLz5cbiAgICA8L1JhTWVudT5cbiAgPC9Cb3g+XG4pO1xuIl0sImZpbGUiOiIvbW50L2RhdGEvZWNvbW1lcmNlL2Vjb21tZXJjZV9hZG1pbi9zcmMvbGF5b3V0cy9NZW51LnRzeCJ9